#!/bin/bash
# Builds the four Why! iPhone apps on a Mac at GitHub and sends them to TestFlight.
# Run by .github/workflows/testflight.yml after why-ios.zip is unpacked. Needs these repository secrets:
#   ASC_KEY_ID, ASC_ISSUER_ID, ASC_KEY_P8 (the App Store Connect API key) and APPLE_TEAM_ID.
# Optional secret TF_CONTACT (first name, last name, mobile, email): the customer app also goes to the public
#   TestFlight group «Owner» (asc.py beta). A zip with the file BETA_ONLY does only that step, with no build.
# Optional repository variables: WHY_HOST (the address of the pages) and BUNDLE_PREFIX.
set -euo pipefail
cd "$(dirname "$0")"

for v in ASC_KEY_ID ASC_ISSUER_ID ASC_KEY_P8 APPLE_TEAM_ID; do
  if [ -z "${!v:-}" ]; then echo "::error::The secret $v is missing: add it in the repository Settings → Secrets and variables → Actions."; exit 1; fi
done
BUNDLE_PREFIX="${BUNDLE_PREFIX:-com.whyroasteryco}"
WHY_HOST="${WHY_HOST:-whycoffee.duckdns.org}"
BUILD="${GITHUB_RUN_NUMBER:-1}"
mkdir -p "$HOME/.appstoreconnect/private_keys"
KEY="$HOME/.appstoreconnect/private_keys/AuthKey_${ASC_KEY_ID}.p8"
printf '%s\n' "$ASC_KEY_P8" > "$KEY"
chmod 600 "$KEY"
trap 'rm -f "$KEY"' EXIT

# BETA_ONLY in the zip: no build, only the public TestFlight for the newest customer build (asc.py beta)
if [ -f BETA_ONLY ]; then
  ASC_KEY_FILE="$KEY" python3 asc.py beta "$BUNDLE_PREFIX" - 0
  exit $?
fi
SPECS=("WhyCustomer:why:Why!" "WhyOrderDesk:orderdesk:Why! Order Desk" "WhyManagement:management:Why! Management" "WhyDelivery:delivery:Why! Delivery")

# the newest Xcode on this Mac that is not a test version (Apple takes builds from the current Xcode only)
XCODE=$(python3 - <<'EOF'
import glob, re
best = None
for p in glob.glob("/Applications/Xcode_*.app"):
    m = re.fullmatch(r"/Applications/Xcode_(\d+(?:\.\d+)*)\.app", p)
    if m:
        v = tuple(int(x) for x in m.group(1).split("."))
        if best is None or v > best[0]:
            best = (v, p)
print(best[1] if best else "/Applications/Xcode.app")
EOF
)
sudo xcode-select -s "$XCODE"
xcodebuild -version

brew install xcodegen >/dev/null 2>&1 || brew install xcodegen
AUTH=(-allowProvisioningUpdates -authenticationKeyPath "$KEY" -authenticationKeyID "$ASC_KEY_ID" -authenticationKeyIssuerID "$ASC_ISSUER_ID")

# bundle IDs registered, and which apps already exist in App Store Connect
ASC_KEY_FILE="$KEY" python3 asc.py prepare "$BUNDLE_PREFIX" "${SPECS[@]}"

xcodegen generate
cat > export.plist <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>method</key><string>app-store-connect</string>
  <key>destination</key><string>upload</string>
  <key>signingStyle</key><string>automatic</string>
  <key>teamID</key><string>${APPLE_TEAM_ID}</string>
  <key>uploadSymbols</key><true/>
  <key>manageAppVersionAndBuildNumber</key><false/>
</dict></plist>
EOF

failed=0
for s in "${SPECS[@]}"; do
  t="${s%%:*}"
  echo "::group::$t"
  if ! xcodebuild -project Why.xcodeproj -scheme "$t" -configuration Release -destination 'generic/platform=iOS' \
       -archivePath "build/$t.xcarchive" archive CODE_SIGNING_ALLOWED=NO \
       CURRENT_PROJECT_VERSION="$BUILD" DEVELOPMENT_TEAM="$APPLE_TEAM_ID" BUNDLE_PREFIX="$BUNDLE_PREFIX" WHY_HOST="$WHY_HOST" -quiet; then
    echo "::endgroup::"; echo "::error::$t did not build"; failed=1; continue
  fi
  if grep -qx "$t" ready.txt; then
    if xcodebuild -exportArchive -archivePath "build/$t.xcarchive" -exportOptionsPlist export.plist -exportPath "build/$t" "${AUTH[@]}"; then
      echo "::notice::$t (build $BUILD) was sent to TestFlight. Apple processes it in about 10 to 30 minutes."
    else
      echo "::error::$t was built but not sent to TestFlight"; failed=1
    fi
  else
    failed=1
  fi
  echo "::endgroup::"
done
# the customer build also goes to the public TestFlight group, once TF_CONTACT is set (waits for Apple's processing)
if [ -n "${TF_CONTACT:-}" ] && grep -qx WhyCustomer ready.txt; then
  ASC_KEY_FILE="$KEY" python3 asc.py beta "$BUNDLE_PREFIX" "$BUILD" 45 || { echo "::warning::The public TestFlight step did not finish"; }
fi
exit $failed
