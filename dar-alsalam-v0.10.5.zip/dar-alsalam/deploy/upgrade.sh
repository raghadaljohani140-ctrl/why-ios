#!/usr/bin/env bash
# ترقية آمنة لخادم دار السلام المثبّت مسبقاً. نفّذها من الحزمة الجديدة بعد فكّها، بصلاحية root:
#     sudo bash deploy/upgrade.sh
# ما تفعله بالترتيب:
#   1) تفحص التثبيت القائم والحزمة الجديدة (لا تغيّر شيئاً إن كان فيها خلل).
#   2) تأخذ نسخة احتياطية متسقة لقاعدة البيانات وتتأكد من سلامتها، ولقطة لملفات الكود الحالية (للتراجع).
#   3) تثبّت الإصدار الجديد بـ install.sh (لا يمسّ .env ولا القاعدة ولا وحدات systemd الموجودة) ويعيد تشغيل الخدمة.
#   4) تفحص أن الخدمة ترد وأنها تقدّم الإصدار الجديد وأن أعداد الأطباء والفروع والتخصصات والخدمات لم تنقص؛
#      وإن فشل أي فحص تتراجع تلقائياً إلى الكود السابق وتعيد تشغيل الخدمة.
# لا تلمس Caddy ولا أي خدمة أخرى، ولا تحذف شيئاً: اللقطة والنسخة الاحتياطية تبقيان لتحذفهما أنت بعد التأكد.
# متغيرات اختيارية: APP_DIR (يُستنتج من وحدة systemd وإلا /opt/daralsalam)  SVC (اسم الخدمة، الافتراضي daralsalam)
#                   SVC_USER (الافتراضي daralsalam)  DS_UPGRADE_WAIT (ثوانٍ لانتظار الخدمة، الافتراضي 25)
set -Eeuo pipefail

SVC="${SVC:-daralsalam}"
SVC_USER="${SVC_USER:-daralsalam}"
WAIT="${DS_UPGRADE_WAIT:-25}"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PY="$(command -v python3 || true)"
say() { printf '%s\n' "$*"; }
die() { say "خطأ: $*"; exit 1; }

[ -n "$PY" ] || die "python3 غير مثبّت."
case "$WAIT" in ''|*[!0-9]*) die "DS_UPGRADE_WAIT يجب أن يكون رقماً (المعطى: $WAIT)";; esac
[ "$(id -u)" -eq 0 ] || die "نفّذ السكربت بصلاحية root:  sudo bash deploy/upgrade.sh"

if [ -z "${APP_DIR:-}" ]; then
  APP_DIR="$(systemctl show "$SVC" -p WorkingDirectory --value 2>/dev/null || true)"
  APP_DIR="${APP_DIR:-/opt/daralsalam}"
fi

# ---------------------------------------------------------------- 1) فحص
say "== 1/4 فحص التثبيت القائم والحزمة الجديدة"
[ -f "$APP_DIR/.env" ] && [ -f "$APP_DIR/data/clinic.db" ] && [ -f "$APP_DIR/server/app.py" ] ||
  die "لا يوجد تثبيت سابق في $APP_DIR (المتوقع .env وdata/clinic.db). للتثبيت الأول استخدم install.sh وليس هذا السكربت."
[ "$SRC_DIR" != "$APP_DIR" ] || die "شغّل السكربت من مجلد الحزمة المفكوكة لا من مجلد التثبيت."
for f in install.sh deploy/upgrade.sh deploy/backup.sh server/app.py server/manage.py server/schema.py web/config.js web/index.html admin/index.html; do
  [ -f "$SRC_DIR/$f" ] || die "الحزمة ناقصة: $f"
done
for f in install.sh deploy/upgrade.sh deploy/backup.sh; do
  bash -n "$SRC_DIR/$f" || die "خطأ في صياغة $f داخل الحزمة"
done
for f in "$SRC_DIR"/server/*.py; do
  PYTHONDONTWRITEBYTECODE=1 "$PY" -c "import sys; compile(open(sys.argv[1], encoding='utf-8').read(), sys.argv[1], 'exec')" "$f" ||
    die "ملف بايثون لا يُقرأ بهذا الإصدار من بايثون: $f (لم يُغيَّر شيء)"
done

envget() { grep -E "^$1=" "$APP_DIR/.env" | tail -n1 | cut -d= -f2- | tr -d '[:space:]"' || true; }
ver() { sed -n 's/.*version: *"\([^"]*\)".*/\1/p' "$1/web/config.js" 2>/dev/null | head -n1 || true; }
OLD_VER="$(ver "$APP_DIR")"; NEW_VER="$(ver "$SRC_DIR")"
[ -n "$NEW_VER" ] || die "تعذّر قراءة رقم الإصدار من الحزمة (web/config.js)"
EP="$(envget DS_PORT)"; EP="${EP:-8080}"
EH="$(envget DS_HOST)"; EH="${EH:-127.0.0.1}"
# العنوان الذي تستمع عليه الخدمة فعلاً (قد يكون عنوان شبكة docker لا 127.0.0.1)؛ نأخذه من النظام إن توفر ss
if command -v ss >/dev/null 2>&1; then
  BOUND="$(ss -H -ltn "sport = :$EP" 2>/dev/null | awk '{print $4}' | head -n1 | sed 's/:[0-9]*$//' || true)"
  case "$BOUND" in
    ''|*[!0-9.]*) ;;            # فارغ أو ليس عنوان IPv4: نبقي ما في .env
    0.0.0.0) EH="127.0.0.1" ;;
    *) EH="$BOUND" ;;
  esac
fi
[ "$EH" != "0.0.0.0" ] || EH="127.0.0.1"
say "   التثبيت: $APP_DIR · الخدمة: $EH:$EP · الإصدار الحالي: ${OLD_VER:-غير معروف} ← الجديد: $NEW_VER"

# يطبع: dataVersion ثم أعداد الأطباء والفروع والتخصصات والخدمات؛ ويفشل إن لم تردّ الخدمة
probe() {
  "$PY" - "$EH" "$EP" <<'PYEOF'
import json, sys, urllib.request
base = "http://%s:%s" % (sys.argv[1], sys.argv[2])
try:
    op = urllib.request.build_opener(urllib.request.ProxyHandler({}))   # لا وسيط: الفحص محلي دائماً
    health = json.load(op.open(base + "/api/v1/health", timeout=3))
    if not health.get("ok"):
        sys.exit(1)
    d = json.load(op.open(base + "/api/v1/clinic", timeout=5))
except Exception:
    sys.exit(1)
n = lambda k: len(d.get(k) or [])
print(health.get("dataVersion", 0), n("doctors"), n("branches"), n("specialties"), n("services"))
PYEOF
}
# مجموع طلبات الحجز المحفوظة (يُشغَّل بمستخدم الخدمة كي لا تُنشأ ملفات SQLite جانبية بصلاحية root)؛ فارغ إن تعذّر
book_total() {
  sudo -u "$SVC_USER" "$PY" "$APP_DIR/server/manage.py" stats 2>/dev/null | "$PY" -c '
import json, sys
try:
    print(sum(int(v) for v in json.load(sys.stdin)["bookings"].values()))
except Exception:
    pass
' || true
}
served_version() {
  "$PY" - "$EH" "$EP" <<'PYEOF' || true
import re, sys, urllib.request
try:
    op = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    t = op.open("http://%s:%s/app/config.js" % (sys.argv[1], sys.argv[2]), timeout=3).read().decode("utf-8", "replace")
    m = re.search(r'version:\s*"([^"]+)"', t)
    print(m.group(1) if m else "")
except Exception:
    print("")
PYEOF
}
wait_probe() { # ينتظر حتى WAIT ثانية؛ يطبع الناتج أو لا شيء
  local i out=""
  for ((i = 0; i < WAIT; i++)); do
    out="$(probe 2>/dev/null || true)"
    [ -z "$out" ] || break
    sleep 1
  done
  printf '%s' "$out"
}

BEFORE="$(probe 2>/dev/null || true)"
[ -n "$BEFORE" ] || say "   تنبيه: الخدمة لا تردّ الآن على $EH:$EP؛ سأكمل لكن لن أقارن البيانات قبل التحديث وبعده."
BK_BEFORE="$(book_total)"

# ---------------------------------------------------------------- 2) نسخة احتياطية ولقطة
say "== 2/4 نسخة احتياطية للقاعدة ولقطة للكود الحالي"
TS="$(date +%Y%m%d-%H%M%S)"
PREV="${APP_DIR}-prev-$TS"
UNIT_DIR="${UNIT_DIR:-/etc/systemd/system}"
mkdir -p "$PREV/data" "$PREV/units"
chmod 700 "$PREV"
for d in server web admin widget deploy; do
  cp -a "$APP_DIR/$d" "$PREV/$d" || die "تعذّر أخذ لقطة من $APP_DIR/$d (مساحة القرص؟)؛ لم يُغيَّر شيء في التثبيت."
done
cp -f "$APP_DIR/data/seed.json" "$APP_DIR/data/lexicon.json" "$PREV/data/" 2>/dev/null || true
cp -f "$APP_DIR/.env.example" "$PREV/" 2>/dev/null || true
for u in daralsalam.service daralsalam-backup.service daralsalam-backup.timer; do cp -f "$UNIT_DIR/$u" "$PREV/units/" 2>/dev/null || true; done

BK_DIR="$APP_DIR/data/backups"
BK_OUT="$(sudo -u "$SVC_USER" env APP_DIR="$APP_DIR" bash "$APP_DIR/deploy/backup.sh")" ||
  die "فشلت النسخة الاحتياطية للقاعدة؛ لم يُغيَّر شيء في التثبيت (اللقطة: $PREV)."
NEWEST="$(printf '%s\n' "$BK_OUT" | sed -n 's/^[^:]*: *\(.*clinic-[0-9-]*\.db\) *$/\1/p' | tail -n1)"
[ -n "$NEWEST" ] && [ -f "$NEWEST" ] || NEWEST="$(ls -1t "$BK_DIR"/clinic-*.db 2>/dev/null | head -n1 || true)"
[ -n "$NEWEST" ] && [ -s "$NEWEST" ] || die "لم أجد النسخة الاحتياطية بعد إنشائها؛ لم يُغيَّر شيء."
# immutable=1: لا تُنشأ ملفات -wal/-shm بصلاحية root بجانب النسخة
"$PY" - "$NEWEST" <<'PYEOF' || die "النسخة الاحتياطية لا تجتاز فحص سلامة SQLite؛ لم يُغيَّر شيء."
import sqlite3, sys
c = sqlite3.connect("file:%s?mode=ro&immutable=1" % sys.argv[1], uri=True)
sys.exit(0 if c.execute("pragma integrity_check").fetchone()[0] == "ok" else 1)
PYEOF
say "   نسخة القاعدة: $NEWEST ($(wc -c < "$NEWEST") بايت، سليمة)"
say "   لقطة الكود السابق: $PREV"

rollback() {
  trap - ERR INT TERM
  set +e
  say ""
  say "!! $1"
  say "!! تراجع تلقائي إلى الكود السابق من $PREV (قاعدة البيانات لم تُمَسّ)"
  systemctl stop "$SVC" 2>/dev/null || true
  for d in server web admin widget deploy; do
    rm -rf "${APP_DIR:?}/$d"
    cp -a "$PREV/$d" "$APP_DIR/$d"
  done
  cp -f "$PREV/data/"*.json "$APP_DIR/data/" 2>/dev/null || true
  for u in daralsalam.service daralsalam-backup.service daralsalam-backup.timer; do
    [ ! -f "$PREV/units/$u" ] || cp -f "$PREV/units/$u" "$UNIT_DIR/$u"
  done
  systemctl daemon-reload 2>/dev/null || true
  systemctl start "$SVC" || true
  if [ -n "$(wait_probe)" ]; then
    say "   عادت الخدمة تعمل بالإصدار السابق (${OLD_VER:-غير معروف}). أرسل لي ناتج:  journalctl -u $SVC -n 60 --no-pager"
  else
    say "   تحذير: الخدمة لا تردّ بعد التراجع. شغّل:  journalctl -u $SVC -n 60 --no-pager   وأرسل لي الناتج فوراً."
  fi
  exit 1
}

# من هنا أي خطأ غير متوقع أو إيقاف يدوي (Ctrl-C) يعيد الكود السابق تلقائياً
trap 'rollback "خطأ غير متوقع أثناء الترقية (السطر $LINENO)"' ERR
trap 'rollback "أُوقف التنفيذ يدوياً"' INT TERM

# ---------------------------------------------------------------- 3) تثبيت الإصدار الجديد
say "== 3/4 تثبيت الإصدار الجديد وإعادة تشغيل الخدمة (انقطاع لثوانٍ)"
ILOG="$PREV/install.log"
if ! APP_DIR="$APP_DIR" SVC_USER="$SVC_USER" DS_PORT="$EP" KEEP_UNITS=1 UNIT_DIR="$UNIT_DIR" bash "$SRC_DIR/install.sh" >"$ILOG" 2>&1; then
  tail -n 15 "$ILOG" | sed 's/^/   | /' || true
  rollback "فشل install.sh أثناء التثبيت (السجل الكامل: $ILOG)"
fi
grep -h 'أُبقيت النسخة' "$ILOG" | sed 's/^ */   /' || true
say "   نُسخت الملفات الجديدة وأُعيد تشغيل الخدمة (سجل التثبيت: $ILOG)"

# ---------------------------------------------------------------- 4) فحص
say "== 4/4 فحص الصحة والتأكد من بقاء البيانات"
AFTER="$(wait_probe)"
[ -n "$AFTER" ] || rollback "لم تردّ الخدمة الجديدة على $EH:$EP خلال $WAIT ثانية"
SERVED="$(served_version)"
[ "$SERVED" = "$NEW_VER" ] || rollback "الخدمة تقدّم الإصدار «${SERVED:-؟}» بدل «$NEW_VER»"
if [ -n "$BEFORE" ]; then
  read -r _ b_doc b_br b_sp b_sv <<<"$BEFORE"
  read -r _ a_doc a_br a_sp a_sv <<<"$AFTER"
  if [ "$a_doc" -lt "$b_doc" ] || [ "$a_br" -lt "$b_br" ] || [ "$a_sp" -lt "$b_sp" ] || [ "$a_sv" -lt "$b_sv" ]; then
    rollback "نقصت أعداد البيانات (أطباء $b_doc←$a_doc، فروع $b_br←$a_br، تخصصات $b_sp←$a_sp، خدمات $b_sv←$a_sv)"
  fi
  say "   البيانات كما هي: أطباء $a_doc · فروع $a_br · تخصصات $a_sp · خدمات $a_sv"
fi
if [ -n "$BK_BEFORE" ]; then
  BK_AFTER="$(book_total)"
  case "$BK_AFTER" in ''|*[!0-9]*) rollback "تعذّرت قراءة عدد الطلبات بعد التحديث";; esac
  [ "$BK_AFTER" -ge "$BK_BEFORE" ] || rollback "نقص عدد طلبات الحجز المحفوظة ($BK_BEFORE←$BK_AFTER)"
  say "   طلبات الحجز المحفوظة: $BK_AFTER (كانت $BK_BEFORE)"
fi
trap - ERR INT TERM
say "   الخدمة تعمل وتقدّم الإصدار $SERVED على $EH:$EP"
say ""
say "تمت الترقية من ${OLD_VER:-غير معروف} إلى $NEW_VER."
say "• نسخة القاعدة الاحتياطية: $NEWEST"
say "• لقطة الكود السابق (للتراجع اليدوي): $PREV"
say "  تراجع يدوي إن لزم:  systemctl stop $SVC && for d in server web admin widget deploy; do rm -rf $APP_DIR/\$d; cp -a $PREV/\$d $APP_DIR/\$d; done && systemctl start $SVC"
say "• بعد أن تتأكد من سلامة كل شيء يمكنك حذف اللقطة:  rm -rf $PREV   (وانقل نسخة القاعدة خارج الخادم إن أردت الاحتفاظ بها)"
