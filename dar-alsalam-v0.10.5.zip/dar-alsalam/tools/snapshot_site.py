#!/usr/bin/env python3
"""نسخة احتياطية «للقراءة فقط» من المحتوى العام لموقع: طلبات GET فقط، تحترم robots.txt، لا كوكيز ولا نماذج ولا تسجيل دخول.

  python3 tools/snapshot_site.py https://daralsalamclinic.com/ar --out backup/site-snapshot/2026-11-22

المخرجات داخل --out:
  files/<النطاق>/...   الملفات الخام كما نزلت (صفحات HTML وCSS وجافاسكربت وصور وملفات)
  text/...             النص المستخرج من كل صفحة HTML (للمراجعة وتحديث بيانات التطبيق)
  manifest.json        فهرس كل طلب: الرابط، الحالة، النوع، الحجم، sha256، مكان الحفظ، أو سبب التخطي

ما لا تفعله الأداة عمداً: لا تخرج عن النطاق نفسه، لا تتبع روابط الصفحات المحجوبة في robots.txt، لا تنزل أكثر من الحدود المضبوطة،
لا ترسل أي بيانات إلى الموقع غير طلبات GET العادية. هذه نسخة للمحتوى العام وليست بديلاً عن نسخة الاستضافة (الملفات + قاعدة البيانات).
تنبيه: شغّلها فقط على موقع تملكه أو لديك إذن بنسخه.
"""
import argparse
import hashlib
import json
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import urllib.robotparser
from collections import deque
from html.parser import HTMLParser
from pathlib import Path

TOOL = "snapshot_site/1.0"
HTML_TYPES = ("text/html", "application/xhtml+xml")
CSS_URL_RE = re.compile(r"url\(\s*['\"]?([^'\")\s]+)['\"]?\s*\)", re.I)


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


class Links(HTMLParser):
    """يجمع روابط الصفحات (a) وروابط الأصول (img/link/script/source/video/...) من HTML."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.pages, self.assets, self.text, self._skip = [], [], [], 0

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag in ("script", "style", "noscript"):
            self._skip += 1
        if tag in ("br", "p", "div", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6", "section", "article", "header", "footer"):
            self.text.append("\n")
        if tag == "a" and a.get("href"):
            self.pages.append(a["href"])
        if tag in ("img", "script", "source", "video", "audio", "iframe", "embed") and a.get("src"):
            (self.pages if tag == "iframe" else self.assets).append(a["src"])
        if tag == "img" and a.get("srcset"):
            self.assets += [p.strip().split(" ")[0] for p in a["srcset"].split(",") if p.strip()]
        if tag == "video" and a.get("poster"):
            self.assets.append(a["poster"])
        if tag == "link" and a.get("href") and (a.get("rel") or "").lower().split()[:1] in (["stylesheet"], ["icon"], ["shortcut"], ["apple-touch-icon"], ["manifest"], ["preload"]):
            self.assets.append(a["href"])

    def handle_endtag(self, tag):
        if tag in ("script", "style", "noscript") and self._skip:
            self._skip -= 1

    def handle_data(self, data):
        if not self._skip and data.strip():
            self.text.append(data.strip() + " ")


def norm_host(h):
    h = (h or "").lower()
    return h[4:] if h.startswith("www.") else h


def normalize(url):
    u = urllib.parse.urldefrag(url)[0]
    p = urllib.parse.urlsplit(u)
    host = p.hostname.lower() if p.hostname else ""
    port = "" if (p.port in (None, 80, 443)) else ":%d" % p.port
    path = re.sub(r"/{2,}", "/", p.path or "/")
    return urllib.parse.urlunsplit((p.scheme.lower(), host + port, path, p.query, ""))


def safe_component(c):
    c = urllib.parse.unquote(c)
    c = re.sub(r"[^\w.\-+@=,~ ]", "_", c, flags=re.UNICODE).strip(" .")
    if c in ("", ".", ".."):
        c = "_"
    if len(c) > 120:
        c = c[:100] + "-" + hashlib.sha1(c.encode()).hexdigest()[:8]
    return c


def local_path(url, ctype):
    p = urllib.parse.urlsplit(url)
    parts = [safe_component(x) for x in p.path.split("/") if x not in ("",)]
    is_html = any(ctype.startswith(t) for t in HTML_TYPES)
    last = parts[-1] if parts else ""
    if not parts or p.path.endswith("/"):
        parts.append("index.html")
    elif "." not in last:
        parts.append("index.html") if is_html else None
    if p.query:
        stem, dot, ext = parts[-1].rpartition(".")
        tag = "__q-" + hashlib.sha1(p.query.encode()).hexdigest()[:8]
        parts[-1] = (stem + tag + "." + ext) if dot else (parts[-1] + tag)
    return Path(safe_component(p.hostname or "host")).joinpath(*parts)


class Snapshotter:
    def __init__(self, a):
        self.a = a
        self.start = normalize(a.url)
        sp = urllib.parse.urlsplit(self.start)
        self.host = norm_host(sp.hostname)
        self.origin = "%s://%s" % (sp.scheme, sp.netloc)
        self.out = Path(a.out).resolve()
        self.ua = "DarAlsalamSnapshot/1.0 (read-only; GET only)" + (" contact:" + a.contact if a.contact else "")
        self.opener = urllib.request.build_opener(NoRedirect)
        self.rp = urllib.robotparser.RobotFileParser()
        self.delay = a.delay
        self.records, self.seen, self.qvariants, self.bytes_total = [], set(), {}, 0
        self.last_req = 0.0

    # ---------------------------------------------------------------- شبكة
    def _get(self, url, limit):
        wait = self.delay - (time.time() - self.last_req)
        if wait > 0:
            time.sleep(wait)
        self.last_req = time.time()
        req = urllib.request.Request(url, method="GET", headers={"User-Agent": self.ua, "Accept": "*/*", "Accept-Language": "ar,en;q=0.5"})
        try:
            with self.opener.open(req, timeout=self.a.timeout) as r:
                ctype = (r.headers.get("Content-Type") or "").split(";")[0].strip().lower()
                clen = int(r.headers.get("Content-Length") or 0)
                if clen > limit:
                    return {"status": r.status, "ctype": ctype, "skipped": "too_large(%d)" % clen}
                body = r.read(limit + 1)
                if len(body) > limit:
                    return {"status": r.status, "ctype": ctype, "skipped": "too_large"}
                return {"status": r.status, "ctype": ctype, "body": body}
        except urllib.error.HTTPError as e:
            if 300 <= e.code < 400 and e.headers.get("Location"):
                return {"status": e.code, "redirect": urllib.parse.urljoin(url, e.headers["Location"])}
            return {"status": e.code, "ctype": "", "error": "http_%d" % e.code}
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            return {"status": 0, "ctype": "", "error": "network: %s" % getattr(e, "reason", e)}

    def load_robots(self):
        r = self._get(self.origin + "/robots.txt", 512 * 1024)
        if r.get("body") is not None and r["status"] == 200:
            self.rp.parse(r["body"].decode("utf-8", "replace").splitlines())
            cd = self.rp.crawl_delay(self.ua) or self.rp.crawl_delay("*")
            if cd:
                self.delay = max(self.delay, float(cd))
            return "robots.txt مقروء"
        if r["status"] and r["status"] < 500 and "redirect" not in r:
            self.rp.parse([])               # 4xx: لا قيود معلنة (RFC 9309)
            return "robots.txt غير موجود (%d): لا قيود معلنة" % r["status"]
        raise SystemExit("تعذّر قراءة robots.txt (%s). لا أنزّل شيئاً من موقع لا أعرف قيوده." % (r.get("error") or r["status"]))

    def allowed(self, url):
        return self.rp.can_fetch(self.ua, url)

    def same_site(self, url):
        p = urllib.parse.urlsplit(url)
        return p.scheme in ("http", "https") and norm_host(p.hostname) == self.host

    # ---------------------------------------------------------------- حفظ
    def save(self, url, ctype, body):
        rel = local_path(url, ctype)
        dest = (self.out / "files" / rel).resolve()
        if (self.out / "files").resolve() not in dest.parents:
            return None
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(body)
        return str(Path("files") / rel)

    def save_text(self, url, html):
        p = Links()
        try:
            p.feed(html)
        except Exception:  # noqa: BLE001
            return None, p
        txt = re.sub(r"\n\s*\n+", "\n\n", "".join(p.text)).strip()
        rel = local_path(url, "text/html").with_suffix(".txt")
        dest = (self.out / "text" / rel).resolve()
        if (self.out / "text").resolve() not in dest.parents:
            return None, p
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(txt + "\n", encoding="utf-8")
        return str(Path("text") / rel), p

    # ---------------------------------------------------------------- الزحف
    def run(self):
        a = self.a
        self.out.mkdir(parents=True, exist_ok=True)
        t0 = time.strftime("%Y-%m-%dT%H:%M:%S%z")
        note = self.load_robots()
        print("•", note)
        if not self.allowed(self.start):
            raise SystemExit("robots.txt يمنع الصفحة الأولى: " + self.start)
        q = deque([(self.start, 0, "start", "page")])
        pages = 0
        while q and len(self.records) < a.max_files:
            url, depth, frm, kind = q.popleft()
            if url in self.seen:
                continue
            self.seen.add(url)
            rec = {"url": url, "from": frm, "depth": depth, "kind": kind}
            if not self.allowed(url):
                rec["skipped"] = "robots"
                self.records.append(rec)
                continue
            if kind == "page" and pages >= a.max_pages:
                rec["skipped"] = "max_pages"
                self.records.append(rec)
                continue
            path_key = urllib.parse.urlsplit(url).path
            if urllib.parse.urlsplit(url).query:
                n = self.qvariants.get(path_key, 0) + 1
                self.qvariants[path_key] = n
                if n > a.max_query_variants:
                    rec["skipped"] = "too_many_query_variants"
                    self.records.append(rec)
                    continue
            cur, hops, r = url, 0, None
            while hops <= 5:
                r = self._get(cur, a.max_file_bytes)
                if "redirect" in r:
                    nxt = normalize(r["redirect"])
                    rec.setdefault("redirects", []).append({"status": r["status"], "to": nxt})
                    if not self.same_site(nxt) or not self.allowed(nxt):
                        r = {"status": r["status"], "skipped": "redirect_offsite_or_disallowed"}
                        break
                    cur = nxt
                    hops += 1
                    continue
                break
            rec["final_url"] = cur
            rec["status"] = r.get("status")
            for k in ("skipped", "error"):
                if r.get(k):
                    rec[k] = r[k]
            body = r.get("body")
            if body is not None and r["status"] == 200:
                if self.bytes_total + len(body) > a.max_total_bytes:
                    rec["skipped"] = "max_total_bytes"
                else:
                    ctype = r["ctype"]
                    rec.update(content_type=ctype, bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
                    rec["saved"] = self.save(cur, ctype, body)
                    self.bytes_total += len(body)
                    if any(ctype.startswith(t) for t in HTML_TYPES):
                        pages += 1
                        html = body.decode(self._charset(body), "replace")
                        rec["text"], lk = self.save_text(cur, html)
                        for href in lk.pages:
                            self._enqueue(cur, href, depth + 1, "page", q)
                        if a.assets:
                            for href in lk.assets:
                                self._enqueue(cur, href, depth + 1, "asset", q)
                    elif ctype == "text/css" and a.assets:
                        for m in CSS_URL_RE.findall(body.decode("utf-8", "replace")):
                            self._enqueue(cur, m, depth + 1, "asset", q)
            print("  [%s] %s" % (rec.get("status"), url[:110]))
            self.records.append(rec)
        manifest = {"tool": TOOL, "start_url": self.start, "started_at": t0, "finished_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                    "user_agent": self.ua, "robots": note, "limits": {k: getattr(a, k) for k in ("max_pages", "max_files", "max_depth", "max_file_bytes", "max_total_bytes", "max_query_variants", "delay")},
                    "stats": {"records": len(self.records), "saved": sum(1 for r in self.records if r.get("saved")), "pages": pages, "bytes": self.bytes_total,
                              "skipped": sum(1 for r in self.records if r.get("skipped")), "errors": sum(1 for r in self.records if r.get("error"))},
                    "files": self.records}
        (self.out / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")
        s = manifest["stats"]
        print("تم: %d طلب · %d ملفاً محفوظاً · %d صفحة · %.1f MB · تخطّي %d · أخطاء %d  →  %s" % (s["records"], s["saved"], s["pages"], s["bytes"] / 1048576, s["skipped"], s["errors"], self.out))
        return 0

    @staticmethod
    def _charset(body):
        m = re.search(rb'charset=["\']?([\w-]+)', body[:2048], re.I)
        try:
            enc = (m.group(1).decode() if m else "utf-8")
            "".encode(enc)
            return enc
        except LookupError:
            return "utf-8"

    def _enqueue(self, base, href, depth, kind, q):
        if not href or depth > self.a.max_depth:
            return
        href = href.strip()
        if href.startswith(("#", "mailto:", "tel:", "javascript:", "data:", "sms:", "whatsapp:")):
            return
        u = normalize(urllib.parse.urljoin(base, href))
        if self.same_site(u) and u not in self.seen:
            q.append((u, depth, base, kind))


def main(argv=None):
    ap = argparse.ArgumentParser(description="نسخة احتياطية للقراءة فقط من المحتوى العام لموقع")
    ap.add_argument("url")
    ap.add_argument("--out", required=True)
    ap.add_argument("--max-pages", type=int, default=300)
    ap.add_argument("--max-files", type=int, default=3000)
    ap.add_argument("--max-depth", type=int, default=6)
    ap.add_argument("--max-file-bytes", type=int, default=25 * 1024 * 1024)
    ap.add_argument("--max-total-bytes", type=int, default=400 * 1024 * 1024)
    ap.add_argument("--max-query-variants", type=int, default=5, help="أقصى عدد روابط بمعاملات استعلام مختلفة لنفس المسار (لتجنّب الدوران اللانهائي)")
    ap.add_argument("--delay", type=float, default=1.0, help="ثوانٍ بين الطلبات (مجاملة للخادم)")
    ap.add_argument("--timeout", type=float, default=20)
    ap.add_argument("--no-assets", dest="assets", action="store_false", help="لا تنزّل الصور وCSS وJS")
    ap.add_argument("--contact", default="", help="بريد اختياري يُضاف إلى User-Agent ليعرف صاحب الموقع من يزحف")
    a = ap.parse_args(argv)
    if not re.match(r"^https?://", a.url):
        sys.exit("الرابط يجب أن يبدأ بـ http:// أو https://")
    return Snapshotter(a).run()


if __name__ == "__main__":
    sys.exit(main())
