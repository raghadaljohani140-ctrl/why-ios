/* اختبار «قمر والمواعيد الفعلية» (0.10.5) بمتصفح حقيقي وخادم مؤقت (:8094) لا يمسّ أي خادم آخر:
     دوام الأطباء يُضبط بأمر الإدارة الحقيقي `manage.py sched-standard --yes` ← المراجع يسأل قمر «موعد أسنان بكرة الصبح»
     ← يظهر أزرار مواعيد فعلية ← يضغط أحدها فتُفتح صفحة الحجز والطبيب واليوم والوقت معبّأة ← يكتب بياناته ويؤكد
     ← الموعد يُحجز مؤكداً في الخادم ← لا يُقترح ثانيةً ← رابط موعد لم يعد متاحاً يُنبَّه صاحبه ← سؤال «أي عيادة؟» بأزرار.
   NODE_PATH=<playwright> node tools/e2e_qamar_slots.js     بيانات تجريبية فقط. اللقطات في qa/shots/q*.png */
const { chromium } = require('playwright');
const { spawn, execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const SHOTS = path.join(ROOT, 'qa', 'shots');
fs.mkdirSync(SHOTS, { recursive: true });
const PW = 'devpass-12345';
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) { pass++; console.log('PASS', m); } else { fail++; console.log('FAIL', m); } };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function http(base, method, p, body, token) {
  const h = { Accept: 'application/json' };
  if (body !== undefined) h['Content-Type'] = 'application/json';
  if (token) h.Authorization = 'Bearer ' + token;
  const r = await fetch(base + p, { method, headers: h, body: body === undefined ? undefined : JSON.stringify(body) });
  return { status: r.status, body: await r.json().catch(() => ({})) };
}
const mins = (t) => Number(t.slice(0, 2)) * 60 + Number(t.slice(3, 5));

(async () => {
  const dir = '/tmp/ds-qslots';
  execSync('rm -rf ' + dir + ' && mkdir -p ' + dir);
  const env = Object.assign({}, process.env, { DS_DB: dir + '/clinic.db', DS_PORT: '8094', DS_QUIET: '1' });
  execSync('python3 ' + ROOT + '/server/manage.py init --password ' + PW, { env, stdio: 'ignore' });
  const base = 'http://127.0.0.1:8094';
  const cli = (args) => execSync('python3 ' + ROOT + '/server/manage.py ' + args, { env }).toString();

  const preview = cli('sched-standard');
  ok(/معاينة فقط/.test(preview) && /الطبيب العام \(5\)/.test(preview), 'أمر الدوام: المعاينة تصف الخطة ولا تغيّر شيئاً');
  const applied = cli('sched-standard --yes');
  ok(/تم ضبط الدوام لـ 27 طبيباً/.test(applied) && /نسخة احتياطية قبل التغيير/.test(applied), 'أمر الدوام: تطبيق + نسخة احتياطية: ' + applied.split('\n').slice(-3).join(' | '));
  ok(fs.readdirSync(dir + '/backups').some((f) => /^before-hours-/.test(f)), 'ملف النسخة الاحتياطية موجود');

  const proc = spawn('python3', [ROOT + '/server/app.py'], { env, stdio: 'ignore' });
  for (let i = 0; i < 40; i++) { try { const r = await fetch(base + '/api/v1/health'); if (r.ok) break; } catch (e) { /* انتظر */ } await sleep(300); }
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const errors = [];
  const watch = (page, tag) => {
    page.on('pageerror', (e) => errors.push(tag + ' pageerror: ' + e.message));
    page.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errors.push(tag + ' console: ' + m.text()); });
  };

  try {
    const AT = (await http(base, 'POST', '/api/admin/login', { password: PW })).body.token;
    const adm = (m, p, b) => http(base, m, '/api/admin' + p, b, AT);
    const ds = (await http(base, 'GET', '/api/v1/clinic')).body;
    const dental = ds.doctors.filter((d) => (d.specialtyIds || []).includes('dental')).map((d) => d.id);
    ok(ds.meta.scheduled.length === 27 && dental.length === 3, 'كل الأطباء (27) صاروا قابلين للحجز بموعد');

    /* الإدارة تفتح جدول طبيب عام (24 ساعة) وتعرض 23:59 ثم تحفظه كما هو */
    const gp = ds.doctors.find((d) => (d.specialtyIds || []).includes('general')).id;
    const g = (await adm('GET', '/schedules/' + gp)).body;
    ok(g.rows.length === 7 && g.rows.every((r) => r.start === '00:00' && r.end === '24:00'), 'الطبيب العام: 24 ساعة طوال الأسبوع في الخادم');
    const actx = await browser.newContext({ viewport: { width: 1100, height: 860 }, locale: 'ar-SA', timezoneId: 'Asia/Riyadh' }), ap = await actx.newPage(); watch(ap, 'admin');
    await ap.goto(base + '/admin/', { waitUntil: 'networkidle' });
    await ap.fill('#pw', PW); await ap.click('button[type=submit]'); await ap.waitForSelector('#nav', { timeout: 8000 });
    await ap.evaluate((id) => { location.hash = '#/sched/' + id; }, gp); await ap.waitForSelector('#sc-form', { timeout: 8000 }); await sleep(400);
    const endVals = await ap.locator('#sc-week [data-w="end"]').evaluateAll((els) => els.map((e) => e.value));
    ok(endVals.length === 7 && endVals.every((v) => v === '23:59'), 'محرر الإدارة يعرض نهاية الدوام 24 ساعة كـ 23:59 (لا حقل فارغ)');
    ap.on('dialog', (d) => d.accept());
    await ap.click('#sc-save'); await sleep(1000);
    const g2 = (await adm('GET', '/schedules/' + gp)).body;
    ok(g2.rows.length === 7 && g2.rows.every((r) => r.end === '24:00'), 'حفظه من المحرر يُبقي «حتى منتصف الليل» كما هي');

    /* =============== المراجع مع قمر =============== */
    const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, locale: 'ar-SA', timezoneId: 'Asia/Riyadh' });
    const page = await ctx.newPage(); watch(page, 'app');
    await page.goto(base + '/app/', { waitUntil: 'networkidle' });
    await page.waitForSelector('#view .hbn', { timeout: 8000 }); await sleep(600);
    ok(await page.evaluate(() => DS.sched.any()), 'التطبيق يعرف أن هناك أطباء بمواعيد');
    await page.evaluate(() => document.querySelector('.fab').click());
    await page.waitForSelector('.sheet .m.bot', { timeout: 4000 });
    const ask = async (q) => {
      const before = await page.locator('.sheet .m.bot:not(.typing)').count();
      await page.fill('#qin', q);
      await page.locator('.sheet .send').click();
      await page.waitForFunction((n) => document.querySelectorAll('.sheet .m.bot:not(.typing)').length > n, before, { timeout: 15000 });
      await sleep(250);
      return page.locator('.sheet .m.bot:not(.typing)').last();
    };
    const hrefs = async (msg) => msg.locator('.act.slot').evaluateAll((els) => els.map((e) => ({ href: e.getAttribute('href'), text: e.innerText.trim() })));
    const parse = (h) => { const q = new URLSearchParams(h.split('?')[1]); return { dr: q.get('dr'), br: q.get('br'), day: q.get('day'), t: q.get('t'), sp: q.get('sp') }; };

    let m = await ask('ابي موعد اسنان بكرة الصبح');
    const slots = await hrefs(m);
    const txt = await m.innerText();
    ok(slots.length >= 1 && slots.length <= 4, 'قمر يعرض أزرار مواعيد فعلية (' + slots.length + ')');
    ok(/أقرب المواعيد المتاحة غداً صباحاً فعلياً/.test(txt) && /تأكيد الحجز/.test(txt), 'الجملة تشرح الأزرار وتوضح أن التأكيد عند «تأكيد الحجز»');
    ok(!/تم الحجز|حجزت لك|تم تأكيد/.test(txt), 'قمر لا يدّعي أنه حجز');
    const parsed = slots.map((s) => parse(s.href));
    ok(parsed.every((p) => dental.includes(p.dr) && p.t && mins(p.t) < 720 && /^\d{4}-\d{2}-\d{2}$/.test(p.day) && p.br === 'quba'), 'كل زر: طبيب أسنان، صباحاً، بتاريخ ووقت وفرع');
    ok(await m.locator('.act.book', { hasText: 'عرض كل المواعيد' }).count() === 1, 'وبجانبها «عرض كل المواعيد»');
    ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1), 'لا تمرير أفقي');
    await sleep(300); await page.screenshot({ path: path.join(SHOTS, 'q01-qamar-slots.png') });

    const pick = slots[0], pp = parse(pick.href);
    await m.locator('.act.slot').first().click(); await sleep(600);
    const hash = await page.evaluate(() => location.hash);
    ok(hash.startsWith('#/book') && hash.includes('day=' + pp.day) && hash.includes('dr=' + pp.dr), 'الزر يفتح صفحة الحجز برابط فيه الطبيب واليوم والوقت');
    ok(await page.locator('.sheet').count() === 0, 'ونافذة قمر تُغلق');
    await page.waitForSelector('.sl-pick', { timeout: 10000 });
    const pickTxt = await page.locator('.sl-pick').innerText();
    ok(/رتّبه لك قمر/.test(pickTxt), 'صفحة الحجز تُظهر الموعد المختار وتقول إن قمر رتّبه: ' + pickTxt.replace(/\s+/g, ' ').slice(0, 90));
    ok(await page.inputValue('#f-dr') === pp.dr && await page.inputValue('#f-br') === 'quba', 'الطبيب والفرع معبّآن');
    ok(await page.locator('.sl-t.on').count() === 1 && (await page.locator('.sl-t.on').getAttribute('data-start')) === pp.t, 'خانة الوقت المختارة هي نفسها التي اقترحها قمر (' + pp.t + ')');
    await sleep(500); await page.screenshot({ path: path.join(SHOTS, 'q02-book-prefilled.png') });
    ok(await page.locator('#f-submit').isEnabled() && !(await page.locator('#f-consent').isChecked()), 'لم تُؤكَّد الموافقة تلقائياً: المراجع هو من يوافق ويؤكد');

    const before = (await adm('GET', '/bookings')).body.bookings.length;
    await page.fill('#f-name', 'مراجع اختبار قمر'); await page.fill('#f-phone', '0565557041'); await page.locator('#f-consent').check();
    ok((await adm('GET', '/bookings')).body.bookings.length === before, 'قبل الضغط على «تأكيد الحجز» لم يُنشأ أي حجز');
    await page.click('#f-submit'); await page.waitForSelector('.okmark', { timeout: 10000 });
    ok(/تم تأكيد موعدك/.test(await page.locator('#bkroot').innerText()), 'عند «تأكيد الحجز» يتأكد الموعد');
    const bid = (await page.locator('.bk-id').innerText()).trim();
    const bk = (await adm('GET', '/bookings')).body.bookings.find((b) => b.id === bid);
    ok(bk && bk.status === 'confirmed' && bk.doctor_id === pp.dr && bk.date === pp.day && bk.slot_start === mins(pp.t), 'الخادم: موعد مؤكد بالطبيب واليوم والوقت نفسها التي اقترحها قمر');
    await sleep(300); await page.screenshot({ path: path.join(SHOTS, 'q03-booked.png') });

    /* الموعد المحجوز لا يُقترح ثانيةً */
    await page.evaluate(() => { location.hash = '#/'; }); await sleep(500);
    await page.evaluate(() => document.querySelector('.fab').click()); await page.waitForSelector('.sheet .m.bot', { timeout: 4000 });
    m = await ask('ابي موعد اسنان بكرة الصبح');
    const again = (await hrefs(m)).map((s) => parse(s.href));
    ok(again.length >= 1 && !again.some((p) => p.dr === pp.dr && p.day === pp.day && p.t === pp.t), 'الموعد الذي حُجز لا يظهر في اقتراحات قمر بعد ذلك');

    /* رابط لموعد لم يعد متاحاً: تنبيه صريح وبلا اختيار */
    await page.evaluate((a) => { location.hash = '#/book?dr=' + a.dr + '&br=quba&day=' + a.day + '&t=' + encodeURIComponent(a.t); }, pp);
    await page.waitForSelector('#bk-slots .alert.warn', { timeout: 10000 });
    ok(/لم يعد متاحاً/.test(await page.locator('#bk-slots .alert.warn').innerText()) && await page.locator('.sl-pick').count() === 0, 'رابط موعد صار محجوزاً: تنبيه «لم يعد متاحاً» وبلا موعد مختار');
    await page.evaluate(() => { location.hash = '#/book?dr=' + 'x' + '&day=bad&t=zz'; }); await sleep(400);
    ok(await page.locator('#f-sel').count() === 1, 'رابط بقيم مشوّهة لا يكسر الصفحة');

    /* طبيب عام ليلاً (24 ساعة) */
    await page.evaluate(() => { location.hash = '#/'; }); await sleep(400);
    await page.evaluate(() => document.querySelector('.fab').click()); await page.waitForSelector('.sheet .m.bot', { timeout: 4000 });
    m = await ask('ابغى موعد عند طبيب عام الليلة');
    const gps = (await hrefs(m)).map((s) => parse(s.href));
    ok(gps.length >= 1 && gps.every((p) => mins(p.t) >= 18 * 60 || p.day > new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Riyadh' })), 'طبيب عام «الليلة»: مواعيد مسائية (أو أقرب متاح إن انتهى اليوم)');

    /* «احجز لي موعد» بلا عيادة (محادثة جديدة بلا سياق): سؤال بأزرار */
    const ctx2 = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, locale: 'ar-SA', timezoneId: 'Asia/Riyadh' });
    const pg2 = await ctx2.newPage(); watch(pg2, 'app2');
    await pg2.goto(base + '/app/', { waitUntil: 'networkidle' }); await pg2.waitForSelector('#view .hbn', { timeout: 8000 }); await sleep(500);
    await pg2.evaluate(() => document.querySelector('.fab').click()); await pg2.waitForSelector('.sheet .m.bot', { timeout: 4000 });
    const ask2 = async (q) => {
      const before = await pg2.locator('.sheet .m.bot:not(.typing)').count();
      await pg2.fill('#qin', q); await pg2.locator('.sheet .send').click();
      await pg2.waitForFunction((n) => document.querySelectorAll('.sheet .m.bot:not(.typing)').length > n, before, { timeout: 15000 });
      await sleep(250);
      return pg2.locator('.sheet .m.bot:not(.typing)').last();
    };
    m = await ask2('احجز لي موعد');
    ok(/أي عيادة/.test(await m.innerText()) && await m.locator('.act.slot').count() === 0, 'بلا تخصص ولا سياق: يسأل «أي عيادة؟»');
    const chips = await pg2.locator('.sheet .qr button').allInnerTexts();
    ok(chips.includes('موعد الأسنان') && chips.includes('موعد الأطفال') && chips.length <= 6, 'ويعرض أزرار العيادات التي لها مواعيد: ' + chips.join('، '));
    await pg2.locator('.sheet .qr button', { hasText: 'موعد الأسنان' }).click();
    await pg2.waitForSelector('.sheet .m.bot:not(.typing) .act.slot', { timeout: 15000 }); await sleep(300);
    ok(await pg2.locator('.sheet .m.bot').last().locator('.act.slot').count() >= 1, 'الضغط على زر العيادة يعرض مواعيدها');
    await pg2.screenshot({ path: path.join(SHOTS, 'q04-qamar-clinic-chips.png') });
    await ctx2.close();

    /* سؤال عادي لا يتغير */
    m = await ask('وين الفروع؟');
    ok(await m.locator('.act.slot').count() === 0 && /قباء/.test(await m.innerText()), 'الأسئلة العادية كما هي بلا أزرار مواعيد');

    /* بلا إنترنت: يرجع للرد المحلي بلا انهيار */
    await ctx.setOffline(true);
    m = await ask('ابي موعد اسنان بكرة الصبح');
    ok(await m.locator('.act.slot').count() === 0 && await m.locator('.act.book').count() >= 1, 'بلا إنترنت: رد محلي بزر «طلب الحجز» (لا مواعيد مخترعة)');
    await ctx.setOffline(false);

    ok(errors.length === 0, 'لا أخطاء في وحدة التحكم' + (errors.length ? ': ' + errors.slice(0, 6).join(' | ') : ''));
  } catch (e) {
    fail++; console.log('CRASH', e && e.stack ? e.stack.split('\n').slice(0, 6).join('\n') : e);
    if (errors.length) console.log('أخطاء المتصفح:', errors.slice(0, 8).join(' | '));
  } finally {
    await browser.close();
    proc.kill();
  }
  console.log('\nالنتيجة: ' + pass + ' ناجح، ' + fail + ' فاشل');
  process.exit(fail ? 1 : 0);
})();
