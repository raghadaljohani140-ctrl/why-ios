/* يولّد كل أيقونات التطبيق وصورة شاشة الإطلاق (PNG) وأيقونة SVG من شعار المجمع الرسمي المتجه.
   التشغيل:  NODE_PATH=<مجلد node_modules العام> node tools/make_icons.js
   المصدر: web/img/mark-white.svg (الشارة البيضاء) وtools/brand/mark-arches.svg (القوسان بألوانهما)، وكلاهما يُولَّد من
   tools/brand/logo-source.png بالأمر: python3 tools/brand/build_brand.py
   لا تعدّل الصور الناتجة يدوياً؛ غيّر هذا الملف أو الشعار المصدر وأعد التشغيل. */
const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const WEB = path.join(ROOT, 'web', 'img');
const ASSETS = path.join(ROOT, 'mobile', 'assets');
const BRAND = path.join(__dirname, 'brand');
fs.mkdirSync(WEB, { recursive: true });
fs.mkdirSync(ASSETS, { recursive: true });

const inner = (file) => fs.readFileSync(file, 'utf8').replace(/^[\s\S]*?<svg[^>]*>/, '').replace(/<\/svg>\s*$/, '');
const WHITE = inner(path.join(WEB, 'mark-white.svg'));
const ARCHES = inner(path.join(BRAND, 'mark-arches.svg'));
const MW = 703, MH = 549;                         // أبعاد الشارة في ملفاتها

/* تدرّج الخلفية من لوني الشعار نفسيهما (الأزرق العميق ← السماوي) */
const G0 = '#00539F', G1 = '#0396C4';

/* bg: 'gradient' | 'white' | 'none'؛ radius: نصف قطر الزوايا؛ markW: عرض الشارة كنسبة من عرض الإطار؛ dy: إزاحة رأسية كنسبة */
function svg(size, o) {
  const c = size, w = c * o.markW, s = w / MW, h = MH * s;
  const x = (c - w) / 2, y = (c - h) / 2 + (o.dy || 0) * c;
  const back = o.bg === 'gradient' ? '<rect width="' + c + '" height="' + c + '" rx="' + (o.radius || 0) + '" fill="url(#bg)"/>'
    : o.bg === 'white' ? '<rect width="' + c + '" height="' + c + '" fill="#fff"/>' : '';
  return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + c + ' ' + c + '" width="' + c + '" height="' + c + '">' +
    '<defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="' + G0 + '"/><stop offset="1" stop-color="' + G1 + '"/></linearGradient></defs>' +
    back + '<g transform="translate(' + x.toFixed(2) + ' ' + y.toFixed(2) + ') scale(' + s.toFixed(5) + ')">' + (o.mark || WHITE) + '</g></svg>';
}
async function out(file, size, o, opaque) {
  let img = sharp(Buffer.from(svg(size, o)), { density: 72 });
  if (opaque) img = img.flatten({ background: '#ffffff' });          // متجر آبل: بلا قناة شفافية
  await img.png({ compressionLevel: 9 }).toFile(file);
  const st = fs.statSync(file);
  console.log('✓', path.relative(ROOT, file), size + 'x' + size, Math.round(st.size / 1024) + 'KB');
}

(async () => {
  /* أيقونة SVG (المتصفح وشريط التبويب في لوحة الإدارة وشاشة تسجيل الدخول) */
  fs.writeFileSync(path.join(WEB, 'icon.svg'), svg(512, { bg: 'gradient', radius: 112, markW: 0.64 }).replace(/ width="512" height="512"/, ''));
  console.log('✓ web/img/icon.svg');

  await out(path.join(WEB, 'icon-192.png'), 192, { bg: 'gradient', radius: 43, markW: 0.64 });
  await out(path.join(WEB, 'icon-512.png'), 512, { bg: 'gradient', radius: 112, markW: 0.64 });
  await out(path.join(WEB, 'icon-180.png'), 180, { bg: 'gradient', markW: 0.64 }, true);                 // apple-touch-icon (يقصّه iOS بنفسه)
  await out(path.join(WEB, 'icon-maskable-512.png'), 512, { bg: 'gradient', markW: 0.5 }, true);          // المنطقة الآمنة للأيقونات القابلة للقص
  await out(path.join(ASSETS, 'icon-only.png'), 1024, { bg: 'gradient', markW: 0.64 }, true);             // أيقونة المتجر 1024
  await out(path.join(ASSETS, 'icon-foreground.png'), 1024, { bg: 'none', markW: 0.5 });                  // مقدّمة أيقونة أندرويد التكيفية (شفافة)
  await out(path.join(ASSETS, 'icon-background.png'), 1024, { bg: 'gradient', markW: 0.0001 }, true);     // خلفية أيقونة أندرويد التكيفية
  /* شاشة الإطلاق الأصلية: خلفية بيضاء + القوسان فقط. أول إطار في شاشة التطبيق المتحركة هو نفسه، ثم يُرسم خط النبض */
  await out(path.join(ASSETS, 'splash.png'), 2732, { bg: 'white', markW: 0.25, mark: ARCHES }, true);
  await out(path.join(ASSETS, 'splash-dark.png'), 2732, { bg: 'white', markW: 0.25, mark: ARCHES }, true);   // التطبيق فاتح اللون دائماً فلا نغيّر الخلفية في الوضع الداكن
})().catch((e) => { console.error(e); process.exit(1); });
