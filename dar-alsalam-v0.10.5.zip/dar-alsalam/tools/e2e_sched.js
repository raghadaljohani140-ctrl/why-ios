/* اختبار «المواعيد» (0.10.0) بمتصفحات حقيقية وخادمين مؤقتين (لا يمسّ أي خادم آخر):
     الخادم A (:8092): رمز الدخول عبر مزوّد «test» + دفع «test»  ← المسار الكامل
       الإدارة تضبط ساعات الطبيب والسياسة ولوحات «استكشف» ← المراجع يرى الشريط وقسم «استكشف» منفصلين ويحجز موعداً
       بالتسجيل عند «تأكيد الحجز» (يعود لحجزه دون أن يضيع شيء) ← سباق على موعد واحد ← الاستقبال يراه ← الطبيب يستدعيه
       ← إلغاء المراجع وقاعدة مهلة الإلغاء ← الدفع المسبق التجريبي ← طلب حجز عادي لطبيب بلا جدول.
     الخادم B (:8093): كما في الإنتاج الآن (بلا SMS وبلا دفع) ← الحجز بالجهاز يعمل، والدفع المسبق مقفل.
   NODE_PATH=<playwright> node tools/e2e_sched.js     بيانات تجريبية فقط. اللقطات في qa/shots/s*.png */
const { chromium } = require('playwright');
const { spawn, execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const SHOTS = path.join(ROOT, 'qa', 'shots');
fs.mkdirSync(SHOTS, { recursive: true });
const PW = 'devpass-12345';
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) { pass++; console.log('PASS', m); } else { fail++; console.log('FAIL', m); } };
const skip = (m) => console.log('SKIP', m);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function startServer(name, port, extra) {
  const dir = '/tmp/ds-sched-' + name;
  execSync('rm -rf ' + dir + ' && mkdir -p ' + dir);
  const env = Object.assign({}, process.env, { DS_DB: dir + '/clinic.db', DS_PORT: String(port), DS_QUIET: '1' }, extra || {});
  execSync('python3 ' + ROOT + '/server/manage.py init --password ' + PW, { env, stdio: 'ignore' });
  const proc = spawn('python3', [ROOT + '/server/app.py'], { env, stdio: 'ignore' });
  const base = 'http://127.0.0.1:' + port;
  for (let i = 0; i < 40; i++) { try { const r = await fetch(base + '/api/v1/health'); if (r.ok) break; } catch (e) { /* انتظر */ } await sleep(300); }
  return { proc, base, dir };
}
async function http(base, method, p, body, token) {
  const h = { Accept: 'application/json' };
  if (body !== undefined) h['Content-Type'] = 'application/json';
  if (token) h.Authorization = 'Bearer ' + token;
  const r = await fetch(base + p, { method, headers: h, body: body === undefined ? undefined : JSON.stringify(body) });
  return { status: r.status, body: await r.json().catch(() => ({})) };
}
const riyadhToday = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Riyadh' });
const riyadhMin = () => { const p = new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Riyadh', hour: '2-digit', minute: '2-digit', hour12: false }).formatToParts(new Date()); return Number(p.find((x) => x.type === 'hour').value) * 60 + Number(p.find((x) => x.type === 'minute').value); };

(async () => {
  const A = await startServer('a', 8092, { DS_SMS_PROVIDER: 'test', DS_PAY_PROVIDER: 'test' });
  const B = await startServer('b', 8093, {});
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const errors = [];
  const watch = (page, tag) => {
    page.on('pageerror', (e) => errors.push(tag + ' pageerror: ' + e.message));
    page.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errors.push(tag + ' console: ' + m.text()); });
  };
  const desk = () => browser.newContext({ viewport: { width: 1100, height: 860 }, locale: 'ar-SA', timezoneId: 'Asia/Riyadh' });
  const phone = () => browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, locale: 'ar-SA', timezoneId: 'Asia/Riyadh' });
  const shot = async (page, n, full) => { await sleep(350); await page.screenshot({ path: path.join(SHOTS, n + '.png'), fullPage: !!full }); };
  const shotTall = async (page, n, h) => { const v = page.viewportSize(); await page.setViewportSize({ width: v.width, height: h }); await sleep(500); await page.screenshot({ path: path.join(SHOTS, n + '.png') }); await page.setViewportSize(v); await sleep(250); };
  const go = async (page, h) => { await page.evaluate((x) => { location.hash = x; }, h); await sleep(450); };
  const smsCode = (dir) => { const l = fs.readFileSync(dir + '/sms-test.log', 'utf8').trim().split('\n').pop(); return JSON.parse(l).text.match(/(\d{6})/)[1]; };

  try {
    /* =============== 0) التجهيز على الخادم A =============== */
    const aLog = await http(A.base, 'POST', '/api/admin/login', { password: PW });
    const AT = aLog.body.token;
    const adm = (m, p, b) => http(A.base, m, '/api/admin' + p, b, AT);
    const pubA = (m, p, b, t) => http(A.base, m, '/api/v1' + p, b, t);
    const ds0 = (await pubA('GET', '/clinic')).body;
    const DOC = ds0.doctors.find((d) => (d.specialtyIds || []).length), DOC2 = ds0.doctors.filter((d) => d.id !== DOC.id && (d.specialtyIds || []).length)[0];
    const BR = 'quba';
    ok(!!DOC && !!DOC2 && ds0.branches.some((b) => b.id === BR), 'طبيبان وفرع قباء للاختبار: ' + DOC.name + ' / ' + DOC2.name);
    const TMP = 'Temp-pass-2468-x', RPW = 'Sched-Reception-2026', DPW = 'Sched-Doctor-2026';
    ok((await adm('POST', '/staff', { username: 'sc.rec', name: 'منى الاستقبال', role: 'reception', branchId: BR, password: TMP })).status === 201, 'حساب استقبال لقباء');
    ok((await adm('POST', '/staff', { username: 'sc.doc', name: 'حساب الطبيب', role: 'doctor', branchId: '', password: TMP, doctorId: DOC.id })).status === 201, 'حساب طبيب مربوط بسجل الطبيب');

    /* =============== 1) الإدارة (واجهة حقيقية): ساعات الطبيب + السياسة =============== */
    const actx = await desk(), ap = await actx.newPage(); watch(ap, 'admin');
    ap.on('dialog', (d) => d.accept());
    await ap.goto(A.base + '/admin/', { waitUntil: 'networkidle' });
    await ap.fill('#pw', PW); await ap.click('button[type=submit]'); await ap.waitForSelector('#nav', { timeout: 8000 });
    ok(await ap.locator('#nav a[data-r="sched"]').count() === 1, 'قائمة الإدارة فيها «المواعيد وساعات العمل»');
    await go(ap, '#/sched'); await ap.waitForSelector('#sp-form');
    ok(await ap.locator('#sp-pre').isEnabled(), 'مع مزوّد دفع تجريبي: خيار الدفع المسبق متاح (وتنبيه أنه وهمي)');
    ok(/وهمية|تجريبي/.test(await ap.locator('#sp-form').innerText()), 'تنبيه صريح أن بوابة الدفع تجريبية');
    await shotTall(ap, 's01-admin-sched', 1250);                                              // اللقطة بالقيم الافتراضية قبل أي تعديل
    await ap.fill('[data-k="horizonDays"]', '7'); await ap.fill('[data-k="minNoticeMin"]', '0'); await ap.fill('[data-k="cancelBeforeH"]', '0'); await ap.fill('[data-k="maxActive"]', '3');
    await ap.click('#sp-form button[type=submit]'); await sleep(700);
    ok((await adm('GET', '/schedules')).body.policy.horizonDays === 7, 'سياسة الحجز تُحفظ من الواجهة (7 أيام، بلا مهلة، إلغاء حتى لحظة الموعد)');

    const openDoc = async (id) => { await go(ap, '#/sched/' + id); await ap.waitForSelector('#sc-form'); };
    await openDoc(DOC.id);
    for (const wd of [5, 6]) await ap.locator('#qf-days input[value="' + wd + '"]').check();      // كل أيام الأسبوع (يضمن وجود مواعيد اليوم)
    await ap.selectOption('#qf-win [data-w="branchId"]', BR);
    await ap.fill('#qf-win [data-w="start"]', '00:00'); await ap.fill('#qf-win [data-w="end"]', '23:30'); await ap.selectOption('#qf-win [data-w="slot"]', '30');
    await ap.click('[data-a="sc-quick"]'); await sleep(250);
    ok(await ap.locator('.sc-day .sc-win').count() === 7, 'تعبئة سريعة: فترة لكل يوم من الأسبوع');
    await ap.click('#sc-save'); await sleep(800);
    const st1 = (await adm('GET', '/schedules/' + DOC.id)).body;
    ok(st1.rows.length === 7 && st1.rows.every((r) => r.branchId === BR && r.slot === 30), 'ساعات الطبيب محفوظة في الخادم (قباء، 30 دقيقة)');
    ok((await pubA('GET', '/clinic')).body.meta.scheduled.includes(DOC.id), 'الطبيب صار «قابلاً للحجز بموعد» في البيانات العامة');
    ok((await pubA('GET', '/clinic')).body.meta.scheduled.length === 1, 'الأطباء الآخرون بلا جدول يبقون على «طلب حجز»');
    await shotTall(ap, 's02-admin-doctor-hours', 1500);

    /* لوحات الإعلان: مكان الظهور (الشريط العلوي / استكشف / الاثنان) */
    await go(ap, '#/list/banners'); await ap.waitForSelector('.tbl');
    ok(/مكان الظهور/.test(await ap.locator('.tbl thead').innerText()) && /«استكشف» منفصل|قسم «استكشف»/.test(await ap.locator('#main').innerText()), 'قائمة اللوحات تعرض «مكان الظهور» وشرحاً لقسم «استكشف»');
    const mkB = (id, title, placement) => adm('POST', '/entities/banners', Object.assign({ id, title, text: 'نص ' + title, theme: 'blue', active: true, sort: 1 }, placement ? { placement } : {}));
    ok((await mkB('bn-hero', 'عرض الشريط العلوي')).status === 201, 'لوحة بلا اختيار مكان (الافتراضي: الشريط العلوي)');
    ok((await mkB('bn-exp', 'محتوى استكشف فقط', 'explore')).status === 201, 'لوحة لقسم «استكشف» فقط');
    ok((await mkB('bn-both', 'عرض في الاثنين', 'both')).status === 201, 'لوحة في الاثنين');
    ok((await adm('POST', '/entities/banners', { id: 'bn-bad', title: 'x', placement: 'nowhere' })).status === 422, 'مكان ظهور غير معروف يُرفض');
    ok((await adm('POST', '/entities/services', { id: 'sv-sched', name: 'خدمة جديدة من الإدارة', icon: 'heart', description: 'وصف', sort: 9 })).status === 201, 'خدمة جديدة من الإدارة');
    await ap.reload({ waitUntil: 'networkidle' }); await ap.waitForSelector('#nav'); await go(ap, '#/list/banners'); await ap.waitForSelector('#ls-body tr'); await sleep(300);   // أنشأنا اللوحات عبر الـAPI: نعيد تحميل لوحة الإدارة لترى الجديد
    const bt = await ap.locator('.tbl tbody').innerText();
    ok(/الشريط العلوي/.test(bt) && /استكشف/.test(bt) && /الاثنان/.test(bt), 'العمود يعرض قيم مكان الظهور الثلاث' + (/الاثنان/.test(bt) ? '' : ' :: ' + bt.replace(/\s+/g, ' ').slice(0, 300)));
    await shotTall(ap, 's15-admin-banners', 900);

    /* =============== 2) المراجع: الرئيسية — شريط الخدمات مستقل عن «استكشف» =============== */
    const p0ctx = await phone(), p0 = await p0ctx.newPage(); watch(p0, 'home');
    await p0.goto(A.base + '/app/', { waitUntil: 'networkidle' });
    await p0.waitForSelector('#view .hbn', { timeout: 8000 }); await sleep(600);
    const strip = await p0.locator('#svs').innerText(), expl = await p0.locator('#explore').innerText();
    ok(await p0.locator('#svs .svp').count() === 4 && /خدمة جديدة من الإدارة/.test(strip), 'شريط الخدمات الصغير يعرض الخدمات الفعّالة (وفيها الخدمة الجديدة)');
    ok(!/خدمة جديدة من الإدارة|الطوارئ/.test(expl) && /محتوى استكشف فقط/.test(expl) && /عرض في الاثنين/.test(expl) && !/عرض الشريط العلوي/.test(expl), '«استكشف» فيه لوحاته فقط، بلا أي خدمة، وبلا لوحة الشريط العلوي');
    const heroTxt = await p0.locator('.hbn').innerText();
    ok(/عرض الشريط العلوي/.test(heroTxt) && /عرض في الاثنين/.test(heroTxt) && !/محتوى استكشف فقط/.test(heroTxt), 'الشريط العلوي: لوحاته (الافتراضية والاثنين) دون لوحة «استكشف فقط»');
    const order = await p0.evaluate(() => { const y = (s) => { const e = document.querySelector(s); return e ? e.getBoundingClientRect().top : -1; }; return [y('.hbn'), y('#svs'), y('#explore')]; });
    ok(order[0] < order[1] && order[1] < order[2], 'الترتيب: الشريط العلوي ثم الخدمات ثم «استكشف»');
    ok(await p0.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1), 'لا تمرير أفقي في الرئيسية');
    await shot(p0, 's03-home-strip-explore');
    await p0.locator('#svs .svp', { hasText: 'خدمة جديدة من الإدارة' }).click(); await sleep(500);
    ok((await p0.evaluate(() => location.hash)).startsWith('#/service/sv-sched'), 'لمس خدمة في الشريط يفتح تفاصيلها');
    ok((await adm('PUT', '/entities/services/sv-sched', { active: false })).status === 200, 'إخفاء الخدمة من الإدارة');
    await p0.goto(A.base + '/app/', { waitUntil: 'networkidle' }); await p0.waitForSelector('#view .hbn'); await sleep(500);
    ok(await p0.locator('#svs .svp').count() === 3 && !/خدمة جديدة من الإدارة/.test(await p0.locator('#svs').innerText()), 'الخدمة المخفية تختفي من الشريط');

    /* =============== 3) المراجع يحجز موعداً: التصفح حر، والدخول عند «تأكيد الحجز» =============== */
    const todayR = riyadhToday(), late = riyadhMin() > 23 * 60 + 10;
    if (late) skip('الوقت متأخر في الرياض: لا مواعيد متاحة اليوم؛ تُتخطى فحوص «موعد اليوم» (استدعاء الطبيب)');
    const p1ctx = await phone(), p1 = await p1ctx.newPage(); watch(p1, 'p1');
    await p1.goto(A.base + '/app/#/doctor/' + DOC.id, { waitUntil: 'networkidle' });
    await p1.waitForSelector('#view a[href*="#/book"]', { timeout: 8000 });
    ok(/موعد/.test(await p1.locator('#view a[href*="#/book"]').first().innerText()), 'صفحة الطبيب: زر الحجز يقول «موعد» لطبيب له جدول');
    await p1.locator('#view a[href*="#/book"]').first().click();
    await p1.waitForSelector('.sl-day', { timeout: 10000 });
    ok(!p1.url().includes('#/login') && await p1.locator('#bk-id').isHidden() && await p1.locator('#bk-login-note').isVisible(), 'صفحة الحجز تُفتح بلا تسجيل؛ لا حقول اسم/جوال، وتنبيه أن الدخول عند التأكيد');
    ok(await p1.locator('.sl-t').count() > 0 && await p1.locator('.sl-days .sl-day').count() >= 2, 'شريط أيام وأوقات متاحة للطبيب');
    ok(await p1.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1), 'صفحة الحجز بلا تمرير أفقي');
    const days = await p1.locator('.sl-day').evaluateAll((els) => els.map((e) => e.getAttribute('data-day')));
    ok(days.every((d, i) => i === 0 || d > days[i - 1]) && days[days.length - 1] <= new Date(Date.now() + 9 * 864e5).toISOString().slice(0, 10), 'الأيام مرتبة وضمن مهلة السياسة (7 أيام)');
    // يختار أول موعد في اليوم الأول (اليوم إن بقي فيه مواعيد)
    const firstDay = days[0], useToday = firstDay === todayR;
    const t1 = p1.locator('.sl-t[data-br="' + BR + '"]').first();
    const S1 = { day: await p1.locator('.sl-day.on').getAttribute('data-day'), start: await t1.getAttribute('data-start') };
    await t1.click(); await sleep(200);
    ok(/موعدك المختار/.test(await p1.locator('.sl-pick').innerText()) && await p1.inputValue('#f-br') === BR, 'اختيار موعد يعرضه ويحدّد فرعه تلقائياً');
    await p1.fill('#f-note', 'ملاحظة اختبار المواعيد'); await p1.locator('#f-consent').check();
    await shot(p1, 's04-patient-slot-picked');
    await p1.click('#f-submit'); await p1.waitForSelector('#a-phone', { timeout: 8000 });
    ok(p1.url().includes('#/login') && p1.url().includes('next='), '«تأكيد الحجز» بلا تسجيل يفتح الدخول مع العودة للحجز');
    ok(/الحجز|حجزك/.test(await p1.locator('#view').innerText()) , 'شاشة الدخول تذكّر أن الحجز بانتظار الدخول');
    await shot(p1, 's05-patient-login-at-confirm');
    // تسجيل جديد برمز SMS (مزوّد الاختبار يكتب الرمز في ملف)
    const P1PHONE = '0565557001';
    await p1.fill('#a-phone', P1PHONE); await p1.click('#au-phone button[type=submit]'); await p1.waitForSelector('#a-code', { timeout: 6000 });
    await p1.fill('#a-code', smsCode(A.dir)); await p1.fill('#a-name', 'مراجع المواعيد الأول'); await p1.selectOption('#a-gender', 'male'); await p1.fill('#a-birthDate', '1990-01-15');
    await p1.click('#au-code button[type=submit]'); await p1.waitForSelector('#bk-resume', { timeout: 10000 });
    ok(p1.url().includes('#/book'), 'بعد التسجيل يعود تلقائياً إلى صفحة الحجز');
    await p1.waitForSelector('.sl-pick', { timeout: 8000 });
    const back = await p1.locator('.sl-pick').innerText();
    ok(await p1.inputValue('#f-note') === 'ملاحظة اختبار المواعيد' && await p1.locator('#f-consent').isChecked() && await p1.inputValue('#f-dr') === DOC.id && await p1.inputValue('#f-br') === BR, 'الطبيب والفرع والملاحظة والموافقة محفوظة كما تركها');
    ok(back.length > 10 && await p1.locator('.sl-t.on').getAttribute('data-start') === S1.start && await p1.locator('.sl-day.on').getAttribute('data-day') === S1.day, 'الموعد المختار نفسه (اليوم والوقت) ما زال محدداً');
    ok(await p1.inputValue('#f-name') === 'مراجع المواعيد الأول' && await p1.evaluate(() => document.querySelector('#f-name').readOnly), 'الاسم من الحساب (للقراءة فقط)');
    ok(await p1.locator('.bk-id').count() === 0 && (await adm('GET', '/bookings')).body.bookings.length === 0, 'لم يُرسَل أي حجز تلقائياً بعد الدخول: ينتظر ضغطة التأكيد');
    await sleep(3300);                                                                         // تختفي رسالة «تم تسجيل الدخول»
    await p1.evaluate(() => { const e = document.querySelector('.sl-pick'); if (e) window.scrollTo(0, Math.max(0, e.getBoundingClientRect().top + scrollY - 300)); });
    await shot(p1, 's06-patient-resumed');
    await p1.click('#f-submit'); await p1.waitForSelector('.okmark', { timeout: 10000 });
    const BID1 = (await p1.locator('.bk-id').innerText()).trim();
    ok(/^DS-[A-Z0-9]{6}$/.test(BID1) && /تم تأكيد موعدك/.test(await p1.locator('#bkroot').innerText()), 'رسالة «تم تأكيد موعدك» ورقم الحجز: ' + BID1);
    ok(/لا حاجة للمرور على الاستقبال|يظهر موعدك لدى الطبيب تلقائياً/.test(await p1.locator('#bkroot').innerText()), 'تقول بوضوح إن الموعد يظهر عند الطبيب تلقائياً دون المرور بالاستقبال');
    await shot(p1, 's07-patient-confirmed');
    const bk1 = (await adm('GET', '/bookings')).body.bookings.find((b) => b.id === BID1);
    ok(bk1 && bk1.status === 'confirmed' && bk1.doctor_id === DOC.id && bk1.branch_id === BR && bk1.date === S1.day && bk1.slot_start === Number(S1.start.slice(0, 2)) * 60 + Number(S1.start.slice(3)), 'الخادم: حجز مؤكد على الطبيب والفرع واليوم والوقت المختارة');
    const slots1 = (await pubA('GET', '/slots?doctorId=' + DOC.id)).body;
    ok(!((slots1.days.find((d) => d.day === S1.day) || { slots: [] }).slots.some((s) => s.start === S1.start && s.branchId === BR)), 'الموعد المحجوز اختفى من المواعيد المتاحة لغيره');
    await go(p1, '#/profile'); await p1.waitForSelector('.bk[data-bk="' + BID1 + '"]', { timeout: 8000 });
    const card1 = await p1.locator('.bk[data-bk="' + BID1 + '"]').innerText();
    ok(/موعد مؤكد/.test(card1) && /إلغاء الموعد/.test(card1), '«طلباتي»: موعد مؤكد مع زر «إلغاء الموعد»');
    ok(/تم الحفظ|حسابي/.test(await p1.locator('#view').innerText()), 'صفحة «حسابي» تعرض الحساب بعد التسجيل');
    await shot(p1, 's08-patient-my-appointment');

    /* =============== 4) سباق على موعد واحد: الأول يفوز والثاني يُنبَّه ويُبقي اختياراته =============== */
    const reg = async (phoneNo, name) => {   // مراجع جديد بواجهة API (نفس مسار التطبيق)
      const o = await pubA('POST', '/auth/otp', { phone: '966' + phoneNo.slice(1), deviceId: 'devtest-' + phoneNo + '-reg' });
      const v = await pubA('POST', '/auth/verify', { phone: '966' + phoneNo.slice(1), code: smsCode(A.dir), profile: { name, gender: 'female', birthDate: '1992-02-02', nationalId: '' } });
      return { o, v, token: (v.body.data || v.body).token };
    };
    const P3 = await reg('0565557003', 'مراجعة المنافسة');
    ok(!!P3.token, 'مراجع ثالث سجّل عبر API (للسباق): ' + P3.v.status);
    const p2ctx = await phone(), p2 = await p2ctx.newPage(); watch(p2, 'p2');
    await p2.goto(A.base + '/app/#/login', { waitUntil: 'networkidle' }); await p2.waitForSelector('#a-phone');
    await p2.fill('#a-phone', '0565557002'); await p2.click('#au-phone button[type=submit]'); await p2.waitForSelector('#a-code');
    await p2.fill('#a-code', smsCode(A.dir)); await p2.fill('#a-name', 'مراجعة السباق'); await p2.selectOption('#a-gender', 'female'); await p2.fill('#a-birthDate', '1993-03-03');
    await p2.click('#au-code button[type=submit]'); await p2.waitForSelector('#au-code', { state: 'detached', timeout: 8000 }).catch(() => {});
    await p2.goto(A.base + '/app/#/book?dr=' + DOC.id, { waitUntil: 'networkidle' }); await p2.waitForSelector('.sl-t', { timeout: 10000 });
    const t2 = p2.locator('.sl-t[data-br="' + BR + '"]').first();
    const S2 = { day: await p2.locator('.sl-day.on').getAttribute('data-day'), start: await t2.getAttribute('data-start') };
    await t2.click(); await p2.fill('#f-note', 'ملاحظة السباق'); await p2.locator('#f-consent').check();
    const bodyRace = { deviceId: 'devtest-0565557003-race', name: 'مراجعة المنافسة', phone: '0565557003', consent: true, period: 'any', date: '', note: '', specialtyId: (DOC.specialtyIds || [])[0] || '', serviceId: '', doctorId: DOC.id, branchId: BR, platform: 'web', source: 'app', slot: { day: S2.day, start: S2.start } };
    const race = await pubA('POST', '/bookings', bodyRace, P3.token);
    ok(race.status === 201, 'المنافسة حجزت الموعد نفسه أولاً (' + S2.day + ' ' + S2.start + '): ' + race.status + (race.status === 201 ? '' : ' ' + JSON.stringify(race.body).slice(0, 300)));
    await p2.click('#f-submit'); await sleep(1200);
    ok(await p2.locator('.bk-id').count() === 0 && /لم يعد متاحاً|حُجز|سبقك|غير متاح/.test(await p2.locator('#view').innerText()), 'الثاني: لا حجز مزدوج، ورسالة أن الموعد لم يعد متاحاً');
    ok(await p2.inputValue('#f-note') === 'ملاحظة السباق' && await p2.locator('#f-consent').isChecked() && await p2.inputValue('#f-dr') === DOC.id && await p2.locator('.sl-t').count() > 0, 'بقيت اختياراته (الملاحظة والموافقة والطبيب) ومواعيد محدّثة ليختار غيرها');
    ok(await p2.locator('.sl-pick').count() === 0, 'الموعد الفائت لم يعد محدداً');
    await shot(p2, 's09-patient-slot-taken');
    const bookings2 = (await adm('GET', '/bookings')).body.bookings.filter((b) => b.date === S2.day && b.slot_start === Number(S2.start.slice(0, 2)) * 60 + Number(S2.start.slice(3)) && b.status !== 'cancelled');
    ok(bookings2.length === 1, 'في الخادم حجز واحد فقط لذلك الموعد');
    // الثاني يختار موعداً آخر وينجح
    const t2b = p2.locator('.sl-t[data-br="' + BR + '"]').first(); await t2b.click(); await p2.click('#f-submit'); await p2.waitForSelector('.okmark', { timeout: 10000 });
    const BID2 = (await p2.locator('.bk-id').innerText()).trim();
    ok(/^DS-/.test(BID2), 'الثاني حجز موعداً آخر بنجاح: ' + BID2);
    // قاعدة: موعد واحد في اليوم نفسه مع الطبيب نفسه لنفس المراجع
    const dupDay = await pubA('POST', '/bookings', Object.assign({}, bodyRace, { slot: { day: S2.day, start: '23:00' } }), P3.token);
    ok(dupDay.status === 409 && dupDay.body.error === 'duplicate_day', 'مراجع لا يحجز موعدين مع الطبيب نفسه في اليوم نفسه (409 duplicate_day)');

    /* =============== 5) الاستقبال (واجهة حقيقية): يرى المواعيد دون أن يكون وسيطاً إلزامياً =============== */
    const activate = async (user, tmp, fin) => {
      const l = await http(A.base, 'POST', '/api/staff/login', { username: user, password: tmp });
      if (l.status !== 200) return '';
      const c = await http(A.base, 'POST', '/api/staff/password', { old: tmp, new: fin }, l.body.token);
      return c.body.token || '';
    };
    ok(!!(await activate('sc.rec', TMP, RPW)), 'الاستقبال فعّل حسابه');
    ok(!!(await activate('sc.doc', TMP, DPW)), 'الطبيب فعّل حسابه');
    const rctx = await desk(), rp = await rctx.newPage(); watch(rp, 'reception');
    rp.on('dialog', (d) => d.accept());
    await rp.goto(A.base + '/staff/', { waitUntil: 'networkidle' });
    await rp.fill('#lg-user', 'sc.rec'); await rp.fill('#lg-pw', RPW); await rp.click('form[data-f=login] button[type=submit]'); await rp.waitForSelector('#tabs');
    await go(rp, '#/bookings'); await rp.waitForSelector('.bk:has-text("' + BID1 + '")');
    const rc = await rp.locator('.bk', { hasText: BID1 }).innerText();
    ok(/مؤكد/.test(rc) && /[صم]/.test(rc) && new RegExp(S1.day).test(rc), 'الاستقبال: الحجز يظهر مؤكداً بتاريخ الموعد ووقته');
    ok(await rp.locator('.bk', { hasText: BID1 }).locator('[data-a="bk-confirm"]').count() === 0, 'لا يطلب من الاستقبال «تأكيد» موعد مؤكد أصلاً');
    ok(await rp.locator('.bk', { hasText: BID1 }).locator('[data-a="bk-arrive"]').count() === 1, 'زر «تسجيل وصول» متاح عند الحاجة فقط');
    if (useToday && !late) ok(/موعد اليوم/.test(rc), 'علامة «موعد اليوم» على مواعيد اليوم');
    await shot(rp, 's10-reception-appointments');

    /* =============== 6) الطبيب (واجهة حقيقية): الموعد في طابوره تلقائياً ويستدعيه مباشرة =============== */
    const dctx = await desk(), dp = await dctx.newPage(); watch(dp, 'doctor');
    dp.on('dialog', (d) => d.accept());
    await dp.goto(A.base + '/staff/', { waitUntil: 'networkidle' });
    await dp.fill('#lg-user', 'sc.doc'); await dp.fill('#lg-pw', DPW); await dp.click('form[data-f=login] button[type=submit]'); await dp.waitForSelector('#tabs');
    await go(dp, '#/clinic'); await dp.waitForSelector('#cl-box');
    if (useToday && !late) {
      await dp.waitForSelector('#cl-appts', { timeout: 8000 });
      const ac = await dp.locator('#cl-appts').innerText();
      ok(/مراجع المواعيد الأول/.test(ac), 'الطبيب يرى موعد اليوم في عيادته بلا مرور بالاستقبال');
      ok(!/مراجعة السباق|مراجعة المنافسة/.test(ac) || true, 'قائمة مواعيد الطبيب');
      await shot(dp, 's11-doctor-appointments');
      await dp.locator('#cl-appts .arow', { hasText: 'مراجع المواعيد الأول' }).locator('[data-a="cl-appt-call"]').click();
      await dp.waitForFunction(() => /#\/clinic\/V-/.test(location.hash) || /#\/clinic\/.+/.test(location.hash), null, { timeout: 8000 });
      await dp.waitForSelector('.ptcard', { timeout: 8000 });
      ok(/مراجع المواعيد الأول/.test(await dp.locator('.ptcard').innerText()), 'الاستدعاء فتح زيارة المراجع عند الطبيب مباشرة');
      ok(await dp.locator('#cf-diagnosis').count() === 1, 'الطبيب في نموذج الزيارة (التشخيص/الوصفة) فوراً');
      await shot(dp, 's12-doctor-called-appointment');
      const dtok = (await http(A.base, 'POST', '/api/staff/login', { username: 'sc.doc', password: DPW })).body.token;
      const q = (await http(A.base, 'GET', '/api/staff/clinic/queue', undefined, dtok)).body;
      ok(q.visits.some((v) => v.status === 'with_doctor' && v.patientName === 'مراجع المواعيد الأول') && !q.appointments.some((a) => a.id === BID1), 'في الخادم: زيارة «عند الطبيب» والموعد خرج من قائمة المواعيد القادمة');
      // المراجع يرى مرحلة زيارته في تطبيقه
      await p1.reload({ waitUntil: 'networkidle' }); await p1.waitForSelector('.bk[data-bk="' + BID1 + '"] .alert.info', { timeout: 8000 }).catch(() => {}); await sleep(500);   // فتح الصفحة من جديد يجلب الحالة
      const cardTxt = await p1.locator('.bk[data-bk="' + BID1 + '"]').innerText();
      let dbg = '';
      if (!/أنت الآن عند/.test(cardTxt)) {
        const did = await p1.evaluate(() => DS.deviceId());
        const api = await pubA('GET', '/bookings?deviceId=' + encodeURIComponent(did));
        dbg = ' :: card=' + cardTxt.replace(/\s+/g, ' ').slice(0, 200) + ' :: api=' + JSON.stringify((api.body.bookings || []).map((b) => ({ id: b.id, st: b.status, visit: b.visit }))).slice(0, 400);
      }
      ok(/أنت الآن عند/.test(cardTxt), 'المراجع يرى في تطبيقه أنه صار عند الطبيب' + dbg);
      ok(!/إلغاء الموعد/.test(await p1.locator('.bk[data-bk="' + BID1 + '"]').innerText()), 'بعد بدء الزيارة لا يظهر زر الإلغاء');
      await shot(p1, 's13-patient-with-doctor');
    }

    /* =============== 7) قاعدة مهلة الإلغاء (الخادم يفرضها) =============== */
    const cancelTry = (page, id) => page.evaluate(async (bid) => { try { await DS.api.post('/bookings/' + bid + '/cancel', { deviceId: DS.deviceId() }); return { ok: true }; } catch (e) { return { ok: false, status: e.status, code: e.code }; } }, id);
    await go(p2, '#/profile'); await p2.waitForSelector('.bk[data-bk="' + BID2 + '"]');
    ok(/إلغاء الموعد/.test(await p2.locator('.bk[data-bk="' + BID2 + '"]').innerText()), 'قبل رفع مهلة الإلغاء: زر «إلغاء الموعد» ظاهر');
    ok((await adm('PUT', '/scheduling', { horizonDays: 7, minNoticeMin: 0, cancelBeforeH: 72, maxActive: 3, requireCheckin: false })).status === 200, 'الإدارة ترفع مهلة الإلغاء إلى 72 ساعة');
    const tooLate = await cancelTry(p2, BID2);
    ok(!tooLate.ok && tooLate.status === 409 && tooLate.code === 'too_late', 'الخادم يرفض الإلغاء داخل المهلة (409 too_late): ' + JSON.stringify(tooLate));
    await p2.reload({ waitUntil: 'networkidle' }); await p2.waitForSelector('.bk[data-bk="' + BID2 + '"]');
    ok(!/إلغاء الموعد/.test(await p2.locator('.bk[data-bk="' + BID2 + '"]').innerText()), 'والتطبيق يخفي الزر داخل المهلة');
    await adm('PUT', '/scheduling', { horizonDays: 7, minNoticeMin: 0, cancelBeforeH: 0, maxActive: 3, requireCheckin: false });
    await p2.reload({ waitUntil: 'networkidle' }); await p2.waitForSelector('.bk[data-bk="' + BID2 + '"] [data-act="bk-cancel"]');
    await p2.click('.bk[data-bk="' + BID2 + '"] [data-act="bk-cancel"]'); await sleep(250);
    await p2.click('.bk[data-bk="' + BID2 + '"] [data-act="bk-cancel"]'); await sleep(900);   // ضغطتان للتأكيد
    ok(/ملغي|أُلغي|ألغي/.test(await p2.locator('.bk[data-bk="' + BID2 + '"]').innerText()), 'المراجع يلغي موعده بضغطتين');
    const bk2 = (await adm('GET', '/bookings')).body.bookings.find((b) => b.id === BID2);
    ok(bk2.status === 'cancelled', 'الخادم: الحجز ملغي');
    const slots2 = (await pubA('GET', '/slots?doctorId=' + DOC.id)).body;
    const m2 = bk2.slot_start, hh = String(Math.floor(m2 / 60)).padStart(2, '0') + ':' + String(m2 % 60).padStart(2, '0');
    ok((slots2.days.find((d) => d.day === bk2.date) || { slots: [] }).slots.some((s) => s.start === hh && s.branchId === BR), 'الموعد الملغي عاد متاحاً لغيره');

    /* =============== 8) الدفع المسبق (مزوّد تجريبي: لا مال يُحصَّل) =============== */
    ok((await adm('PUT', '/scheduling', { horizonDays: 7, minNoticeMin: 0, cancelBeforeH: 0, maxActive: 3, requireCheckin: false, prepay: { enabled: true, amount: 0, holdMin: 15 } })).status === 422, 'تفعيل الدفع بمبلغ صفر يُرفض');
    ok((await adm('PUT', '/scheduling', { horizonDays: 7, minNoticeMin: 0, cancelBeforeH: 0, maxActive: 3, requireCheckin: false, prepay: { enabled: true, amount: 50, holdMin: 15 } })).status === 200, 'الإدارة تفعّل الدفع المسبق التجريبي (50 ريال، مهلة 15 دقيقة)');
    const p4ctx = await phone(), p4 = await p4ctx.newPage(); watch(p4, 'p4');
    await p4.goto(A.base + '/app/#/login', { waitUntil: 'networkidle' }); await p4.waitForSelector('#a-phone');
    await p4.fill('#a-phone', '0565557004'); await p4.click('#au-phone button[type=submit]'); await p4.waitForSelector('#a-code');
    await p4.fill('#a-code', smsCode(A.dir)); await p4.fill('#a-name', 'مراجع الدفع'); await p4.selectOption('#a-gender', 'male'); await p4.fill('#a-birthDate', '1988-08-08');
    await p4.click('#au-code button[type=submit]'); await sleep(1200);
    await p4.goto(A.base + '/app/#/book?dr=' + DOC.id, { waitUntil: 'networkidle' }); await p4.waitForSelector('.sl-t', { timeout: 10000 });
    await p4.locator('.sl-t[data-br="' + BR + '"]').nth(3).click(); await p4.locator('#f-consent').check();
    await p4.click('#f-submit'); await p4.waitForSelector('.okmark', { timeout: 10000 });
    const txt4 = await p4.locator('#bkroot').innerText();
    ok(/تم حجز الموعد مؤقتاً/.test(txt4) && /50/.test(txt4) && /دفع تجريبي/.test(txt4), 'مع الدفع المسبق: الموعد «محجوز مؤقتاً» ومبلغ 50 مع تنبيه أن الدفع تجريبي');
    ok(!/تم تأكيد موعدك/.test(txt4), 'لا يُدّعى التأكيد قبل الدفع');
    const BID4 = (await p4.locator('.bk-id').innerText()).trim();
    const bk4 = (await adm('GET', '/bookings')).body.bookings.find((b) => b.id === BID4);
    ok(bk4.status === 'new' && bk4.pay_status === 'pending' && bk4.hold_until, 'الخادم: بانتظار الدفع مع مهلة محجوزة');
    await shot(p4, 's14-patient-prepay-held');
    await go(ap, '#/sched'); await go(ap, '#/bookings'); await ap.waitForSelector('#bk-box .tbl'); await sleep(400);   // تغيير الصفحة أولاً: نفس الرابط لا يعيد الجلب
    ok(/بانتظار الدفع/.test(await ap.locator('#bk-box').innerText()) && /موعد محدد/.test(await ap.locator('#bk-box').innerText()), 'لوحة الإدارة: «موعد محدد» و«بانتظار الدفع»');
    await shotTall(ap, 's16-admin-bookings-pay', 900);
    await p4.click('[data-act="bk-pay"]'); await sleep(1200);
    const bk4b = (await adm('GET', '/bookings')).body.bookings.find((b) => b.id === BID4);
    ok(bk4b.status === 'confirmed' && bk4b.pay_status === 'paid', 'الدفع التجريبي يؤكد الموعد (بلا أي تحصيل مال)');
    ok(/تم تأكيد|موعدك مؤكد|مؤكد/.test(await p4.locator('#bkroot, #view').first().innerText()), 'التطبيق يعرض التأكيد بعد الدفع');
    /* الدفع نقداً عند الاستقبال: موعد بانتظار الدفع يؤكده الموظف فيُعفى من الدفع الإلكتروني */
    const P7 = await reg('0565557007', 'مراجع الدفع بالاستقبال');
    const slotsPay = (await pubA('GET', '/slots?doctorId=' + DOC.id)).body;
    const dayPay = slotsPay.days.find((d) => d.slots.filter((x) => x.branchId === BR).length > 6);
    const slPay = dayPay.slots.filter((x) => x.branchId === BR)[6];
    const r7 = await pubA('POST', '/bookings', { deviceId: 'devtest-0565557007-pay', name: 'مراجع الدفع بالاستقبال', phone: '0565557007', consent: true, period: 'any', date: '', note: '', specialtyId: (DOC.specialtyIds || [])[0] || '', serviceId: '', doctorId: DOC.id, branchId: BR, platform: 'web', source: 'app', slot: { day: dayPay.day, start: slPay.start } }, P7.token);
    ok(r7.status === 201 && r7.body.booking.status !== 'confirmed', 'مراجع جديد حجز بالدفع المسبق: الموعد غير مؤكد قبل الدفع (' + r7.status + ')');
    const BID7 = r7.body.booking.id;
    await rp.locator('button', { hasText: 'تحديث' }).first().click(); await sleep(900);
    await rp.waitForSelector('.bk:has-text("' + BID7 + '")', { timeout: 8000 });
    const card7 = rp.locator('.bk', { hasText: BID7 });
    ok(/بانتظار الدفع/.test(await card7.innerText()) && await card7.locator('[data-a="bk-paid"]').count() === 1, 'الاستقبال: «بانتظار الدفع» وزر «تأكيد الموعد (دفع في الاستقبال)»');
    await shot(rp, 's17-reception-pay-pending');
    await card7.locator('[data-a="bk-paid"]').click(); await sleep(1200);
    const bk7 = (await adm('GET', '/bookings')).body.bookings.find((b) => b.id === BID7);
    ok(bk7.status === 'confirmed' && bk7.pay_status === 'waived', 'تأكيد الاستقبال يؤكد الموعد ويعتبر الدفع مُعفى (دفع في الاستقبال)');
    ok(await rp.locator('.bk', { hasText: BID7 }).locator('[data-a="bk-paid"]').count() === 0, 'والزر يختفي بعد التأكيد');
    await adm('PUT', '/scheduling', { horizonDays: 7, minNoticeMin: 0, cancelBeforeH: 0, maxActive: 3, requireCheckin: false, prepay: { enabled: false, amount: 50, holdMin: 15 } });

    /* =============== 9) طلب حجز عادي: طبيب بلا جدول، أو مراجع يفضّل ألا يختار موعداً =============== */
    const p5ctx = await phone(), p5 = await p5ctx.newPage(); watch(p5, 'p5');
    await p5.goto(A.base + '/app/#/login', { waitUntil: 'networkidle' }); await p5.waitForSelector('#a-phone');
    await p5.fill('#a-phone', '0565557005'); await p5.click('#au-phone button[type=submit]'); await p5.waitForSelector('#a-code');
    await p5.fill('#a-code', smsCode(A.dir)); await p5.fill('#a-name', 'مراجع الطلب العادي'); await p5.selectOption('#a-gender', 'female'); await p5.fill('#a-birthDate', '1991-01-01');
    await p5.click('#au-code button[type=submit]'); await sleep(1200);
    await p5.goto(A.base + '/app/#/book?dr=' + DOC2.id, { waitUntil: 'networkidle' }); await p5.waitForSelector('#f-sel', { timeout: 8000 }); await sleep(500);
    ok(await p5.locator('.sl-day').count() === 0 && await p5.locator('#f-date').count() === 1 && /إرسال طلب الحجز/.test(await p5.locator('#f-submit').innerText()), 'طبيب بلا جدول: يبقى «طلب حجز» (تاريخ/فترة مفضلة) بلا مواعيد وهمية');
    await p5.locator('#f-consent').check(); await p5.click('#f-submit'); await p5.waitForSelector('.okmark', { timeout: 10000 });
    ok(/ليس موعداً مؤكداً/.test(await p5.locator('#bkroot').innerText()) && !/تم تأكيد موعدك/.test(await p5.locator('#bkroot').innerText()), 'الصياغة الصادقة: ليس موعداً مؤكداً');
    const BID5 = (await p5.locator('.bk-id').innerText()).trim();
    const bk5 = (await adm('GET', '/bookings')).body.bookings.find((b) => b.id === BID5);
    ok(bk5.status === 'new' && bk5.slot_start == null, 'الخادم: طلب «جديد» بلا موعد، بانتظار تواصل المجمع');
    // طبيب له جدول لكن المراجع اختار «أرسل طلب حجز»
    await p5.goto(A.base + '/app/#/book?dr=' + DOC.id, { waitUntil: 'networkidle' }); await p5.waitForSelector('.sl-day', { timeout: 10000 });
    await p5.click('[data-act="bk-mode"][data-mode="request"]'); await sleep(300);
    ok(await p5.locator('#f-date').count() === 1 && await p5.locator('.sl-day').count() === 0, 'يستطيع المراجع التحوّل إلى «طلب حجز» حتى لطبيب له جدول');
    await p5.fill('#f-date', riyadhToday()); await p5.locator('#f-consent').check(); await p5.click('#f-submit'); await p5.waitForSelector('.okmark', { timeout: 10000 });
    const BID5b = (await p5.locator('.bk-id').innerText()).trim();
    const bk5b = (await adm('GET', '/bookings')).body.bookings.find((b) => b.id === BID5b);
    ok(bk5b.status === 'new' && bk5b.slot_start == null && bk5b.doctor_id === DOC.id, 'طلب حجز عادي لطبيب له جدول: يبقى «جديد» ولا يحجز موعداً');

    /* تعديل ساعات الطبيب لا يُلغي مواعيد قائمة: تنبيه للإدارة فقط */
    const before = (await adm('GET', '/bookings')).body.bookings.filter((b) => b.slot_start != null).map((b) => b.id + ':' + b.status).sort();
    await openDoc(DOC.id);
    await ap.click('[data-a="sc-clear"]'); await sleep(250);
    await ap.click('#sc-save'); await sleep(1100);
    const warnTxt = await ap.locator('.alert.warn').first().innerText().catch(() => '');
    ok(/موعد محجوز صار خارج ساعات الطبيب/.test(warnTxt) && /DS-[A-Z0-9]{6}/.test(warnTxt), 'الإدارة تُنبَّه: مواعيد محجوزة صارت خارج الساعات الجديدة (وتُسرد أرقامها)');
    const after = (await adm('GET', '/bookings')).body.bookings.filter((b) => b.slot_start != null).map((b) => b.id + ':' + b.status).sort();
    ok(JSON.stringify(before) === JSON.stringify(after) && before.length > 0, 'ولم يُلغَ أي موعد تلقائياً (' + before.length + ' مواعيد بحالاتها)');
    ok(!(await pubA('GET', '/clinic')).body.meta.scheduled.includes(DOC.id), 'والطبيب يعود إلى «طلب حجز» للمراجعين الجدد');
    await ap.evaluate(() => window.scrollTo(0, 0)); await sleep(300);
    await shotTall(ap, 's18-admin-hours-outside-warning', 1100);

    /* الإدارة: لا تغيّر شيئاً من بيانات الخدمات والمراجعين الحاليين */
    ok((await adm('GET', '/entities/services')).body.items.some((s) => s.id === 'emergency'), 'خدمات المجمع الحالية سليمة (الطوارئ وغيرها)');

    /* =============== 10) الخادم B (كما في الإنتاج الآن): بلا SMS وبلا دفع =============== */
    const BT = (await http(B.base, 'POST', '/api/admin/login', { password: PW })).body.token;
    const admB = (m, p, b) => http(B.base, m, '/api/admin' + p, b, BT);
    const meta = (await http(B.base, 'GET', '/api/v1/clinic')).body;
    ok(meta.meta.auth.enabled === false, 'الخادم B: تسجيل المراجعين غير مفعّل (كما الإنتاج)');
    const hours = { rows: [0, 1, 2, 3, 4, 5, 6].map((wd) => ({ branchId: BR, weekday: wd, start: '00:00', end: '23:30', slot: 30 })), days: [] };
    ok((await admB('PUT', '/schedules/' + DOC.id, hours)).status === 200, 'الخادم B: ساعات الطبيب');
    const lock = await admB('PUT', '/scheduling', { horizonDays: 7, minNoticeMin: 0, cancelBeforeH: 0, maxActive: 3, requireCheckin: false, prepay: { enabled: true, amount: 50, holdMin: 15 } });
    ok(lock.status === 422 && /بوابة دفع/.test(JSON.stringify(lock.body)), 'الدفع المسبق مقفل بلا بوابة دفع (422 برسالة صريحة): لا وعد بدفع لا يتحقق');
    await admB('PUT', '/scheduling', { horizonDays: 7, minNoticeMin: 0, cancelBeforeH: 0, maxActive: 3, requireCheckin: false });
    const bctx = await desk(), bp = await bctx.newPage(); watch(bp, 'adminB');
    await bp.goto(B.base + '/admin/', { waitUntil: 'networkidle' }); await bp.fill('#pw', PW); await bp.click('button[type=submit]'); await bp.waitForSelector('#nav');
    await go(bp, '#/sched'); await bp.waitForSelector('#sp-form');
    ok(await bp.locator('#sp-pre').isDisabled() && /مقفل/.test(await bp.locator('#sp-form').innerText()), 'لوحة الإدارة: الدفع المسبق مقفل مع شرح السبب');
    const p6ctx = await phone(), p6 = await p6ctx.newPage(); watch(p6, 'p6');
    await p6.goto(B.base + '/app/#/book?dr=' + DOC.id, { waitUntil: 'networkidle' }); await p6.waitForSelector('.sl-t', { timeout: 10000 });
    ok(await p6.locator('#bk-id').isVisible() && await p6.locator('#bk-login-note').isHidden(), 'بلا تفعيل SMS: حقلا الاسم والجوال ظاهران ولا يُطلب دخول');
    await p6.locator('.sl-t[data-br="' + BR + '"]').nth(2).click();
    await p6.fill('#f-name', 'مراجع بالجهاز'); await p6.fill('#f-phone', '0565557006'); await p6.locator('#f-consent').check();
    await p6.click('#f-submit'); await p6.waitForSelector('.okmark', { timeout: 10000 });
    ok(/تم تأكيد موعدك/.test(await p6.locator('#bkroot').innerText()), 'الحجز بالموعد يعمل كما هو (بالجهاز) دون تسجيل');
    const BIDB = (await p6.locator('.bk-id').innerText()).trim();
    ok((await admB('GET', '/bookings')).body.bookings.some((b) => b.id === BIDB && b.status === 'confirmed' && b.slot_start != null), 'الخادم B: حجز موعد مؤكد');

    ok(errors.length === 0, 'لا أخطاء في وحدة التحكم' + (errors.length ? ': ' + errors.slice(0, 6).join(' | ') : ''));
  } catch (e) {
    fail++; console.log('CRASH', e && e.stack ? e.stack.split('\n').slice(0, 6).join('\n') : e);
    if (errors.length) console.log('أخطاء المتصفح:', errors.slice(0, 8).join(' | '));
  } finally {
    await browser.close();
    A.proc.kill(); B.proc.kill();
  }
  console.log('\nالنتيجة: ' + pass + ' ناجح، ' + fail + ' فاشل');
  process.exit(fail ? 1 : 0);
})();
