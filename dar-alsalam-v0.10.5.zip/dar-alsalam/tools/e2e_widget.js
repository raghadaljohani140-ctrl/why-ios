/* اختبار ويدجت قمر بمتصفح حقيقي، من دومين مختلف عن الخادم (حالة موقع المجمع الفعلية).
   NODE_PATH=<playwright> node tools/e2e_widget.js [BASE_URL] [ADMIN_PASSWORD]
   يتطلب خادماً يعمل على BASE_URL. يشغّل خادماً صغيراً على منفذ آخر ليكون «موقعاً مضيفاً» بتنسيقات عدائية. */
const { chromium } = require('playwright');
const http = require('http');
const fs = require('fs');
const path = require('path');

const BASE = process.argv[2] || 'http://127.0.0.1:8090';
const PW = process.argv[3] || 'devpass-12345';
const HOST_PORT = 8091;
const HOST = 'http://127.0.0.1:' + HOST_PORT;
const SHOTS = path.join(__dirname, '..', 'qa', 'shots');
fs.mkdirSync(SHOTS, { recursive: true });
let fails = 0, passes = 0;
function ok(c, m) { if (c) { passes++; console.log('PASS', m); } else { fails++; console.log('FAIL', m); } }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* صفحة «الموقع المضيف»: تنسيقات عدائية تحاول تخريب أي ويدجت، والسكربت من دومين الخادم (عبر الدومين) */
const hostPage = (attrs) => `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>موقع مضيف تجريبي</title>
<style>*{color:#c00!important;font-size:42px!important;font-family:cursive!important;letter-spacing:6px!important}
button,a,textarea,form,header,section,div{display:none!important;border:9px solid red!important}
body{display:block!important}body *{visibility:visible}
h1{display:block!important}</style></head>
<body><h1>موقع مضيف بتنسيقات عدائية</h1>
<script src="${BASE}/widget/qamar.js" ${attrs || ''} defer></script></body></html>`;
const hostSrv = http.createServer((req, res) => {
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  if (req.url.startsWith('/right')) return res.end(hostPage('data-side="right"'));
  res.end(hostPage(''));
});

async function adminToken() {
  const r = await fetch(BASE + '/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password: PW }) });
  return (await r.json()).token;
}
async function setQamarEnabled(tok, v) {
  const r = await fetch(BASE + '/api/admin/qamar', { method: 'PUT', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + tok }, body: JSON.stringify({ enabled: v }) });
  return r.status;
}

(async () => {
  await new Promise((r) => hostSrv.listen(HOST_PORT, '127.0.0.1', r));
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 }, locale: 'ar-SA', timezoneId: 'Asia/Riyadh' });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  const shot = async (n, p) => { await sleep(300); await (p || page).screenshot({ path: path.join(SHOTS, n + '.png') }); };

  /* ---------- خادم: نقطة الإعدادات والملف الثابت ---------- */
  const cr = await fetch(BASE + '/api/v1/qamar/config', { headers: { Origin: HOST } });
  const cj = await cr.json();
  const raw = JSON.stringify(cj);
  ok(cr.status === 200 && cj.enabled === true && cj.name === 'قمر' && cj.greeting && Array.isArray(cj.quickReplies), 'GET /qamar/config يعطي الإعدادات');
  ok(raw.length < 2048, 'الإعدادات خفيفة: ' + Buffer.byteLength(raw) + ' بايت');
  ok(cr.headers.get('access-control-allow-origin') === '*', 'CORS مفتوح لنقطة الإعدادات');
  ok(!/"(?:doctors|branches|bookings)"/.test(raw), 'لا تتسرب بيانات الأطباء أو الحجوزات في الإعدادات');
  const wr = await fetch(BASE + '/widget/qamar.js', { headers: { Origin: HOST } });
  ok(wr.status === 200 && /javascript/.test(wr.headers.get('content-type')) && wr.headers.get('access-control-allow-origin') === '*', 'الملف يُخدَّم كجافاسكربت مع CORS');

  /* ---------- الظهور في موقع مضيف بتنسيقات عدائية ---------- */
  await page.goto(HOST + '/', { waitUntil: 'load' });
  await page.waitForSelector('#ds-qamar-root', { state: 'attached', timeout: 8000 });
  const fab = page.locator('#ds-qamar-root .fab');
  await fab.waitFor({ state: 'visible', timeout: 5000 });
  ok(await fab.isVisible(), 'الأيقونة العائمة ظاهرة رغم تنسيقات الموقع العدائية (عزل Shadow DOM)');
  const htmlFs = await page.evaluate(() => getComputedStyle(document.documentElement).fontSize);
  ok(htmlFs === '42px', 'الصفحة المضيفة تضخّم خط الجذر عمداً (' + htmlFs + ') لاختبار وحدات rem');
  const fs1 = await fab.evaluate((e) => getComputedStyle(e).fontSize + '|' + getComputedStyle(e).color + '|' + getComputedStyle(e).letterSpacing);
  ok(fs1.startsWith('15px|rgb(255, 255, 255)|normal'), 'تنسيقات الموقع لا تتسرب إلى الويدجت: ' + fs1);
  const sheets = await page.evaluate(() => document.styleSheets.length);
  ok(sheets === 1, 'الويدجت لا يضيف تنسيقات لصفحة الموقع (عدد الأوراق ' + sheets + ')');
  ok(await page.evaluate(() => document.querySelectorAll('body > #ds-qamar-root').length === 1 && !!window.DSQamar && window.DSQamar.version), 'عنصر واحد فقط يُضاف للصفحة ويُعرِّف DSQamar');
  const box = await fab.boundingBox();
  ok(box && box.x < 100 && box.y > 600, 'الأيقونة أسفل يسار الصفحة افتراضياً: ' + Math.round(box.x) + ',' + Math.round(box.y));
  await shot('w01-widget-closed');

  /* ---------- فتح المحادثة والتحية ---------- */
  await fab.click();
  const panel = page.locator('#ds-qamar-root .panel');
  await panel.waitFor({ state: 'visible' });
  const greet = await page.locator('#ds-qamar-root .m.bot').first().innerText();
  ok(greet.trim() === cj.greeting.trim(), 'التحية تأتي من إعدادات الإدارة');
  ok(await page.locator('#ds-qamar-root .qr button').count() === cj.quickReplies.length, 'أزرار الردود السريعة من الإعدادات');
  ok(await fab.isHidden(), 'الأيقونة تختفي أثناء فتح النافذة');
  ok(await page.evaluate(() => document.querySelector('#ds-qamar-root').shadowRoot.activeElement && document.querySelector('#ds-qamar-root').shadowRoot.activeElement.tagName === 'TEXTAREA'), 'التركيز على حقل الكتابة');
  const sizes = await page.evaluate(() => {
    const sr = document.querySelector('#ds-qamar-root').shadowRoot, g = (q) => { const e = sr.querySelector(q); return e ? getComputedStyle(e).fontSize : null; };
    const big = [...sr.querySelectorAll('*')].filter((e) => parseFloat(getComputedStyle(e).fontSize) > 20 && !e.closest('svg')).map((e) => e.tagName + '.' + e.className);
    return { disc: g('.disc'), small: g('header small'), title: g('header b'), chip: g('.qr button'), msg: g('.m.bot'), big };
  });
  ok(sizes.disc === '11px' && sizes.small === '12px' && sizes.title === '16px' && sizes.chip === '13px' && sizes.msg === '15px', 'أحجام الخطوط ثابتة ولا تتأثر بحجم خط جذر الصفحة: ' + JSON.stringify(sizes));
  ok(sizes.big.length === 0, 'لا عنصر داخل الويدجت بخط أكبر من 20px ' + JSON.stringify(sizes.big));
  await shot('w02-widget-open');

  /* ---------- سؤال عبر زر سريع ثم كتابة ---------- */
  await page.locator('#ds-qamar-root .qr button', { hasText: 'أبي أحجز موعد' }).click();
  await page.waitForSelector('#ds-qamar-root .m.bot:not(.typing) .act.book', { timeout: 8000 });
  const bookHref = await page.locator('#ds-qamar-root .act.book').first().getAttribute('href');
  ok(bookHref.startsWith(BASE + '/app/#/book'), 'زر «احجز» يفتح صفحة الحجز في التطبيق: ' + bookHref);
  ok(await page.locator('#ds-qamar-root .act.book').first().getAttribute('target') === '_blank' && /noopener/.test(await page.locator('#ds-qamar-root .act.book').first().getAttribute('rel')), 'روابط التطبيق تُفتح في تبويب جديد مع noopener');

  await page.fill('#ds-qamar-root textarea', 'ابي احجز اسنان');
  await page.keyboard.press('Enter');
  await page.waitForFunction(() => document.querySelector('#ds-qamar-root').shadowRoot.querySelectorAll('.m.bot:not(.typing) .act.book').length >= 2, null, { timeout: 8000 });
  const hrefs = await page.locator('#ds-qamar-root .act.book').evaluateAll((a) => a.map((x) => x.getAttribute('href')));
  ok(hrefs.some((h) => /sp=dental/.test(h)), 'التوجيه لتخصص الأسنان داخل رابط الحجز: ' + hrefs[hrefs.length - 1]);
  ok(await page.locator('#ds-qamar-root .m.me').count() === 2, 'رسائل المستخدم تظهر');
  await shot('w03-widget-book');

  /* ---------- الطوارئ ---------- */
  await page.fill('#ds-qamar-root textarea', 'عندي ألم شديد في الصدر');
  await page.keyboard.press('Enter');
  await page.waitForSelector('#ds-qamar-root .act.em', { timeout: 8000 });
  ok(await page.locator('#ds-qamar-root .act.em').first().getAttribute('href') === 'tel:997', 'الطوارئ: زر اتصال بالإسعاف 997');
  ok(await page.locator('#ds-qamar-root .qr button').count() === 0, 'الطوارئ: لا ردود سريعة تشتّت المراجع');
  const lastBot = await page.locator('#ds-qamar-root .m.bot:not(.typing)').last().innerText();
  ok(/997/.test(lastBot), 'نص الرد يطلب الاتصال بـ 997');
  await shot('w04-widget-emergency');

  /* ---------- حفظ الجلسة وإعادة التعيين والإغلاق ---------- */
  const before = await page.locator('#ds-qamar-root .m').count();
  await page.reload({ waitUntil: 'load' });
  await page.waitForSelector('#ds-qamar-root .fab');
  await page.click('#ds-qamar-root .fab');
  ok(await page.locator('#ds-qamar-root .m').count() === before, 'المحادثة تبقى بعد تحديث الصفحة داخل نفس التبويب (' + before + ' رسالة)');
  await page.keyboard.press('Escape');
  await page.locator('#ds-qamar-root .fab').waitFor({ state: 'visible' });
  ok(await page.locator('#ds-qamar-root .panel').isHidden(), 'Esc يغلق النافذة');
  ok(await page.evaluate(() => document.querySelector('#ds-qamar-root').shadowRoot.activeElement && document.querySelector('#ds-qamar-root').shadowRoot.activeElement.classList.contains('fab')), 'التركيز يعود للأيقونة');
  await page.evaluate(() => window.DSQamar.open());
  await page.waitForSelector('#ds-qamar-root .panel', { state: 'visible' });
  await page.click('#ds-qamar-root header .x[aria-label="محادثة جديدة"]');
  ok(await page.locator('#ds-qamar-root .m').count() === 1, 'زر «محادثة جديدة» يمسح الرسائل ويبقي التحية');
  ok(await page.evaluate(() => (sessionStorage.getItem('dsq_did') || '').match(/^web_[a-f0-9]{24}$/) !== null), 'معرّف مجهول عشوائي في sessionStorage فقط');
  ok(await page.evaluate(() => localStorage.length === 0 && document.cookie === ''), 'لا localStorage ولا كوكيز');
  await page.keyboard.press('Escape');

  /* ---------- تعذّر الخادم و429 ---------- */
  await page.route('**/api/v1/qamar', (r) => r.request().method() === 'POST' ? r.abort('failed') : r.continue());
  await page.evaluate(() => window.DSQamar.ask('وين الفروع'));
  await page.waitForSelector('#ds-qamar-root .m.bot:not(.typing) .act', { timeout: 8000 });
  const fb = await page.locator('#ds-qamar-root .m.bot:not(.typing)').last().innerText();
  ok(/997/.test(fb) && /920031134/.test(fb), 'عند تعذّر الاتصال: الرقم الموحّد ورقم الإسعاف يظهران');
  ok((await page.locator('#ds-qamar-root .m.bot:not(.typing) .act').last().getAttribute('href')) === 'tel:920031134', 'زر اتصال بالمجمع');
  await page.unroute('**/api/v1/qamar');
  await page.route('**/api/v1/qamar', (r) => r.request().method() === 'POST' ? r.fulfill({ status: 429, contentType: 'application/json', body: JSON.stringify({ error: 'rate_limited', message: 'أرسلت رسائل كثيرة، انتظر قليلاً' }) }) : r.continue());
  await page.evaluate(() => window.DSQamar.ask('اختبار الحد'));
  await page.waitForFunction(() => /انتظر قليلاً/.test(document.querySelector('#ds-qamar-root').shadowRoot.querySelector('.msgs').innerText), null, { timeout: 8000 });
  ok(true, 'رسالة الحد من الخادم (429) تُعرض للمراجع');
  await page.unroute('**/api/v1/qamar');
  const errsBefore = errors.length;

  /* ---------- رد خادم خبيث: لا تنفيذ ولا روابط خطرة ---------- */
  const evil = {
    reply: {
      text: '<img src=x onerror="window.__pwned=1">مرحبا <script>window.__pwned=3</script>', source: 'llm', intent: 'service', chips: ['<b>x</b>'],
      actions: [{ type: 'book', label: '<b>حجز</b>', specialtyId: '"><script>window.__pwned=2</script>' },
        { type: 'call', number: 'javascript:alert(1)', label: 'اتصال خبيث' },
        { type: 'whatsapp', number: '123', label: 'قصير' },
        { type: 'nav', to: '../admin', label: 'تنقّل خارج' },
        { type: 'nav', to: 'doctors', label: 'الأطباء' },
        { type: 'script', label: 'x' }, { type: 'branch', id: 'q"onmouseover="window.__pwned=4', label: 'فرع' }]
    }
  };
  await page.route('**/api/v1/qamar', (r) => r.request().method() === 'POST' ? r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(evil) }) : r.continue());
  await page.evaluate(() => window.DSQamar.ask('اختبار أمان'));
  await page.waitForFunction(() => /onerror/.test(document.querySelector('#ds-qamar-root').shadowRoot.querySelector('.msgs').innerText), null, { timeout: 8000 });
  await sleep(300);
  const bad = await page.evaluate(() => {
    const sr = document.querySelector('#ds-qamar-root').shadowRoot;
    const bubble = [...sr.querySelectorAll('.m.bot:not(.typing)')].pop();
    return { pwned: window.__pwned, imgs: sr.querySelectorAll('.msgs img, .msgs script').length, text: bubble.querySelector('.t').textContent,
      hrefs: [...bubble.querySelectorAll('a')].map((a) => a.getAttribute('href')), labels: [...bubble.querySelectorAll('a')].map((a) => a.textContent.trim()),
      chip: [...sr.querySelectorAll('.qr button')].map((b) => b.textContent), src: !!bubble.querySelector('.src') };
  });
  ok(bad.pwned === undefined, 'لا يُنفَّذ أي كود قادم من الخادم');
  ok(bad.imgs === 0 && bad.text.includes('<img src=x onerror='), 'نص الرد يُعرض كنص خام لا كـ HTML');
  ok(bad.hrefs.length === 3, 'تُعرض فقط الإجراءات السليمة (3 من 7): ' + JSON.stringify(bad.hrefs));
  ok(bad.hrefs.every((h) => !/^javascript:/i.test(h)) && bad.hrefs.some((h) => h.startsWith(BASE + '/app/#/book?sp=%22%3E%3Cscript%3E')) && bad.hrefs.includes(BASE + '/app/#/doctors'), 'القيم تُرمَّز ولا روابط javascript:');
  ok(bad.labels.includes('<b>حجز</b>') && bad.chip.includes('<b>x</b>'), 'عناوين الأزرار والردود السريعة نص خام');
  ok(bad.src === true, 'ردود النموذج الذكي تحمل تنبيه «رد آلي»');
  await page.unroute('**/api/v1/qamar');
  errors.length = errsBefore;

  /* ---------- أزرار المواعيد التي يرتّبها قمر (slot): تُعرض سليمة وتُرفض المشوّهة ---------- */
  const slotReply = {
    reply: {
      text: 'هذه أقرب المواعيد المتاحة فعلياً في النظام.', source: 'kb', intent: 'booking', chips: [],
      actions: [
        { type: 'slot', doctorId: 'dr1', branchId: 'quba', day: '2026-11-24', start: '16:30', label: 'غداً 4:30 م', specialtyId: 'dental' },
        { type: 'slot', doctorId: 'dr1', day: 'غداً', start: '16:30', label: 'تاريخ مشوّه' },
        { type: 'slot', day: '2026-11-24', start: '16:30', label: 'بلا طبيب' },
        { type: 'slot', doctorId: 'dr2', day: '2026-11-24', start: 'x9:00', label: 'وقت مشوّه' },
        { type: 'slot', doctorId: '"><script>window.__pwned=9</script>', day: '2026-11-24', start: '17:00', label: 'قيمة خبيثة' }
      ]
    }
  };
  await page.route('**/api/v1/qamar', (r) => r.request().method() === 'POST' ? r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(slotReply) }) : r.continue());
  await page.evaluate(() => window.DSQamar.ask('اختبار المواعيد'));
  await page.waitForFunction(() => /أقرب المواعيد المتاحة/.test(document.querySelector('#ds-qamar-root').shadowRoot.querySelector('.msgs').innerText), null, { timeout: 8000 });
  await sleep(300);
  const sl = await page.evaluate(() => {
    const sr = document.querySelector('#ds-qamar-root').shadowRoot;
    const bubble = [...sr.querySelectorAll('.m.bot:not(.typing)')].pop();
    return { pwned: window.__pwned, scripts: sr.querySelectorAll('.msgs script').length,
      links: [...bubble.querySelectorAll('a.slot')].map((a) => ({ h: a.getAttribute('href'), t: a.textContent.trim(), tg: a.getAttribute('target'), rel: a.getAttribute('rel') })) };
  });
  ok(sl.links.length === 2, 'يُعرض زر موعد لكل إجراء سليم فقط (2 من 5): ' + JSON.stringify(sl.links.map((l) => l.t)));
  ok(sl.links[0] && sl.links[0].h === BASE + '/app/#/book?sp=dental&dr=dr1&br=quba&day=2026-11-24&t=16%3A30' && sl.links[0].t === 'غداً 4:30 م', 'زر الموعد يفتح صفحة الحجز معبّأة (الطبيب والفرع واليوم والوقت): ' + (sl.links[0] && sl.links[0].h));
  ok(sl.links.every((l) => l.tg === '_blank' && /noopener/.test(l.rel || '')), 'أزرار المواعيد تُفتح في تبويب جديد مع noopener');
  ok(sl.links[1] && !/<script/i.test(sl.links[1].h) && sl.links[1].h.includes('%3Cscript%3E') && sl.pwned === undefined && sl.scripts === 0, 'قيمة الطبيب الخبيثة تُرمَّز ولا تُنفَّذ');
  await page.unroute('**/api/v1/qamar');
  errors.length = errsBefore;

  /* ---------- جهة اليمين ---------- */
  const p2 = await ctx.newPage();
  await p2.goto(HOST + '/right', { waitUntil: 'load' });
  await p2.waitForSelector('#ds-qamar-root .fab', { state: 'visible', timeout: 8000 });
  const b2 = await p2.locator('#ds-qamar-root .fab').boundingBox();
  ok(b2.x > 900, 'data-side="right": الأيقونة أسفل اليمين (x=' + Math.round(b2.x) + ')');
  await p2.close();

  /* ---------- جوال ---------- */
  const mctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, locale: 'ar-SA' });
  const mp = await mctx.newPage();
  mp.on('pageerror', (e) => errors.push('mobile pageerror: ' + e.message));
  await mp.goto(HOST + '/', { waitUntil: 'load' });
  await mp.waitForSelector('#ds-qamar-root .fab', { state: 'visible' });
  await mp.tap('#ds-qamar-root .fab');
  await mp.locator('#ds-qamar-root .panel').waitFor({ state: 'visible' });
  const pb = await mp.locator('#ds-qamar-root .panel').boundingBox();
  ok(Math.round(pb.width) === 390 && Math.round(pb.y + pb.height) === 844, 'الجوال: النافذة تملأ العرض كاملاً من الأسفل (' + Math.round(pb.width) + '×' + Math.round(pb.height) + ')');
  ok(await mp.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), 'الجوال: لا تمرير أفقي');
  await mp.fill('#ds-qamar-root textarea', 'وش التخصصات');
  await mp.tap('#ds-qamar-root .send');
  await mp.waitForSelector('#ds-qamar-root .m.bot:not(.typing) .act', { timeout: 8000 });
  await shot('w05-widget-mobile', mp);
  await mctx.close();

  /* ---------- تعطيل قمر من الإدارة يُخفي الويدجت ---------- */
  const tok = await adminToken();
  ok(await setQamarEnabled(tok, false) === 200, 'الإدارة تعطّل قمر');
  const cr2 = await fetch(BASE + '/api/v1/qamar/config');
  ok((await cr2.json()).enabled === false, 'الإعدادات تعكس التعطيل');
  const c3 = await browser.newContext({ viewport: { width: 1280, height: 800 } });   // سياق جديد: ذاكرة تخزين مؤقتة فارغة (الإعدادات تُخزَّن دقيقتين)
  const p3 = await c3.newPage();
  await p3.goto(HOST + '/', { waitUntil: 'load' });
  await sleep(1500);
  ok(await p3.locator('#ds-qamar-root').count() === 0, 'قمر معطّل: لا يظهر شيء في صفحة الموقع');
  await c3.close();
  ok(await setQamarEnabled(tok, true) === 200, 'تمت إعادة تفعيل قمر');

  /* ---------- الخادم غير متاح: لا يظهر شيء ولا يكسر الصفحة ---------- */
  const p4 = await ctx.newPage();
  const e4 = [];
  p4.on('pageerror', (e) => e4.push(e.message));
  await p4.route('**/api/v1/qamar/config', (r) => r.abort('failed'));
  await p4.goto(HOST + '/', { waitUntil: 'load' });
  await sleep(1200);
  ok(await p4.locator('#ds-qamar-root').count() === 0 && e4.length === 0, 'تعذّر جلب الإعدادات: لا يظهر شيء ولا أخطاء في الصفحة');
  await p4.close();

  const real = errors.filter((e) => !/net::ERR_FAILED|Failed to load resource/.test(e));
  ok(real.length === 0, 'لا أخطاء جافاسكربت في أي صفحة ' + (real.length ? JSON.stringify(real) : ''));
  await browser.close();
  hostSrv.close();
  console.log('\nالنتيجة: ' + passes + ' ناجح، ' + fails + ' فاشل');
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error('خطأ في الاختبار:', e); process.exit(2); });
