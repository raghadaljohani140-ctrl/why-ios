"""طبقة SQLite: جداول عامة للكيانات (فروع، أطباء...) + حجوزات + أجهزة + إشعارات + سجلات. بدون اعتماديات."""
import hashlib
import json
import secrets
import sqlite3
import threading
import time
from contextlib import contextmanager
from pathlib import Path

from scheddb import SchedDB
from util import riyadh_today

KINDS = ("branches", "specialties", "services", "doctors", "faqs", "banners")

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS entities(
  kind TEXT NOT NULL, id TEXT NOT NULL, data TEXT NOT NULL,
  sort INTEGER NOT NULL DEFAULT 100, active INTEGER NOT NULL DEFAULT 1, updated_at TEXT NOT NULL,
  PRIMARY KEY(kind,id));
CREATE INDEX IF NOT EXISTS ix_entities_kind ON entities(kind, active, sort);
CREATE TABLE IF NOT EXISTS kv(key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS bookings(
  id TEXT PRIMARY KEY, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'new',
  name TEXT NOT NULL, phone TEXT NOT NULL, device_id TEXT NOT NULL,
  specialty_id TEXT, doctor_id TEXT, branch_id TEXT, service_id TEXT,
  date TEXT, period TEXT, note TEXT, source TEXT, admin_note TEXT, appointment_text TEXT);
CREATE INDEX IF NOT EXISTS ix_bookings_device ON bookings(device_id, created_at);
CREATE INDEX IF NOT EXISTS ix_bookings_status ON bookings(status, created_at);
CREATE TABLE IF NOT EXISTS devices(
  id TEXT PRIMARY KEY, created_at TEXT NOT NULL, last_seen TEXT NOT NULL, platform TEXT, push_token TEXT);
CREATE TABLE IF NOT EXISTS notifications(
  id INTEGER PRIMARY KEY AUTOINCREMENT, target TEXT NOT NULL DEFAULT 'all', title TEXT NOT NULL, body TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'info', ref TEXT, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_notif_target ON notifications(target, id);
CREATE TABLE IF NOT EXISTS qamar_log(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, device_hash TEXT, question TEXT, intent TEXT,
  confident INTEGER, used_llm INTEGER, source TEXT);
CREATE TABLE IF NOT EXISTS usage(day TEXT NOT NULL, key TEXT NOT NULL, n INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(day,key));
CREATE TABLE IF NOT EXISTS patients(
  id TEXT PRIMARY KEY, phone TEXT NOT NULL UNIQUE, name TEXT NOT NULL, gender TEXT, birth_date TEXT, national_id TEXT,
  created_at TEXT NOT NULL, last_login TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS otps(
  phone TEXT PRIMARY KEY, code_hash TEXT NOT NULL, expires INTEGER NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, created INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS patient_files(
  id TEXT PRIMARY KEY, phone TEXT NOT NULL, kind TEXT NOT NULL, title TEXT NOT NULL, note TEXT, size INTEGER NOT NULL, sha256 TEXT NOT NULL,
  uploaded_by TEXT NOT NULL, uploaded_at TEXT NOT NULL, updated_by TEXT, updated_at TEXT, deleted_by TEXT, deleted_at TEXT);
CREATE INDEX IF NOT EXISTS ix_pfiles_phone ON patient_files(phone, deleted_at);
CREATE TABLE IF NOT EXISTS records(
  mrn TEXT PRIMARY KEY, name TEXT NOT NULL, phone TEXT NOT NULL, national_id TEXT, birth_date TEXT, gender TEXT,
  source TEXT NOT NULL DEFAULT 'manual', created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_records_phone ON records(phone);
CREATE TABLE IF NOT EXISTS record_links(
  patient_id TEXT NOT NULL, mrn TEXT NOT NULL, linked_at TEXT NOT NULL, PRIMARY KEY(patient_id, mrn));
CREATE INDEX IF NOT EXISTS ix_links_mrn ON record_links(mrn);
CREATE TABLE IF NOT EXISTS audit(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, who TEXT, action TEXT, kind TEXT, ref TEXT, detail TEXT);
CREATE TABLE IF NOT EXISTS staff(
  id TEXT PRIMARY KEY, username TEXT NOT NULL UNIQUE COLLATE NOCASE, name TEXT NOT NULL, role TEXT NOT NULL, branch_id TEXT,
  pw TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, must_change INTEGER NOT NULL DEFAULT 1,
  failed INTEGER NOT NULL DEFAULT 0, locked_until INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL, created_by TEXT, last_login TEXT);
CREATE TABLE IF NOT EXISTS visits(
  id TEXT PRIMARY KEY, day TEXT NOT NULL, branch_id TEXT, doctor_id TEXT NOT NULL, mrn TEXT NOT NULL, patient_name TEXT NOT NULL,
  booking_id TEXT, reason TEXT, status TEXT NOT NULL DEFAULT 'waiting', queue_no INTEGER NOT NULL,
  arrived_at TEXT NOT NULL, updated_at TEXT NOT NULL, called_at TEXT, finished_at TEXT, created_by TEXT NOT NULL, updated_by TEXT, left_at TEXT);
CREATE INDEX IF NOT EXISTS ix_visits_day ON visits(day, branch_id, doctor_id);
CREATE INDEX IF NOT EXISTS ix_visits_mrn ON visits(mrn, day);
CREATE TABLE IF NOT EXISTS encounters(
  id TEXT PRIMARY KEY, visit_id TEXT NOT NULL UNIQUE, mrn TEXT NOT NULL, doctor_id TEXT NOT NULL,
  complaint TEXT, diagnosis TEXT, notes TEXT, advice TEXT, follow_up TEXT,
  rx TEXT NOT NULL DEFAULT '[]', orders TEXT NOT NULL DEFAULT '[]', publish INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL, finished_at TEXT, created_by TEXT, updated_by TEXT);
CREATE INDEX IF NOT EXISTS ix_enc_mrn ON encounters(mrn, finished_at);
CREATE TABLE IF NOT EXISTS orders(
  id TEXT PRIMARY KEY, visit_id TEXT NOT NULL, mrn TEXT NOT NULL, patient_name TEXT NOT NULL, doctor_id TEXT NOT NULL, branch_id TEXT,
  kind TEXT NOT NULL, name TEXT NOT NULL, note TEXT, status TEXT NOT NULL DEFAULT 'sent', seq INTEGER NOT NULL, day TEXT NOT NULL,
  sent_at TEXT NOT NULL, sent_by TEXT NOT NULL, started_at TEXT, started_by TEXT,
  result_rows TEXT NOT NULL DEFAULT '[]', result_text TEXT, resulted_at TEXT, resulted_by TEXT, done_day TEXT,
  reviewed_at TEXT, reviewed_by TEXT, released INTEGER NOT NULL DEFAULT 0,
  cancelled_at TEXT, cancelled_by TEXT, cancel_reason TEXT, updated_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_orders_unit ON orders(kind, status, branch_id);
CREATE INDEX IF NOT EXISTS ix_orders_visit ON orders(visit_id);
CREATE INDEX IF NOT EXISTS ix_orders_mrn ON orders(mrn, sent_at);
CREATE INDEX IF NOT EXISTS ix_orders_doctor ON orders(doctor_id, status);
CREATE TABLE IF NOT EXISTS schedules(
  id INTEGER PRIMARY KEY AUTOINCREMENT, doctor_id TEXT NOT NULL, branch_id TEXT NOT NULL, weekday INTEGER NOT NULL,
  start_min INTEGER NOT NULL, end_min INTEGER NOT NULL, slot_min INTEGER NOT NULL DEFAULT 20, updated_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_sched_doc ON schedules(doctor_id, weekday);
CREATE TABLE IF NOT EXISTS schedule_days(
  id INTEGER PRIMARY KEY AUTOINCREMENT, doctor_id TEXT NOT NULL, branch_id TEXT NOT NULL DEFAULT '', day TEXT NOT NULL, kind TEXT NOT NULL,
  start_min INTEGER, end_min INTEGER, slot_min INTEGER, note TEXT, updated_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_sched_days ON schedule_days(doctor_id, day);
"""

BOOKING_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"


def now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def today():
    return time.strftime("%Y-%m-%d", time.gmtime())


def canon(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


class DB(SchedDB):
    def __init__(self, path):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        self.conn().executescript(SCHEMA_SQL)
        self._migrate()

    def conn(self):
        c = getattr(self._local, "c", None)
        if c is None:
            c = sqlite3.connect(self.path, timeout=15, isolation_level=None)
            c.row_factory = sqlite3.Row
            c.execute("PRAGMA journal_mode=WAL")
            c.execute("PRAGMA synchronous=NORMAL")
            c.execute("PRAGMA busy_timeout=15000")
            self._local.c = c
        return c

    def _migrate(self):
        """ترقيات خفيفة لقواعد قائمة (آمنة للتكرار)."""
        c = self.conn()
        if "doctor_id" not in {r["name"] for r in c.execute("PRAGMA table_info(staff)")}:
            c.execute("ALTER TABLE staff ADD COLUMN doctor_id TEXT")   # حساب الطبيب يرتبط بسجله في قائمة الأطباء
        if "left_at" not in {r["name"] for r in c.execute("PRAGMA table_info(visits)")}:
            c.execute("ALTER TABLE visits ADD COLUMN left_at TEXT")    # وقت مغادرة المراجع (يسجله الاستقبال)
        bcols = {r["name"] for r in c.execute("PRAGMA table_info(bookings)")}
        for col, typ in (("slot_start", "INTEGER"), ("slot_min", "INTEGER"), ("pay_status", "TEXT"), ("pay_amount", "INTEGER"), ("pay_ref", "TEXT"), ("hold_until", "TEXT")):
            if col not in bcols:
                c.execute("ALTER TABLE bookings ADD COLUMN %s %s" % (col, typ))    # 0.10.0: الحجز بموعد محدد (والدفع المسبق: مهلة حجز مؤقت)
        c.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_booking_slot ON bookings(doctor_id, date, slot_start) "
                  "WHERE slot_start IS NOT NULL AND status IN ('new','contacted','confirmed')")
        c.execute("CREATE INDEX IF NOT EXISTS ix_bookings_slot ON bookings(doctor_id, date)")
        cols = {r["name"] for r in c.execute("PRAGMA table_info(patient_files)")}
        if "mrn" not in cols:
            c.execute("ALTER TABLE patient_files ADD COLUMN mrn TEXT")
            c.execute("CREATE INDEX IF NOT EXISTS ix_pfiles_mrn ON patient_files(mrn, deleted_at)")
            # ملفات 0.5.0 كانت مربوطة بالجوال: نُنشئ لكل رقم سجلاً مؤقتاً (يراجعه الموظف) ونربط ملفاته به
            for r in c.execute("SELECT DISTINCT phone FROM patient_files WHERE mrn IS NULL").fetchall():
                pt = c.execute("SELECT * FROM patients WHERE phone=?", (r["phone"],)).fetchone()
                mrn = "LEGACY-" + r["phone"][-9:]
                t = now()
                c.execute("INSERT OR IGNORE INTO records(mrn,name,phone,national_id,birth_date,gender,source,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",
                          (mrn, pt["name"] if pt else "مراجع (يلزم تحديث البيانات)", r["phone"], pt["national_id"] if pt else None, pt["birth_date"] if pt else None,
                           pt["gender"] if pt else None, "legacy", t, t))
                c.execute("UPDATE patient_files SET mrn=? WHERE phone=? AND mrn IS NULL", (mrn, r["phone"]))

    @contextmanager
    def tx(self):
        c = self.conn()
        c.execute("BEGIN IMMEDIATE")
        try:
            yield c
            c.execute("COMMIT")
        except BaseException:
            c.execute("ROLLBACK")
            raise

    # ------------------------------------------------------------------ kv
    def get_kv(self, key, default=None):
        r = self.conn().execute("SELECT value FROM kv WHERE key=?", (key,)).fetchone()
        return json.loads(r["value"]) if r else default

    def set_kv(self, key, value):
        with self.tx() as c:
            c.execute("INSERT INTO kv(key,value,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
                      (key, json.dumps(value, ensure_ascii=False), now()))

    def is_seeded(self):
        return self.get_kv("settings") is not None

    # ------------------------------------------------------------------ كيانات
    @staticmethod
    def _row_entity(r):
        d = json.loads(r["data"])
        d["id"] = r["id"]
        d["sort"] = r["sort"]
        d["active"] = bool(r["active"])
        return d

    def list_entities(self, kind, include_inactive=False):
        q = "SELECT * FROM entities WHERE kind=?" + ("" if include_inactive else " AND active=1") + " ORDER BY sort, id"
        return [self._row_entity(r) for r in self.conn().execute(q, (kind,))]

    def get_entity(self, kind, eid):
        r = self.conn().execute("SELECT * FROM entities WHERE kind=? AND id=?", (kind, eid)).fetchone()
        return self._row_entity(r) if r else None

    def ids(self, kind):
        return {r["id"] for r in self.conn().execute("SELECT id FROM entities WHERE kind=?", (kind,))}

    def upsert_entity(self, kind, data, who="system"):
        eid = data["id"]
        sort = int(data.get("sort") if data.get("sort") is not None else 100)
        active = 1 if data.get("active", True) else 0
        payload = {k: v for k, v in data.items() if k not in ("id", "sort", "active")}
        existed = self.get_entity(kind, eid) is not None
        with self.tx() as c:
            c.execute("INSERT INTO entities(kind,id,data,sort,active,updated_at) VALUES(?,?,?,?,?,?) "
                      "ON CONFLICT(kind,id) DO UPDATE SET data=excluded.data, sort=excluded.sort, active=excluded.active, updated_at=excluded.updated_at",
                      (kind, eid, json.dumps(payload, ensure_ascii=False), sort, active, now()))
            c.execute("INSERT INTO audit(ts,who,action,kind,ref,detail) VALUES(?,?,?,?,?,?)",
                      (now(), who, "update" if existed else "create", kind, eid, ""))
        self._bump()
        return self.get_entity(kind, eid)

    def delete_entity(self, kind, eid, hard=False, who="system"):
        e = self.get_entity(kind, eid)
        if not e:
            return False
        with self.tx() as c:
            if hard:
                c.execute("DELETE FROM entities WHERE kind=? AND id=?", (kind, eid))
            else:
                c.execute("UPDATE entities SET active=0, updated_at=? WHERE kind=? AND id=?", (now(), kind, eid))
            c.execute("INSERT INTO audit(ts,who,action,kind,ref,detail) VALUES(?,?,?,?,?,?)",
                      (now(), who, "delete" if hard else "hide", kind, eid, json.dumps(e, ensure_ascii=False)[:2000] if hard else ""))
        self._bump()
        return True

    def _bump(self):
        v = int(self.get_kv("dataVersion", 0) or 0) + 1
        self.set_kv("dataVersion", v)

    # ------------------------------------------------------------------ تهيئة من ملف seed
    def seed(self, seed, who="seed"):
        with self.tx() as c:
            for kind in KINDS:
                for e in seed.get(kind, []):
                    e = dict(e)
                    eid = e["id"]
                    sort = int(e.get("sort", 100))
                    active = 1 if e.get("active", True) else 0
                    payload = {k: v for k, v in e.items() if k not in ("id", "sort", "active")}
                    c.execute("INSERT OR IGNORE INTO entities(kind,id,data,sort,active,updated_at) VALUES(?,?,?,?,?,?)",
                              (kind, eid, json.dumps(payload, ensure_ascii=False), sort, active, now()))
            c.execute("INSERT OR IGNORE INTO kv(key,value,updated_at) VALUES('settings',?,?)", (json.dumps(seed.get("settings", {}), ensure_ascii=False), now()))
            c.execute("INSERT OR IGNORE INTO kv(key,value,updated_at) VALUES('qamar',?,?)", (json.dumps(seed.get("qamar", {}), ensure_ascii=False), now()))
            c.execute("INSERT OR IGNORE INTO kv(key,value,updated_at) VALUES('meta',?,?)", (json.dumps(seed.get("meta", {}), ensure_ascii=False), now()))
            c.execute("INSERT OR IGNORE INTO kv(key,value,updated_at) VALUES('dataVersion','1',?)", (now(),))
            c.execute("INSERT INTO audit(ts,who,action,kind,ref,detail) VALUES(?,?,?,?,?,?)", (now(), who, "seed", "", "", ""))

    # ------------------------------------------------------------------ مجموعة البيانات
    def dataset(self, public=True):
        ds = {"meta": {"version": int(self.get_kv("dataVersion", 1) or 1)},
              "settings": dict(self.get_kv("settings", {}) or {}),
              "qamar": dict(self.get_kv("qamar", {}) or {})}
        for kind in KINDS:
            items = self.list_entities(kind, include_inactive=not public)
            if public:
                items = [{k: v for k, v in e.items() if k not in ("needsReview", "active")} for e in items]
            ds[kind] = items
        if public:
            ds["settings"].pop("reviewNotes", None)
            if not ds["settings"].get("email"):
                ds["settings"]["email"] = ""
            ds["qamar"].pop("extraInstructions", None)
        return ds

    def etag(self, ds):
        return '"' + hashlib.sha256(canon(ds).encode("utf-8")).hexdigest()[:24] + '"'

    # ------------------------------------------------------------------ حجوزات
    def new_booking_id(self):
        for _ in range(20):
            bid = "DS-" + "".join(secrets.choice(BOOKING_ALPHABET) for _ in range(6))
            if not self.conn().execute("SELECT 1 FROM bookings WHERE id=?", (bid,)).fetchone():
                return bid
        raise RuntimeError("could not allocate booking id")

    def create_booking(self, rec):
        bid = self.new_booking_id()
        t = now()
        with self.tx() as c:
            c.execute("INSERT INTO bookings(id,created_at,updated_at,status,name,phone,device_id,specialty_id,doctor_id,branch_id,service_id,date,period,note,source) "
                      "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (bid, t, t, "new", rec["name"], rec["phone"], rec["device_id"], rec.get("specialty_id"), rec.get("doctor_id"),
                       rec.get("branch_id"), rec.get("service_id"), rec.get("date"), rec.get("period"), rec.get("note", ""), rec.get("source", "app")))
        return self.get_booking(bid)

    def get_booking(self, bid):
        r = self.conn().execute("SELECT * FROM bookings WHERE id=?", (bid,)).fetchone()
        return dict(r) if r else None

    def list_bookings(self, device_id=None, status=None, q=None, limit=300):
        sql, args = "SELECT * FROM bookings WHERE 1=1", []
        if device_id:
            sql += " AND device_id=?"
            args.append(device_id)
        if status:
            sql += " AND status=?"
            args.append(status)
        if q:
            sql += " AND (id LIKE ? OR name LIKE ? OR phone LIKE ?)"
            args += ["%" + q + "%"] * 3
        sql += " ORDER BY created_at DESC LIMIT ?"
        args.append(int(limit))
        return [dict(r) for r in self.conn().execute(sql, args)]

    def update_booking(self, bid, **fields):
        allowed = {"status", "admin_note", "appointment_text"}
        sets = {k: v for k, v in fields.items() if k in allowed}
        if not sets:
            return self.get_booking(bid)
        cols = ", ".join(f"{k}=?" for k in sets)
        # حجز موعد ينتظر الدفع: إلغاؤه يُنهي انتظار الدفع، وتأكيده من الإدارة يُسقط شرط الدفع (دُفع عند الاستقبال مثلاً)
        st = sets.get("status")
        if st == "cancelled":
            cols += ", pay_status=CASE WHEN pay_status='pending' THEN 'cancelled' ELSE pay_status END, hold_until=CASE WHEN pay_status='pending' THEN NULL ELSE hold_until END"
        elif st == "confirmed":
            cols += ", pay_status=CASE WHEN pay_status='pending' THEN 'waived' ELSE pay_status END, hold_until=CASE WHEN pay_status='pending' THEN NULL ELSE hold_until END"
        with self.tx() as c:
            c.execute(f"UPDATE bookings SET {cols}, updated_at=? WHERE id=?", (*sets.values(), now(), bid))
        return self.get_booking(bid)

    def count_recent_bookings(self, device_id, hours=24):
        since = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - hours * 3600))
        r = self.conn().execute("SELECT COUNT(*) n FROM bookings WHERE device_id=? AND created_at>=?", (device_id, since)).fetchone()
        return r["n"]

    def booking_stats(self):
        out = {s: 0 for s in ("new", "contacted", "confirmed", "cancelled")}
        for r in self.conn().execute("SELECT status, COUNT(*) n FROM bookings GROUP BY status"):
            out[r["status"]] = r["n"]
        return out

    # ------------------------------------------------------------------ أجهزة وإشعارات
    def upsert_device(self, device_id, platform="", push_token=""):
        t = now()
        with self.tx() as c:
            c.execute("INSERT INTO devices(id,created_at,last_seen,platform,push_token) VALUES(?,?,?,?,?) "
                      "ON CONFLICT(id) DO UPDATE SET last_seen=excluded.last_seen, platform=CASE WHEN excluded.platform!='' THEN excluded.platform ELSE platform END, "
                      "push_token=CASE WHEN excluded.push_token!='' THEN excluded.push_token ELSE push_token END",
                      (device_id, t, t, platform or "", push_token or ""))

    def push_tokens(self, target="all", limit=500):
        if target == "all":
            rows = self.conn().execute("SELECT push_token FROM devices WHERE push_token!='' ORDER BY last_seen DESC LIMIT ?", (limit,))
        else:
            rows = self.conn().execute("SELECT push_token FROM devices WHERE id=? AND push_token!=''", (target,))
        return [r["push_token"] for r in rows]

    def delete_device_data(self, device_id):
        with self.tx() as c:
            c.execute("UPDATE bookings SET name='(محذوف)', phone='', note='', device_id=? WHERE device_id=?", ("deleted-" + secrets.token_hex(4), device_id))
            c.execute("DELETE FROM notifications WHERE target=?", (device_id,))
            c.execute("DELETE FROM devices WHERE id=?", (device_id,))

    # ------------------------------------------------------------------ مرضى مسجّلون (حساب بالجوال + رمز تحقق)
    def otp_put(self, phone, code_hash, ttl):
        t = int(time.time())
        with self.tx() as c:
            c.execute("INSERT OR REPLACE INTO otps(phone,code_hash,expires,attempts,created) VALUES(?,?,?,0,?)", (phone, code_hash, t + ttl, t))

    def otp_get(self, phone):
        r = self.conn().execute("SELECT * FROM otps WHERE phone=?", (phone,)).fetchone()
        return dict(r) if r else None

    def otp_fail(self, phone):
        with self.tx() as c:
            c.execute("UPDATE otps SET attempts=attempts+1 WHERE phone=?", (phone,))

    def otp_clear(self, phone):
        with self.tx() as c:
            c.execute("DELETE FROM otps WHERE phone=?", (phone,))

    def patient_by_phone(self, phone):
        r = self.conn().execute("SELECT * FROM patients WHERE phone=?", (phone,)).fetchone()
        return dict(r) if r else None

    def patient_by_id(self, pid):
        r = self.conn().execute("SELECT * FROM patients WHERE id=?", (pid,)).fetchone()
        return dict(r) if r else None

    def patient_create(self, phone, name, gender, birth_date, national_id):
        pid = "pt-" + secrets.token_hex(6)
        t = now()
        with self.tx() as c:
            c.execute("INSERT INTO patients(id,phone,name,gender,birth_date,national_id,created_at,last_login) VALUES(?,?,?,?,?,?,?,?)",
                      (pid, phone, name, gender, birth_date, national_id, t, t))
        return self.patient_by_id(pid)

    def patient_touch(self, pid):
        with self.tx() as c:
            c.execute("UPDATE patients SET last_login=? WHERE id=?", (now(), pid))

    def patient_update(self, pid, name, gender, birth_date, national_id):
        with self.tx() as c:
            c.execute("UPDATE patients SET name=?, gender=?, birth_date=?, national_id=? WHERE id=?", (name, gender, birth_date, national_id, pid))
        return self.patient_by_id(pid)

    def patient_delete(self, pid):
        """حذف الحساب: يمحو بيانات المريض، وتُجهَّل طلبات الحجز المرتبطة برقمه (مثل «حذف بياناتي»)."""
        p = self.patient_by_id(pid)
        if not p:
            return
        with self.tx() as c:
            c.execute("UPDATE bookings SET name='(محذوف)', phone='', note='', device_id=? WHERE phone=?", ("deleted-" + secrets.token_hex(4), p["phone"]))
            c.execute("DELETE FROM patients WHERE id=?", (pid,))
            c.execute("DELETE FROM record_links WHERE patient_id=?", (pid,))
            c.execute("DELETE FROM notifications WHERE target=?", ("pt:" + pid,))
            c.execute("DELETE FROM otps WHERE phone=?", (p["phone"],))

    # ------------------------------------------------------------------ ملفات المرضى (PDF يرفعها الموظفون يدوياً)
    def audit(self, who, action, kind="", ref="", detail=""):
        with self.tx() as c:
            c.execute("INSERT INTO audit(ts,who,action,kind,ref,detail) VALUES(?,?,?,?,?,?)", (now(), who, action, kind, ref, detail))

    # ------------------------------------------------------------------ موظفو المنظومة (حسابات وأدوار)
    def staff_get(self, sid=None, username=None):
        if sid:
            r = self.conn().execute("SELECT * FROM staff WHERE id=?", (sid,)).fetchone()
        else:
            r = self.conn().execute("SELECT * FROM staff WHERE username=? COLLATE NOCASE", (username or "",)).fetchone()
        if not r:
            return None
        d = dict(r)
        d["pw"] = json.loads(d["pw"])
        return d

    def staff_list(self):
        rows = [dict(r) for r in self.conn().execute("SELECT * FROM staff ORDER BY active DESC, role, name")]
        for d in rows:
            d.pop("pw", None)
        return rows

    def staff_for_doctor(self, doctor_id, exclude_sid=None):
        """حساب الطبيب الفعّال المرتبط بهذا السجل (حساب واحد لكل طبيب)."""
        r = self.conn().execute("SELECT id, username FROM staff WHERE doctor_id=? AND active=1 AND role='doctor' AND id<>? LIMIT 1", (doctor_id, exclude_sid or "")).fetchone()
        return dict(r) if r else None

    def staff_create(self, username, name, role, branch_id, pw, by, doctor_id=None):
        sid = "s-" + secrets.token_hex(5)
        with self.tx() as c:
            c.execute("INSERT INTO staff(id,username,name,role,branch_id,pw,created_at,created_by,doctor_id) VALUES(?,?,?,?,?,?,?,?,?)",
                      (sid, username, name, role, branch_id or None, json.dumps(pw), now(), by, doctor_id or None))
        return self.staff_get(sid)

    def staff_update(self, sid, **f):
        allowed = {"name", "role", "branch_id", "doctor_id", "active", "must_change", "failed", "locked_until", "last_login"}
        sets = {k: v for k, v in f.items() if k in allowed}
        if "pw" in f:
            sets["pw"] = json.dumps(f["pw"])
        if not sets:
            return self.staff_get(sid)
        with self.tx() as c:
            c.execute("UPDATE staff SET " + ", ".join(k + "=?" for k in sets) + " WHERE id=?", (*sets.values(), sid))
        return self.staff_get(sid)

    # ------------------------------------------------------------------ الزيارات وقوائم الانتظار
    ACTIVE_VISIT = ("waiting", "ready", "with_doctor")

    def visit_get(self, vid):
        r = self.conn().execute("SELECT * FROM visits WHERE id=?", (vid,)).fetchone()
        return dict(r) if r else None

    def visits_list(self, day, branch_id=None):
        sql, args = "SELECT * FROM visits WHERE day=?", [day]
        if branch_id:
            sql += " AND branch_id=?"
            args.append(branch_id)
        return [dict(r) for r in self.conn().execute(sql + " ORDER BY doctor_id, queue_no", args)]

    def visit_active_for(self, mrn, day):
        r = self.conn().execute("SELECT * FROM visits WHERE mrn=? COLLATE NOCASE AND day=? AND status IN ('waiting','ready','with_doctor')", (mrn, day)).fetchone()
        return dict(r) if r else None

    @staticmethod
    def _visit_insert(c, day, branch_id, doctor_id, rec, booking_id, reason, by, status="waiting", called=None):
        """يُدرج زيارة برقم الطابور التالي لطبيب اليوم داخل معاملة قائمة (c). ValueError('duplicate:<vid>') إن كان للمراجع زيارة جارية اليوم."""
        vid = "v-" + secrets.token_hex(6)
        dup = c.execute("SELECT id FROM visits WHERE mrn=? COLLATE NOCASE AND day=? AND status IN ('waiting','ready','with_doctor')", (rec["mrn"], day)).fetchone()
        if dup:
            raise ValueError("duplicate:" + dup["id"])
        n = c.execute("SELECT COALESCE(MAX(queue_no),0)+1 FROM visits WHERE day=? AND doctor_id=?", (day, doctor_id)).fetchone()[0]
        t = now()
        c.execute("INSERT INTO visits(id,day,branch_id,doctor_id,mrn,patient_name,booking_id,reason,status,queue_no,arrived_at,called_at,updated_at,created_by,updated_by) "
                  "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                  (vid, day, branch_id, doctor_id, rec["mrn"], rec["name"], booking_id, reason, status, n, t, called, t, by, by if status != "waiting" else None))
        return vid

    def visit_create(self, day, branch_id, doctor_id, rec, booking_id, reason, by):
        """يعطي الرقم التالي في طابور الطبيب لليوم داخل معاملة واحدة (لا يتكرر رقمان)."""
        with self.tx() as c:
            vid = self._visit_insert(c, day, branch_id, doctor_id, rec, booking_id, reason, by)
        return self.visit_get(vid)

    def visit_update(self, vid, by, **f):
        allowed = {"status", "doctor_id", "queue_no", "called_at", "finished_at", "left_at"}
        sets = {k: v for k, v in f.items() if k in allowed}
        sets.update({"updated_at": now(), "updated_by": by})
        with self.tx() as c:
            if "doctor_id" in sets and "queue_no" not in sets:
                v = self.visit_get(vid)
                sets["queue_no"] = c.execute("SELECT COALESCE(MAX(queue_no),0)+1 FROM visits WHERE day=? AND doctor_id=?", (v["day"], sets["doctor_id"])).fetchone()[0]
            c.execute("UPDATE visits SET " + ", ".join(k + "=?" for k in sets) + " WHERE id=?", (*sets.values(), vid))
        return self.visit_get(vid)

    def visit_call(self, vid, by):
        """الطبيب يستدعي مراجعه: فحص «لا مراجع آخر عنده» والتحويل إلى عند الطبيب في معاملة واحدة، فلا يدخل اثنان معاً.
        ValueError('busy') عنده مراجع آخر؛ ValueError('state') الحالة لا تسمح. الاستدعاء المتكرر لمن عند الطبيب أصلاً يعيده كما هو."""
        t = now()
        with self.tx() as c:
            v = c.execute("SELECT * FROM visits WHERE id=?", (vid,)).fetchone()
            if not v or v["status"] not in ("waiting", "ready", "with_doctor"):
                raise ValueError("state")
            if v["status"] != "with_doctor":
                if c.execute("SELECT 1 FROM visits WHERE doctor_id=? AND day=? AND status='with_doctor' AND id<>? LIMIT 1", (v["doctor_id"], v["day"], vid)).fetchone():
                    raise ValueError("busy")
                c.execute("UPDATE visits SET status='with_doctor', called_at=COALESCE(NULLIF(called_at,''),?), updated_at=?, updated_by=? WHERE id=?", (t, t, by, vid))
        return self.visit_get(vid)

    # ------------------------------------------------------------------ الزيارة السريرية: تشخيص، وصفة، طلبات (يكتبها الطبيب)
    ENC_TEXT = ("complaint", "diagnosis", "notes", "advice", "follow_up")

    @staticmethod
    def _enc(r):
        if not r:
            return None
        d = dict(r)
        d["rx"], d["orders"] = json.loads(d["rx"] or "[]"), json.loads(d["orders"] or "[]")
        d["publish"] = bool(d["publish"])
        return d

    def enc_get(self, vid):
        return self._enc(self.conn().execute("SELECT * FROM encounters WHERE visit_id=?", (vid,)).fetchone())

    @staticmethod
    def _enc_insert(c, vid, mrn, doctor_id, complaint, by):
        if not c.execute("SELECT 1 FROM encounters WHERE visit_id=?", (vid,)).fetchone():
            t = now()
            c.execute("INSERT INTO encounters(id,visit_id,mrn,doctor_id,complaint,created_at,updated_at,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?,?)",
                      ("e-" + secrets.token_hex(6), vid, mrn, doctor_id, complaint or "", t, t, by, by))

    def enc_ensure(self, visit, by):
        """مسودة سريرية واحدة لكل زيارة؛ الشكوى تبدأ بسبب الزيارة الذي كتبه الاستقبال."""
        with self.tx() as c:
            self._enc_insert(c, visit["id"], visit["mrn"], visit["doctor_id"], visit.get("reason") or "", by)
        return self.enc_get(visit["id"])

    def enc_save(self, vid, by, f, finish=False):
        """يحفظ المسودة؛ ومع finish ينهي الزيارة والمسودة معاً في معاملة واحدة، وتُرسَل طلبات التحاليل والأشعة إلى أقسامها في المعاملة نفسها
        (فلا تنتهي زيارة بلا طلباتها ولا تُرسل طلبات لزيارة لم تنتهِ). المنتهية لا تُعدَّل (ValueError('locked'))."""
        sets = {k: f[k] for k in self.ENC_TEXT if k in f}
        for k in ("rx", "orders"):
            if k in f:
                sets[k] = json.dumps(f[k], ensure_ascii=False)
        if "publish" in f:
            sets["publish"] = 1 if f["publish"] else 0
        t = now()
        sets["updated_at"], sets["updated_by"] = t, by
        if finish:
            sets["finished_at"] = t
        with self.tx() as c:
            v = c.execute("SELECT * FROM visits WHERE id=?", (vid,)).fetchone()
            if not v or v["status"] != "with_doctor":
                raise ValueError("state")
            if finish:
                e = c.execute("SELECT orders FROM encounters WHERE visit_id=? AND finished_at IS NULL", (vid,)).fetchone()
                if not e:
                    raise ValueError("locked")
                drafts = f["orders"] if "orders" in f else json.loads(e["orders"] or "[]")
                sets["orders"] = json.dumps(self._send_orders(c, v, drafts, by, t), ensure_ascii=False)
            cur = c.execute("UPDATE encounters SET " + ", ".join(k + "=?" for k in sets) + " WHERE visit_id=? AND finished_at IS NULL", (*sets.values(), vid))
            if cur.rowcount != 1:
                raise ValueError("locked")
            if finish:
                c.execute("UPDATE visits SET status='done', finished_at=?, updated_at=?, updated_by=? WHERE id=?", (t, t, by, vid))
        return self.enc_get(vid)

    @staticmethod
    def _send_orders(c, v, items, by, t):
        """كل طلب تحليل/أشعة يصير طلباً في قائمة قسمه، برقم تسلسلي لليوم والفرع، ويُختم برقمه (oid) في سجل الزيارة."""
        out, day = [], riyadh_today().isoformat()
        for it in items:
            if it.get("oid"):
                out.append(it)
                continue
            kind = it["type"]
            seq = c.execute("SELECT COALESCE(MAX(seq),0)+1 FROM orders WHERE kind=? AND day=? AND COALESCE(branch_id,'')=?", (kind, day, v["branch_id"] or "")).fetchone()[0]
            oid = "o-" + secrets.token_hex(6)
            c.execute("INSERT INTO orders(id,visit_id,mrn,patient_name,doctor_id,branch_id,kind,name,note,seq,day,sent_at,sent_by,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (oid, v["id"], v["mrn"], v["patient_name"], v["doctor_id"], v["branch_id"], kind, it["name"], it.get("note", ""), seq, day, t, by, t))
            out.append({"type": kind, "name": it["name"], "note": it.get("note", ""), "oid": oid})
        return out

    def enc_for_visits(self, vids):
        """ملخص خفيف لكل زيارة (عدد الأدوية والطلبات) للوحة الاستقبال."""
        out = {}
        for i in range(0, len(vids), 400):
            part = vids[i:i + 400]
            for r in self.conn().execute("SELECT visit_id, rx, orders, finished_at, publish FROM encounters WHERE visit_id IN (%s)" % ",".join("?" * len(part)), part):
                out[r["visit_id"]] = {"rx": len(json.loads(r["rx"] or "[]")), "orders": len(json.loads(r["orders"] or "[]")), "finished": bool(r["finished_at"]),
                                      "open": not r["finished_at"], "publish": bool(r["publish"])}
        return out

    def enc_history(self, mrn, exclude_vid=None, limit=15):
        rows = self.conn().execute("SELECT e.*, v.day, v.branch_id FROM encounters e JOIN visits v ON v.id=e.visit_id "
                                   "WHERE e.mrn=? COLLATE NOCASE AND e.finished_at IS NOT NULL AND e.visit_id<>? ORDER BY e.finished_at DESC LIMIT ?", (mrn, exclude_vid or "", int(limit)))
        out = []
        for r in rows:
            d = self._enc(r)
            d["day"], d["branch_id"] = r["day"], r["branch_id"]
            out.append(d)
        return out

    def enc_published(self, mrns=None, device_id=None, vid=None, limit=50):
        """ما يراه المراجع: زيارات منتهية اعتمد الطبيب نشرها. إما لملفات مرتبطة بحسابه (mrns) أو لجهاز حجز (device_id)."""
        sql = ("SELECT e.*, v.day, v.branch_id, v.booking_id FROM encounters e JOIN visits v ON v.id=e.visit_id "
               "WHERE e.finished_at IS NOT NULL AND e.publish=1")
        args = []
        if device_id:
            sql += " AND v.booking_id IN (SELECT id FROM bookings WHERE device_id=?)"
            args.append(device_id)
        elif mrns is not None:
            if not mrns:
                return []
            sql += " AND v.mrn COLLATE NOCASE IN (%s)" % ",".join("?" * len(mrns))
            args += list(mrns)
        else:
            return []
        if vid:
            sql += " AND e.visit_id=?"
            args.append(vid)
        out = []
        for r in self.conn().execute(sql + " ORDER BY e.finished_at DESC LIMIT ?", args + [int(limit)]):
            d = self._enc(r)
            d["day"], d["branch_id"], d["booking_id"] = r["day"], r["branch_id"], r["booking_id"]
            out.append(d)
        return out

    # ------------------------------------------------------------------ طلبات المختبر والأشعة: من الطبيب إلى القسم ثم النتيجة ثم مراجعة الطبيب
    # sent (بانتظار القسم) ← in_progress (قيد التنفيذ) ← resulted (النتيجة عند الطبيب) ← reviewed (راجعها الطبيب، released = نُشرت للمراجع) | cancelled
    ORDER_OPEN = ("sent", "in_progress")

    @staticmethod
    def _ord(r):
        if not r:
            return None
        d = dict(r)
        d["rows"] = json.loads(d.pop("result_rows", None) or "[]")
        d["released"] = bool(d["released"])
        return d

    def order_get(self, oid):
        return self._ord(self.conn().execute("SELECT * FROM orders WHERE id=?", (oid,)).fetchone())

    def orders_for_visit(self, vid):
        return [self._ord(r) for r in self.conn().execute("SELECT * FROM orders WHERE visit_id=? ORDER BY rowid", (vid,))]

    def orders_for_visit_ids(self, vids):
        out = {}
        for i in range(0, len(vids), 400):
            part = vids[i:i + 400]
            for r in self.conn().execute("SELECT * FROM orders WHERE visit_id IN (%s) ORDER BY rowid" % ",".join("?" * len(part)), part):
                out.setdefault(r["visit_id"], []).append(self._ord(r))
        return out

    def orders_for_visits(self, vids):
        """عدّاد حالات طلبات كل زيارة (للوحة الاستقبال وطابور الطبيب): open بانتظار القسم، await عند الطبيب للمراجعة، done اكتملت، cancelled."""
        out, kind = {}, {"sent": "open", "in_progress": "open", "resulted": "await", "reviewed": "done", "cancelled": "cancelled"}
        for i in range(0, len(vids), 400):
            part = vids[i:i + 400]
            for r in self.conn().execute("SELECT visit_id, status, COUNT(*) AS n FROM orders WHERE visit_id IN (%s) GROUP BY visit_id, status" % ",".join("?" * len(part)), part):
                o = out.setdefault(r["visit_id"], {"total": 0, "open": 0, "await": 0, "done": 0, "cancelled": 0})
                o["total"] += r["n"]
                o[kind.get(r["status"], "open")] += r["n"]
        return out

    def orders_for_mrn(self, mrn, exclude_vid="", limit=60):
        rows = self.conn().execute("SELECT * FROM orders WHERE mrn=? COLLATE NOCASE AND visit_id<>? ORDER BY sent_at DESC, rowid DESC LIMIT ?", (mrn, exclude_vid or "", int(limit)))
        return [self._ord(r) for r in rows]

    def orders_unit(self, kind, branch_id, today_iso):
        """قائمة عمل القسم: كل الطلبات المفتوحة (أياً كان يومها: قد يعود المراجع في يوم آخر) + ما أُنجز اليوم."""
        sql = "SELECT * FROM orders WHERE kind=? AND (status IN ('sent','in_progress') OR (status IN ('resulted','reviewed') AND done_day=?))"
        args = [kind, today_iso]
        if branch_id:
            sql += " AND (branch_id IS NULL OR branch_id=?)"
            args.append(branch_id)
        rows = self.conn().execute(sql + " ORDER BY CASE status WHEN 'in_progress' THEN 0 WHEN 'sent' THEN 1 ELSE 2 END, sent_at, rowid", args)
        return [self._ord(r) for r in rows]

    def orders_doctor_open(self, did):
        rows = self.conn().execute("SELECT * FROM orders WHERE doctor_id=? AND status IN ('sent','in_progress','resulted') ORDER BY CASE status WHEN 'resulted' THEN 0 ELSE 1 END, sent_at, rowid", (did,))
        return [self._ord(r) for r in rows]

    def orders_doctor_recent(self, did, limit=40):
        rows = self.conn().execute("SELECT * FROM orders WHERE doctor_id=? AND status IN ('reviewed','cancelled') ORDER BY COALESCE(reviewed_at, cancelled_at) DESC, rowid DESC LIMIT ?", (did, int(limit)))
        return [self._ord(r) for r in rows]

    def orders_await_count(self, did):
        return self.conn().execute("SELECT COUNT(*) FROM orders WHERE doctor_id=? AND status='resulted'", (did,)).fetchone()[0]

    def order_start(self, oid, by):
        t = now()
        with self.tx() as c:
            cur = c.execute("UPDATE orders SET status='in_progress', started_at=?, started_by=?, updated_at=? WHERE id=? AND status='sent'", (t, by, t, oid))
            if cur.rowcount != 1:
                raise ValueError("state")
        return self.order_get(oid)

    def order_result_save(self, oid, by, rows, text, complete=False):
        """يحفظ نتيجة القسم (مسودة أو نهائية). مسموح حتى يراجعها الطبيب فقط (ValueError('state') بعدها). الحفظ الأول يبدأ التنفيذ تلقائياً."""
        t = now()
        with self.tx() as c:
            r = c.execute("SELECT status FROM orders WHERE id=?", (oid,)).fetchone()
            if not r or r["status"] not in ("sent", "in_progress", "resulted"):
                raise ValueError("state")
            sets = {"result_rows": json.dumps(rows, ensure_ascii=False), "result_text": text, "updated_at": t}
            if r["status"] == "sent":
                sets.update(status="in_progress", started_at=t, started_by=by)
            if complete and r["status"] != "resulted":
                sets.update(status="resulted", resulted_at=t, resulted_by=by, done_day=riyadh_today().isoformat())
            c.execute("UPDATE orders SET " + ", ".join(k + "=?" for k in sets) + " WHERE id=?", (*sets.values(), oid))
        return self.order_get(oid)

    def order_review(self, oid, by, release):
        """الطبيب يراجع النتيجة (resulted ← reviewed) وقراره: تُنشر للمراجع أم لا. بعد المراجعة يمكن النشر لاحقاً لكن لا يُسحب النشر ولا تُعدَّل النتيجة."""
        t = now()
        with self.tx() as c:
            r = c.execute("SELECT status, released FROM orders WHERE id=?", (oid,)).fetchone()
            if not r:
                raise ValueError("state")
            if r["status"] == "resulted":
                c.execute("UPDATE orders SET status='reviewed', reviewed_at=?, reviewed_by=?, released=?, updated_at=? WHERE id=?", (t, by, 1 if release else 0, t, oid))
            elif r["status"] == "reviewed" and release and not r["released"]:
                c.execute("UPDATE orders SET released=1, updated_at=? WHERE id=?", (t, oid))
            else:
                raise ValueError("state")
        return self.order_get(oid)

    def order_cancel(self, oid, by, reason, from_status):
        t = now()
        with self.tx() as c:
            cur = c.execute("UPDATE orders SET status='cancelled', cancelled_at=?, cancelled_by=?, cancel_reason=?, updated_at=? WHERE id=? AND status IN (%s)" % ",".join("?" * len(from_status)),
                            (t, by, reason, t, oid, *from_status))
            if cur.rowcount != 1:
                raise ValueError("state")
        return self.order_get(oid)

    def orders_released(self, mrns=None, device_id=None, limit=100):
        """ما يراه المراجع من نتائجه: طلبات راجعها الطبيب وأقرّ نشرها. إما لملفات مرتبطة بحسابه (mrns) أو لجهاز حجز (device_id)."""
        sql = "SELECT o.*, v.booking_id FROM orders o JOIN visits v ON v.id=o.visit_id WHERE o.status='reviewed' AND o.released=1"
        args = []
        if device_id:
            sql += " AND v.booking_id IN (SELECT id FROM bookings WHERE device_id=?)"
            args.append(device_id)
        elif mrns is not None:
            if not mrns:
                return []
            sql += " AND o.mrn COLLATE NOCASE IN (%s)" % ",".join("?" * len(mrns))
            args += list(mrns)
        else:
            return []
        return [self._ord(r) for r in self.conn().execute(sql + " ORDER BY o.reviewed_at DESC, o.rowid DESC LIMIT ?", args + [int(limit)])]

    def visits_for_bookings(self, bids):
        """آخر زيارة لكل حجز (لعرض مرحلة المراجع في بطاقة حجزه)."""
        out = {}
        if not bids:
            return out
        for r in self.conn().execute("SELECT v.*, e.publish AS e_publish, e.finished_at AS e_finished FROM visits v LEFT JOIN encounters e ON e.visit_id=v.id "
                                     "WHERE v.booking_id IN (%s) ORDER BY v.arrived_at" % ",".join("?" * len(bids)), list(bids)):
            out[r["booking_id"]] = dict(r)
        return out

    def doctor_has_patient(self, doctor_id, mrn):
        return bool(self.conn().execute("SELECT 1 FROM visits WHERE doctor_id=? AND mrn=? COLLATE NOCASE AND status<>'cancelled' LIMIT 1", (doctor_id, mrn)).fetchone())

    def doctor_busy(self, doctor_id, day, exclude_vid=""):
        r = self.conn().execute("SELECT id FROM visits WHERE doctor_id=? AND day=? AND status='with_doctor' AND id<>? LIMIT 1", (doctor_id, day, exclude_vid)).fetchone()
        return r["id"] if r else None

    def next_local_mrn(self):
        """رقم ملف محلي للمراجع الجديد (DS-100001…) لا يتعارض مع أرقام نظام المستوصف."""
        with self.tx() as c:
            r = c.execute("SELECT value FROM kv WHERE key='mrn_seq'").fetchone()
            n = (json.loads(r["value"]) if r else 100000) + 1
            while c.execute("SELECT 1 FROM records WHERE mrn=? COLLATE NOCASE", ("DS-%d" % n,)).fetchone():
                n += 1
            c.execute("INSERT INTO kv(key,value,updated_at) VALUES('mrn_seq',?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at", (json.dumps(n), now()))
        return "DS-%d" % n

    def audit_search(self, limit=200, who=None, action=None, before=None):
        sql, args = "SELECT id,ts,who,action,kind,ref,detail FROM audit WHERE 1=1", []
        if who:
            sql += " AND who LIKE ?"
            args.append("%" + who + "%")
        if action:
            sql += " AND action LIKE ?"
            args.append("%" + action + "%")
        if before:
            sql += " AND id<?"
            args.append(int(before))
        return [dict(r) for r in self.conn().execute(sql + " ORDER BY id DESC LIMIT ?", args + [min(int(limit), 500)])]

    def patients_search(self, q, limit=30):
        q = (q or "").strip()
        sql, args = "SELECT * FROM patients", []
        if q:
            digits = "".join(ch for ch in q if ch.isdigit())
            conds, args = ["name LIKE ?"], ["%" + q + "%"]
            if len(digits) >= 3:
                conds += ["phone LIKE ?", "national_id LIKE ?"]
                args += ["%" + digits.lstrip("0") + "%", "%" + digits + "%"]
            sql += " WHERE " + " OR ".join(conds)
        rows = self.conn().execute(sql + " ORDER BY last_login DESC LIMIT ?", args + [int(limit)])
        return [dict(r) for r in rows]

    def file_create(self, rec):
        fid = "f-" + secrets.token_hex(16)
        with self.tx() as c:
            c.execute("INSERT INTO patient_files(id,phone,mrn,kind,title,note,size,sha256,uploaded_by,uploaded_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                      (fid, rec["phone"], rec["mrn"], rec["kind"], rec["title"], rec.get("note", ""), rec["size"], rec["sha256"], rec["by"], now()))
        return self.file_get(fid)

    def file_get(self, fid):
        r = self.conn().execute("SELECT * FROM patient_files WHERE id=?", (fid,)).fetchone()
        return dict(r) if r else None

    def file_list(self, mrns, include_deleted=False, kind=None):
        mrns = [mrns] if isinstance(mrns, str) else list(mrns)
        if not mrns:
            return []
        sql = "SELECT * FROM patient_files WHERE mrn IN (%s)" % ",".join("?" * len(mrns)) + ("" if include_deleted else " AND deleted_at IS NULL")
        args = list(mrns)
        if kind:
            sql += " AND kind=?"
            args.append(kind)
        return [dict(r) for r in self.conn().execute(sql + " ORDER BY uploaded_at DESC", args)]

    # ------------------------------------------------------------------ سجلات المراجعين (رقم الملف الطبي)
    def record_get(self, mrn):
        r = self.conn().execute("SELECT * FROM records WHERE mrn=? COLLATE NOCASE", (mrn,)).fetchone()
        return dict(r) if r else None

    def record_upsert(self, rec, source):
        """يعيد 'new' أو 'updated' أو 'same'. لا يحذف شيئاً أبداً."""
        old = self.record_get(rec["mrn"])
        t = now()
        keys = ("name", "phone", "national_id", "birth_date", "gender")
        if not old:
            with self.tx() as c:
                c.execute("INSERT INTO records(mrn,name,phone,national_id,birth_date,gender,source,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",
                          (rec["mrn"], rec["name"], rec["phone"], rec.get("national_id"), rec.get("birth_date"), rec.get("gender"), source, t, t))
            return "new"
        # الحقول الفارغة في الملف الجديد لا تمسح بيانات موجودة
        merged = {k: (rec.get(k) or old.get(k)) for k in keys}
        if all(merged[k] == old.get(k) for k in keys):
            return "same"
        with self.tx() as c:
            c.execute("UPDATE records SET name=?, phone=?, national_id=?, birth_date=?, gender=?, updated_at=? WHERE mrn=? COLLATE NOCASE",
                      (merged["name"], merged["phone"], merged["national_id"], merged["birth_date"], merged["gender"], t, old["mrn"]))
        return "updated"

    def records_search(self, q, limit=40):
        q = (q or "").strip()
        sql, args = "SELECT * FROM records", []
        if q:
            digits = "".join(ch for ch in q if ch.isdigit())
            conds, args = ["name LIKE ?", "mrn LIKE ?"], ["%" + q + "%", "%" + q + "%"]
            if len(digits) >= 3:
                conds += ["phone LIKE ?", "national_id LIKE ?"]
                args += ["%" + digits.lstrip("0") + "%", "%" + digits + "%"]
            sql += " WHERE " + " OR ".join(conds)
        out = [dict(r) for r in self.conn().execute(sql + " ORDER BY updated_at DESC LIMIT ?", args + [int(limit)])]
        fc = {r["mrn"]: r["n"] for r in self.conn().execute("SELECT mrn, COUNT(*) n FROM patient_files WHERE deleted_at IS NULL GROUP BY mrn")}
        lc = {r["mrn"]: r["n"] for r in self.conn().execute("SELECT mrn, COUNT(*) n FROM record_links GROUP BY mrn")}
        for r in out:
            r["files"], r["linked"] = fc.get(r["mrn"], 0), lc.get(r["mrn"], 0)
        return out

    def records_count(self):
        return self.conn().execute("SELECT COUNT(*) FROM records").fetchone()[0]

    def records_for_phone(self, phone):
        return [dict(r) for r in self.conn().execute("SELECT * FROM records WHERE phone=?", (phone,))]

    def link_add(self, pid, mrn):
        with self.tx() as c:
            c.execute("INSERT OR IGNORE INTO record_links(patient_id,mrn,linked_at) VALUES(?,?,?)", (pid, mrn, now()))

    def link_remove(self, pid, mrn):
        with self.tx() as c:
            c.execute("DELETE FROM record_links WHERE patient_id=? AND mrn=?", (pid, mrn))

    def linked_records(self, pid):
        rows = self.conn().execute("SELECT r.* FROM record_links l JOIN records r ON r.mrn=l.mrn WHERE l.patient_id=? ORDER BY l.linked_at", (pid,))
        return [dict(r) for r in rows]

    def patients_of_mrn(self, mrn):
        return [r["patient_id"] for r in self.conn().execute("SELECT patient_id FROM record_links WHERE mrn=?", (mrn,))]

    def file_update(self, fid, by, **fields):
        allowed = {k: v for k, v in fields.items() if k in ("kind", "title", "note", "size", "sha256")}
        sets = ", ".join("%s=?" % k for k in allowed) + (", " if allowed else "") + "updated_by=?, updated_at=?"
        with self.tx() as c:
            c.execute("UPDATE patient_files SET " + sets + " WHERE id=?", list(allowed.values()) + [by, now(), fid])
        return self.file_get(fid)

    def file_soft_delete(self, fid, by):
        with self.tx() as c:
            c.execute("UPDATE patient_files SET deleted_by=?, deleted_at=? WHERE id=?", (by, now(), fid))

    def add_notification(self, title, body, target="all", kind="info", ref=""):
        with self.tx() as c:
            cur = c.execute("INSERT INTO notifications(target,title,body,kind,ref,created_at) VALUES(?,?,?,?,?,?)", (target, title, body, kind, ref, now()))
            return cur.lastrowid

    def list_notifications(self, device_id, since=0, limit=50, patient_id=None):
        rows = self.conn().execute("SELECT * FROM notifications WHERE (target='all' OR target=? OR target=?) AND id>? ORDER BY id DESC LIMIT ?",
                                   (device_id, ("pt:" + patient_id) if patient_id else "-", int(since), int(limit)))
        return [dict(r) for r in rows]

    def list_all_notifications(self, limit=100):
        return [dict(r) for r in self.conn().execute("SELECT * FROM notifications ORDER BY id DESC LIMIT ?", (int(limit),))]

    # ------------------------------------------------------------------ سجلات وعدّادات
    def usage_incr(self, key, n=1):
        d = today()
        with self.tx() as c:
            c.execute("INSERT INTO usage(day,key,n) VALUES(?,?,?) ON CONFLICT(day,key) DO UPDATE SET n=n+excluded.n", (d, key, n))
            return c.execute("SELECT n FROM usage WHERE day=? AND key=?", (d, key)).fetchone()["n"]

    def usage_get(self, key):
        r = self.conn().execute("SELECT n FROM usage WHERE day=? AND key=?", (today(), key)).fetchone()
        return r["n"] if r else 0

    def log_qamar(self, device_id, question, intent, confident, used_llm, source):
        dh = hashlib.sha256(("ds|" + (device_id or "")).encode()).hexdigest()[:10]
        with self.tx() as c:
            c.execute("INSERT INTO qamar_log(ts,device_hash,question,intent,confident,used_llm,source) VALUES(?,?,?,?,?,?,?)",
                      (now(), dh, question[:240], intent, 1 if confident else 0, 1 if used_llm else 0, source))
            c.execute("DELETE FROM qamar_log WHERE id < (SELECT MAX(id) FROM qamar_log) - 2000")

    def recent_qamar_log(self, limit=100, only_unconfident=False):
        sql = "SELECT * FROM qamar_log" + (" WHERE confident=0" if only_unconfident else "") + " ORDER BY id DESC LIMIT ?"
        return [dict(r) for r in self.conn().execute(sql, (int(limit),))]

    def recent_audit(self, limit=100):
        return [dict(r) for r in self.conn().execute("SELECT id,ts,who,action,kind,ref FROM audit ORDER BY id DESC LIMIT ?", (int(limit),))]

    # ------------------------------------------------------------------ نسخ احتياطي
    def backup_to(self, dest):
        dest = Path(dest)
        dest.parent.mkdir(parents=True, exist_ok=True)
        out = sqlite3.connect(str(dest))
        try:
            self.conn().backup(out)
        finally:
            out.close()
        return str(dest)

    def export_all(self):
        ds = self.dataset(public=False)
        ds["meta"]["exportedAt"] = now()
        ds["bookings"] = self.list_bookings(limit=100000)
        return ds
