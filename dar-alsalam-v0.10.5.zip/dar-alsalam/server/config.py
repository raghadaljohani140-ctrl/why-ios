"""إعدادات الخادم من متغيرات البيئة أو من ملف .env في جذر المشروع. لا أسرار داخل الكود."""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _load_env_file(path):
    out = {}
    if not path.exists():
        return out
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        out[k.strip()] = v.strip().strip('"').strip("'")
    return out


class Config:
    def __init__(self, env=None):
        file_env = _load_env_file(ROOT / ".env")
        src = dict(file_env)
        src.update(os.environ if env is None else env)
        g = lambda k, d="": src.get(k, d)  # noqa: E731
        self.host = g("DS_HOST", "127.0.0.1")
        self.port = int(g("DS_PORT", "8080"))
        self.db_path = Path(g("DS_DB", str(ROOT / "data" / "clinic.db")))
        # تسجيل المرضى برمز تحقق SMS: none (متوقف، الحجز كما هو) | taqnyat | test (للاختبار فقط: الرمز يُسجَّل ولا يُرسل)
        self.sms_provider = g("DS_SMS_PROVIDER", "none").strip().lower()
        self.sms_token = g("DS_SMS_TOKEN", "")
        self.sms_sender = g("DS_SMS_SENDER", "")
        # الدفع المسبق لموعد: "" (لا بوابة مربوطة → التفعيل مرفوض من الخادم) | test (للتجربة فقط: لا يحصّل أي مبلغ). لا توجد بوابة حقيقية في هذه النسخة.
        self.pay_provider = g("DS_PAY_PROVIDER", "").strip().lower()
        self.records_source = g("DS_RECORDS_SOURCE", "local").strip().lower()   # local = Excel/يدوي | api = نظام المستوصف (إن وفّرته الشركة المشغّلة)
        self.records_api_url = g("DS_RECORDS_API_URL", "").rstrip("/")
        self.records_api_token = g("DS_RECORDS_API_TOKEN", "")
        self.files_dir = Path(g("DS_FILES", str(self.db_path.parent / "files")))  # ملفات المرضى PDF: خارج أي مسار عام
        self.uploads_dir = Path(g("DS_UPLOADS", str(self.db_path.parent / "uploads")))
        self.secret_path = Path(g("DS_SECRET_FILE", str(self.db_path.parent / ".secret")))
        self.cors_origin = g("DS_CORS", "*")
        self.trust_proxy = g("DS_TRUST_PROXY", "0") == "1"
        self.web_dir = Path(g("DS_WEB_DIR", str(ROOT / "web")))
        self.admin_dir = Path(g("DS_ADMIN_DIR", str(ROOT / "admin")))
        self.widget_dir = Path(g("DS_WIDGET_DIR", str(ROOT / "widget")))
        self.seed_path = Path(g("DS_SEED", str(ROOT / "data" / "seed.json")))
        self.lexicon_path = Path(g("DS_LEXICON", str(ROOT / "data" / "lexicon.json")))
        # قمر: الذكاء الاصطناعي معطّل افتراضياً (وضع قاعدة المعرفة فقط)
        self.qamar_provider = g("QAMAR_PROVIDER", "").lower()          # "" | anthropic | openai
        self.qamar_api_key = g("QAMAR_API_KEY", "")
        self.qamar_model = g("QAMAR_MODEL", "claude-haiku-5-5" if self.qamar_provider == "anthropic" else "")
        self.qamar_base_url = g("QAMAR_BASE_URL", "").rstrip("/")
        self.qamar_tokens_param = g("QAMAR_TOKENS_PARAM", "max_tokens")
        self.qamar_daily_cap = int(g("QAMAR_DAILY_CAP", "300"))
        self.qamar_device_cap = int(g("QAMAR_DEVICE_CAP", "20"))
        self.qamar_timeout = float(g("QAMAR_TIMEOUT", "15"))
        # تنبيهات الموظفين (اختياري، بدون بيانات شخصية)
        self.telegram_token = g("TELEGRAM_BOT_TOKEN", "")
        self.telegram_chat = g("TELEGRAM_CHAT_ID", "")
        # إشعارات الدفع (اختياري ولم يُختبر مع FCM الحقيقي)
        self.fcm_project = g("FCM_PROJECT_ID", "")
        self.fcm_service_account = g("FCM_SERVICE_ACCOUNT", "")
        self.admin_token_hours = int(g("DS_ADMIN_TOKEN_HOURS", "12"))

    @property
    def llm_enabled(self):
        if not self.qamar_provider or not self.qamar_api_key:
            return False
        if self.qamar_provider == "anthropic":
            return bool(self.qamar_model)
        return bool(self.qamar_base_url and self.qamar_model)
