"""محرك المعرفة لقمر: تطبيع عربي + نوايا + توجيه الشكاوى إلى العيادات + أسئلة شائعة.

يعمل بدون أي اعتماديات ولا يستدعي أي ذكاء اصطناعي. نفس المنطق مكتوب بالجافاسكربت في web/js/20-kb.js
ويستخدم نفس ملف المفردات data/lexicon.json حتى تتطابق النتائج (يوجد اختبار مطابقة).
دالة answer() حتمية ولا تعتمد على BM25؛ البحث BM25 يُستخدم فقط لبناء سياق النموذج عند تفعيله.
"""
import json
import math
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# ----------------------------------------------------------------- تطبيع الحروف
_AR_FIX = {"أ": "ا", "إ": "ا", "آ": "ا", "ٱ": "ا", "ى": "ي", "ة": "ه", "ؤ": "و", "ئ": "ي", "ک": "ك", "ی": "ي", "ۀ": "ه"}
_TRANS = {ord(k): v for k, v in _AR_FIX.items()}
_TRANS.update({ord(c): str(i) for i, c in enumerate("٠١٢٣٤٥٦٧٨٩")})
_TRANS.update({ord(c): str(i) for i, c in enumerate("۰۱۲۳۴۵۶۷۸۹")})
_DIAC = re.compile("[ؐ-ًؚ-ٰٟۖ-ۭـ]")
_NONTOK = re.compile("[^a-z0-9ء-ي]+")
_ARONLY = re.compile("^[ء-ي]+$")
_PREF = ["وبال", "وال", "بال", "كال", "فال", "لل", "ال"]
_SUF1 = ["ها", "هم", "كم", "نا", "ه", "ي"]          # ضمائر متصلة
_SUF2 = ["ات", "ان", "ين", "ون", "ت"]               # جمع/مثنى/تاء


def normalize(s):
    s = (s or "").lower().replace("x-ray", "xray")
    s = _DIAC.sub("", s)
    s = s.translate(_TRANS)
    return _NONTOK.sub(" ", s).strip()


def stem(t):
    """تجذيع خفيف على مرحلتين: بادئة، ثم ضمير متصل، ثم علامة جمع/تاء. الحد الأدنى للجذع 3 أحرف."""
    if len(t) < 4 or not _ARONLY.match(t):
        return t
    for p in _PREF:
        if t.startswith(p) and len(t) - len(p) >= 3:
            t = t[len(p):]
            break
    if t.endswith("ء") and len(t) >= 4:
        t = t[:-1]
    for s in _SUF1:
        if t.endswith(s) and len(t) - len(s) >= 3:
            t = t[: -len(s)]
            break
    for s in _SUF2:
        if t.endswith(s) and len(t) - len(s) >= 3:
            t = t[: -len(s)]
            break
    return t


def e164_digits(n):
    """يحوّل رقماً محلياً أو دولياً إلى أرقام فقط بصيغة دولية (للروابط wa.me)."""
    d = re.sub(r"\D", "", n or "")
    if d.startswith("00"):
        d = d[2:]
    if d.startswith("05") and len(d) == 10:
        d = "966" + d[1:]
    elif d.startswith("5") and len(d) == 9:
        d = "966" + d
    return d


class Lexicon:
    def __init__(self, raw):
        self.raw = raw
        self.syn = {}
        for canon, alts in raw.get("synonyms", {}).items():
            c = stem(normalize(canon))
            self.syn[c] = c
            for a in alts:
                n = normalize(a)
                if " " in n:
                    continue
                self.syn[stem(n)] = c
        self.stop = set()
        for w in raw.get("stopwords", []):
            n = normalize(w)
            if n and " " not in n:
                self.stop.add(self.syn.get(stem(n), stem(n)))

    def analyze(self, text, vocab=None):
        """يحوّل النص إلى رموز مجذّعة. إن مُرّر vocab فتُزال واو العطف من الكلمة إذا كان الباقي معروفاً."""
        out = []
        for t in normalize(text).split():
            s = stem(t)
            if vocab is not None and s not in vocab and len(t) >= 5 and t[0] == "و" and _ARONLY.match(t):
                s2 = self.syn.get(stem(t[1:]), stem(t[1:]))
                if s2 in vocab:
                    s = s2
            out.append(self.syn.get(s, s))
        return out

    def phrases(self, items):
        return [p for p in (self.analyze(x) for x in items) if p]

    @staticmethod
    def load(path=None):
        p = Path(path) if path else ROOT / "data" / "lexicon.json"
        return Lexicon(json.loads(p.read_text(encoding="utf-8")))


def contains_phrase(tokens, ptoks):
    n, m = len(tokens), len(ptoks)
    if m == 0 or m > n:
        return False
    for i in range(n - m + 1):
        if tokens[i : i + m] == ptoks:
            return True
    return False


def fill(tpl, **kw):
    out = tpl
    for k, v in kw.items():
        out = out.replace("{" + k + "}", str(v))
    return out


def _active(items):
    return [e for e in items if e.get("active", True)]


class KB:
    K1 = 1.5
    B = 0.75

    def __init__(self, data, lex):
        self.lex = lex
        self.d = data
        self.s = data.get("settings", {})
        self.q = data.get("qamar", {}) or {}
        self.branches = _active(data.get("branches", []))
        self.specs = _active(data.get("specialties", []))
        self.services = _active(data.get("services", []))
        self.doctors = _active(data.get("doctors", []))
        self.faqs = _active(data.get("faqs", []))
        self.by_id = {}
        for kind, items in (("branches", self.branches), ("specialties", self.specs), ("services", self.services),
                            ("doctors", self.doctors), ("faqs", self.faqs)):
            for e in items:
                self.by_id[(kind, e["id"])] = e
        phones = self.s.get("phones", [])
        main = next((p for p in phones if p.get("type") == "main"), phones[0] if phones else {"number": ""})
        self.vars = {
            "clinic": self.s.get("name", ""),
            "city": self.s.get("city", ""),
            "phone_main": main.get("number", ""),
            "emergency": self.s.get("emergencyNumber", "997"),
            "healthline": self.s.get("healthLine", "937"),
            "handoff": self.q.get("handoffText") or "ما عندي معلومة مؤكدة عن هذا الموضوع، والأفضل تتواصل مع المجمع مباشرة.",
        }
        self.T = lex.raw["templates"]
        self.vocab = None
        self._compile_lexicon()
        self._build_index()
        self._build_vocab()

    # ------------------------------------------------------------ تحليل بمفردات المجمع
    def an(self, text):
        return self.lex.analyze(text, self.vocab)

    # ------------------------------------------------------------ تجهيز المفردات
    def _compile_lexicon(self):
        L, raw = self.lex, self.lex.raw
        self.intent_phrases = {k: L.phrases(v) for k, v in raw["intents"].items()}
        self.advice_phrases = L.phrases(raw.get("advice", []))
        self.self_harm_phrases = L.phrases(raw.get("selfHarm", []))
        self.yes_follow = L.phrases(raw.get("yesFollowups", []))
        self.tips_tokens = {t for p in self.intent_phrases.get("tips", []) for t in p}
        self.priority = raw.get("priority", [])
        self.emergency_rules = []
        for r in raw.get("emergency", []):
            rule = {"id": r["id"], "hint": r.get("hint", ""), "any": L.phrases(r.get("any", [])), "all": []}
            for group in r.get("all", []):
                rule["all"].append(L.phrases(group))
            self.emergency_rules.append(rule)
        toks = []
        for b in self.branches:
            ts = set()
            for f in ("name", "shortName", "area", "landmark", "address"):
                ts |= {t for t in L.analyze(b.get(f, "")) if len(t) >= 3 and t not in L.stop}
            toks.append(ts)
        common = set.intersection(*toks) if len(toks) > 1 else set()
        generic = {"فرع", "دار", "سلام", "طبي", "مدينه", "منور", "مدين", "مجمع"}
        self.branch_tokens = [t - common - generic for t in toks]

    # ------------------------------------------------------------ بناء الفهرس (للسياق فقط)
    def _chunk(self, cid, typ, ref, title, text, extra=""):
        L = self.lex
        toks = [t for t in (L.analyze(title) * 2 + L.analyze(text) + L.analyze(extra)) if t not in L.stop]
        self.chunks.append({"id": cid, "type": typ, "ref": ref, "title": title, "text": text})
        self.docs.append(Counter(toks))

    def doc_label(self, d):
        return "د. " + d["name"]

    def _names(self, ids, kind):
        return [self.by_id[(kind, i)]["name"] for i in ids if (kind, i) in self.by_id]

    def _build_index(self):
        self.chunks, self.docs = [], []
        s = self.s
        about = " ".join(x for x in (s.get("about"), s.get("mission"), s.get("vision")) if x)
        self._chunk("clinic", "clinic", "clinic", s.get("name", ""), about, "نبذه عن المجمع تأسيس رؤية رسالة")
        phones = " ".join(f"{p['label']}: {p['number']}" for p in s.get("phones", []))
        self._chunk("contact", "contact", "contact", "التواصل", phones, "رقم هاتف جوال واتساب تواصل اتصال")
        for b in self.branches:
            txt = f"{b.get('address','')} {b.get('landmark','')} {b.get('area','')} هاتف {b.get('phone','')}"
            self._chunk("branch:" + b["id"], "branch", b["id"], b["name"], txt, "فرع موقع عنوان خريطة")
        for sp in self.specs:
            docs = [self.doc_label(d) for d in self.doctors if sp["id"] in d.get("specialtyIds", [])]
            txt = f"{sp.get('description','')} الأطباء: {'، '.join(docs)} {sp.get('hoursText','')}"
            self._chunk("specialty:" + sp["id"], "specialty", sp["id"], sp["name"], txt, " ".join(sp.get("keywords", [])))
        for sv in self.services:
            docs = [self.doc_label(d) for d in self.doctors if sv["id"] in d.get("serviceIds", [])]
            txt = f"{sv.get('description','')} الأطباء: {'، '.join(docs)} {sv.get('hoursText','')}"
            self._chunk("service:" + sv["id"], "service", sv["id"], sv["name"], txt, " ".join(sv.get("keywords", [])))
        for d in self.doctors:
            sps = self._names(d.get("specialtyIds", []), "specialties") + self._names(d.get("serviceIds", []), "services")
            txt = f"{self.doc_label(d)} {d.get('rank','')} {d.get('degree','')} التخصص: {'، '.join(sps)} {d.get('bio','')}"
            self._chunk("doctor:" + d["id"], "doctor", d["id"], self.doc_label(d), txt, "طبيب دكتور")
        for f in self.faqs:
            self._chunk("faq:" + f["id"], "faq", f["id"], f["question"], self._faq_answer(f), " ".join(f.get("keywords", [])))
        n = len(self.docs)
        self.N = n
        self.dl = [sum(c.values()) for c in self.docs]
        self.avgdl = (sum(self.dl) / n) if n else 1
        self.df = Counter()
        for c in self.docs:
            for t in c:
                self.df[t] += 1
        # رموز الأسئلة الشائعة (السؤال + الكلمات المفتاحية فقط، بدون نص الجواب)
        L = self.lex
        self.faq_tokens = {}
        for f in self.faqs:
            ts = set(L.analyze(f["question"]))
            for k in f.get("keywords", []):
                ts |= set(L.analyze(k))
            self.faq_tokens[f["id"]] = {t for t in ts if t not in L.stop}

    VOCAB_SKIP = {"id", "photo", "icon", "category", "lat", "lng", "mapQuery", "sort", "active", "needsReview", "specialtyIds", "serviceIds",
                  "branchIds", "whatsapp", "phone", "linkType", "linkRef"}

    def _build_vocab(self):
        """مفردات المجمع المعروفة (تُستخدم لإزالة واو العطف). تعريف بسيط ليطابقه المنفذ بالجافاسكربت تماماً."""
        L = self.lex
        v = set(L.stop) | set(L.syn.keys()) | set(L.syn.values())
        for group in (list(self.intent_phrases.values()), [self.advice_phrases, self.self_harm_phrases]):
            for phrases in group:
                for p in phrases:
                    v |= set(p)
        texts = [self.s.get(k, "") for k in ("name", "legalName", "city", "about", "mission", "vision")]
        texts += [p.get("label", "") for p in self.s.get("phones", [])]
        for items in (self.branches, self.specs, self.services, self.doctors, self.faqs):
            for e in items:
                for k, val in e.items():
                    if k in self.VOCAB_SKIP:
                        continue
                    if isinstance(val, str):
                        texts.append(val)
                    elif isinstance(val, list):
                        texts += [x for x in val if isinstance(x, str)]
        for t in texts:
            v |= set(L.analyze(t))
        self.vocab = v

    def _faq_answer(self, f):
        return fill(f["answer"], **self.vars)

    # ------------------------------------------------------------ البحث BM25 (للسياق)
    def search(self, text, k=5, types=None):
        L = self.lex
        qt = [t for t in self.an(text) if t not in L.stop]
        uq = list(dict.fromkeys(qt))
        if not uq:
            return []
        out = []
        for i, doc in enumerate(self.docs):
            if types and self.chunks[i]["type"] not in types:
                continue
            sc, matched = 0.0, 0
            for t in uq:
                tf = doc.get(t, 0)
                if tf:
                    matched += 1
                    df = self.df[t]
                    idf = math.log(1 + (self.N - df + 0.5) / (df + 0.5))
                    sc += idf * (tf * (self.K1 + 1)) / (tf + self.K1 * (1 - self.B + self.B * self.dl[i] / self.avgdl))
            if sc > 0:
                out.append((sc, i, matched / len(uq)))
        out.sort(key=lambda x: (-x[0], x[1]))
        return [{"chunk": self.chunks[i], "score": round(sc, 4), "coverage": cov} for sc, i, cov in out[:k]]

    # ------------------------------------------------------------ تحليل الرسالة
    def _emergency(self, toks):
        for r in self.emergency_rules:
            if any(contains_phrase(toks, p) for p in r["any"]):
                return r
            if r["all"] and all(any(contains_phrase(toks, p) for p in grp) for grp in r["all"]):
                return r
        return None

    def _self_harm(self, toks):
        return any(contains_phrase(toks, p) for p in self.self_harm_phrases)

    def _intents(self, toks):
        found = set()
        for name, phrases in self.intent_phrases.items():
            if name in ("yes", "no") and len(toks) > 4:
                continue
            if name == "qamar":
                if any(contains_phrase(toks, p) and (len(p) >= 2 or len(toks) <= 2) for p in phrases):
                    found.add(name)
                continue
            if any(contains_phrase(toks, p) for p in phrases):
                found.add(name)
        if any(contains_phrase(toks, p) for p in self.advice_phrases):
            found.add("advice")
        return [n for n in self.priority if n in found]

    def _route_group(self, toks, items):
        L = self.lex
        tset = set(toks)
        scored = []
        for it in items:
            sc = 0
            for kw in list(it.get("keywords", [])) + [it["name"]]:
                kt = [t for t in L.analyze(kw) if t not in L.stop]
                if kt and all(t in tset for t in kt):
                    sc += len(kt)
            if sc:
                scored.append((sc, it.get("sort", 0), it["id"]))
        scored.sort(key=lambda x: (-x[0], x[1], x[2]))
        return [(i, sc) for sc, _s, i in scored]

    def route(self, toks):
        return self._route_group(toks, self.specs)

    def service_match(self, toks):
        return self._route_group(toks, self.services)

    def branches_in(self, toks):
        tset = set(toks)
        return [b["id"] for b, bt in zip(self.branches, self.branch_tokens) if bt & tset]

    def doctors_in(self, toks):
        L = self.lex
        tset = set(toks)
        has_title = "طبيب" in tset
        found = []
        for d in self.doctors:
            nt = [t for t in L.analyze(d["name"]) if len(t) >= 3 and t not in L.stop]
            m = [t for t in nt if t in tset]
            if not m:
                continue
            if len(m) >= 2 or any(len(t) >= 4 for t in m) or has_title:
                found.append(d["id"])
        return found

    def faq_match(self, toks, only=None, exclude=None, drop=None):
        """أقرب سؤال شائع: (faq، عدد المتطابق، التغطية) أو None. يعتمد على السؤال والكلمات المفتاحية فقط."""
        L = self.lex
        q = {t for t in toks if t not in L.stop and not (drop and t in drop)}
        if not q:
            return None
        best = None
        for idx, f in enumerate(self.faqs):
            cat = f.get("category", "app")
            if only and cat != only:
                continue
            if exclude and cat == exclude:
                continue
            m = q & self.faq_tokens[f["id"]]
            if not m:
                continue
            key = (len(m) / len(q), len(m), -idx)
            if best is None or key > best[0]:
                best = (key, f, len(m), len(m) / len(q), len(q))
        if not best:
            return None
        _, f, nm, cov, nq = best
        return {"faq": f, "matched": nm, "coverage": cov, "qsize": nq}

    # ------------------------------------------------------------ مساعدات الصياغة
    def T_(self, key, **kw):
        v = dict(self.vars)
        v.update(kw)
        return fill(self.T[key], **v)

    def _phones_text(self):
        lines = [self.T_("contact_line", label=p["label"], number=p["number"]) for p in self.s.get("phones", [])]
        return self.T_("contact_intro") + "\n" + "\n".join(lines)

    def _landmark(self, b):
        return f" ({b['landmark']})" if b.get("landmark") else ""

    def _branch_line(self, b):
        return self.T_("branch_line", name=b["name"], address=b.get("address", ""), landmark=self._landmark(b))

    def _branch_one(self, b):
        return self.T_("branch_one", name=b["name"], address=b.get("address", ""), landmark=self._landmark(b), phone=b.get("phone", ""))

    def _a(self, typ, **kw):
        d = {"type": typ}
        d.update(kw)
        return d

    def _call_main(self):
        return self._a("call", number=self.vars["phone_main"], label="اتصال بالرقم الموحد")

    def _wa_actions(self):
        acts = []
        for b in self.branches:
            wa = b.get("whatsapp") or ""
            if wa:
                acts.append(self._a("whatsapp", number=e164_digits(wa), label="واتساب " + (b.get("shortName") or b["name"])))
        if not acts and self.s.get("whatsapp"):
            acts.append(self._a("whatsapp", number=e164_digits(self.s["whatsapp"]), label="واتساب"))
        return acts

    def _book_action(self, spec=None, doctor=None, branch=None):
        a = self._a("book", label="ابدأ طلب الحجز")
        if spec:
            a["specialtyId"] = spec
        if doctor:
            a["doctorId"] = doctor
        if branch:
            a["branchId"] = branch
        return a

    def mentions(self, text):
        """يستخرج الكيانات المذكورة في نص (يُستخدم لبناء البطاقات من رد النموذج ومن الرد السابق)."""
        toks = self.an(text)
        ents = {"branches": self.branches_in(toks), "doctors": self.doctors_in(toks), "specialties": [], "services": []}
        tset = set(toks)
        L = self.lex
        for items, key in ((self.specs, "specialties"), (self.services, "services")):
            for it in items:
                nt = [t for t in L.analyze(it["name"]) if t not in L.stop and len(t) >= 3]
                if nt and all(t in tset for t in nt):
                    ents[key].append(it["id"])
        return ents

    def faq_text(self, f):
        head = f["question"]
        body = self._faq_answer(f)
        if f.get("category") == "tips":
            return self.T_("tips_intro") + "\n" + head + "\n" + body + "\n" + self.T_("tips_note")
        return head + "\n" + body

    # ------------------------------------------------------------ الإجابة القاعدية (حتمية)
    def answer(self, text, history=None):
        L = self.lex
        q = (text or "").strip()[:600]
        toks = self.an(q)
        res = {"text": "", "actions": [], "intent": None, "confident": True, "emergency": False,
               "direct": False, "faq": None, "routed": [], "entities": {}, "chips": []}

        em = self._emergency(toks)
        if em:
            res.update(intent="emergency", emergency=True, text=self.T_("emergency", hint=em["hint"]))
            res["actions"] = [self._a("emergency", number=self.vars["emergency"], label="اتصال بالإسعاف " + self.vars["emergency"])]
            return res
        if self._self_harm(toks):
            res.update(intent="self_harm", emergency=True, text=self.T_("self_harm"))
            res["actions"] = [self._a("emergency", number=self.vars["emergency"], label="اتصال بالإسعاف " + self.vars["emergency"]),
                              self._a("call", number=self.vars["healthline"], label="خط وزارة الصحة " + self.vars["healthline"])]
            return res

        ints = self._intents(toks)
        main = ints[0] if ints else None
        routed = self.route(toks)
        svc = self.service_match(toks)
        ents = {"branches": self.branches_in(toks), "doctors": self.doctors_in(toks),
                "specialties": [i for i, _ in routed[:2]], "services": [i for i, _ in svc[:1]]}
        res["routed"] = [i for i, _ in routed[:2]]
        res["entities"] = ents

        # ---- الأسئلة الشائعة الخاصة بالتطبيق (إجابة مباشرة عند تطابق قوي)
        if self.q.get("answerFaqDirectly", True) and main in (None, "about", "which_clinic", "booking", "cancel", "hours", "contact", "qamar"):
            fm = self.faq_match(toks, exclude="tips")
            if fm:
                strict = main in ("booking", "cancel", "hours", "contact", "qamar")
                ok = (fm["matched"] >= 3 and fm["coverage"] >= 0.75) if strict else (fm["coverage"] >= 0.6 and (fm["matched"] >= 2 or fm["qsize"] == 1))
                if ok:
                    f = fm["faq"]
                    res.update(intent="faq", direct=True, faq=f["id"], text=self.faq_text(f))
                    if f["id"] in ("faq-book", "faq-confirm"):
                        res["actions"].append(self._book_action())
                    res["actions"].append(self._call_main())
                    return res

        # ---- النصائح الصحية المنشورة
        if main == "tips":
            fm = self.faq_match(toks, only="tips", drop=self.tips_tokens)
            if fm and fm["coverage"] >= 0.4:
                f = fm["faq"]
                res.update(intent="tips", direct=True, faq=f["id"], text=self.faq_text(f))
                res["actions"] = [self._call_main()]
                return res
            tips = [f for f in self.faqs if f.get("category") == "tips"]
            if tips:
                res.update(intent="tips", text=self.T_("tips_list") + "\n" + "\n".join("• " + f["question"] for f in tips),
                           chips=[f["question"] for f in tips][:4])
                return res
            main = None

        if main == "yes":
            last = ""
            for m in reversed(history or []):
                if m.get("role") == "assistant":
                    last = m.get("content", "")
                    break
            lt = self.an(last)
            if any(contains_phrase(lt, p) for p in self.yes_follow):
                prev = self.mentions(last)
                res.update(intent="booking", text=self.T_("booking"))
                sp = prev["specialties"][0] if prev["specialties"] else None
                dr = prev["doctors"][0] if len(prev["doctors"]) == 1 else None
                res["actions"] = [self._book_action(sp, dr)]
                return res
            main = None

        if main == "booking":
            sp = ents["specialties"][0] if ents["specialties"] else None
            dr = ents["doctors"][0] if len(ents["doctors"]) == 1 else None
            br = ents["branches"][0] if len(ents["branches"]) == 1 else None
            if dr:
                text_ = self.T_("booking_for_doctor", doctor=self.doc_label(self.by_id[("doctors", dr)]))
            elif sp:
                text_ = self.T_("booking_for_specialty", specialty=self.by_id[("specialties", sp)]["name"])
            else:
                text_ = self.T_("booking")
            res.update(intent="booking", text=text_)
            res["actions"] = [self._book_action(sp, dr, br), self._call_main()]
            return res

        if main == "cancel":
            res.update(intent="cancel", text=self.T_("cancel"))
            res["actions"] = [self._a("nav", to="profile", label="حجوزاتي"), self._call_main()]
            return res

        if main == "contact":
            res.update(intent="contact", text=self._phones_text())
            res["actions"] = [self._call_main()] + self._wa_actions()
            return res

        if main == "branches":
            if ents["branches"]:
                bs = [self.by_id[("branches", i)] for i in ents["branches"]]
                res.update(intent="branches", text="\n\n".join(self._branch_one(b) for b in bs))
                res["actions"] = [self._a("branch", id=b["id"], label="تفاصيل " + (b.get("shortName") or b["name"])) for b in bs[:2]]
            else:
                res.update(intent="branches", text=self.T_("branches_intro") + "\n" + "\n".join(self._branch_line(b) for b in self.branches))
                res["actions"] = [self._a("branch", id=b["id"], label=b.get("shortName") or b["name"]) for b in self.branches[:3]]
            return res

        if main == "hours":
            lines = [self.T_("hours_line", name=e["name"], hours=e["hoursText"]) for e in self.services + self.specs if e.get("hoursText")]
            if lines:
                res.update(intent="hours", text=self.T_("hours_intro") + "\n" + "\n".join(lines) + "\n" + self.T_("hours_note"))
            else:
                res.update(intent="hours", text=self.T_("hours_none"), confident=False)
            res["actions"] = [self._call_main()]
            return res

        if main in ("insurance", "price"):
            res.update(intent=main, text=self.T_(main), confident=False)
            res["actions"] = [self._call_main()] + self._wa_actions()[:1]
            return res

        if main == "advice":
            res.update(intent="advice", text=self.T_("advice"))
            if routed:
                res["actions"] = [self._a("specialty", id=routed[0][0], label=self.by_id[("specialties", routed[0][0])]["name"]), self._book_action(routed[0][0])]
            else:
                res["actions"] = [self._a("nav", to="specialties", label="عرض التخصصات")]
            return res

        if main == "which_clinic" and not routed:
            res.update(intent="which_clinic", text=self.T_("which_clinic"), chips=["أسنان", "عظام", "جلدية", "أطفال", "نساء وولادة"])
            return res

        if main == "doctors" and not ents["doctors"] and not routed:
            names = [self.doc_label(d) for d in self.doctors[:8]]
            res.update(intent="doctors", text=self.T_("doctors_intro") + "\n" + "\n".join("• " + n for n in names))
            res["actions"] = [self._a("nav", to="doctors", label="عرض كل الأطباء")]
            return res

        if main == "specialties" and not routed:
            res.update(intent="specialties", text=self.T_("specialties_intro") + "\n" + "\n".join("• " + s["name"] for s in self.specs))
            res["actions"] = [self._a("nav", to="specialties", label="عرض التخصصات")]
            return res

        if main == "services" and not svc:
            res.update(intent="services", text=self.T_("services_intro") + "\n" + "\n".join("• " + s["name"] for s in self.services))
            res["actions"] = [self._a("nav", to="services", label="عرض الخدمات")]
            return res

        if main == "about":
            res.update(intent="about", text=self.T_("about", about=self.s.get("about", "")))
            res["actions"] = [self._a("nav", to="about", label="عن المجمعات")]
            return res

        if main == "qamar":
            res.update(intent="qamar", text=self.T_("qamar"), chips=list(self.q.get("quickReplies", [])))
            return res

        if main in ("thanks", "greeting", "no"):
            res.update(intent=main, text=self.T_(main), chips=list(self.q.get("quickReplies", [])) if main != "thanks" else [])
            return res

        # ---- لا نية واضحة: طبيب مذكور، ثم توجيه أعراض/تخصص، ثم خدمة، ثم فرع، ثم سؤال شائع
        if ents["doctors"]:
            ds = [self.by_id[("doctors", i)] for i in ents["doctors"][:3]]
            if len(ds) == 1:
                d = ds[0]
                sps = "، ".join(self._names(d.get("specialtyIds", []), "specialties") + self._names(d.get("serviceIds", []), "services")) or "—"
                res.update(intent="doctor", text=self.T_("doctor_one", doctor=self.doc_label(d), rank=(" — " + d["rank"] if d.get("rank") else ""),
                                                        degree=(" — " + d["degree"] if d.get("degree") else ""), specialties=sps))
                res["actions"] = [self._a("doctor", id=d["id"], label=self.doc_label(d)), self._book_action(None, d["id"])]
            else:
                res.update(intent="doctors", text=self.T_("doctors_intro") + "\n" + "\n".join("• " + self.doc_label(d) for d in ds))
                res["actions"] = [self._a("doctor", id=d["id"], label=self.doc_label(d)) for d in ds]
            return res

        if routed and (not svc or routed[0][1] > svc[0][1]):
            sp = self.by_id[("specialties", routed[0][0])]
            if len(routed) > 1 and routed[1][1] >= routed[0][1]:
                sp2 = self.by_id[("specialties", routed[1][0])]
                t = self.T_("route_two", specialty=sp["name"], specialty2=sp2["name"])
                res["actions"] = [self._a("specialty", id=sp["id"], label=sp["name"]), self._a("specialty", id=sp2["id"], label=sp2["name"]), self._book_action(sp["id"])]
            else:
                t = self.T_("route", specialty=sp["name"])
                res["actions"] = [self._a("specialty", id=sp["id"], label=sp["name"]), self._book_action(sp["id"])]
            if sp["id"] == "chest":
                t = t.replace(" تبي أرتّب لك طلب حجز؟", self.T_("route_chest_note") + " تبي أرتّب لك طلب حجز؟")
            res.update(intent="route", text=t)
            return res

        if svc:
            sv = self.by_id[("services", svc[0][0])]
            docs = [self.doc_label(d) for d in self.doctors if sv["id"] in d.get("serviceIds", [])]
            t = sv["name"] + ": " + sv.get("description", "")
            if sv.get("hoursText"):
                t += "\nالدوام المعلن: " + sv["hoursText"]
            if docs:
                t += "\nالأطباء: " + "، ".join(docs)
            res.update(intent="service", text=t)
            res["actions"] = [self._a("service", id=sv["id"], label=sv["name"]), self._call_main()]
            return res

        if ents["branches"]:
            bs = [self.by_id[("branches", i)] for i in ents["branches"]]
            res.update(intent="branches", text="\n\n".join(self._branch_one(b) for b in bs))
            res["actions"] = [self._a("branch", id=b["id"], label="تفاصيل " + (b.get("shortName") or b["name"])) for b in bs[:2]]
            return res

        fm = self.faq_match(toks)
        if fm and fm["coverage"] >= 0.75 and fm["matched"] >= 2:
            f = fm["faq"]
            res.update(intent="faq", direct=True, faq=f["id"], text=self.faq_text(f))
            res["actions"] = [self._call_main()]
            return res

        res.update(intent="unknown", confident=False, text=self.T_("unknown"), chips=list(self.q.get("quickReplies", [])))
        res["actions"] = [self._call_main()] + self._wa_actions()[:1]
        return res

    # ------------------------------------------------------------ سياق النموذج
    def context_text(self, text, max_chars=5200):
        s = self.s
        lines = [f"المجمع: {s.get('name','')} ({s.get('legalName','')}) — {s.get('city','')}. {s.get('about','')}"]
        lines.append("أرقام التواصل: " + "، ".join(f"{p['label']} {p['number']}" for p in s.get("phones", [])))
        lines.append("الفروع:")
        for b in self.branches:
            lm = f"، {b['landmark']}" if b.get("landmark") else ""
            lines.append(f"- {b['name']}: {b.get('address','')}{lm}")
        lines.append("العيادات والأطباء (الأطباء المعلنون فقط):")
        for sp in self.specs:
            docs = [self.doc_label(d) + (f" ({d['rank']})" if d.get("rank") else "") for d in self.doctors if sp["id"] in d.get("specialtyIds", [])]
            h = f" — الدوام المعلن: {sp['hoursText']}" if sp.get("hoursText") else ""
            lines.append(f"- {sp['name']}: {'، '.join(docs) if docs else 'لا يوجد أطباء معلنون'}{h}")
        lines.append("الخدمات:")
        for sv in self.services:
            docs = [self.doc_label(d) for d in self.doctors if sv["id"] in d.get("serviceIds", [])]
            h = f" — الدوام المعلن: {sv['hoursText']}" if sv.get("hoursText") else ""
            lines.append(f"- {sv['name']}: {sv.get('description','')}{(' الأطباء: ' + '، '.join(docs)) if docs else ''}{h}")
        base = "\n".join(lines)
        extra = []
        for h in self.search(text, 4):
            c = h["chunk"]
            if c["type"] in ("faq", "clinic"):
                extra.append(f"[{c['type']}] {c['title']}: {c['text']}")
        ctx = base[:max_chars]
        if extra:
            ctx += "\nمقتطفات ذات صلة بالسؤال:\n" + "\n".join(extra)
        return ctx

    def allowed_text(self):
        """النص المسموح بأن تظهر فيه الأرقام والأسماء (للتحقق من رد النموذج)."""
        return self.context_text("", 100000) + " " + " ".join(self._faq_answer(f) for f in self.faqs) + " " + \
            json.dumps(self.s.get("phones", []), ensure_ascii=False) + " " + " ".join(self.vars.values())
