"""إرسال رسائل التحقق (OTP). مزوّد واحد حقيقي (تقنيات) + مزوّد اختبار لا يُرسل شيئاً.
لا يُفعَّل أي إرسال إلا إذا ضُبط DS_SMS_PROVIDER في .env؛ ومفتاح المزوّد يوضع على الخادم فقط."""
import json
import time
import urllib.error
import urllib.request


class SmsError(Exception):
    pass


def enabled(cfg):
    return cfg.sms_provider in ("taqnyat", "test")


def send(cfg, phone, text):
    """phone بصيغة 9665xxxxxxxx. يرفع SmsError عند الفشل."""
    if cfg.sms_provider == "test":
        # للاختبار الآلي فقط: يُسجَّل الرمز في ملف بجوار قاعدة البيانات ولا يُرسل لأحد. لا تضبطه في الإنتاج.
        with open(cfg.db_path.parent / "sms-test.log", "a", encoding="utf-8") as f:
            f.write(json.dumps({"t": int(time.time()), "phone": phone, "text": text}, ensure_ascii=False) + "\n")
        return
    if cfg.sms_provider == "taqnyat":
        if not (cfg.sms_token and cfg.sms_sender):
            raise SmsError("مزوّد الرسائل غير مكتمل الإعداد")
        req = urllib.request.Request(
            "https://api.taqnyat.sa/v1/messages",
            data=json.dumps({"recipients": [phone], "body": text, "sender": cfg.sms_sender}, ensure_ascii=False).encode("utf-8"),
            method="POST", headers={"Content-Type": "application/json", "Authorization": "Bearer " + cfg.sms_token})
        try:
            with urllib.request.urlopen(req, timeout=10) as r:
                if r.status not in (200, 201):
                    raise SmsError("رفض المزوّد الرسالة (%s)" % r.status)
        except urllib.error.HTTPError as e:
            raise SmsError("رفض المزوّد الرسالة (%s)" % e.code)
        except (urllib.error.URLError, TimeoutError, OSError):
            raise SmsError("تعذّر الوصول إلى مزوّد الرسائل")
        return
    raise SmsError("لا يوجد مزوّد رسائل")
