"""واجهات الموظفين: دخول الموظف، الاستقبال (المراجعون، الحجوزات، الزيارات)، وإدارة الحسابات من لوحة الإدارة.

كل طلب يمر بثلاث بوابات في الخادم (لا في الواجهة): توكن موظف صالح لحساب فعّال ← الدور يملك الصلاحية ← نطاق الفرع.
كل عملية تعديل تُسجَّل في جدول audit باسم المستخدم.
"""
import hmac
import hashlib
import json
import re
import sqlite3
import time

import importer
import rbac
import scheddb as scd
from util import b64url, b64url_dec, check_password, hash_password, norm_phone, riyadh_today

STAFF_HOURS = 10
LOCK_AFTER, LOCK_SECONDS = 5, 900
USERNAME_RE = re.compile(r"^[a-z][a-z0-9._-]{2,29}$")
VISIT_STATUS = {"waiting": "ينتظر", "ready": "جاهز للطبيب", "with_doctor": "عند الطبيب", "done": "انتهت الزيارة", "left": "غادر المراجع", "cancelled": "ملغاة"}
TRANSITIONS = {"waiting": ("ready", "with_doctor", "cancelled"), "ready": ("waiting", "with_doctor", "cancelled"), "with_doctor": ("ready", "done"), "done": ("left",)}
STATUS_PERM = {"cancelled": "visits.cancel", "left": "visits.checkout"}      # غير ذلك: visits.advance
OPEN_BOOKING = ("new", "contacted", "confirmed")
_DUMMY_PW = hash_password("dummy-password-for-timing", iters=200_000)


def mask_id(nid):
    return ("******" + nid[-4:]) if nid else ""


def norm_name(s):
    return re.sub(r"\s+", " ", str(s or "")).strip().lower()


class StaffMixin:
    # ------------------------------------------------------------------ التوكن
    def staff_token(self, s):
        payload = b64url(json.dumps({"k": "st", "sid": s["id"], "ph": s["pw"]["hash"][:10], "exp": int(time.time() + STAFF_HOURS * 3600)}).encode())
        return payload + "." + hmac.new(self.app.secret, payload.encode(), hashlib.sha256).hexdigest()

    def staff_from_token(self, tok):
        try:
            payload, sig = tok.split(".", 1)
            if not hmac.compare_digest(sig, hmac.new(self.app.secret, payload.encode(), hashlib.sha256).hexdigest()):
                return None
            d = json.loads(b64url_dec(payload))
            if d.get("k") != "st" or d["exp"] <= time.time():
                return None
            s = self.app.db.staff_get(d["sid"])
            # تغيير كلمة المرور أو إيقاف الحساب يُبطل كل التوكنات القديمة فوراً
            if not s or not s["active"] or d["ph"] != s["pw"]["hash"][:10]:
                return None
            return s
        except Exception:  # noqa: BLE001
            return None

    @staticmethod
    def staff_public(s):
        r = rbac.ROLES.get(s["role"], {})
        return {"id": s["id"], "username": s["username"], "name": s["name"], "role": s["role"], "roleLabel": r.get("label", s["role"]),
                "branchId": s["branch_id"] or "", "doctorId": s.get("doctor_id") or "", "perms": rbac.perms_of(s["role"]), "mustChange": bool(s["must_change"])}

    def staff_auth(self, allow_must_change=False):
        h = self.headers.get("Authorization", "")
        s = self.staff_from_token(h[7:]) if h.startswith("Bearer ") else None
        if not s:
            self.err(401, "unauthorized", "سجّل الدخول")
            return None
        if s["must_change"] and not allow_must_change:
            self.err(403, "must_change", "غيّر كلمة المرور المؤقتة أولاً")
            return None
        if not self.app.rl.allow("sapi:" + s["id"], 600, 60):
            self.err(429, "rate_limited", "طلبات كثيرة")
            return None
        return s

    def need(self, s, perm):
        if rbac.can(s["role"], perm):
            return True
        self.err(403, "forbidden", "ليست لديك صلاحية لهذه العملية")
        return False

    @staticmethod
    def in_scope(s, branch_id):
        return not s["branch_id"] or not branch_id or s["branch_id"] == branch_id

    def saudit(self, s, action, kind="", ref="", detail=None):
        self.app.db.audit("staff:" + s["username"], action, kind, ref, json.dumps(detail, ensure_ascii=False) if detail else "")

    # ------------------------------------------------------------------ توزيع
    def staff_api(self, method, p):
        app = self.app
        if method == "POST" and p == "/login":
            return self.staff_login()
        if method == "POST" and p == "/password":
            s = self.staff_auth(allow_must_change=True)
            return self.staff_password(s) if s else None
        s = self.staff_auth()
        if not s:
            return
        db = app.db
        if method == "GET" and p == "/me":
            return self.json(200, {"user": self.staff_public(s)})
        if method == "GET" and p == "/lookups":
            return self.staff_lookups(s)
        if method == "GET" and p == "/records":
            return self.staff_records_search(s)
        if method == "POST" and p == "/records":
            return self.staff_record_save(s)
        m = re.fullmatch(r"/records/([A-Za-z0-9][A-Za-z0-9\-_/.]{0,29})", p)
        if method == "GET" and m:
            return self.staff_record_view(s, m.group(1))
        if method == "GET" and p == "/bookings":
            return self.staff_bookings(s)
        m = re.fullmatch(r"/bookings/(DS-[A-Z0-9]{6})", p)
        if method == "PATCH" and m:
            if not self.need(s, "bookings.manage"):
                return
            b = db.get_booking(m.group(1))
            if not b or not self.in_scope(s, b["branch_id"]):
                return self.err(404, "not_found")
            return self.admin_booking_update(m.group(1), who="staff:" + s["username"])
        if method == "GET" and p == "/visits":
            return self.staff_visits(s)
        if method == "POST" and p == "/visits":
            return self.staff_visit_create(s)
        m = re.fullmatch(r"/visits/(v-[0-9a-f]{12})/(status|transfer)", p)
        if method == "POST" and m:
            return self.staff_visit_status(s, m.group(1)) if m.group(2) == "status" else self.staff_visit_transfer(s, m.group(1))
        if p.startswith("/clinic/") or p.startswith("/unit/") or p.endswith("/summary"):
            if self.clinic_api(method, p, s):
                return
        if method == "GET" and p == "/audit":
            if not self.need(s, "audit.read"):
                return
            return self.json(200, {"audit": db.audit_search(limit=self.qs.get("limit", 100), who=self.qs.get("who"), action=self.qs.get("action"), before=self.qs.get("before") or None)})
        self.err(404, "not_found")

    # ------------------------------------------------------------------ الدخول وكلمة المرور
    def staff_login(self):
        app = self.app
        if not app.rl.allow("slogin:" + self.ip, 30, 600):
            return self.err(429, "rate_limited", "محاولات كثيرة، انتظر 10 دقائق")
        body = self.body_json()
        if body is None:
            return
        username = str(body.get("username", "")).strip().lower()[:40]
        pw = str(body.get("password", ""))
        s = app.db.staff_get(username=username) if USERNAME_RE.fullmatch(username) else None
        bad = "اسم المستخدم أو كلمة المرور غير صحيحة، أو الحساب مقفل مؤقتاً (بعد %d محاولات فاشلة يُقفل %d دقيقة)" % (LOCK_AFTER, LOCK_SECONDS // 60)
        locked = bool(s) and s["locked_until"] > time.time()
        ok = check_password(pw, s["pw"] if s else _DUMMY_PW)   # نفس الكلفة سواء وُجد الحساب أم لا
        if not s or not s["active"] or locked or not ok:
            if s and s["active"] and not locked:
                f = s["failed"] + 1
                app.db.staff_update(s["id"], failed=0 if f >= LOCK_AFTER else f, locked_until=int(time.time()) + LOCK_SECONDS if f >= LOCK_AFTER else 0)
                if f >= LOCK_AFTER:
                    app.db.audit("staff:" + s["username"], "staff_locked", "staff", s["id"], "")
            app.db.audit("staff:" + (username or "?"), "staff_login_fail", "staff", s["id"] if s else "", "")
            return self.err(401, "bad_credentials", bad)
        s = app.db.staff_update(s["id"], failed=0, locked_until=0, last_login=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
        app.db.audit("staff:" + s["username"], "staff_login", "staff", s["id"], "")
        return self.json(200, {"token": self.staff_token(s), "user": self.staff_public(s), "hours": STAFF_HOURS})

    def staff_password(self, s):
        body = self.body_json()
        if body is None:
            return
        old, new = str(body.get("old", "")), str(body.get("new", ""))
        if not check_password(old, s["pw"]):
            return self.err(401, "bad_password", "كلمة المرور الحالية غير صحيحة")
        if len(new) < 10 or new == old or new.lower() == s["username"]:
            return self.err(422, "weak", "كلمة المرور الجديدة: 10 أحرف على الأقل، وتختلف عن الحالية واسم المستخدم")
        s = self.app.db.staff_update(s["id"], pw=hash_password(new), must_change=0)
        self.saudit(s, "staff_password_change", "staff", s["id"])
        return self.json(200, {"ok": True, "token": self.staff_token(s), "user": self.staff_public(s)})

    # ------------------------------------------------------------------ مراجع للقوائم
    def staff_lookups(self, s):
        db = self.app.db
        branches = [b for b in db.list_entities("branches") if not s["branch_id"] or b["id"] == s["branch_id"]]
        bids = {b["id"] for b in branches}
        doctors = [d for d in db.list_entities("doctors") if not s["branch_id"] or not d.get("branchIds") or s["branch_id"] in d["branchIds"]]
        spec = {x["id"]: x["name"] for x in db.list_entities("specialties")}
        return self.json(200, {
            "today": riyadh_today().isoformat(),
            "branches": [{"id": b["id"], "name": b.get("shortName") or b["name"]} for b in branches],
            "doctors": [{"id": d["id"], "name": d["name"], "branchIds": [x for x in d.get("branchIds", []) if not bids or x in bids] if d.get("branchIds") else [],
                         "specialties": [spec.get(i, i) for i in d.get("specialtyIds", [])]} for d in doctors],
            "visitStatus": VISIT_STATUS})

    # ------------------------------------------------------------------ المراجعون
    @staticmethod
    def record_staff_dict(r):
        return {"mrn": r["mrn"], "name": r["name"], "phone": r["phone"], "birthDate": r["birth_date"] or "", "gender": r["gender"] or "",
                "nationalIdMasked": mask_id(r["national_id"]), "source": r["source"]}

    def staff_records_search(self, s):
        if not self.need(s, "records.read"):
            return
        q = self.qs.get("q", "").strip()
        if len(q) < 2:
            return self.json(200, {"records": [], "hint": "اكتب حرفين على الأقل"})
        return self.json(200, {"records": [self.record_staff_dict(r) for r in self.app.db.records_search(q, limit=25)]})

    def staff_record_view(self, s, mrn):
        if not self.need(s, "records.read"):
            return
        db = self.app.db
        r = db.record_get(mrn)
        if not r:
            return self.err(404, "not_found", "رقم الملف غير موجود")
        self.saudit(s, "record_view", "record", r["mrn"])
        docs = {d["id"]: d["name"] for d in db.list_entities("doctors", include_inactive=True)}
        rows = db.conn().execute("SELECT * FROM visits WHERE mrn=? COLLATE NOCASE ORDER BY arrived_at DESC LIMIT 10", (r["mrn"],))
        rows = [dict(v) for v in rows]
        vids = [v["id"] for v in rows]
        encs, ords = db.enc_for_visits(vids), db.orders_for_visits(vids)
        return self.json(200, {"record": self.record_staff_dict(r), "visits": [self.visit_dict(v, docs, encs.get(v["id"]), ords.get(v["id"])) for v in rows]})

    def staff_record_save(self, s):
        if not self.need(s, "records.write"):
            return
        body = self.body_json()
        if body is None:
            return
        db = self.app.db
        mrn = str(body.get("mrn", "") or "").strip()
        src = {"mrn": mrn or "TMP-1", "name": body.get("name"), "phone": body.get("phone"), "nationalId": body.get("nationalId"),
               "birthDate": body.get("birthDate"), "gender": body.get("gender")}
        rows, errs = importer.parse_rows([src], norm_phone)
        if errs or not rows:
            return self.err(422, "validation", errs[0]["error"] if errs else "بيانات غير صحيحة")
        r = rows[0]
        if not mrn:
            same = [x for x in db.records_for_phone(r["phone"]) if norm_name(x["name"]) == norm_name(r["name"])]
            if same and not body.get("force"):
                return self.json(409, {"error": "duplicate", "message": "يوجد مراجع بنفس الاسم والجوال", "existing": [self.record_staff_dict(x) for x in same]})
            r["mrn"] = db.next_local_mrn()
        state = db.record_upsert(r, "reception")
        self.saudit(s, "record_" + ("create" if state == "new" else "update"), "record", r["mrn"], {"state": state})
        return self.json(201 if state == "new" else 200, {"state": state, "record": self.record_staff_dict(db.record_get(r["mrn"]))})

    # ------------------------------------------------------------------ الحجوزات
    def staff_bookings(self, s):
        if not self.need(s, "bookings.read"):
            return
        db = self.app.db
        today = riyadh_today().isoformat()
        cutoff = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - 30 * 86400))
        out = []
        vis = {v["booking_id"]: v for v in db.conn().execute("SELECT * FROM visits WHERE booking_id IS NOT NULL AND day>=?", (today,))}
        for b in db.list_bookings(limit=400):
            if b["status"] not in OPEN_BOOKING or b["created_at"] < cutoff or not self.in_scope(s, b["branch_id"]):
                continue
            if b["status"] == "confirmed" and (b["date"] or "9999") < today and not vis.get(b["id"]):
                continue
            v = vis.get(b["id"])
            out.append({"id": b["id"], "status": b["status"], "name": b["name"], "phone": b["phone"], "doctorId": b["doctor_id"] or "", "branchId": b["branch_id"] or "",
                        "specialtyId": b["specialty_id"] or "", "date": b["date"] or "", "period": b["period"] or "", "note": b["note"] or "", "adminNote": b["admin_note"] or "",
                        "appointmentText": b["appointment_text"] or "", "createdAt": b["created_at"], "visitId": v["id"] if v else "", "visitStatus": v["status"] if v else "",
                        "slotLabel": scd.time_ar(b["slot_start"]) if b.get("slot_start") is not None else "", "slotStart": b["slot_start"] if b.get("slot_start") is not None else -1,
                        "payStatus": b.get("pay_status") or ""})
        return self.json(200, {"bookings": out})

    # ------------------------------------------------------------------ الزيارات
    @staticmethod
    def visit_dict(v, docs, enc=None, ords=None):
        enc = enc or {}
        return {"id": v["id"], "day": v["day"], "branchId": v["branch_id"] or "", "doctorId": v["doctor_id"], "doctorName": docs.get(v["doctor_id"], v["doctor_id"]),
                "mrn": v["mrn"], "patientName": v["patient_name"], "bookingId": v["booking_id"] or "", "reason": v["reason"] or "", "status": v["status"],
                "statusLabel": VISIT_STATUS.get(v["status"], v["status"]), "queueNo": v["queue_no"], "arrivedAt": v["arrived_at"], "calledAt": v["called_at"] or "",
                "finishedAt": v["finished_at"] or "", "leftAt": v.get("left_at") or "", "updatedBy": v["updated_by"] or v["created_by"],
                "rxCount": enc.get("rx", 0), "orderCount": enc.get("orders", 0), "hasSummary": bool(enc.get("finished")), "doctorWriting": bool(enc.get("open")),
                "orderStat": ords or {"total": 0, "open": 0, "await": 0, "done": 0, "cancelled": 0}}

    def _docs(self):
        return {d["id"]: d["name"] for d in self.app.db.list_entities("doctors", include_inactive=True)}

    def vd(self, v, docs=None):
        """زيارة واحدة بصيغة الواجهة (مع عدد الأدوية والطلبات)."""
        db = self.app.db
        return self.visit_dict(v, docs or self._docs(), db.enc_for_visits([v["id"]]).get(v["id"]), db.orders_for_visits([v["id"]]).get(v["id"]))

    def staff_visits(self, s):
        if not self.need(s, "visits.read"):
            return
        db = self.app.db
        day = self.qs.get("day") or riyadh_today().isoformat()
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", day):
            return self.err(422, "validation", "تاريخ غير صحيح")
        branch = s["branch_id"] or self.qs.get("branch") or None
        docs = self._docs()
        rows = db.visits_list(day, branch)
        vids = [v["id"] for v in rows]
        encs, ords = db.enc_for_visits(vids), db.orders_for_visits(vids)
        times = db.appt_times([v["booking_id"] for v in rows])
        out = []
        for v in rows:
            d = self.visit_dict(v, docs, encs.get(v["id"]), ords.get(v["id"]))
            if times.get(v["booking_id"]):
                d["apptTime"] = scd.time_ar(times[v["booking_id"]]["start"])
            out.append(d)
        return self.json(200, {"day": day, "visits": out})

    def staff_visit_create(self, s):
        if not self.need(s, "visits.create"):
            return
        body = self.body_json()
        if body is None:
            return
        db = self.app.db
        rec = db.record_get(str(body.get("mrn", "")).strip())
        if not rec:
            return self.err(422, "validation", "المراجع غير مسجّل: سجّله أولاً")
        doc = db.get_entity("doctors", str(body.get("doctorId", "")))
        if not doc or not doc.get("active"):
            return self.err(422, "validation", "اختر الطبيب")
        branch = s["branch_id"] or str(body.get("branchId", "") or "")
        if not branch or not db.get_entity("branches", branch):
            return self.err(422, "validation", "اختر الفرع")
        if s["branch_id"] and body.get("branchId") and body["branchId"] != s["branch_id"]:
            return self.err(403, "forbidden", "هذا الفرع خارج نطاق حسابك")
        if doc.get("branchIds") and branch not in doc["branchIds"]:
            return self.err(422, "validation", "هذا الطبيب لا يعمل في الفرع المختار")
        bid = str(body.get("bookingId", "") or "") or None
        if bid:
            b = db.get_booking(bid)
            if not b or not self.in_scope(s, b["branch_id"]):
                return self.err(422, "validation", "طلب الحجز غير موجود")
        reason = re.sub(r"\s+", " ", str(body.get("reason", "") or "")).strip()[:200]
        try:
            v = db.visit_create(riyadh_today().isoformat(), branch, doc["id"], rec, bid, reason, "staff:" + s["username"])
        except ValueError as e:
            if str(e).startswith("duplicate:"):
                old = db.visit_get(str(e)[10:])
                od = doc if old["doctor_id"] == doc["id"] else (db.get_entity("doctors", old["doctor_id"]) or {})
                return self.err(409, "duplicate", "لدى المراجع زيارة جارية اليوم (رقم %d عند %s)" % (old["queue_no"], od.get("name") or old["doctor_id"]))
            raise
        self.saudit(s, "visit_create", "visit", v["id"], {"mrn": v["mrn"], "doctor": v["doctor_id"], "branch": branch, "queue": v["queue_no"], "booking": bid or ""})
        self.notify_visit(v, "arrived")
        return self.json(201, {"visit": self.vd(v)})

    def _visit_for(self, s, vid):
        v = self.app.db.visit_get(vid)
        if not v or not self.in_scope(s, v["branch_id"]):
            self.err(404, "not_found", "الزيارة غير موجودة")
            return None
        return v

    def staff_visit_status(self, s, vid):
        body = self.body_json()
        if body is None:
            return
        v = self._visit_for(s, vid)
        if not v:
            return
        db = self.app.db
        new = str(body.get("status", ""))
        if new not in VISIT_STATUS or new not in TRANSITIONS.get(v["status"], ()):
            return self.err(409, "bad_transition", "لا يمكن تغيير الحالة من «%s» إلى «%s»" % (VISIT_STATUS.get(v["status"], v["status"]), VISIT_STATUS.get(new, new)))
        if not self.need(s, STATUS_PERM.get(new, "visits.advance")):
            return
        if new == "done":
            e = db.enc_get(vid)
            if e and not e["finished_at"]:       # الطبيب فتح زيارته: ينهيها هو حتى لا تضيع كتابته
                return self.err(409, "doctor_writing", "الطبيب يكتب زيارة هذا المراجع الآن؛ ينهيها هو من تطبيقه")
        f = {"status": new}
        t = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        if new == "with_doctor" and not v["called_at"]:
            f["called_at"] = t
        if new in ("done", "cancelled"):
            f["finished_at"] = t
        if new == "left":
            f["left_at"] = t
        v2 = db.visit_update(vid, "staff:" + s["username"], **f)
        self.saudit(s, "visit_" + new, "visit", vid, {"from": v["status"]})
        if new == "with_doctor":
            self.notify_visit(v2, "called")
        return self.json(200, {"visit": self.vd(v2)})

    def staff_visit_transfer(self, s, vid):
        if not self.need(s, "visits.transfer"):
            return
        body = self.body_json()
        if body is None:
            return
        db = self.app.db
        v = self._visit_for(s, vid)
        if not v:
            return
        if v["status"] not in ("waiting", "ready"):
            return self.err(409, "bad_transition", "لا يمكن التحويل بعد دخول المراجع للطبيب أو انتهاء الزيارة")
        doc = db.get_entity("doctors", str(body.get("doctorId", "")))
        if not doc or not doc.get("active"):
            return self.err(422, "validation", "اختر الطبيب")
        if doc["id"] == v["doctor_id"]:
            return self.err(422, "validation", "المراجع عند هذا الطبيب أصلاً")
        if doc.get("branchIds") and v["branch_id"] not in doc["branchIds"]:
            return self.err(422, "validation", "هذا الطبيب لا يعمل في فرع هذه الزيارة")
        v2 = db.visit_update(vid, "staff:" + s["username"], doctor_id=doc["id"], status="waiting")
        self.saudit(s, "visit_transfer", "visit", vid, {"from": v["doctor_id"], "to": doc["id"], "queue": v2["queue_no"]})
        return self.json(200, {"visit": self.vd(v2)})

    # ------------------------------------------------------------------ إدارة الحسابات (لوحة الإدارة، المالك فقط)
    def admin_staff_api(self, method, p):
        db = self.app.db
        if method == "GET" and p == "/roles":
            return self.json(200, {"roles": rbac.public_roles(ready_only=False), "branches": [{"id": b["id"], "name": b.get("shortName") or b["name"]} for b in db.list_entities("branches")],
                                   "doctors": [{"id": d["id"], "name": d["name"]} for d in db.list_entities("doctors", include_inactive=True)]})
        if method == "GET" and p == "/audit":
            return self.json(200, {"audit": db.audit_search(limit=self.qs.get("limit", 200), who=self.qs.get("who"), action=self.qs.get("action"), before=self.qs.get("before") or None)})
        if method == "GET" and p == "/staff":
            return self.json(200, {"staff": [self.staff_admin_dict(x) for x in db.staff_list()]})
        if method == "POST" and p == "/staff":
            body = self.body_json()
            if body is None:
                return
            f = {}
            username = str(body.get("username", "")).strip().lower()
            if not USERNAME_RE.fullmatch(username):
                f["username"] = "اسم المستخدم: 3–30 حرفاً إنجليزياً صغيراً/أرقاماً/نقطة/شرطة، ويبدأ بحرف"
            name = re.sub(r"\s+", " ", str(body.get("name", ""))).strip()
            if not (2 <= len(name) <= 60):
                f["name"] = "اكتب الاسم الكامل"
            role = str(body.get("role", ""))
            if role not in rbac.ROLES or not rbac.ROLES[role]["ready"]:
                f["role"] = "اختر دوراً من الأدوار المتاحة"
            branch = str(body.get("branchId", "") or "")
            if branch and not db.get_entity("branches", branch):
                f["branchId"] = "فرع غير موجود"
            doctor_id = None
            if role == "doctor":
                doctor_id = str(body.get("doctorId", "") or "")
                if not doctor_id or not db.get_entity("doctors", doctor_id):
                    f["doctorId"] = "اختر الطبيب الذي يخصّ هذا الحساب"
                elif db.staff_for_doctor(doctor_id):
                    f["doctorId"] = "هذا الطبيب مرتبط بحساب فعّال آخر"
            pw = str(body.get("password", ""))
            if len(pw) < 10:
                f["password"] = "كلمة المرور المؤقتة 10 أحرف على الأقل"
            if f:
                return self.err(422, "validation", "تحقق من الحقول", f)
            try:
                s = db.staff_create(username, name, role, branch, hash_password(pw), "admin", doctor_id)
            except sqlite3.IntegrityError:
                return self.err(409, "exists", "اسم المستخدم مستخدم", {"username": "اسم المستخدم مستخدم"})
            db.audit("admin", "staff_create", "staff", s["id"], json.dumps({"username": username, "role": role, "branch": branch, "doctor": doctor_id or ""}, ensure_ascii=False))
            return self.json(201, {"staff": self.staff_admin_dict(s)})
        m = re.fullmatch(r"/staff/(s-[0-9a-f]{10})", p)
        if method == "PATCH" and m:
            s = db.staff_get(m.group(1))
            if not s:
                return self.err(404, "not_found")
            body = self.body_json()
            if body is None:
                return
            f, upd = {}, {}
            if "name" in body:
                name = re.sub(r"\s+", " ", str(body["name"])).strip()
                if not (2 <= len(name) <= 60):
                    f["name"] = "اكتب الاسم الكامل"
                upd["name"] = name
            if "role" in body:
                if body["role"] not in rbac.ROLES or not (rbac.ROLES[body["role"]]["ready"] or body["role"] == s["role"]):
                    f["role"] = "دور غير متاح"
                upd["role"] = body["role"]
            if "branchId" in body:
                b = str(body["branchId"] or "")
                if b and not db.get_entity("branches", b):
                    f["branchId"] = "فرع غير موجود"
                upd["branch_id"] = b or None
            if "active" in body:
                upd["active"] = 1 if body["active"] else 0
            role_new, active_new = upd.get("role", s["role"]), bool(upd.get("active", s["active"]))
            if role_new != "doctor":
                upd["doctor_id"] = None
            elif active_new and ("doctorId" in body or "role" in body or "active" in body):
                did = str(body["doctorId"] or "") if "doctorId" in body else (s.get("doctor_id") or "")
                if not did or not db.get_entity("doctors", did):
                    f["doctorId"] = "اختر الطبيب الذي يخصّ هذا الحساب"
                elif db.staff_for_doctor(did, s["id"]):
                    f["doctorId"] = "هذا الطبيب مرتبط بحساب فعّال آخر"
                else:
                    upd["doctor_id"] = did
            if body.get("password"):
                if len(str(body["password"])) < 10:
                    f["password"] = "كلمة المرور المؤقتة 10 أحرف على الأقل"
                else:
                    upd.update(pw=hash_password(str(body["password"])), must_change=1, failed=0, locked_until=0)
            if f:
                return self.err(422, "validation", "تحقق من الحقول", f)
            s2 = db.staff_update(s["id"], **upd)
            db.audit("admin", "staff_update", "staff", s["id"], json.dumps({k: ("***" if k == "pw" else v) for k, v in upd.items()}, ensure_ascii=False))
            return self.json(200, {"staff": self.staff_admin_dict(s2)})
        self.err(404, "not_found")

    @staticmethod
    def staff_admin_dict(s):
        r = rbac.ROLES.get(s["role"], {})
        return {"id": s["id"], "username": s["username"], "name": s["name"], "role": s["role"], "roleLabel": r.get("label", s["role"]), "branchId": s["branch_id"] or "", "doctorId": s.get("doctor_id") or "",
                "active": bool(s["active"]), "mustChange": bool(s["must_change"]), "locked": s["locked_until"] > time.time(), "createdAt": s["created_at"], "lastLogin": s["last_login"] or ""}
