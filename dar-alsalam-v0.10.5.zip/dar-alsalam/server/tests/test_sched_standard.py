"""ضبط الدوام القياسي من سطر الأوامر (manage.py sched-standard):
معاينة بلا أي تغيير ← نسخة احتياطية ← شفتان لكل طبيب و24 ساعة للطبيب العام ← المحجوز لا يُمسّ ولا يُلغى.
الوقت مثبَّت (الاثنين 23 نوفمبر 2026 الساعة 9:00 بتوقيت الرياض)."""
import argparse
import contextlib
import io
import os
import re
import shutil
import sqlite3
import stat
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from helpers import Env
from test_schedule import NOW, day, fake_now   # يضبط مسار الخادم (helpers) قبل استيراد وحداته

import manage  # noqa: E402
import scheddb as sd  # noqa: E402

SHIFTS = [(540, 750), (960, 1320)]            # 09:00–12:30 و16:00–22:00
ALL_DAY = [(0, 1440)]


def ns(**kw):
    d = dict(yes=False, slot=30, branch=None, off="", skip_existing=False, list=False)
    d.update(kw)
    return argparse.Namespace(**d)


class TestSchedStandard(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.e = Env()
        cls.app = cls.e.app
        cls.db = cls.app.db
        cls.brs = [b["id"] for b in cls.db.list_entities("branches")]
        docs = cls.db.list_entities("doctors")
        cls.general = [d["id"] for d in docs if "general" in (d.get("specialtyIds") or [])]
        cls.others = [d["id"] for d in docs if "general" not in (d.get("specialtyIds") or [])]
        cls.all_ids = [d["id"] for d in docs]

    @classmethod
    def tearDownClass(cls):
        cls.e.close()

    def setUp(self):
        with self.db.tx() as c:
            c.execute("DELETE FROM schedules")
            c.execute("DELETE FROM schedule_days")
            c.execute("UPDATE bookings SET status='cancelled', pay_status=NULL, hold_until=NULL WHERE slot_start IS NOT NULL")
        self.db.set_kv("scheduling", {})
        self.db._bump()
        for f in (self.app.cfg.db_path.parent / "backups").glob("before-hours-*.db") if (self.app.cfg.db_path.parent / "backups").exists() else []:
            f.unlink()
        self._ctx = fake_now()
        self._ctx.__enter__()
        self.addCleanup(self._ctx.__exit__, None, None, None)

    # --------------------------------------------------------------- أدوات
    def run_cmd(self, **kw):
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = manage.cmd_sched_standard(ns(**kw), self.app)
        return rc, buf.getvalue()

    def windows(self, doctor):
        rows, _ = self.db.sched_get(doctor)
        out = {}
        for r in rows:
            out.setdefault(r["weekday"], []).append((r["start_min"], r["end_min"]))
        return out

    def backups(self):
        d = self.app.cfg.db_path.parent / "backups"
        return sorted(d.glob("before-hours-*.db")) if d.exists() else []

    def starts(self, doctor, n, branch=None):
        pol = self.db.sched_policy()
        days = self.db.sched_days(doctor, branch or self.brs[0], pol, NOW)
        return [s["start"] for s in days[n]["slots"]]

    # --------------------------------------------------------------- معاينة
    def test_preview_changes_nothing(self):
        n_audit = lambda: self.db.conn().execute("SELECT COUNT(*) FROM audit WHERE action='sched-standard'").fetchone()[0]  # noqa: E731
        n0, v0 = n_audit(), self.app._data_version()
        rc, out = self.run_cmd()
        self.assertEqual(rc, 0)
        self.assertIn("معاينة فقط", out)
        self.assertIn("أعد الأمر وأضف --yes", out)
        self.assertEqual(self.db.sched_doctor_ids(), [])
        self.assertEqual(self.backups(), [])
        self.assertEqual((n_audit(), self.app._data_version()), (n0, v0))

    def test_preview_describes_the_plan(self):
        rc, out = self.run_cmd()
        self.assertIn("أطباء سيُضبط دوامهم: %d" % len(self.all_ids), out)
        self.assertIn("الطبيب العام (%d): 00:00–24:00 كل يوم" % len(self.general), out)
        self.assertIn("بقية الأطباء (%d): 09:00–12:30 و16:00–22:00 كل يوم" % len(self.others), out)
        self.assertIn("مدة الموعد: 30 دقيقة", out)

    # --------------------------------------------------------------- التطبيق
    def test_apply_sets_two_shifts_and_24h_for_general(self):
        self.assertTrue(self.general and self.others)
        rc, out = self.run_cmd(yes=True)
        self.assertEqual(rc, 0, out)
        self.assertEqual(self.db.sched_doctor_ids(), sorted(self.all_ids))
        for d in self.general:
            w = self.windows(d)
            self.assertEqual({wd: v for wd, v in w.items()}, {wd: ALL_DAY for wd in range(7)}, d)
        for d in self.others:
            w = self.windows(d)
            self.assertEqual(w, {wd: SHIFTS for wd in range(7)}, d)
        rows, _ = self.db.sched_get(self.others[0])
        self.assertEqual({r["slot_min"] for r in rows}, {30})
        self.assertEqual({r["branch_id"] for r in rows}, {self.brs[0]})               # من لم يُحدَّد له فرع ← أول فرع
        self.assertTrue(any(a["action"] == "sched-standard" for a in self.db.audit_search(limit=20)))

    def test_backup_is_taken_before_any_change_and_is_usable(self):
        rc, out = self.run_cmd(yes=True)
        self.assertEqual(rc, 0, out)
        b = self.backups()
        self.assertEqual(len(b), 1)
        self.assertIn(str(b[0]), out)
        import sqlite3
        c = sqlite3.connect(str(b[0]))
        try:
            self.assertEqual(c.execute("SELECT COUNT(*) FROM schedules").fetchone()[0], 0)       # النسخة تحمل الحال قبل التغيير
            self.assertGreater(c.execute("SELECT COUNT(*) FROM entities WHERE kind='doctors'").fetchone()[0], 0)
        finally:
            c.close()

    def test_failed_backup_means_nothing_changes(self):
        with mock.patch.object(type(self.db), "backup_to", side_effect=OSError("disk full")):
            rc, out = self.run_cmd(yes=True)
        self.assertEqual(rc, 1)
        self.assertIn("لم يتغير شيء", out)
        self.assertEqual(self.db.sched_doctor_ids(), [])

    def test_slots_follow_the_hours(self):
        self.run_cmd(yes=True)
        want = ["%02d:%02d" % (m // 60, m % 60) for m in list(range(540, 750, 30)) + list(range(960, 1320, 30))]
        got = self.starts(self.others[0], 1)                                     # الثلاثاء 24 نوفمبر (يوم كامل)
        self.assertEqual(got, want)
        self.assertIn("12:00", got)                                               # آخر موعد صباحي ينتهي 12:30
        self.assertNotIn("12:30", got)
        self.assertNotIn("15:30", got)
        self.assertIn("21:30", got)                                               # آخر موعد مسائي ينتهي 22:00
        self.assertNotIn("22:00", got)
        gp = self.starts(self.general[0], 1)
        self.assertEqual(len(gp), 48)                                             # من منتصف الليل إلى منتصف الليل
        self.assertEqual((gp[0], gp[-1]), ("00:00", "23:30"))

    def test_second_run_is_the_same(self):
        self.run_cmd(yes=True)
        before = {d: self.windows(d) for d in self.all_ids}
        rc, out = self.run_cmd(yes=True)
        self.assertEqual(rc, 0, out)
        self.assertEqual({d: self.windows(d) for d in self.all_ids}, before)

    # --------------------------------------------------------------- الفروع والجداول الموجودة
    def test_branch_choice_order(self):
        if len(self.brs) < 2:
            self.skipTest("فرع واحد")
        a, b = self.brs[0], self.brs[1]
        d_admin, d_assigned, d_plain = self.others[0], self.others[1], self.others[2]
        ent = self.db.get_entity("doctors", d_assigned)
        ent["branchIds"] = [b]
        self.db.upsert_entity("doctors", ent, "test")
        self.db.sched_replace(d_admin, [{"branch_id": b, "weekday": 1, "start_min": 600, "end_min": 700, "slot_min": 20}], [])   # اختارته الإدارة سابقاً
        self.run_cmd(yes=True)
        br_of = lambda d: {r["branch_id"] for r in self.db.sched_get(d)[0]}  # noqa: E731
        self.assertEqual(br_of(d_admin), {b})                 # يبقى كما اختارته الإدارة
        self.assertEqual(br_of(d_assigned), {b})              # فرعه المسجّل
        self.assertEqual(br_of(d_plain), {a})                 # الافتراضي
        d_new = self.others[3]
        self.db.sched_replace(d_new, [], [])                  # طبيب بلا جدول
        self.run_cmd(yes=True, branch=b)
        self.assertEqual(br_of(d_new), {b})                   # --branch يغيّر الافتراضي لمن لا فرع له
        self.assertEqual(br_of(d_plain), {a})                 # ومن له جدول يبقى على فرعه
        rc, out = self.run_cmd(branch="لا-يوجد")
        self.assertEqual(rc, 1)

    def test_future_exceptions_are_kept(self):
        d = self.others[0]
        days = [{"branch_id": "", "day": day(5), "kind": "off", "note": "إجازة"},
                {"branch_id": self.brs[0], "day": day(6), "kind": "hours", "start_min": 600, "end_min": 700, "slot_min": 20, "note": ""}]
        self.db.sched_replace(d, [{"branch_id": self.brs[0], "weekday": 1, "start_min": 600, "end_min": 700, "slot_min": 20}], days)
        self.run_cmd(yes=True)
        _, kept = self.db.sched_get(d)
        self.assertEqual([(x["day"], x["kind"], x["note"]) for x in kept], [(day(5), "off", "إجازة"), (day(6), "hours", "")])

    def test_skip_existing_leaves_current_hours_alone(self):
        d = self.others[0]
        mine = [{"branch_id": self.brs[0], "weekday": 2, "start_min": 600, "end_min": 700, "slot_min": 20}]
        self.db.sched_replace(d, mine, [])
        rc, out = self.run_cmd(yes=True, skip_existing=True)
        self.assertEqual(rc, 0, out)
        self.assertEqual(self.windows(d), {2: [(600, 700)]})
        self.assertEqual(len(self.db.sched_doctor_ids()), len(self.all_ids))
        self.assertIn("تُركوا كما هم", out)

    def test_replacing_existing_hours_is_announced_in_the_preview(self):
        d = self.others[0]
        self.db.sched_replace(d, [{"branch_id": self.brs[0], "weekday": 2, "start_min": 600, "end_min": 700, "slot_min": 20}], [])
        rc, out = self.run_cmd()
        self.assertIn("يستبدل جدولاً موجوداً لدى 1", out)
        self.assertEqual(self.windows(d), {2: [(600, 700)]})                       # المعاينة لم تغيّره

    # --------------------------------------------------------------- خيارات
    def test_days_off_apply_to_standard_doctors_only(self):
        rc, out = self.run_cmd(yes=True, off="الجمعة")
        self.assertEqual(rc, 0, out)
        self.assertNotIn(5, self.windows(self.others[0]))
        self.assertEqual(sorted(self.windows(self.others[0])), [0, 1, 2, 3, 4, 6])
        self.assertEqual(sorted(self.windows(self.general[0])), list(range(7)))     # الطب العام 24 ساعة طوال الأسبوع
        rc, out = self.run_cmd(off="كذا")
        self.assertEqual(rc, 1)
        rc, out = self.run_cmd(off="7")
        self.assertEqual(rc, 1)

    def test_slot_option(self):
        rc, out = self.run_cmd(yes=True, slot=20)
        self.assertEqual(rc, 0)
        self.assertEqual({r["slot_min"] for r in self.db.sched_get(self.others[0])[0]}, {20})
        rc, out = self.run_cmd(slot=25)
        self.assertEqual(rc, 1)

    def test_inactive_doctors_are_not_touched(self):
        d = self.others[-1]
        ent = self.db.get_entity("doctors", d)
        ent["active"] = False
        self.db.upsert_entity("doctors", ent, "test")
        try:
            self.run_cmd(yes=True)
            self.assertNotIn(d, self.db.sched_doctor_ids())
        finally:
            ent["active"] = True
            self.db.upsert_entity("doctors", ent, "test")

    # --------------------------------------------------------------- الحجوزات
    def test_existing_appointments_are_kept_and_outside_ones_reported(self):
        d = self.others[0]
        A = self.brs[0]
        s, r, _ = self.e.adm("PUT", "/schedules/" + d, {"rows": [{"branchId": A, "weekday": w, "start": "08:00", "end": "20:00", "slot": 20} for w in range(7)], "days": []})
        self.assertEqual(s, 200, r)
        body = {"deviceId": "sched_std_device_0123456789", "name": "مراجع", "phone": "0577700001", "doctorId": d, "branchId": A, "consent": True,
                "slot": {"day": day(2), "start": "13:00"}}                          # 13:00 خارج الشفتين الجديدين
        s, r, _ = self.e.req("POST", "/api/v1/bookings", body)
        self.assertEqual(s, 201, r)
        bid = r["booking"]["id"] if "booking" in r else r.get("id")
        rc, out = self.run_cmd(yes=True)
        self.assertEqual(rc, 0, out)
        row = self.db.conn().execute("SELECT status, slot_start FROM bookings WHERE id=?", (bid,)).fetchone()
        self.assertEqual((row["status"] in ("new", "contacted", "confirmed"), row["slot_start"]), (True, 780))   # لم يُلغَ ولم يتحرك
        self.assertIn("خارج الدوام الجديد", out)
        self.assertIn("%s: 1" % self.db.get_entity("doctors", d)["name"], out)

    def test_preview_counts_upcoming_appointments(self):
        d = self.others[0]
        A = self.brs[0]
        self.e.adm("PUT", "/schedules/" + d, {"rows": [{"branchId": A, "weekday": w, "start": "08:00", "end": "20:00", "slot": 20} for w in range(7)], "days": []})
        body = {"deviceId": "sched_std_device_0123456780", "name": "مراجع", "phone": "0577700002", "doctorId": d, "branchId": A, "consent": True,
                "slot": {"day": day(3), "start": "10:00"}}
        s, r, _ = self.e.req("POST", "/api/v1/bookings", body)
        self.assertEqual(s, 201, r)
        rc, out = self.run_cmd(skip_existing=True)
        self.assertIn("مواعيد محجوزة قادمة بموعد محدد: 0", out)                       # الطبيب نفسه متروك
        rc, out = self.run_cmd()
        self.assertIn("مواعيد محجوزة قادمة بموعد محدد: 1", out)

    # --------------------------------------------------------------- محرر الإدارة يتعامل مع «حتى منتصف الليل»
    def test_admin_editor_roundtrip_with_midnight(self):
        self.run_cmd(yes=True)
        d = self.general[0]
        s, g, _ = self.e.adm("GET", "/schedules/" + d)
        self.assertEqual(s, 200, g)
        self.assertEqual({(r["start"], r["end"]) for r in g["rows"]}, {("00:00", "24:00")})
        s, r, _ = self.e.adm("PUT", "/schedules/" + d, {"rows": g["rows"], "days": g["days"]})            # ما يعرضه المحرر يُحفظ كما هو
        self.assertEqual(s, 200, r)
        rows = [{"branchId": g["rows"][0]["branchId"], "weekday": 1, "start": "00:00", "end": "23:59", "slot": 30}]   # حقل الوقت في المتصفح: 23:59
        s, r, _ = self.e.adm("PUT", "/schedules/" + d, {"rows": rows, "days": []})
        self.assertEqual(s, 200, r)
        self.assertEqual([(x["start"], x["end"]) for x in r["rows"]], [("00:00", "24:00")])
        self.assertIn("23:30", self.starts(d, 0))                                   # اليوم (الاثنين): آخر موعد 23:30 لأن الفترة حتى منتصف الليل


MANAGE = Path(__file__).resolve().parent.parent / "manage.py"


class TestRealCommandLine(unittest.TestCase):
    """الأمر كما ستشغّله على الخادم: عملية بايثون مستقلة تقرأ القاعدة من DS_DB (لا استدعاء داخلي)، معاينة ثم تطبيق."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="ds-cli-")
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.dbfile = os.path.join(self.tmp, "clinic.db")
        self.env = dict(os.environ, DS_DB=self.dbfile, PYTHONIOENCODING="utf-8")
        rc, out, err = self.cli("init", "--password", "devpass-12345")
        self.assertEqual(rc, 0, out + err)

    def cli(self, *args):
        p = subprocess.run([sys.executable, "-W", "ignore", str(MANAGE), *args], env=self.env, capture_output=True, text=True, timeout=180)
        return p.returncode, p.stdout, p.stderr

    def count(self, sql):
        c = sqlite3.connect(self.dbfile)
        try:
            return c.execute(sql).fetchone()[0]
        finally:
            c.close()

    def backups(self):
        d = Path(self.tmp) / "backups"
        return sorted(d.glob("before-hours-*.db")) if d.exists() else []

    def test_preview_then_apply(self):
        self.assertEqual(self.count("SELECT COUNT(*) FROM schedules"), 0)
        rc, out, err = self.cli("sched-standard")
        self.assertEqual(rc, 0, out + err)
        self.assertIn("معاينة فقط — لم يتغير شيء في بياناتك.", out)
        n = int(re.search(r"أطباء سيُضبط دوامهم: (\d+)", out).group(1))
        self.assertGreater(n, 0)
        gp = int(re.search(r"الطبيب العام \((\d+)\)", out).group(1))
        self.assertGreater(gp, 0)
        self.assertIn("09:00–12:30 و16:00–22:00 كل يوم", out)
        self.assertIn("أعد الأمر وأضف --yes", out)
        self.assertEqual(self.count("SELECT COUNT(*) FROM schedules"), 0, "المعاينة لا تكتب شيئاً")
        self.assertEqual(self.backups(), [], "المعاينة لا تأخذ نسخة ولا تنشئ شيئاً")

        rc, out, err = self.cli("sched-standard", "--yes")
        self.assertEqual(rc, 0, out + err)
        self.assertIn("تم ضبط الدوام لـ %d طبيباً." % n, out)
        self.assertEqual(self.count("SELECT COUNT(DISTINCT doctor_id) FROM schedules"), n)
        self.assertEqual(self.count("SELECT COUNT(*) FROM schedules WHERE start_min=0 AND end_min=1440"), 7 * gp, "الطبيب العام: 24 ساعة كل يوم")
        self.assertEqual(self.count("SELECT COUNT(*) FROM schedules WHERE start_min=540 AND end_min=750"), 7 * (n - gp), "الصباحية لغير العام")
        self.assertEqual(self.count("SELECT COUNT(*) FROM schedules WHERE start_min=960 AND end_min=1320"), 7 * (n - gp), "المسائية لغير العام")
        bk = self.backups()
        self.assertEqual(len(bk), 1, "نسخة احتياطية واحدة قبل التغيير")
        self.assertIn(str(bk[0]), out)
        self.assertEqual(stat.S_IMODE(bk[0].stat().st_mode) & 0o077, 0, "النسخة لصاحبها فقط")
        c = sqlite3.connect(str(bk[0]))
        try:
            self.assertEqual(c.execute("PRAGMA integrity_check").fetchone()[0], "ok")
            self.assertEqual(c.execute("SELECT COUNT(*) FROM schedules").fetchone()[0], 0, "النسخة أُخذت قبل التغيير")
        finally:
            c.close()

    def test_bad_options_change_nothing(self):
        for args in (["--slot", "7"], ["--off", "يوم-غلط"], ["--branch", "no-such-branch"]):
            rc, out, err = self.cli("sched-standard", "--yes", *args)
            self.assertEqual(rc, 1, args)
            self.assertEqual(self.count("SELECT COUNT(*) FROM schedules"), 0, args)
            self.assertEqual(self.backups(), [], args)


if __name__ == "__main__":
    unittest.main()
