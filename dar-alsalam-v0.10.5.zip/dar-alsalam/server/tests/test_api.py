import datetime as dt
import json
import os
import re
import shutil
import socket
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from helpers import Env, ROOT  # noqa: F401
import app as appmod

DEV = "dev_0123456789abcdef0123"
DEV2 = "dev_ffffffffffffffffffff"


def future(days=3):
    return (appmod.riyadh_today() + dt.timedelta(days=days)).isoformat()


def booking_body(**kw):
    b = {"deviceId": DEV, "name": "أحمد الجهني", "phone": "0565551234", "specialtyId": "dental", "branchId": "quba",
         "date": future(), "period": "evening", "note": "", "consent": True}
    b.update(kw)
    return b


class TestPublicApi(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.e = Env()

    @classmethod
    def tearDownClass(cls):
        cls.e.close()

    def test_health_and_clinic_etag(self):
        s, d, _ = self.e.req("GET", "/api/v1/health")
        self.assertEqual((s, d["ok"]), (200, True))
        s, d, h = self.e.req("GET", "/api/v1/clinic")
        self.assertEqual(s, 200)
        self.assertEqual(len(d["branches"]), 2)
        self.assertEqual(len(d["specialties"]), 13)
        self.assertEqual(len(d["doctors"]), 27)
        self.assertNotIn("reviewNotes", d["settings"])
        self.assertTrue(all("needsReview" not in x for x in d["doctors"]))
        self.assertNotIn("extraInstructions", d["qamar"])
        self.assertEqual(h["Access-Control-Allow-Origin"], "*")
        s2, _, _ = self.e.req("GET", "/api/v1/clinic", headers={"If-None-Match": h["ETag"]})
        self.assertEqual(s2, 304)

    def test_lexicon_endpoint(self):
        s, d, _ = self.e.req("GET", "/api/v1/lexicon")
        self.assertEqual(s, 200)
        self.assertIn("templates", d)

    def test_cors_preflight(self):
        s, _, h = self.e.req("OPTIONS", "/api/v1/bookings", headers={"Origin": "capacitor://localhost"})
        self.assertEqual(s, 204)
        self.assertIn("POST", h["Access-Control-Allow-Methods"])

    def test_booking_lifecycle(self):
        s, d, _ = self.e.req("POST", "/api/v1/bookings", booking_body())
        self.assertEqual(s, 201, d)
        b = d["booking"]
        self.assertTrue(b["id"].startswith("DS-"))
        self.assertEqual(b["status"], "new")
        self.assertNotIn("phone", b)
        s, d, _ = self.e.req("GET", "/api/v1/bookings?deviceId=" + DEV)
        self.assertEqual([x["id"] for x in d["bookings"]], [b["id"]])
        s, d, _ = self.e.req("GET", "/api/v1/bookings?deviceId=" + DEV2)
        self.assertEqual(d["bookings"], [])
        # لا يستطيع جهاز آخر الإلغاء
        s, _, _ = self.e.req("POST", "/api/v1/bookings/%s/cancel" % b["id"], {"deviceId": DEV2})
        self.assertEqual(s, 404)
        s, d, _ = self.e.req("POST", "/api/v1/bookings/%s/cancel" % b["id"], {"deviceId": DEV})
        self.assertEqual((s, d["booking"]["status"]), (200, "cancelled"))
        s, _, _ = self.e.req("POST", "/api/v1/bookings/%s/cancel" % b["id"], {"deviceId": DEV})
        self.assertEqual(s, 409)

    def test_booking_validation(self):
        cases = [({"phone": "123"}, "phone"), ({"name": "x"}, "name"), ({"consent": False}, "consent"),
                 ({"date": "2020-01-01"}, "date"), ({"date": future(400)}, "date"), ({"date": "غير"}, "date"),
                 ({"specialtyId": "nope"}, "specialtyId"), ({"period": "night"}, "period"), ({"deviceId": "short"}, "deviceId"),
                 ({"specialtyId": "", "branchId": "quba"}, "specialtyId")]
        for patch, field in cases:
            body = booking_body(deviceId=DEV2)
            body.update(patch)
            s, d, _ = self.e.req("POST", "/api/v1/bookings", body)
            self.assertEqual(s, 422, (patch, d))
            self.assertIn(field, d["fields"], (patch, d))

    def test_phone_normalization(self):
        self.assertEqual(appmod.norm_phone("0565075051"), "966565075051")
        self.assertEqual(appmod.norm_phone("+966 56 507 5051"), "966565075051")
        self.assertEqual(appmod.norm_phone("٠٥٦٥٠٧٥٠٥١"), "966565075051")
        self.assertEqual(appmod.norm_phone("565075051"), "966565075051")
        self.assertEqual(appmod.norm_phone("00201001234567"), "+201001234567")
        self.assertIsNone(appmod.norm_phone("0165075051"))
        self.assertIsNone(appmod.norm_phone("12345"))

    def test_duplicate_submit_is_idempotent(self):
        dev = "dev_dup_00000000000000000"
        s1, d1, _ = self.e.req("POST", "/api/v1/bookings", booking_body(deviceId=dev))
        s2, d2, _ = self.e.req("POST", "/api/v1/bookings", booking_body(deviceId=dev))
        self.assertEqual((s1, s2), (201, 200))
        self.assertEqual(d1["booking"]["id"], d2["booking"]["id"])
        self.assertTrue(d2["duplicate"])

    def test_doctor_booking_derives_specialty(self):
        s, d, _ = self.e.req("POST", "/api/v1/bookings", booking_body(deviceId="dev_doc_0000000000000000", specialtyId="", doctorId="dr-rasha-abdelhalim"))
        self.assertEqual(s, 201, d)
        self.assertEqual(d["booking"]["specialtyId"], "obgyn")

    def test_delete_my_data_anonymizes(self):
        dev = "dev_del_0000000000000000"
        s, d, _ = self.e.req("POST", "/api/v1/bookings", booking_body(deviceId=dev, name="سعد المطيري", phone="0501112233"))
        self.assertEqual(s, 201)
        self.e.app.db.add_notification("t", "b", dev)
        s, _, _ = self.e.req("DELETE", "/api/v1/devices/" + dev)
        self.assertEqual(s, 200)
        row = self.e.app.db.get_booking(d["booking"]["id"])
        self.assertEqual((row["name"], row["phone"], row["note"]), ("(محذوف)", "", ""))
        self.assertNotEqual(row["device_id"], dev)
        s, d2, _ = self.e.req("GET", "/api/v1/notifications?deviceId=" + dev)
        self.assertEqual(d2["notifications"], [])

    def test_notifications_broadcast_and_targeted(self):
        dev = "dev_not_0000000000000000"
        nid = self.e.app.db.add_notification("للجميع", "نص", "all")
        self.e.app.db.add_notification("لك", "نص", dev)
        self.e.app.db.add_notification("لغيرك", "نص", DEV2)
        s, d, _ = self.e.req("GET", "/api/v1/notifications?deviceId=" + dev)
        titles = {n["title"] for n in d["notifications"]}
        self.assertTrue({"للجميع", "لك"} <= titles)
        self.assertNotIn("لغيرك", titles)
        s, d, _ = self.e.req("GET", "/api/v1/notifications?deviceId=%s&since=%d" % (dev, nid + 5))
        self.assertEqual(d["notifications"], [])

    def test_qamar_endpoint(self):
        s, d, _ = self.e.req("POST", "/api/v1/qamar", {"deviceId": DEV, "message": "عندي ألم شديد في الصدر"})
        self.assertEqual(s, 200)
        self.assertEqual(d["reply"]["intent"], "emergency")
        s, d, _ = self.e.req("POST", "/api/v1/qamar", {"deviceId": DEV, "message": "ابي احجز اسنان", "history": [{"role": "user", "content": "x"}]})
        self.assertEqual(d["reply"]["actions"][0]["specialtyId"], "dental")
        self.assertEqual(d["reply"]["source"], "kb")
        s, _, _ = self.e.req("POST", "/api/v1/qamar", {"deviceId": DEV, "message": ""})
        self.assertEqual(s, 400)
        s, _, _ = self.e.req("POST", "/api/v1/qamar", {"deviceId": DEV, "message": "ا" * 700})
        self.assertEqual(s, 400)

    def test_bad_json_and_oversize(self):
        import urllib.request
        r = urllib.request.Request(self.e.base + "/api/v1/bookings", data=b"{not json", method="POST", headers={"Content-Type": "application/json"})
        try:
            urllib.request.urlopen(r)
            self.fail("expected error")
        except Exception as ex:  # noqa: BLE001
            self.assertEqual(ex.code, 400)
        r = urllib.request.Request(self.e.base + "/api/v1/bookings", data=b"x" * 70000, method="POST", headers={"Content-Type": "application/json"})
        try:
            urllib.request.urlopen(r)
            self.fail("expected error")
        except Exception as ex:  # noqa: BLE001
            self.assertEqual(ex.code, 413)

    def test_path_traversal_blocked(self):
        for p in ("/app/%2e%2e/server/app.py", "/app/..%2fserver%2fapp.py", "/admin/%2e%2e/data/clinic.db", "/widget/../../etc/passwd"):
            s, b, _ = self.e.req("GET", p, raw=True)
            self.assertIn(s, (404, 400), p)
            self.assertNotIn(b"import", b if isinstance(b, bytes) else b"")

    def test_privacy_page(self):
        s, b, h = self.e.req("GET", "/privacy", raw=True)
        self.assertEqual(s, 200)
        self.assertIn("سياسة الخصوصية".encode(), b)

    def test_static_roots_and_headers(self):
        s, b, h = self.e.req("GET", "/", raw=True)                       # يحوَّل إلى /app/
        self.assertEqual(s, 200)
        self.assertIn(b'<html', b)
        s, b, h = self.e.req("GET", "/app/js/90-app.js", raw=True)
        self.assertEqual((s, h["Content-Type"].split(";")[0]), (200, "application/javascript"))
        s, b, h = self.e.req("GET", "/app/data/seed.public.json", raw=True)
        self.assertEqual(s, 200)
        self.assertNotIn("password", b.decode().lower())
        s, b, h = self.e.req("GET", "/admin/", raw=True)
        self.assertEqual(s, 200)
        self.assertIn("script-src 'self'", h["Content-Security-Policy"])
        self.assertEqual(h["X-Frame-Options"], "DENY")
        s, b, h = self.e.req("GET", "/widget/qamar.js", raw=True)
        self.assertEqual(s, 200)
        self.assertEqual(h["Access-Control-Allow-Origin"], "*")
        self.assertIn("max-age", h["Cache-Control"])
        s, _, _ = self.e.req("GET", "/widget/nope.js", raw=True)
        self.assertEqual(s, 404)

    def test_qamar_config_endpoint_is_light(self):
        s, d, h = self.e.req("GET", "/api/v1/qamar/config")
        self.assertEqual(s, 200)
        self.assertTrue(d["enabled"])
        self.assertEqual(d["name"], "قمر")
        self.assertEqual(d["emergencyNumber"], "997")
        self.assertTrue(d["mainPhone"])
        self.assertLess(len(json.dumps(d, ensure_ascii=False).encode("utf-8")), 2048)
        for k in ("doctors", "branches", "bookings", "faqs", "specialties"):
            self.assertNotIn(k, d)
        self.assertEqual(h["Access-Control-Allow-Origin"], "*")
        self.assertIn("max-age", h["Cache-Control"])


class TestAdminApi(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.e = Env()

    @classmethod
    def tearDownClass(cls):
        cls.e.close()

    def test_auth_required(self):
        for m, p in (("GET", "/api/admin/dataset"), ("GET", "/api/admin/bookings"), ("PUT", "/api/admin/settings"), ("GET", "/api/admin/export")):
            s, _, _ = self.e.req(m, p, {} if m == "PUT" else None)
            self.assertEqual(s, 401, p)
        s, _, _ = self.e.req("GET", "/api/admin/dataset", headers={"Authorization": "Bearer abc.def"})
        self.assertEqual(s, 401)

    def test_image_upload(self):
        import urllib.request, urllib.error
        jpg = b"\xff\xd8\xff\xe0" + b"x" * 500

        def up(data, token=True):
            h = {"Content-Type": "image/jpeg"}
            if token:
                h["Authorization"] = "Bearer " + self.e.admin_token()
            r = urllib.request.Request(self.e.base + "/api/admin/upload", data=data, method="POST", headers=h)
            try:
                with urllib.request.urlopen(r, timeout=10) as resp:
                    return resp.status, json.loads(resp.read())
            except urllib.error.HTTPError as ex:
                return ex.code, json.loads(ex.read() or b"{}")
        self.assertEqual(up(jpg, token=False)[0], 401)
        self.assertEqual(up(b"<html>not an image</html>")[0], 415)
        self.assertEqual(up(b"GIF89a" + b"x" * 50)[0], 415)
        self.assertEqual(up(b"\xff\xd8\xff" + b"x" * (2 * 1024 * 1024))[0], 413)
        s, d = up(jpg)
        self.assertEqual(s, 200, d)
        self.assertRegex(d["path"], r"^/uploads/[0-9a-f]{24}\.jpg$")
        s, body, h = self.e.req("GET", d["path"], raw=True)
        self.assertEqual((s, body), (200, jpg))
        self.assertEqual(h["Content-Type"], "image/jpeg")
        s, _, _ = self.e.req("GET", "/uploads/../.secret", raw=True)
        self.assertEqual(s, 404)
        s, _, _ = self.e.req("GET", "/uploads/" + "0" * 24 + ".jpg", raw=True)
        self.assertEqual(s, 404)

    def test_login_wrong_password_and_rate_limit(self):
        e = Env()
        try:
            for _ in range(8):
                s, _, _ = e.req("POST", "/api/admin/login", {"password": "wrong"})
                self.assertEqual(s, 401)
            s, _, _ = e.req("POST", "/api/admin/login", {"password": "test-password-123"})
            self.assertEqual(s, 429)
        finally:
            e.close()

    def test_crud_doctor_and_public_reflects(self):
        _, before, h1 = self.e.req("GET", "/api/v1/clinic")
        s, d, _ = self.e.adm("POST", "/entities/doctors", {"name": "سالم الاختبار", "rank": "أخصائي", "specialtyIds": ["dental"], "branchIds": ["quba"]})
        self.assertEqual(s, 201, d)
        did = d["item"]["id"]
        self.assertTrue(did.startswith("dr-"))
        _, after, h2 = self.e.req("GET", "/api/v1/clinic")
        self.assertNotEqual(h1["ETag"], h2["ETag"])
        self.assertIn(did, [x["id"] for x in after["doctors"]])
        # Qamar يعرف الطبيب الجديد دون إعادة تشغيل
        s, r, _ = self.e.req("POST", "/api/v1/qamar", {"deviceId": DEV, "message": "من هو الدكتور سالم الاختبار"})
        self.assertEqual(r["reply"]["intent"], "doctor")
        # إخفاء وليس حذفاً
        s, d, _ = self.e.adm("DELETE", "/entities/doctors/" + did)
        self.assertEqual((s, d["hard"]), (200, False))
        _, after, _ = self.e.req("GET", "/api/v1/clinic")
        self.assertNotIn(did, [x["id"] for x in after["doctors"]])
        s, d, _ = self.e.adm("GET", "/dataset")
        self.assertIn(did, [x["id"] for x in d["doctors"]])
        # حذف نهائي يتطلب تأكيداً
        s, _, _ = self.e.adm("DELETE", "/entities/doctors/%s?hard=1" % did)
        self.assertEqual(s, 422)
        s, _, _ = self.e.adm("DELETE", "/entities/doctors/%s?hard=1&confirm=%s" % (did, did))
        self.assertEqual(s, 200)
        s, d, _ = self.e.adm("GET", "/stats")
        self.assertTrue(any(a["action"] == "delete" for a in d["audit"]))

    def test_validation_errors(self):
        s, d, _ = self.e.adm("POST", "/entities/branches", {"name": "", "address": ""})
        self.assertEqual(s, 422)
        self.assertIn("name", d["fields"])
        s, d, _ = self.e.adm("POST", "/entities/branches", {"name": "فرع", "address": "عنوان", "lat": 24.4})
        self.assertEqual(s, 422)
        s, d, _ = self.e.adm("POST", "/entities/doctors", {"name": "طبيب", "specialtyIds": ["ghost"]})
        self.assertEqual(s, 422)
        s, d, _ = self.e.adm("POST", "/entities/banners", {"title": "x", "linkType": "url", "linkRef": "http://insecure"})
        self.assertEqual(s, 422)
        s, d, _ = self.e.adm("POST", "/entities/nothing", {})
        self.assertEqual(s, 404)

    def test_banner_fields_theme_and_link_validation(self):
        """شرائح العروض: حقول جديدة (زر/لون/صورة) وروابط داخلية يتحقق الخادم من وجود وجهتها، فلا تُنشر بطاقة برابط مكسور."""
        s, d, _ = self.e.adm("GET", "/schema")
        fields = {f["key"]: f for f in d["kinds"]["banners"]["fields"]}
        for k in ("title", "text", "buttonLabel", "theme", "image", "linkType", "linkRef"):
            self.assertIn(k, fields)
        self.assertEqual(fields["theme"]["options"], ["blue", "deep", "sky", "light"])
        for t in ("book", "qamar", "specialty", "doctor", "service", "branch", "url", "none"):
            self.assertIn(t, fields["linkType"]["options"])
        _, ds, _ = self.e.req("GET", "/api/v1/clinic")
        sp, dr, sv, br = (ds[k][0]["id"] for k in ("specialties", "doctors", "services", "branches"))
        made = []
        try:
            for body in ({"title": "حجز بتخصص", "buttonLabel": "احجز", "theme": "sky", "linkType": "book", "linkRef": sp},
                         {"title": "حجز عام", "linkType": "book"},
                         {"title": "قمر", "linkType": "qamar", "linkRef": "تُهمل"},
                         {"title": "تخصص", "linkType": "specialty", "linkRef": sp},
                         {"title": "طبيب", "linkType": "doctor", "linkRef": dr},
                         {"title": "خدمة", "linkType": "service", "linkRef": sv},
                         {"title": "فرع", "linkType": "branch", "linkRef": br},
                         {"title": "صورة", "image": "https://example.com/offer.jpg", "theme": "deep"}):
                s, d, _ = self.e.adm("POST", "/entities/banners", body)
                self.assertEqual(s, 201, (body, d))
                made.append(d["item"]["id"])
            _, pub, _ = self.e.req("GET", "/api/v1/clinic")
            by = {b["title"]: b for b in pub["banners"]}
            self.assertEqual(by["حجز بتخصص"]["theme"], "sky")
            self.assertEqual(by["حجز بتخصص"]["buttonLabel"], "احجز")
            self.assertEqual(by["حجز عام"]["theme"], "blue")                 # الافتراضي
            self.assertEqual(by["قمر"]["linkRef"], "")                       # لا معنى للمعرّف مع «قمر»
            self.assertEqual(by["صورة"]["image"], "https://example.com/offer.jpg")
            bad = [({"title": "x", "theme": "purple"}, "theme"),
                   ({"title": "x", "image": "http://example.com/a.png"}, "image"),
                   ({"title": "x", "linkType": "specialty", "linkRef": "ghost"}, "linkRef"),
                   ({"title": "x", "linkType": "specialty"}, "linkRef"),
                   ({"title": "x", "linkType": "doctor", "linkRef": "ghost"}, "linkRef"),
                   ({"title": "x", "linkType": "service", "linkRef": sp + "-nope"}, "linkRef"),
                   ({"title": "x", "linkType": "branch", "linkRef": ""}, "linkRef"),
                   ({"title": "x", "linkType": "book", "linkRef": "ghost"}, "linkRef"),
                   ({"title": "x", "linkType": "url", "linkRef": "http://insecure"}, "linkRef"),
                   ({"title": "x", "linkType": "evil"}, "linkType")]
            for body, field in bad:
                s, d, _ = self.e.adm("POST", "/entities/banners", body)
                self.assertEqual(s, 422, body)
                self.assertIn(field, d["fields"], body)
        finally:
            for i in made:
                self.e.adm("DELETE", "/entities/banners/%s?hard=1&confirm=%s" % (i, i))
        _, pub, _ = self.e.req("GET", "/api/v1/clinic")
        self.assertEqual(pub["banners"], [])

    def test_banner_placement_default_and_validation(self):
        """مكان ظهور اللوحة: الشريط العلوي (الافتراضي) أو «استكشف» أو الاثنان. قيمة غير معروفة تُرفض، واللوحة الجديدة بلا اختيار تذهب للشريط العلوي كما كانت كل اللوحات."""
        s, d, _ = self.e.adm("GET", "/schema")
        fields = {f["key"]: f for f in d["kinds"]["banners"]["fields"]}
        self.assertEqual(fields["placement"]["options"], ["hero", "explore", "both"])
        self.assertEqual(fields["placement"]["default"], "hero")
        made = []
        try:
            for title, extra, want in (("بلا اختيار", {}, "hero"), ("علوي", {"placement": "hero"}, "hero"),
                                       ("للاستكشاف", {"placement": "explore"}, "explore"), ("في الاثنين", {"placement": "both"}, "both")):
                s, d, _ = self.e.adm("POST", "/entities/banners", dict({"title": title}, **extra))
                self.assertEqual(s, 201, d)
                made.append(d["item"]["id"])
                self.assertEqual(d["item"]["placement"], want, title)
            _, pub, _ = self.e.req("GET", "/api/v1/clinic")
            self.assertEqual({b["title"]: b["placement"] for b in pub["banners"]},
                             {"بلا اختيار": "hero", "علوي": "hero", "للاستكشاف": "explore", "في الاثنين": "both"})
            for bad in ("nowhere", "HERO", "hero,explore", "footer"):
                s, d, _ = self.e.adm("POST", "/entities/banners", {"title": "x", "placement": bad})
                self.assertEqual(s, 422, bad)
                self.assertIn("placement", d["fields"], bad)
            # نقل لوحة قائمة من مكان لآخر لا يمسّ بقية حقولها
            s, d, _ = self.e.adm("PUT", "/entities/banners/" + made[0], {"placement": "explore"})
            self.assertEqual(s, 200, d)
            self.assertEqual(d["item"]["placement"], "explore")
            self.assertEqual(d["item"]["title"], "بلا اختيار")
        finally:
            for i in made:
                self.e.adm("DELETE", "/entities/banners/%s?hard=1&confirm=%s" % (i, i))
        _, pub, _ = self.e.req("GET", "/api/v1/clinic")
        self.assertEqual(pub["banners"], [])

    def test_settings_share_url_is_https_only(self):
        s, d, _ = self.e.adm("GET", "/dataset")
        st = d["settings"]
        st["shareUrl"] = "https://example.com/get-app"
        s, d, _ = self.e.adm("PUT", "/settings", st)
        self.assertEqual(s, 200, d)
        _, pub, _ = self.e.req("GET", "/api/v1/clinic")
        self.assertEqual(pub["settings"]["shareUrl"], "https://example.com/get-app")
        st["shareUrl"] = "http://example.com/get-app"
        s, d, _ = self.e.adm("PUT", "/settings", st)
        self.assertEqual(s, 422)
        self.assertIn("shareUrl", d["fields"])
        st["shareUrl"] = ""
        s, d, _ = self.e.adm("PUT", "/settings", st)
        self.assertEqual(s, 200, d)

    def test_add_third_branch_appears_everywhere(self):
        s, d, _ = self.e.adm("POST", "/entities/branches", {"name": "مجمع دار السلام الطبي ٣ (اختبار)", "shortName": "فرع الاختبار", "address": "حي الاختبار",
                                                           "phone": "920031134", "lat": 24.47, "lng": 39.61})
        self.assertEqual(s, 201, d)
        _, ds, _ = self.e.req("GET", "/api/v1/clinic")
        self.assertEqual(len(ds["branches"]), 3)
        s, r, _ = self.e.req("POST", "/api/v1/qamar", {"deviceId": DEV, "message": "وين الفروع"})
        self.assertIn("الاختبار", r["reply"]["text"])

    def test_settings_update(self):
        s, d, _ = self.e.adm("GET", "/dataset")
        st = d["settings"]
        st["notice"] = "إشعار تجريبي"
        s, d, _ = self.e.adm("PUT", "/settings", st)
        self.assertEqual(s, 200, d)
        _, pub, _ = self.e.req("GET", "/api/v1/clinic")
        self.assertEqual(pub["settings"]["notice"], "إشعار تجريبي")
        st["email"] = "not-an-email"
        s, d, _ = self.e.adm("PUT", "/settings", st)
        self.assertEqual(s, 422)
        st["email"] = ""
        st["booking"] = {"mode": "external", "externalUrl": "http://x"}
        s, d, _ = self.e.adm("PUT", "/settings", st)
        self.assertEqual(s, 422)

    def test_settings_save_never_drops_unknown_or_nested_keys(self):
        """حفظ الإعدادات من اللوحة لا يحذف حقولاً غير ظاهرة في النموذج (اسم مختصر، ملاحظات المراجعة، الفترات...)."""
        s, d, _ = self.e.adm("GET", "/dataset")
        before = d["settings"]
        self.assertTrue(before.get("shortName"))
        s, d, _ = self.e.adm("PUT", "/settings", {"notice": "ملاحظة"})   # تحديث جزئي
        self.assertEqual(s, 200, d)
        after = d["settings"]
        for k in ("shortName", "tagline", "website", "values", "reviewNotes", "legalName", "founded"):
            self.assertEqual(after.get(k), before.get(k), k)
        self.assertEqual(after["social"], before["social"])
        self.assertEqual(after["stats"], before["stats"])
        self.assertEqual(after["booking"]["periods"], before["booking"]["periods"])
        # تعديل مفتاح داخلي واحد يدمج ولا يستبدل المجموعة كلها
        s, d, _ = self.e.adm("PUT", "/settings", {"social": {"x": "https://x.com/new"}})
        self.assertEqual(s, 200, d)
        self.assertEqual(d["settings"]["social"]["x"], "https://x.com/new")
        self.assertEqual(d["settings"]["social"]["instagram"], before["social"]["instagram"])
        # رابط بوابة المريض يجب أن يكون https
        s, d, _ = self.e.adm("PUT", "/settings", {"booking": {"externalUrl": "http://insecure"}})
        self.assertEqual(s, 422)
        self.assertIn("booking.externalUrl", d.get("fields", {}))
        s, d, _ = self.e.adm("PUT", "/settings", {"booking": {"externalUrl": "https://portal.example.com/book"}})
        self.assertEqual(s, 200, d)
        _, pub, _ = self.e.req("GET", "/api/v1/clinic")
        self.assertEqual(pub["settings"]["booking"]["externalUrl"], "https://portal.example.com/book")

    def test_booking_status_flow_and_notification(self):
        dev = "dev_adm_0000000000000000"
        _, d, _ = self.e.req("POST", "/api/v1/bookings", booking_body(deviceId=dev))
        bid = d["booking"]["id"]
        s, _, _ = self.e.adm("PATCH", "/bookings/" + bid, {"status": "confirmed"})
        self.assertEqual(s, 422)  # لا تأكيد بدون تفاصيل الموعد
        s, d, _ = self.e.adm("PATCH", "/bookings/" + bid, {"status": "contacted", "adminNote": "اتصلت بالمراجع"})
        self.assertEqual(s, 200)
        s, d, _ = self.e.adm("PATCH", "/bookings/" + bid, {"status": "confirmed", "appointmentText": "الثلاثاء 6:30 مساءً — د. فلان"})
        self.assertEqual((s, d["booking"]["status"]), (200, "confirmed"))
        _, n, _ = self.e.req("GET", "/api/v1/notifications?deviceId=" + dev)
        kinds = [x["title"] for x in n["notifications"]]
        self.assertIn("تم تأكيد موعدك", kinds)
        self.assertIn("تواصل معك المجمع", kinds)
        _, mine, _ = self.e.req("GET", "/api/v1/bookings?deviceId=" + dev)
        self.assertEqual(mine["bookings"][0]["appointmentText"], "الثلاثاء 6:30 مساءً — د. فلان")
        self.assertNotIn("adminNote", json.dumps(mine))
        s, _, _ = self.e.req("POST", "/api/v1/bookings/%s/cancel" % bid, {"deviceId": dev})
        self.assertEqual(s, 409)  # بعد التأكيد يلغى عبر المجمع فقط

    def test_broadcast_notification(self):
        s, d, _ = self.e.adm("POST", "/notifications", {"title": "عرض", "body": "نص", "target": "all"})
        self.assertEqual(s, 201)
        self.assertFalse(d["push"]["enabled"])
        _, n, _ = self.e.req("GET", "/api/v1/notifications?deviceId=" + DEV)
        self.assertIn("عرض", [x["title"] for x in n["notifications"]])
        s, _, _ = self.e.adm("POST", "/notifications", {"title": "", "body": "x"})
        self.assertEqual(s, 422)

    def test_qamar_toggle_reaches_widget_config_and_api(self):
        try:
            s, _, _ = self.e.adm("PUT", "/qamar", {"enabled": False})
            self.assertEqual(s, 200)
            s, d, _ = self.e.req("GET", "/api/v1/qamar/config")
            self.assertFalse(d["enabled"])
            s, d, _ = self.e.req("POST", "/api/v1/qamar", {"deviceId": DEV, "message": "هلا"})
            self.assertEqual((s, d["error"]), (503, "qamar_disabled"))
        finally:
            self.e.adm("PUT", "/qamar", {"enabled": True})
        s, d, _ = self.e.req("GET", "/api/v1/qamar/config")
        self.assertTrue(d["enabled"])
        s, d, _ = self.e.req("POST", "/api/v1/qamar", {"deviceId": DEV, "message": "هلا"})
        self.assertEqual(s, 200)

    def test_password_change_invalidates_old_token(self):
        e = Env()
        try:
            tok = e.admin_token()
            s, d, _ = e.req("POST", "/api/admin/password", {"old": "test-password-123", "new": "another-long-password"}, {"Authorization": "Bearer " + tok})
            self.assertEqual(s, 200)
            s, _, _ = e.req("GET", "/api/admin/stats", headers={"Authorization": "Bearer " + tok})
            self.assertEqual(s, 401)
            s, _, _ = e.req("GET", "/api/admin/stats", headers={"Authorization": "Bearer " + d["token"]})
            self.assertEqual(s, 200)
            s, _, _ = e.req("POST", "/api/admin/password", {"old": "wrong", "new": "x" * 12}, {"Authorization": "Bearer " + d["token"]})
            self.assertEqual(s, 401)
        finally:
            e.close()

    def test_export_contains_everything_and_backup_works(self):
        s, d, _ = self.e.adm("GET", "/export")
        self.assertEqual(s, 200)
        for k in ("settings", "qamar", "branches", "doctors", "bookings", "faqs"):
            self.assertIn(k, d)
        out = self.e.tmp / "b.db"
        self.e.app.db.backup_to(out)
        con = sqlite3.connect(str(out))
        self.assertGreater(con.execute("SELECT COUNT(*) FROM entities").fetchone()[0], 50)
        con.close()

    def test_schema_endpoint_drives_admin(self):
        s, d, _ = self.e.adm("GET", "/schema")
        self.assertEqual(set(d["kinds"]), {"branches", "specialties", "services", "doctors", "faqs", "banners"})
        self.assertTrue(any(f["key"] == "lat" for f in d["kinds"]["branches"]["fields"]))


class TestPrivacyText(unittest.TestCase):
    """نص الخصوصية موجود في مكانين (صفحة الخادم والتطبيق للعمل بلا إنترنت): يجب ألا يختلفا ولا يَعِدا بما لا يحدث."""

    BASE = ["عند إرسال طلب حجز: الاسم ورقم الجوال والتخصص/الطبيب/الفرع المطلوب والتاريخ المفضل وملاحظتك الاختيارية.",
            "معرّف عشوائي للجهاز لربط طلباتك وإشعاراتك بجهازك، دون أي معلومات هوية.",
            "التي لم يفهمها بشكل كافٍ", "تُحفظ مختصرة بعد إخفاء الأرقام والبريد، لتحسين الإجابات، ويُحذف الأقدم تلقائياً.",
            "لا نبيع بياناتك ولا نشاركها لأغراض إعلانية.", "إلغاء طلباتك وحذف بياناتك من الخادم",
            "المساعد «قمر» لا يقدّم تشخيصاً ولا وصفات علاجية.",
            "عند زيارتك للمجمع: يسجّل الاستقبال وصولك، ويسجّل الطبيب التشخيص والتعليمات والوصفة وما يطلبه من تحاليل وأشعة، ويدخل موظفو المختبر والأشعة نتائجها ثم يراجعها الطبيب. بعد انتهاء الزيارة يظهر لك في التطبيق ملخصها إن اعتمد الطبيب إظهاره، وتظهر لك النتائج بعد أن يراجعها الطبيب ويقرر إظهارها، دون ملاحظاته الداخلية، ولا يطّلع عليه إلا أنت وموظفو المجمع المخوَّلون. وتبقى سجلات الزيارة لدى المجمع وفق أنظمة حفظ السجلات الطبية حتى لو حذفت بياناتك من التطبيق.",
            "وتصل بيانات الزيارة إلى الطبيب المعالج وموظفي الاستقبال فقط، ويرى موظفو المختبر والأشعة الطلبات الموجّهة لقسمهم فقط (اسمك وعمرك ورقم ملفك واسم الفحص وملاحظة الطبيب عليه) دون التشخيص والوصفة.", "وتنظيم زيارتك وتسجيلها طبياً"]
    AI = ["(وكذلك ما أُرسل منها للمزوّد الخارجي)", "المساعد «قمر» مفعَّل حالياً بخدمة ذكاء اصطناعي خارجية",
          "بعد استبدال الأرقام الطويلة والبريد الإلكتروني برموز", "ولا يُرسَل إليه الاسم ولا الجوال المسجّلان في طلبات الحجز",
          "قد تُعالَج هذه النصوص خارج المملكة بحسب مزوّد الخدمة", "فننصحك بعدم كتابة معلومات شخصية أو تفاصيل طبية في المحادثة"]

    def test_server_page_and_app_copy_agree(self):
        js = (ROOT / "web" / "js" / "40-booking.js").read_text(encoding="utf-8")
        settings = {"name": "المجمع", "phones": [{"type": "main", "number": "920000000"}], "emergencyNumber": "997"}
        off, on = appmod.privacy_html(settings, False), appmod.privacy_html(settings, True)
        for frag in self.BASE:
            self.assertIn(frag, off, "الخادم (بلا مزوّد): " + frag)
            self.assertIn(frag, on, "الخادم (مع مزوّد): " + frag)
            self.assertIn(frag, js, "التطبيق: " + frag)
        for frag in self.AI:
            self.assertNotIn(frag, off, "فقرة المزوّد يجب ألا تظهر حين يكون معطّلاً: " + frag)
            self.assertIn(frag, on, "الخادم (مع مزوّد): " + frag)
            self.assertIn(frag, js, "التطبيق: " + frag)

    def test_public_dataset_discloses_external_ai_flag_only(self):
        e = Env()
        try:
            s, d, _ = e.req("GET", "/api/v1/clinic")
            self.assertEqual(s, 200)
            self.assertIs(d["qamar"]["externalAi"], False)
            self.assertNotIn("extraInstructions", d["qamar"])
        finally:
            e.close()
        e = Env({"QAMAR_PROVIDER": "anthropic", "QAMAR_API_KEY": "sk-x", "QAMAR_MODEL": "m"})
        try:
            s, d, _ = e.req("GET", "/api/v1/clinic")
            self.assertIs(d["qamar"]["externalAi"], True)
            self.assertNotIn("sk-x", json.dumps(d, ensure_ascii=False))
        finally:
            e.close()


class TestEnvExample(unittest.TestCase):
    """ملف .env.example يجب أن يبقى متزامناً مع ما يقرؤه الخادم فعلاً، وأن يكون نسخه كما هو آمناً."""

    def test_documents_exactly_the_variables_config_reads(self):
        import config as cfgmod
        cfg_src = (ROOT / "server" / "config.py").read_text(encoding="utf-8")
        read = set(re.findall(r'g\("([A-Z_]+)"', cfg_src))
        documented = set(re.findall(r"^#?\s*([A-Z][A-Z_]+)=", (ROOT / ".env.example").read_text(encoding="utf-8"), re.M))
        self.assertTrue(read, "لم يُعثر على متغيرات في config.py")
        self.assertEqual(sorted(read - documented), [], "متغيرات يقرؤها الخادم وغير موثّقة في .env.example")
        self.assertEqual(sorted(documented - read), [], "متغيرات موثّقة في .env.example ولا يقرؤها الخادم")
        # نسخه كما هو لا يغيّر أي افتراضي (كل الأسطر معلّقة)
        self.assertEqual(cfgmod._load_env_file(ROOT / ".env.example"), {})

    def test_no_inline_comments_on_value_lines(self):
        for line in (ROOT / ".env.example").read_text(encoding="utf-8").splitlines():
            if line.strip() and not line.lstrip().startswith("#"):
                self.assertNotIn(" #", line, "التعليق في نهاية سطر القيمة يصير جزءاً من القيمة: " + line)


class TestDeployFiles(unittest.TestCase):
    """ملفات النشر (التثبيت، وحدات systemd، مثال Caddy، قوالب البناء) تبقى متسقة، ومسار التثبيت الكامل يعمل بأوامر نظام محاكاة."""

    DOMAIN = "daralsalamclinic.duckdns.org"

    def _read(self, rel):
        return (ROOT / rel).read_text(encoding="utf-8")

    def test_shell_scripts_have_valid_syntax(self):
        import shutil
        import subprocess
        bash = shutil.which("bash")
        if not bash:
            self.skipTest("bash غير متاح")
        for rel in ("install.sh", "deploy/backup.sh", "deploy/upgrade.sh"):
            r = subprocess.run([bash, "-n", str(ROOT / rel)], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, rel + ": " + r.stderr)

    def test_systemd_units_are_consistent(self):
        svc = self._read("deploy/daralsalam.service")
        bk = self._read("deploy/daralsalam-backup.service")
        tm = self._read("deploy/daralsalam-backup.timer")
        install = self._read("install.sh")
        for unit in ("daralsalam.service", "daralsalam-backup.service", "daralsalam-backup.timer"):
            self.assertIn(unit, install, "install.sh لا يثبّت الوحدة " + unit)
        for text in (svc, bk):
            self.assertIn("ReadWritePaths=/opt/daralsalam/data", text)
            self.assertIn("User=daralsalam", text)
        self.assertIn("WantedBy=multi-user.target", svc)
        self.assertIn("Type=oneshot", bk)
        # عبر bash صراحةً: لا يتعطل إن ضاعت صلاحية التنفيذ عند رفع الملفات
        self.assertIn("ExecStart=/bin/bash /opt/daralsalam/deploy/backup.sh", bk)
        self.assertIn("EnvironmentFile=-/opt/daralsalam/.env", bk)
        self.assertRegex(tm, r"(?m)^OnCalendar=\S+")
        self.assertIn("Persistent=true", tm)
        self.assertIn("WantedBy=timers.target", tm)

    def test_domain_and_port_agree_across_files(self):
        d = self.DOMAIN
        caddy = self._read("deploy/Caddyfile.example")
        golive = self._read("docs/GO-LIVE-ar.md")
        self.assertRegex(caddy, r"(?m)^" + re.escape(d) + r" \{")
        self.assertIn(d, golive)
        for wf in ("android-apk.yml", "ios-testflight.yml"):
            self.assertIn('default: "https://%s"' % d, self._read(".github/workflows/" + wf), wf)
        port = re.search(r"reverse_proxy 127\.0\.0\.1:(\d+)", caddy).group(1)
        self.assertIn("reverse_proxy 127.0.0.1:" + port, golive)
        self.assertIn("proxy_pass http://127.0.0.1:" + port, golive)
        for rel in ("docs/GO-LIVE-ar.md", "docs/DEPLOY.md"):
            self.assertEqual(set(re.findall(r"DS_PORT=(\d+)", self._read(rel))), {port}, rel)

    def test_workflows_are_valid_yaml_with_prefilled_server(self):
        try:
            import yaml
        except ImportError:
            self.skipTest("PyYAML غير متاح")
        for wf in ("android-apk.yml", "ios-testflight.yml"):
            doc = yaml.safe_load(self._read(".github/workflows/" + wf))
            trig = doc.get("on", doc.get(True))  # YAML 1.1 يقرأ المفتاح on كقيمة True
            inp = trig["workflow_dispatch"]["inputs"]["api_base"]
            self.assertEqual(inp["default"], "https://" + self.DOMAIN)
            self.assertTrue(inp["required"])

    def test_install_script_full_path_with_simulated_system_commands(self):
        """يشغّل install.sh الحقيقي بمسار التثبيت الكامل داخل مجلد مؤقت، مع أوامر نظام وهمية (useradd/chown/sudo/systemctl)."""
        import os
        import shutil
        import socket
        import stat
        import subprocess
        import sys
        import tempfile
        from pathlib import Path
        if not hasattr(os, "geteuid") or os.geteuid() != 0:
            self.skipTest("يلزم root لمسار التثبيت الكامل")
        bash = shutil.which("bash")
        if not bash:
            self.skipTest("bash غير متاح")
        tmp = Path(tempfile.mkdtemp(prefix="ds-install-test-"))
        shims, units, app_dir = tmp / "shims", tmp / "units", tmp / "app"
        shims.mkdir()
        log, active, pidf = tmp / "calls.log", tmp / "active", tmp / "srv.pid"
        log.write_text("")

        def shim(name, body):
            p = shims / name
            p.write_text("#!/bin/sh\n" + body)
            p.chmod(0o755)

        shim("useradd", 'echo "useradd $*" >> "$SHIM_LOG"\nexit 0\n')
        shim("chown", 'echo "chown $*" >> "$SHIM_LOG"\nexit 0\n')
        shim("sudo", 'echo "sudo $*" >> "$SHIM_LOG"\nif [ "$1" = "-u" ]; then shift 2; fi\nexec "$@"\n')
        shim("systemctl", 'echo "systemctl $*" >> "$SHIM_LOG"\ncase "$1" in\n'
                          '  is-active) [ -f "$SHIM_ACTIVE" ] && exit 0 || exit 3 ;;\n'
                          '  enable) if [ "$3" = "daralsalam" ] && [ ! -f "$SHIM_PID" ]; then\n'
                          '    ( cd "$APP_DIR"; DS_QUIET=1 nohup "%s" server/app.py >/dev/null 2>&1 & echo $! > "$SHIM_PID" )\n'
                          '  fi ;;\nesac\nexit 0\n' % sys.executable)

        base_env = {k: v for k, v in os.environ.items() if not k.startswith(("DS_", "QAMAR_"))}
        base_env.update(PATH=str(shims) + os.pathsep + os.environ.get("PATH", ""), APP_DIR=str(app_dir), UNIT_DIR=str(units),
                        SVC_USER="ds-test-no-such-user", SHIM_LOG=str(log), SHIM_ACTIVE=str(active), SHIM_PID=str(pidf))

        def run(port, trust=None):
            env = dict(base_env, DS_PORT=str(port))
            if trust:
                env["DS_TRUST_PROXY"] = trust
            return subprocess.run([bash, str(ROOT / "install.sh")], env=env, capture_output=True, text=True, timeout=90)

        def free_port():
            s = socket.socket()
            s.bind(("127.0.0.1", 0))
            p = s.getsockname()[1]
            s.close()
            return p

        busy_sock = socket.socket()
        try:
            # (1) المنفذ مشغول: يرفض ولا يكتب شيئاً
            busy_sock.bind(("127.0.0.1", 0))
            busy_sock.listen(1)
            r = run(busy_sock.getsockname()[1], trust="1")
            self.assertEqual(r.returncode, 1, r.stdout + r.stderr)
            self.assertIn("مشغول", r.stdout)
            self.assertFalse(app_dir.exists(), "لا يجوز أن يكتب شيئاً قبل التأكد من المنفذ")
            busy_sock.close()

            # (2) تثبيت جديد على منفذ حر
            port = free_port()
            r = run(port, trust="1")
            self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
            env_file = app_dir / ".env"
            env_txt = env_file.read_text(encoding="utf-8")
            self.assertRegex(env_txt, r"(?m)^DS_PORT=%d$" % port)
            self.assertRegex(env_txt, r"(?m)^DS_TRUST_PROXY=1$")
            self.assertEqual(stat.S_IMODE(env_file.stat().st_mode), 0o600)
            self.assertFalse((app_dir / "server" / "tests").exists(), "الاختبارات لا تُنسخ للخادم")
            self.assertTrue(os.access(app_dir / "deploy" / "backup.sh", os.X_OK))
            for u in ("daralsalam.service", "daralsalam-backup.service", "daralsalam-backup.timer"):
                self.assertTrue((units / u).exists(), u)
                self.assertNotIn("/opt/daralsalam", (units / u).read_text(encoding="utf-8"), u + ": لم يُستبدل مسار التثبيت")
            self.assertIn("User=ds-test-no-such-user", (units / "daralsalam.service").read_text(encoding="utf-8"))
            self.assertIn("الخدمة تعمل وتردّ على 127.0.0.1:%d" % port, r.stdout)
            calls = log.read_text(encoding="utf-8")
            for needle in ("useradd --system", "systemctl enable --now daralsalam\n", "systemctl enable --now daralsalam-backup.timer"):
                self.assertIn(needle, calls)

            # (3) ترقية والخدمة تعمل: لا رفض بسبب المنفذ، و.env كما هو
            before = env_file.read_bytes()
            active.write_text("1")
            r = run(port)
            self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
            self.assertEqual(env_file.read_bytes(), before)
            self.assertIn("لم يُمسّ", r.stdout)
        finally:
            busy_sock.close()
            if pidf.exists():
                try:
                    os.kill(int(pidf.read_text().strip()), 15)
                except (ProcessLookupError, ValueError):
                    pass
            shutil.rmtree(tmp, ignore_errors=True)


SHIM_SYSTEMCTL = r"""#!/bin/sh
echo "systemctl $*" >> "$SHIM_LOG"
running() {
  [ -f "$SHIM_PID" ] || return 1
  pid="$(cat "$SHIM_PID")"
  kill -0 "$pid" 2>/dev/null || return 1
  st="$(sed -n 's/^[0-9]* ([^)]*) \(.\).*/\1/p' "/proc/$pid/stat" 2>/dev/null)"
  [ "$st" != "Z" ]
}
start() {
  running && return 0
  ( cd "$SHIM_APPDIR" && DS_QUIET=1 nohup "@PY@" server/app.py >>"$SHIM_SRV" 2>&1 & echo $! > "$SHIM_PID" )
}
stop() {
  if running; then
    kill "$(cat "$SHIM_PID")" 2>/dev/null
    i=0
    while running && [ "$i" -lt 50 ]; do sleep 0.1; i=$((i+1)); done
  fi
  rm -f "$SHIM_PID"
}
case "$1" in
  is-active) running; exit $? ;;
  show) echo "$SHIM_APPDIR"; exit 0 ;;
  enable) if [ "$3" = "daralsalam" ]; then start; fi ;;
  start) start ;;
  stop) stop ;;
  restart) stop; start ;;
esac
exit 0
"""


class TestUpgradeScript(unittest.TestCase):
    """يشغّل deploy/upgrade.sh الحقيقي فوق تثبيت حقيقي (install.sh) بأوامر نظام وهمية:
    نجاح مع بقاء البيانات، وتراجع تلقائي عند فشل التشغيل أو نقص البيانات، ورفض قبل أي تغيير عند خلل في الحزمة أو غياب تثبيت سابق."""

    @classmethod
    def setUpClass(cls):
        if not hasattr(os, "geteuid") or os.geteuid() != 0:
            raise unittest.SkipTest("يلزم root لمسار الترقية الكامل")
        cls.bash = shutil.which("bash")
        if not cls.bash:
            raise unittest.SkipTest("bash غير متاح")
        cls.root_tmp = Path(tempfile.mkdtemp(prefix="ds-upg-pkg-"))
        cls.pristine = cls.root_tmp / "dar-alsalam"
        cls.pristine.mkdir()
        ign = shutil.ignore_patterns("__pycache__", "tests", "*.pyc")
        for d in ("server", "web", "admin", "widget", "deploy"):
            shutil.copytree(ROOT / d, cls.pristine / d, ignore=ign)
        (cls.pristine / "data").mkdir()
        for f in ("seed.json", "lexicon.json"):
            shutil.copy2(ROOT / "data" / f, cls.pristine / "data" / f)
        for f in ("install.sh", ".env.example"):
            shutil.copy2(ROOT / f, cls.pristine / f)
        cls.new_ver = cls._ver_of(cls.pristine / "web" / "config.js")

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(getattr(cls, "root_tmp", "/nonexistent"), ignore_errors=True)

    @staticmethod
    def _ver_of(cfg_js):
        return re.search(r'version:\s*"([^"]+)"', Path(cfg_js).read_text(encoding="utf-8")).group(1)

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="ds-upg-"))
        shims = self.tmp / "shims"
        shims.mkdir()
        self.app, self.units = self.tmp / "app", self.tmp / "units"
        self.log, self.pidf, self.srvlog = self.tmp / "calls.log", self.tmp / "srv.pid", self.tmp / "srv.log"
        self.log.write_text("")

        def shim(name, body):
            f = shims / name
            f.write_text("#!/bin/sh\n" + body)
            f.chmod(0o755)

        shim("useradd", 'echo "useradd $*" >> "$SHIM_LOG"\nexit 0\n')
        shim("chown", 'echo "chown $*" >> "$SHIM_LOG"\nexit 0\n')
        shim("sudo", 'echo "sudo $*" >> "$SHIM_LOG"\nif [ "$1" = "-u" ]; then shift 2; fi\nexec "$@"\n')
        (shims / "systemctl").write_text(SHIM_SYSTEMCTL.replace("@PY@", sys.executable))
        (shims / "systemctl").chmod(0o755)
        s = socket.socket()
        s.bind(("127.0.0.1", 0))
        self.port = s.getsockname()[1]
        s.close()
        self.env = {k: v for k, v in os.environ.items() if not k.startswith(("DS_", "QAMAR_", "APP_DIR"))}
        self.env.update(PATH=str(shims) + os.pathsep + os.environ.get("PATH", ""), UNIT_DIR=str(self.units),
                        SVC_USER="ds-test-no-such-user", SHIM_LOG=str(self.log), SHIM_PID=str(self.pidf),
                        SHIM_SRV=str(self.srvlog), SHIM_APPDIR=str(self.app))
        self.n_pkg = 0

    def tearDown(self):
        if self.pidf.exists():
            try:
                os.kill(int(self.pidf.read_text().strip()), 15)
            except (ProcessLookupError, ValueError, OSError):
                pass
        shutil.rmtree(self.tmp, ignore_errors=True)

    # ---------------------------------------------------------------- أدوات
    def new_pkg(self):
        self.n_pkg += 1
        dst = self.tmp / ("pkg-%d" % self.n_pkg) / "dar-alsalam"
        shutil.copytree(self.pristine, dst)
        return dst

    def sub(self, pkg, rel, old, new):
        f = pkg / rel
        txt = f.read_text(encoding="utf-8")
        self.assertEqual(txt.count(old), 1, "تغيّر الكود الذي يعتمد عليه الاختبار في " + rel)
        f.write_text(txt.replace(old, new), encoding="utf-8")

    def install_old(self):
        """تثبيت «قديم» (إصدار 0.0.1 وعلامة في web) عبر install.sh الحقيقي؛ تعمل الخدمة الوهمية بعده."""
        old = self.new_pkg()
        self.sub(old, "web/config.js", 'version: "%s"' % self.new_ver, 'version: "0.0.1"')
        (old / "web" / "OLD_MARKER.txt").write_text("old", encoding="utf-8")
        env = dict(self.env, APP_DIR=str(self.app), DS_PORT=str(self.port))
        r = subprocess.run([self.bash, str(old / "install.sh")], env=env, capture_output=True, text=True, timeout=90)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertIn("الخدمة تعمل وتردّ على 127.0.0.1:%d" % self.port, r.stdout)
        return old

    def upgrade(self, pkg, wait=4, **extra):
        env = dict(self.env, DS_UPGRADE_WAIT=str(wait), **extra)
        return subprocess.run([self.bash, str(pkg / "deploy" / "upgrade.sh")], env=env, capture_output=True, text=True, timeout=120)

    def http(self, path, body=None):
        import urllib.request
        op = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        req = urllib.request.Request("http://127.0.0.1:%d%s" % (self.port, path),
                                     data=None if body is None else json.dumps(body).encode("utf-8"),
                                     headers={} if body is None else {"Content-Type": "application/json"})
        with op.open(req, timeout=5) as r:
            return r.status, r.read().decode("utf-8")

    def served_version(self):
        return re.search(r'version:\s*"([^"]+)"', self.http("/app/config.js")[1]).group(1)

    def prev_dirs(self):
        return sorted(self.tmp.glob("app-prev-*"))

    def pid(self):
        return self.pidf.read_text().strip()

    # ---------------------------------------------------------------- الاختبارات
    def test_upgrade_success_keeps_data_and_leaves_backup_and_snapshot(self):
        self.install_old()
        self.assertEqual(self.served_version(), "0.0.1")
        s, body = self.http("/api/v1/bookings", booking_body())
        self.assertEqual(s, 201, body)
        bid = json.loads(body)["booking"]["id"]
        env_before = (self.app / ".env").read_bytes()
        unit = self.units / "daralsalam.service"
        unit.write_text(unit.read_text(encoding="utf-8") + "# تعديل يدوي من المالك\n", encoding="utf-8")
        pid_before = self.pid()

        r = self.upgrade(self.new_pkg())   # بلا APP_DIR: يُستنتج من الخدمة
        out = r.stdout + r.stderr
        self.assertEqual(r.returncode, 0, out)
        self.assertIn("تمت الترقية من 0.0.1 إلى %s" % self.new_ver, out)
        self.assertIn("طلبات الحجز المحفوظة: 1 (كانت 1)", out)
        self.assertEqual(self.served_version(), self.new_ver)
        self.assertNotEqual(self.pid(), pid_before, "لم تُعَد الخدمة، فلن يُحمَّل الكود الجديد")
        self.assertIn("systemctl restart daralsalam", self.log.read_text(encoding="utf-8"))
        self.assertEqual((self.app / ".env").read_bytes(), env_before)
        self.assertFalse((self.app / "web" / "OLD_MARKER.txt").exists())
        # الوحدة المعدّلة يدوياً تبقى كما هي
        self.assertIn("# تعديل يدوي من المالك", unit.read_text(encoding="utf-8"))
        self.assertIn("أُبقيت النسخة المثبّتة كما هي", out)
        # الحجز ما زال موجوداً عبر الواجهة
        s, body = self.http("/api/v1/bookings?deviceId=" + DEV)
        self.assertEqual([b["id"] for b in json.loads(body)["bookings"]], [bid])
        # لقطة الكود السابق
        prevs = self.prev_dirs()
        self.assertEqual(len(prevs), 1, prevs)
        self.assertEqual(oct(prevs[0].stat().st_mode & 0o777), "0o700")
        self.assertTrue((prevs[0] / "web" / "OLD_MARKER.txt").exists())
        self.assertEqual(self._ver_of(prevs[0] / "web" / "config.js"), "0.0.1")
        # نسخة القاعدة الاحتياطية سليمة وتحوي الحجز، ولم تُنشأ بجانبها ملفات -wal/-shm
        dbs = sorted((self.app / "data" / "backups").glob("clinic-*.db"))
        self.assertEqual(len(dbs), 1, dbs)
        c = sqlite3.connect("file:%s?mode=ro&immutable=1" % dbs[0], uri=True)
        try:
            self.assertEqual(c.execute("pragma integrity_check").fetchone()[0], "ok")
            self.assertEqual(c.execute("select count(*) from bookings").fetchone()[0], 1)
        finally:
            c.close()
        self.assertEqual(sorted(p.name for p in (self.app / "data" / "backups").iterdir()), [dbs[0].name])

    def test_upgrade_rolls_back_when_new_service_does_not_start(self):
        old = self.install_old()
        s, body = self.http("/api/v1/bookings", booking_body())
        self.assertEqual(s, 201, body)
        bad = self.new_pkg()
        # يبقى الاستيراد سليماً (manage.py يعمل) لكن الخدمة نفسها تخرج فوراً
        self.sub(bad, "server/app.py", 'if __name__ == "__main__":\n    main()', 'if __name__ == "__main__":\n    raise SystemExit(3)')
        r = self.upgrade(bad, wait=3)
        out = r.stdout + r.stderr
        self.assertEqual(r.returncode, 1, out)
        self.assertIn("لم تردّ الخدمة الجديدة", out)
        self.assertIn("تراجع تلقائي", out)
        self.assertIn("عادت الخدمة تعمل بالإصدار السابق", out)
        self.assertEqual(self.served_version(), "0.0.1")
        self.assertTrue((self.app / "web" / "OLD_MARKER.txt").exists())
        self.assertEqual((self.app / "server" / "app.py").read_text(encoding="utf-8"),
                         (old / "server" / "app.py").read_text(encoding="utf-8"))
        s, body = self.http("/api/v1/bookings?deviceId=" + DEV)
        self.assertEqual(len(json.loads(body)["bookings"]), 1, "ضاع حجز بعد التراجع")
        self.assertEqual(len(self.prev_dirs()), 1, "اللقطة تبقى بعد التراجع ولا تُحذف")

    def test_upgrade_rolls_back_when_data_counts_drop(self):
        self.install_old()
        bad = self.new_pkg()
        # كود جديد «يُخفي» طبيباً من البيانات العامة: يجب أن يكتشف الفحص نقص الأعداد ويتراجع
        self.sub(bad, "server/db.py", "            ds[kind] = items\n",
                 '            ds[kind] = items[:-1] if (public and kind == "doctors") else items\n')
        r = self.upgrade(bad, wait=6)
        out = r.stdout + r.stderr
        self.assertEqual(r.returncode, 1, out)
        self.assertIn("نقصت أعداد البيانات", out)
        self.assertIn("تراجع تلقائي", out)
        self.assertEqual(self.served_version(), "0.0.1")
        s, body = self.http("/api/v1/clinic")
        self.assertEqual(len(json.loads(body)["doctors"]), 27)

    def test_upgrade_preflight_failure_changes_nothing(self):
        self.install_old()
        pid_before = self.pid()
        bad = self.new_pkg()
        (bad / "server" / "db.py").write_text("def broken(:\n", encoding="utf-8")
        r = self.upgrade(bad)
        out = r.stdout + r.stderr
        self.assertEqual(r.returncode, 1, out)
        self.assertIn("لا يُقرأ", out)
        self.assertEqual(self.prev_dirs(), [])
        self.assertFalse((self.app / "data" / "backups").exists(), "لا نسخ ولا لقطات قبل اجتياز الفحص")
        self.assertEqual(self.pid(), pid_before, "لا يجوز إعادة تشغيل الخدمة عند فشل الفحص")
        self.assertEqual(self.served_version(), "0.0.1")
        self.assertTrue((self.app / "web" / "OLD_MARKER.txt").exists())
        # حزمة ناقصة
        bad2 = self.new_pkg()
        (bad2 / "web" / "index.html").unlink()
        r = self.upgrade(bad2)
        self.assertEqual(r.returncode, 1, r.stdout + r.stderr)
        self.assertIn("الحزمة ناقصة: web/index.html", r.stdout)

    def test_upgrade_refuses_without_existing_install_or_from_install_dir(self):
        empty = self.tmp / "empty"
        empty.mkdir()
        r = self.upgrade(self.new_pkg(), APP_DIR=str(empty))
        self.assertEqual(r.returncode, 1, r.stdout + r.stderr)
        self.assertIn("لا يوجد تثبيت سابق", r.stdout)
        self.assertEqual(list(empty.iterdir()), [])
        self.assertEqual(self.prev_dirs(), [])
        self.install_old()
        r = subprocess.run([self.bash, str(self.app / "deploy" / "upgrade.sh")], env=dict(self.env, APP_DIR=str(self.app)),
                           capture_output=True, text=True, timeout=60)
        self.assertEqual(r.returncode, 1, r.stdout + r.stderr)
        self.assertIn("من مجلد الحزمة المفكوكة", r.stdout)


if __name__ == "__main__":
    unittest.main()
