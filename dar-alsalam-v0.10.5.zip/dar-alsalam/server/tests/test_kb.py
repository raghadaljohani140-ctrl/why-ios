import json
import unittest

from helpers import ROOT  # noqa: F401  (يضبط المسارات)
import kb as kbmod


def load_kb():
    seed = json.loads((ROOT / "data" / "seed.json").read_text(encoding="utf-8"))
    return kbmod.KB(seed, kbmod.Lexicon.load())


class TestNormalize(unittest.TestCase):
    def test_normalize(self):
        self.assertEqual(kbmod.normalize("أَبْغَى مَوْعِد"), "ابغي موعد")
        self.assertEqual(kbmod.normalize("رقم ٠٥٦٥٠٧٥٠٥١"), "رقم 0565075051")
        self.assertEqual(kbmod.normalize("X-Ray"), "xray")

    def test_stem_two_stage(self):
        self.assertEqual(kbmod.stem("بياناتي"), kbmod.stem("بيانات"))
        self.assertEqual(kbmod.stem("الاسنان"), kbmod.stem("اسنان"))
        self.assertEqual(kbmod.stem("عيادتي"), kbmod.stem("عيادة".replace("ة", "ه")))

    def test_phone_digits(self):
        self.assertEqual(kbmod.e164_digits("0565075051"), "966565075051")
        self.assertEqual(kbmod.e164_digits("+966 56 093 0526"), "966560930526")
        self.assertEqual(kbmod.e164_digits("920031134"), "920031134")


class TestAnswers(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.kb = load_kb()

    def intent(self, q, hist=None):
        return self.kb.answer(q, hist)["intent"]

    def test_emergency_never_goes_to_booking(self):
        for q in ["عندي ألم شديد في الصدر", "ما أقدر أتنفس", "ابني ما يتنفس", "عندي نزيف شديد", "أبي أحجز لأن عندي ألم في قلبي"]:
            r = self.kb.answer(q)
            self.assertTrue(r["emergency"], q)
            self.assertIn("997", r["text"])
            self.assertEqual([a["type"] for a in r["actions"]], ["emergency"])

    def test_self_harm(self):
        r = self.kb.answer("ابغى انتحر")
        self.assertTrue(r["emergency"])
        self.assertIn("937", r["text"])

    def test_no_diagnosis_or_drugs(self):
        for q in ["وش الدواء المناسب للصداع", "اعطني جرعة بنادول", "هل عندي سكر", "فسر لي نتيجة تحليلي"]:
            r = self.kb.answer(q)
            self.assertEqual(r["intent"], "advice", q)
            self.assertIn("ما أقدر أشخّص", r["text"])

    def test_routing(self):
        cases = {"عندي ألم في الأسنان": "dental", "أبغى دكتور عظام": "orthopedics", "عندي طفح جلدي": "dermatology",
                 "ابي اختبار حمل": "obgyn", "عيادة الاطفال": "pediatrics", "عندي وجع في الاذن": "ent",
                 "عندي ألم في ركبتي": "orthopedics", "عندي حمى": "general"}
        for q, sp in cases.items():
            r = self.kb.answer(q)
            self.assertIn(sp, r["routed"], q)
            self.assertIn(r["intent"], ("route", "advice"), q)

    def test_booking_is_request_not_confirmation(self):
        r = self.kb.answer("أبي أحجز موعد")
        self.assertEqual(r["intent"], "booking")
        self.assertIn("لا يعني أن الموعد تأكد", r["text"])
        self.assertEqual(r["actions"][0]["type"], "book")

    def test_booking_with_entities(self):
        r = self.kb.answer("ابي احجز عند دكتورة رشا")
        self.assertEqual(r["actions"][0].get("doctorId"), "dr-rasha-abdelhalim")
        r = self.kb.answer("ابي احجز اسنان")
        self.assertEqual(r["actions"][0].get("specialtyId"), "dental")

    def test_follow_up_yes(self):
        hist = [{"role": "assistant", "content": "من كلامك، العيادة الأقرب لما ذكرته هي «الأسنان». تبي أرتّب لك طلب حجز؟"}]
        r = self.kb.answer("نعم", hist)
        self.assertEqual(r["intent"], "booking")
        self.assertEqual(r["actions"][0].get("specialtyId"), "dental")
        self.assertEqual(self.kb.answer("نعم")["intent"], "unknown")

    def test_data_intents(self):
        self.assertEqual(self.intent("وين الفروع؟"), "branches")
        self.assertEqual(self.intent("أرقام التواصل"), "contact")
        self.assertEqual(self.intent("وش التخصصات"), "specialties")
        self.assertEqual(self.intent("كم سعر الكشف"), "price")
        self.assertEqual(self.intent("هل عندكم تأمين؟"), "insurance")
        self.assertEqual(self.intent("متى دوامكم"), "hours")
        self.assertEqual(self.intent("شكرا"), "thanks")
        self.assertEqual(self.intent("هلا"), "greeting")
        self.assertEqual(self.intent("من انت"), "qamar")

    def test_price_and_insurance_are_not_invented(self):
        for q in ["كم سعر الكشف", "هل عندكم تأمين بوبا"]:
            r = self.kb.answer(q)
            self.assertFalse(r["confident"])
            self.assertIn("ما عندي", r["text"])
            self.assertNotRegex(r["text"], r"\d{2,3}\s*ريال")

    def test_hours_use_only_published(self):
        t = self.kb.answer("متى دوامكم")["text"]
        self.assertIn("24", t)
        self.assertNotIn("8 صباحاً", t)

    def test_doctor_lookup(self):
        r = self.kb.answer("من هو الدكتور ايمن")
        self.assertEqual(r["intent"], "doctor")
        self.assertIn("أيمن", r["text"])

    def test_faq_direct(self):
        r = self.kb.answer("هل بياناتي محفوظة وخصوصية")
        self.assertEqual(r["faq"], "faq-privacy")
        r = self.kb.answer("هل الحجز يعني تأكيد الموعد؟")
        self.assertEqual(r["faq"], "faq-confirm")

    def test_tips(self):
        self.assertEqual(self.kb.answer("وش نصايح الحر")["faq"], "tip-heat")
        self.assertEqual(self.kb.answer("كيف احمي نفسي من فيروس سي")["faq"], "tip-hep-c")

    def test_off_topic_is_unknown(self):
        r = self.kb.answer("اريد اكل بيتزا")
        self.assertEqual(r["intent"], "unknown")
        self.assertFalse(r["confident"])

    def test_waw_prefix(self):
        r = self.kb.answer("وين الفروع والتخصصات")
        self.assertEqual(r["intent"], "branches")

    def test_inactive_entities_hidden(self):
        seed = json.loads((ROOT / "data" / "seed.json").read_text(encoding="utf-8"))
        for d in seed["doctors"]:
            if d["id"] == "dr-rasha-abdelhalim":
                d["active"] = False
        k = kbmod.KB(seed, kbmod.Lexicon.load())
        self.assertNotIn("رشا", k.context_text("x", 100000))

    def test_deterministic(self):
        a = json.dumps(self.kb.answer("عندي ألم في الاسنان وابي احجز"), ensure_ascii=False, sort_keys=True)
        b = json.dumps(load_kb().answer("عندي ألم في الاسنان وابي احجز"), ensure_ascii=False, sort_keys=True)
        self.assertEqual(a, b)

    def test_templates_have_no_unfilled_placeholders(self):
        qs = ["هلا", "وين الفروع", "ارقام التواصل", "متى دوامكم", "ابي احجز", "كيف الغي", "عندي طفح جلدي", "كم سعر", "تامين", "من انتم",
              "ابي اشعه", "ابي تحليل", "نصائح", "مين انت", "عندي صداع وابي دواء", "من هو دكتور ايمن", "عندكم دكاترة"]
        for q in qs:
            self.assertNotRegex(self.kb.answer(q)["text"], r"\{[a-z_0-9]+\}", q)


if __name__ == "__main__":
    unittest.main()
