"""المواعيد: ساعات عمل الطبيب ← مواعيد متاحة ← حجز مؤكد تلقائياً (بلا حجز مزدوج) ← يظهر عند الطبيب ← استدعاؤه.
الوقت مثبَّت (الاثنين 23 نوفمبر 2026 الساعة 9:00 بتوقيت الرياض) حتى لا تتأثر النتائج بساعة تشغيل الاختبار."""
import contextlib
import datetime as dt
import threading
import unittest
from unittest import mock
from urllib.parse import quote

from test_clinic import DX, Base          # يضبط مسار الخادم (helpers) قبل استيراد وحداته

import clinicapi  # noqa: E402
import schedapi  # noqa: E402
import scheddb as sd  # noqa: E402
import staffapi  # noqa: E402
from util import norm_phone  # noqa: E402

NOW = dt.datetime(2026, 11, 23, 9, 0, tzinfo=sd.RIYADH)        # الاثنين
TODAY = NOW.date()


def day(n=0):
    return (TODAY + dt.timedelta(days=n)).isoformat()


@contextlib.contextmanager
def fake_now(now=NOW):
    ps = [mock.patch.object(sd, "riyadh_now", lambda: now)]
    for m in (schedapi, clinicapi, staffapi):
        ps.append(mock.patch.object(m, "riyadh_today", lambda: now.date()))
    for p in ps:
        p.start()
    try:
        yield
    finally:
        for p in ps:
            p.stop()


class SchedBase(Base):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.A = cls.br[0]
        cls.DOC, cls.DOC2, cls.DOC3 = cls.docs[0], cls.docs[1], cls.docs[2]

    def setUp(self):
        super().setUp()
        db = self.e.app.db
        with db.tx() as c:                                  # كل اختبار يبدأ من «لا ساعات ولا مواعيد وسياسة افتراضية»
            c.execute("DELETE FROM schedules")
            c.execute("DELETE FROM schedule_days")
            c.execute("UPDATE bookings SET status='cancelled', pay_status=NULL, hold_until=NULL WHERE slot_start IS NOT NULL")
        db.set_kv("scheduling", {})
        db._bump()
        self._ctx = fake_now()
        self._ctx.__enter__()
        self.addCleanup(self._ctx.__exit__, None, None, None)

    # --------------------------------------------------------------- أدوات
    def week(self, branch=None, start="08:00", end="20:00", slot=20, days=range(7)):
        return [{"branchId": branch or self.A, "weekday": w, "start": start, "end": end, "slot": slot} for w in days]

    def hours(self, doctor=None, rows=None, days=None, expect=200):
        s, d, _ = self.e.adm("PUT", "/schedules/" + (doctor or self.DOC), {"rows": self.week() if rows is None else rows, "days": days or []})
        self.assertEqual(s, expect, d)
        return d

    def policy(self, expect=200, **kw):
        s, d, _ = self.e.adm("PUT", "/scheduling", kw)
        self.assertEqual(s, expect, d)
        return d

    def slots(self, doctor=None, branch=""):
        s, d, _ = self.e.req("GET", "/api/v1/slots?doctorId=%s%s" % (doctor or self.DOC, ("&branchId=" + branch) if branch else ""))
        self.assertEqual(s, 200, d)
        return d

    def free(self, d, n):
        return [x["start"] for x in self.slots(d)["days"][n]["slots"]]

    def book(self, d_, start, doctor=None, phone=None, name="مراجع المواعيد", dev=None, branch=None, expect=201, code=None, **kw):
        n = self.uniq()
        dev = dev or "sch_device_%03d_0123456789" % n
        phone = phone or "05777%05d" % n
        body = {"deviceId": dev, "name": name, "phone": phone, "doctorId": doctor or self.DOC, "branchId": branch or self.A, "consent": True,
                "slot": {"day": d_, "start": start}}
        body.update(kw)
        s, d, _ = self.e.req("POST", "/api/v1/bookings", body)
        self.assertEqual(s, expect, d)
        if code:
            self.assertEqual(d["error"], code, d)
        return dev, phone, d

    def cards(self, dev):
        s, d, _ = self.e.req("GET", "/api/v1/bookings?deviceId=" + dev)
        self.assertEqual(s, 200, d)
        return d["bookings"]

    def cancel(self, dev, bid, expect=200):
        s, d, _ = self.e.req("POST", "/api/v1/bookings/%s/cancel" % bid, {"deviceId": dev})
        self.assertEqual(s, expect, d)
        return d


# ====================================================================== ساعات العمل والسياسة (الإدارة)
class TestScheduleAdmin(SchedBase):
    def test_default_state_and_auth(self):
        s, d, _ = self.e.req("GET", "/api/admin/schedules")
        self.assertEqual(s, 401)
        s, d, _ = self.e.adm("GET", "/schedules")
        self.assertEqual(s, 200, d)
        self.assertTrue(all(x["rows"] == 0 for x in d["doctors"]))               # لا ساعات مخترعة: الجداول فارغة افتراضياً
        self.assertEqual(d["policy"], {"horizonDays": 14, "minNoticeMin": 60, "cancelBeforeH": 2, "maxActive": 3, "requireCheckin": False,
                                       "prepay": {"enabled": False, "amount": 0, "holdMin": 15}})
        self.assertEqual((d["payProvider"], d["slotChoices"]), ("", [5, 10, 15, 20, 30, 45, 60]))
        _, ds, _ = self.e.req("GET", "/api/v1/clinic")
        self.assertEqual(ds["meta"]["scheduled"], [])

    def test_weekly_hours_roundtrip_and_public_flag(self):
        _, ds0, h0 = self.e.req("GET", "/api/v1/clinic")
        audit_n = lambda: self.e.app.db.conn().execute("SELECT COUNT(*) FROM audit WHERE ref=? AND action='schedule_update'", (self.DOC,)).fetchone()[0]  # noqa: E731
        n0 = audit_n()
        d = self.hours(rows=[{"branchId": self.A, "weekday": 1, "start": "09:00", "end": "13:00", "slot": 30},
                             {"branchId": self.A, "weekday": 1, "start": "16:00", "end": "20:00", "slot": 20}])
        self.assertEqual([(r["weekday"], r["start"], r["end"], r["slot"]) for r in d["rows"]], [(1, "09:00", "13:00", 30), (1, "16:00", "20:00", 20)])
        s, g, _ = self.e.adm("GET", "/schedules/" + self.DOC)
        self.assertEqual(g["rows"], d["rows"])
        _, ds, h1 = self.e.req("GET", "/api/v1/clinic")
        self.assertIn(self.DOC, ds["meta"]["scheduled"])
        self.assertNotEqual(h0.get("ETag"), h1.get("ETag"))                    # تغيّر الإصدار فيعرف التطبيق من صار قابلاً للحجز بموعد
        docs = self.e.adm("GET", "/schedules")[1]["doctors"]
        self.assertEqual(next(x for x in docs if x["id"] == self.DOC)["rows"], 2)
        self.hours(rows=[])                                                      # تفريغ الجدول = العودة إلى «طلب حجز»
        self.assertNotIn(self.DOC, self.e.req("GET", "/api/v1/clinic")[1]["meta"]["scheduled"])
        self.assertEqual(audit_n() - n0, 2)

    def test_row_validation(self):
        A = self.A
        ok = {"branchId": A, "weekday": 1, "start": "09:00", "end": "13:00", "slot": 20}
        bad = [
            [ok, dict(ok, start="12:00", end="15:00")],                          # تداخل في اليوم نفسه
            [dict(ok, start="13:00", end="09:00")],                              # النهاية قبل البداية
            [dict(ok, end="09:00")],
            [dict(ok, slot=25)],                                                 # مدة غير مسموحة
            [dict(ok, slot=20.0)], [dict(ok, slot="20")], [dict(ok, slot=True)],
            [dict(ok, start="09:00", end="09:10", slot=20)],                     # مدة الموعد أطول من فترة العمل
            [dict(ok, weekday=7)], [dict(ok, weekday=-1)], [dict(ok, weekday=True)], [dict(ok, weekday="1")],
            [dict(ok, branchId="لا-يوجد")],
            [dict(ok, start="9am")], [dict(ok, end="25:00")], [dict(ok, start="")],
            ["نص"], [None],
        ]
        for rows in bad:
            s, d, _ = self.e.adm("PUT", "/schedules/" + self.DOC, {"rows": rows, "days": []})
            self.assertEqual(s, 422, (rows, d))
            self.assertIn("rows", d.get("fields", {}), (rows, d))
        for body in ({"rows": "x"}, {"days": []}, {"rows": [ok] * 71, "days": []}, {"rows": [], "days": "x"}):
            self.assertEqual(self.e.adm("PUT", "/schedules/" + self.DOC, body)[0], 422, body)
        self.assertEqual(self.e.adm("GET", "/schedules/" + self.DOC)[1]["rows"], [])          # لا شيء حُفظ من المحاولات الخاطئة
        self.assertEqual(self.e.adm("PUT", "/schedules/" + quote("لا-يوجد"), {"rows": [], "days": []})[0], 404)
        # أوقات متلاصقة وحتى منتصف الليل مقبولة
        self.hours(rows=[dict(ok, start="00:00", end="12:00", slot=60), dict(ok, start="12:00", end="24:00", slot=60)])

    def test_branch_must_be_one_the_doctor_works_in(self):
        if len(self.br) < 2:
            self.skipTest("فرع واحد")
        doc = self.docs[5]
        item = next(x for x in self.e.adm("GET", "/entities/doctors")[1]["items"] if x["id"] == doc)
        s, r, _ = self.e.adm("PUT", "/entities/doctors/" + doc, dict(item, branchIds=[self.br[0]]))              # الطبيب مقيّد بالفرع الأول
        self.assertEqual(s, 200, r)
        s, r, _ = self.e.adm("PUT", "/schedules/" + doc, {"rows": self.week(branch=self.br[1]), "days": []})
        self.assertEqual((s, "rows" in r.get("fields", {})), (422, True), r)
        s, r, _ = self.e.adm("PUT", "/schedules/" + doc, {"rows": [], "days": [{"branchId": self.br[1], "day": day(3), "kind": "off"}]})
        self.assertEqual((s, "days" in r.get("fields", {})), (422, True), r)
        self.assertEqual(self.e.adm("PUT", "/schedules/" + doc, {"rows": self.week(branch=self.br[0]), "days": []})[0], 200)

    def test_date_exceptions_validation_and_past_dropped(self):
        A = self.A
        ok_off = {"branchId": "", "day": day(5), "kind": "off", "note": "إجازة"}
        d = self.hours(days=[ok_off, {"branchId": A, "day": day(6), "kind": "hours", "start": "14:00", "end": "16:00", "slot": 30},
                             {"branchId": "", "day": day(-3), "kind": "off"}])                    # الماضي لا يُحفظ
        self.assertEqual([(x["day"], x["kind"]) for x in d["days"]], [(day(5), "off"), (day(6), "hours")])
        bad = [dict(ok_off, kind="x"), dict(ok_off, day="2026-13-40"), dict(ok_off, day=""), dict(ok_off, branchId="لا-يوجد"),
               {"branchId": "", "day": day(7), "kind": "hours", "start": "14:00", "end": "16:00", "slot": 30},        # ساعات خاصة بلا فرع
               {"branchId": A, "day": day(7), "kind": "hours", "start": "16:00", "end": "14:00", "slot": 30},
               {"branchId": A, "day": day(7), "kind": "hours", "start": "14:00", "end": "14:10", "slot": 30},
               {"branchId": A, "day": day(7), "kind": "hours", "start": "14:00", "end": "16:00", "slot": 7}, "نص"]
        for x in bad:
            s, r, _ = self.e.adm("PUT", "/schedules/" + self.DOC, {"rows": self.week(), "days": [x]})
            self.assertEqual(s, 422, (x, r))
            self.assertIn("days", r.get("fields", {}))
        overlap = [{"branchId": A, "day": day(7), "kind": "hours", "start": "10:00", "end": "13:00", "slot": 30},
                   {"branchId": A, "day": day(7), "kind": "hours", "start": "12:00", "end": "15:00", "slot": 30}]
        self.assertEqual(self.e.adm("PUT", "/schedules/" + self.DOC, {"rows": self.week(), "days": overlap})[0], 422)

    def test_policy_validation_and_prepay_locked_without_provider(self):
        d = self.policy(horizonDays=30, minNoticeMin=120, cancelBeforeH=0, maxActive=5, requireCheckin=True)
        self.assertEqual({k: d["policy"][k] for k in ("horizonDays", "minNoticeMin", "cancelBeforeH", "maxActive", "requireCheckin")}, {"horizonDays": 30, "minNoticeMin": 120, "cancelBeforeH": 0, "maxActive": 5, "requireCheckin": True})
        self.assertEqual(self.e.adm("GET", "/schedules")[1]["policy"]["horizonDays"], 30)
        for k, v in (("horizonDays", 0), ("horizonDays", 61), ("horizonDays", "14"), ("horizonDays", 14.5), ("horizonDays", True), ("minNoticeMin", -1),
                     ("cancelBeforeH", 73), ("maxActive", 0), ("requireCheckin", "yes")):
            s, r, _ = self.e.adm("PUT", "/scheduling", {k: v})
            self.assertEqual(s, 422, (k, v, r))
            self.assertIn(k, r["fields"])
        self.assertEqual(self.e.adm("GET", "/schedules")[1]["policy"]["horizonDays"], 30)       # الخاطئ لم يُحفظ
        # لا بوابة دفع مربوطة: الخادم يرفض التفعيل مهما كان المطلوب
        s, r, _ = self.e.adm("PUT", "/scheduling", {"prepay": {"enabled": True, "amount": 50, "holdMin": 15}})
        self.assertEqual(s, 422, r)
        self.assertIn("بوابة دفع", r["fields"]["prepay"])
        self.assertFalse(self.e.adm("GET", "/schedules")[1]["policy"]["prepay"]["enabled"])
        # تعديل مبلغ ومهلة دون تفعيل مسموح (يُحفظ استعداداً)
        d = self.policy(prepay={"enabled": False, "amount": 80, "holdMin": 30})
        self.assertEqual(d["policy"]["prepay"], {"enabled": False, "amount": 80, "holdMin": 30})
        for bad in ({"enabled": "true"}, {"enabled": False, "amount": -1}, {"enabled": False, "holdMin": 2}, {"enabled": False, "amount": "50"}):
            self.assertEqual(self.e.adm("PUT", "/scheduling", {"prepay": bad})[0], 422, bad)
        self.assertIn("scheduling_policy", [r["action"] for r in self.e.app.db.conn().execute("SELECT action FROM audit")])

    def test_existing_bookings_outside_new_hours_are_reported_not_cancelled(self):
        self.hours()
        dev, _, d = self.book(day(1), "10:00")
        bid = d["booking"]["id"]
        d = self.hours(rows=self.week(start="14:00", end="18:00"))                               # الجدول الجديد لا يشمل 10:00
        self.assertEqual([(x["id"], x["day"], x["time"]) for x in d["outside"]], [(bid, day(1), "10:00")])
        self.assertEqual(self.cards(dev)[0]["status"], "confirmed")                                # لم يُلغَ تلقائياً
        self.assertEqual(self.hours(rows=self.week())["outside"], [])


# ====================================================================== المواعيد المتاحة والحجز (المراجع)
class TestSlotsAndBooking(SchedBase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.hours_set = False

    def setUp(self):
        super().setUp()
        self.hours()                                  # كل الأيام 08:00–20:00 بموعد 20 دقيقة وسياسة افتراضية

    def test_available_slots_shape_and_notice(self):
        d = self.slots()
        self.assertTrue(d["scheduled"])
        self.assertEqual(d["branches"], [self.A])
        self.assertEqual(len(d["days"]), 15)                                      # اليوم + 14
        today, tomorrow = d["days"][0], d["days"][1]
        self.assertEqual((today["day"], today["weekday"]), (day(0), 1))           # الاثنين = 1 (الأحد 0)
        self.assertEqual((tomorrow["day"], tomorrow["weekday"]), (day(1), 2))
        self.assertEqual(today["slots"][0], {"start": "10:00", "min": 20, "branchId": self.A})        # 9:00 + مهلة ساعة
        self.assertEqual(today["slots"][-1]["start"], "19:40")
        self.assertEqual((len(today["slots"]), len(tomorrow["slots"])), (30, 36))
        self.assertEqual(d["policy"], {"horizonDays": 14, "minNoticeMin": 60, "cancelBeforeH": 2, "checkin": False, "prepay": {"enabled": False, "amount": 0, "holdMin": 15, "test": False}})

    def test_unscheduled_doctor_and_bad_input(self):
        d = self.slots(self.DOC3)
        self.assertEqual((d["scheduled"], d["days"], d["branches"]), (False, [], []))
        self.assertEqual(self.e.req("GET", "/api/v1/slots?doctorId=" + quote("لا-يوجد"))[0], 404)
        self.assertEqual(self.e.req("GET", "/api/v1/slots")[0], 404)
        self.assertEqual(self.e.req("GET", "/api/v1/slots?doctorId=%s&branchId=%s" % (self.DOC, quote("لا-يوجد")))[0], 422)
        # الفرع المطلوب لا يعمل فيه الطبيب: لا مواعيد
        if len(self.br) > 1:
            self.assertTrue(all(not x["slots"] for x in self.slots(self.DOC, self.br[1])["days"]))

    def test_booking_confirms_automatically_and_blocks_the_slot(self):
        dev, phone, d = self.book(day(1), "10:00", name="سعد الاختبار")
        b = d["booking"]
        self.assertTrue(d["appointment"])
        self.assertEqual((b["status"], b["doctorId"], b["branchId"], b["date"], b["period"]), ("confirmed", self.DOC, self.A, day(1), "morning"))
        self.assertEqual(b["slot"]["start"], "10:00")
        self.assertEqual((b["slot"]["min"], b["slot"]["label"]), (20, "10:00 ص"))
        self.assertEqual(b["slot"]["cancelUntil"], "2026-11-24T05:00:00Z")          # 10:00 رياض = 07:00 UTC؛ − ساعتان = 05:00
        self.assertNotIn("pay", b)
        t = b["appointmentText"]
        self.assertTrue(t.startswith("موعدك مؤكد: الثلاثاء 24 نوفمبر 2026 · 10:00 ص — د. "), t)
        self.assertIn(self.names[self.DOC], t)
        self.assertLessEqual(len(t), 200)
        self.assertNotIn("10:00", self.free(self.DOC, 1))                             # اختفى من المتاح
        self.assertIn("10:20", self.free(self.DOC, 1))
        c = self.cards(dev)
        self.assertEqual((len(c), c[0]["id"], c[0]["status"]), (1, b["id"], "confirmed"))
        self.assertEqual(c[0]["slot"]["cancelUntil"], b["slot"]["cancelUntil"])
        # مساء الموعد: فترة evening
        _, _, d2 = self.book(day(1), "17:40")
        self.assertEqual(d2["booking"]["period"], "evening")
        self.assertEqual(d2["booking"]["slot"]["label"], "5:40 م")
        self.assertIn("5:40 م", d2["booking"]["appointmentText"])

    def test_double_booking_is_impossible(self):
        self.book(day(2), "11:00")
        self.book(day(2), "11:00", expect=409, code="slot_taken")
        # موعد ملغى يعود متاحاً لغيره
        dev, _, d = self.book(day(2), "11:20")
        self.cancel(dev, d["booking"]["id"])
        self.assertIn("11:20", self.free(self.DOC, 2))
        self.book(day(2), "11:20")

    def test_concurrent_requests_one_winner(self):
        res, lock = [], threading.Lock()

        def go(i):
            dev = "race_device_%03d_0123456789" % i
            s, d, _ = self.e.req("POST", "/api/v1/bookings", {"deviceId": dev, "name": "مراجع سباق", "phone": "05888%05d" % i, "doctorId": self.DOC, "branchId": self.A,
                                                              "consent": True, "slot": {"day": day(3), "start": "09:00"}})
            with lock:
                res.append((s, d.get("error")))
        ts = [threading.Thread(target=go, args=(i,)) for i in range(8)]
        [t.start() for t in ts]
        [t.join() for t in ts]
        self.assertEqual(sorted(s for s, _ in res), [201] + [409] * 7, res)
        self.assertEqual({e for s, e in res if s == 409}, {"slot_taken"})
        n = self.e.app.db.conn().execute("SELECT COUNT(*) FROM bookings WHERE doctor_id=? AND date=? AND slot_start=540 AND status IN ('new','contacted','confirmed')", (self.DOC, day(3))).fetchone()[0]
        self.assertEqual(n, 1)

    def test_database_itself_refuses_duplicates(self):
        import sqlite3
        _, _, d = self.book(day(4), "13:00")
        c = self.e.app.db.conn()
        with self.assertRaises(sqlite3.IntegrityError):
            c.execute("INSERT INTO bookings(id,created_at,updated_at,status,name,phone,device_id,doctor_id,branch_id,date,period,slot_start,slot_min) "
                      "VALUES('DS-XXXXXX','x','x','confirmed','س','0500000000','d',?,?,?,'evening',780,20)", (self.DOC, self.A, day(4)))

    def test_invalid_slots_rejected(self):
        for d_, st in ((day(1), "10:10"),                   # ليس على شبكة الموعد (08:00 + 20×ن)
                       (day(1), "07:40"), (day(1), "20:00"),  # خارج ساعات العمل
                       (day(0), "09:40"),                    # أقل من مهلة الساعة
                       (day(0), "08:00"),                    # فات وقته
                       (day(-1), "10:00"),                   # أمس
                       (day(15), "10:00"),                   # بعد مهلة الحجز المسبق (14 يوماً)
                       (day(1), "24:00")):
            self.book(d_, st, expect=409, code="slot_invalid")
        self.book(day(0), "10:00")                              # على حدّ المهلة تماماً: مقبول
        self.book(day(14), "10:00")                             # آخر يوم في المهلة

    def test_malformed_slot_payload(self):
        for sl in ("x", 5, [], {}, {"day": "2026-13-45", "start": "10:00"}, {"day": day(1)}, {"day": day(1), "start": "25:00"}, {"day": day(1), "start": "ص"},
                   {"day": 20261124, "start": "10:00"}):
            n, dev = self.uniq(), "bad_device_%03d_0123456789" % self.uniq()
            s, d, _ = self.e.req("POST", "/api/v1/bookings", {"deviceId": dev, "name": "مراجع خطأ", "phone": "05999%05d" % n, "doctorId": self.DOC, "branchId": self.A, "consent": True, "slot": sl})
            self.assertEqual(s, 422, (sl, d))
        # الموعد يحتاج طبيباً وفرعاً
        n = self.uniq()
        base = {"deviceId": "nodoc_device_%03d_0123456789" % n, "name": "مراجع خطأ", "phone": "05999%05d" % n, "consent": True, "slot": {"day": day(1), "start": "10:00"}}
        self.assertEqual(self.e.req("POST", "/api/v1/bookings", dict(base, specialtyId="dental", branchId=self.A))[0], 422)
        self.assertEqual(self.e.req("POST", "/api/v1/bookings", dict(base, doctorId=self.DOC))[0], 422)
        # الموافقة على الخصوصية تبقى شرطاً
        self.assertEqual(self.e.req("POST", "/api/v1/bookings", dict(base, doctorId=self.DOC, branchId=self.A, consent=False))[0], 422)

    def test_wrong_branch_for_the_slot(self):
        if len(self.br) < 2:
            self.skipTest("فرع واحد")
        self.book(day(1), "10:00", branch=self.br[1], expect=409, code="slot_invalid")

    def test_old_request_flow_unchanged_for_doctors_without_hours(self):
        self.book(day(1), "10:00", doctor=self.DOC3, expect=409, code="not_scheduled")
        n = self.uniq()
        s, d, _ = self.e.req("POST", "/api/v1/bookings", {"deviceId": "old_device_%03d_0123456789" % n, "name": "مراجع قديم", "phone": "05666%05d" % n, "doctorId": self.DOC3,
                                                           "branchId": self.A, "date": day(2), "period": "evening", "consent": True})
        self.assertEqual(s, 201, d)
        b = d["booking"]
        self.assertEqual((b["status"], b["period"]), ("new", "evening"))
        self.assertNotIn("slot", b)
        self.assertNotIn("pay", b)
        # لا يستطيع المراجع إلغاء حجز قديم أكّدته الإدارة (كما كان)
        self.assertEqual(self.e.adm("PATCH", "/bookings/" + b["id"], {"status": "confirmed", "appointmentText": "الثلاثاء 5 م"})[0], 200)
        self.cancel("old_device_%03d_0123456789" % n, b["id"], expect=409)

    def test_slots_response_carries_no_patient_data(self):
        self.book(day(1), "10:00", name="اسم-سري-للمراجع", phone="0577123456")
        raw = self.e.req("GET", "/api/v1/slots?doctorId=" + self.DOC, raw=True)
        body = raw[1].decode()
        for secret in ("اسم-سري", "0577123456", "577123456", "DS-"):
            self.assertNotIn(secret, body)
        self.assertEqual(raw[2].get("Cache-Control"), "no-store")

    def test_active_appointments_limit_per_phone_and_one_per_day(self):
        self.policy(maxActive=2)
        dev, phone, _ = self.book(day(1), "10:00")
        self.book(day(2), "10:00", phone=phone)
        self.book(day(3), "10:00", phone=phone, expect=409, code="too_many_active")
        self.book(day(3), "10:00")                                                       # جوال آخر غير متأثر
        # الإلغاء يفتح المجال
        c = self.cards(dev)
        self.cancel(dev, c[0]["id"])
        self.book(day(3), "10:20", phone=phone)
        # موعد واحد لكل طبيب في اليوم الواحد للجوال نفسه
        self.policy(maxActive=5)
        self.hours(self.DOC2, rows=self.week())
        _, p2, _ = self.book(day(5), "10:00")
        self.book(day(5), "12:00", phone=p2, expect=409, code="duplicate_day")
        self.book(day(5), "12:00", phone=p2, doctor=self.DOC2)                           # طبيب آخر في اليوم نفسه: مقبول

    def test_overlap_when_slot_length_changes(self):
        self.book(day(1), "10:00")                                                       # 10:00–10:20
        self.hours(rows=self.week(slot=30))                                             # الشبكة الجديدة 30 دقيقة
        f = self.free(self.DOC, 1)
        self.assertNotIn("10:00", f)                                                     # 10:00–10:30 يتقاطع مع المحجوز
        self.assertIn("09:30", f)                                                        # 9:30–10:00 يلامسه فقط
        self.assertIn("10:30", f)
        self.book(day(1), "10:00", expect=409)

    def test_date_exceptions_change_available_slots(self):
        A = self.A
        self.hours(days=[{"branchId": "", "day": day(2), "kind": "off", "note": "إجازة"},
                         {"branchId": A, "day": day(3), "kind": "hours", "start": "14:00", "end": "16:00", "slot": 30},
                         {"branchId": "", "day": day(4), "kind": "off"}, {"branchId": A, "day": day(4), "kind": "hours", "start": "09:00", "end": "10:00", "slot": 30}])
        self.assertEqual(self.free(self.DOC, 2), [])
        self.assertEqual(self.free(self.DOC, 3), ["14:00", "14:30", "15:00", "15:30"])
        self.assertEqual(self.free(self.DOC, 4), ["09:00", "09:30"])                      # الساعات الخاصة تغلب الإجازة
        self.assertEqual(len(self.free(self.DOC, 1)), 36)
        self.book(day(2), "10:00", expect=409, code="slot_invalid")
        self.book(day(3), "14:30")

    def test_horizon_setting(self):
        self.policy(horizonDays=3)
        self.assertEqual(len(self.slots()["days"]), 4)
        self.book(day(4), "10:00", expect=409, code="slot_invalid")
        self.policy(horizonDays=3, minNoticeMin=1440)                                   # يوم كامل مهلة: لا شيء اليوم ولا قبل 9:00 غداً
        d = self.slots()["days"]
        self.assertEqual(d[0]["slots"], [])
        self.assertEqual(d[1]["slots"][0]["start"], "09:00")

    def test_sunday_first_weekday_mapping(self):
        self.hours(rows=[{"branchId": self.A, "weekday": 0, "start": "08:00", "end": "09:00", "slot": 20}])      # الأحد فقط
        d = self.slots()["days"]
        sundays = [x["day"] for x in d if x["slots"]]
        self.assertEqual(sundays, [day(6), day(13)])                                      # 29 نوفمبر و6 ديسمبر 2026 أحد
        self.assertEqual(dt.date.fromisoformat(sundays[0]).strftime("%A"), "Sunday")

    # ------------------------------------------------------------------ الإلغاء
    def test_patient_cancel_window(self):
        dev1, _, a = self.book(day(0), "11:00")                      # بعد ساعتين تماماً من الآن (9:00): مسموح
        dev2, _, b = self.book(day(0), "10:00")                      # بعد ساعة: أقل من المهلة (ساعتان)
        dev3, _, c = self.book(day(1), "10:00")
        d = self.cancel(dev2, b["booking"]["id"], expect=409)
        self.assertEqual(d["error"], "too_late")
        self.assertEqual(self.cards(dev2)[0]["status"], "confirmed")
        self.assertEqual(self.cancel(dev1, a["booking"]["id"])["booking"]["status"], "cancelled")
        self.assertEqual(self.cancel(dev3, c["booking"]["id"])["booking"]["status"], "cancelled")
        self.assertIn("10:00", self.free(self.DOC, 1))
        self.cancel("other_device_000_0123456789", b["booking"]["id"], expect=404)       # جهاز آخر لا يلغي
        self.policy(cancelBeforeH=0)                                                      # بلا مهلة: يلغي حتى لحظة الموعد
        self.assertEqual(self.cancel(dev2, b["booking"]["id"])["booking"]["status"], "cancelled")

    def test_cancel_after_the_slot_time_is_refused(self):
        dev, _, a = self.book(day(0), "11:00")
        self.policy(cancelBeforeH=0)
        with fake_now(NOW + dt.timedelta(hours=3)):                                       # صار 12:00
            self.cancel(dev, a["booking"]["id"], expect=409)

    # ------------------------------------------------------------------ لوحة الإدارة
    def test_admin_reactivating_a_cancelled_slot_taken_by_someone_else(self):
        dev, _, a = self.book(day(1), "15:00")
        self.cancel(dev, a["booking"]["id"])
        self.book(day(1), "15:00")                                                        # مراجع آخر أخذه
        s, d, _ = self.e.adm("PATCH", "/bookings/" + a["booking"]["id"], {"status": "confirmed", "appointmentText": "x"})
        self.assertEqual((s, d["error"]), (409, "slot_taken"))
        self.assertEqual(self.e.app.db.get_booking(a["booking"]["id"])["status"], "cancelled")

    def test_admin_cancel_frees_slot_and_notifies(self):
        dev, _, a = self.book(day(1), "16:00")
        self.assertEqual(self.e.adm("PATCH", "/bookings/" + a["booking"]["id"], {"status": "cancelled"})[0], 200)
        self.assertIn("16:00", self.free(self.DOC, 1))
        self.assertTrue(any(x["kind"] == "booking" for x in self.notifs(dev)))


# ====================================================================== الدفع المسبق: مزوّد «تجريبي» فقط
class TestPrepayLocked(SchedBase):
    def test_no_provider_means_no_prepay_and_no_pay_endpoint(self):
        self.hours()
        s, r, _ = self.e.adm("PUT", "/scheduling", {"prepay": {"enabled": True, "amount": 100, "holdMin": 15}})
        self.assertEqual(s, 422, r)
        dev, _, d = self.book(day(1), "10:00")
        self.assertEqual(d["booking"]["status"], "confirmed")                              # لا حجز مؤقت ولا مبلغ
        s, r, _ = self.e.req("POST", "/api/v1/bookings/%s/pay" % d["booking"]["id"], {"deviceId": dev})
        self.assertEqual(s, 404)
        self.assertFalse(self.slots()["policy"]["prepay"]["enabled"])


class TestPrepayTestProvider(SchedBase):
    ENV = {"DS_PAY_PROVIDER": "test"}

    def setUp(self):
        super().setUp()
        self.hours()
        self.policy(horizonDays=14, minNoticeMin=60, cancelBeforeH=2, maxActive=9, requireCheckin=False, prepay={"enabled": True, "amount": 50, "holdMin": 15})

    def pay(self, dev, bid, expect=200):
        s, d, _ = self.e.req("POST", "/api/v1/bookings/%s/pay" % bid, {"deviceId": dev})
        self.assertEqual(s, expect, d)
        return d

    def test_hold_then_pay_confirms(self):
        pol = self.slots()["policy"]["prepay"]
        self.assertEqual(pol, {"enabled": True, "amount": 50, "holdMin": 15, "test": True})
        dev, _, d = self.book(day(1), "10:00")
        b = d["booking"]
        self.assertEqual((b["status"], b["appointmentText"]), ("new", ""))                # لم يُؤكَّد بعد
        self.assertEqual((b["pay"]["status"], b["pay"]["amount"]), ("pending", 50))
        self.assertGreater(b["pay"]["holdUntil"], "2026")
        self.assertNotIn("10:00", self.free(self.DOC, 1))                                 # محجوز مؤقتاً لغيره
        self.book(day(1), "10:00", expect=409, code="slot_taken")
        self.pay("other_device_000_0123456789", b["id"], expect=404)
        d2 = self.pay(dev, b["id"])["booking"]
        self.assertEqual((d2["status"], d2["pay"]["status"]), ("confirmed", "paid"))
        self.assertTrue(d2["appointmentText"].startswith("موعدك مؤكد:"))
        self.assertEqual(self.pay(dev, b["id"], expect=409)["error"], "state")
        self.assertNotIn("10:00", self.free(self.DOC, 1))

    def test_expired_hold_releases_the_slot(self):
        dev, _, d = self.book(day(1), "11:00")
        bid = d["booking"]["id"]
        self.e.app.db.conn().execute("UPDATE bookings SET hold_until='2000-01-01T00:00:00Z' WHERE id=?", (bid,))
        self.assertIn("11:00", self.free(self.DOC, 1))                                     # عاد متاحاً
        c = self.cards(dev)[0]
        self.assertEqual((c["status"], c["pay"]["status"]), ("cancelled", "expired"))
        self.assertEqual(self.pay(dev, bid, expect=409)["error"], "expired")
        self.book(day(1), "11:00")                                                         # وأخذه غيره

    def test_expired_hold_is_released_even_if_nobody_lists_slots(self):
        dev, _, d = self.book(day(1), "12:00")
        self.e.app.db.conn().execute("UPDATE bookings SET hold_until='2000-01-01T00:00:00Z' WHERE id=?", (d["booking"]["id"],))
        self.book(day(1), "12:00")                                                         # الحجز الجديد نفسه يفرج عن المنتهي في معاملته

    def test_admin_confirm_waives_payment_and_patient_cancel_ends_it(self):
        dev, _, d = self.book(day(1), "13:00")
        bid = d["booking"]["id"]
        s, r, _ = self.e.adm("PATCH", "/bookings/" + bid, {"status": "confirmed"})
        self.assertEqual(s, 200, r)                                                        # نصّ الموعد التلقائي موجود فلا يلزم كتابته
        self.assertEqual((r["booking"]["status"], r["booking"]["pay_status"], r["booking"]["hold_until"]), ("confirmed", "waived", None))
        self.e.app.db.conn().execute("UPDATE bookings SET hold_until='2000-01-01T00:00:00Z' WHERE id=?", (bid,))
        self.assertEqual(self.cards(dev)[0]["status"], "confirmed")                         # انقضاء المهلة لا يمسّه بعد التنازل
        dev2, _, d2 = self.book(day(1), "13:20")
        c = self.cancel(dev2, d2["booking"]["id"])["booking"]
        self.assertEqual((c["status"], c["pay"]["status"]), ("cancelled", "cancelled"))
        self.assertEqual(self.pay(dev2, d2["booking"]["id"], expect=409)["error"], "state")  # لا يُؤكَّد ملغى بالدفع

    def test_pending_hold_counts_toward_limits(self):
        self.policy(maxActive=1, prepay={"enabled": True, "amount": 50, "holdMin": 15})
        dev, phone, _ = self.book(day(1), "14:00")
        self.book(day(2), "14:00", phone=phone, expect=409, code="too_many_active")


# ====================================================================== الطبيب: مواعيد اليوم والاستدعاء
class TestDoctorAppointments(SchedBase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.D = cls.ready("doc_appt", "doctor", cls.br[0], cls.docs[0])
        cls.D2 = cls.ready("doc_appt2", "doctor", cls.br[0], cls.docs[1])

    def setUp(self):
        super().setUp()
        self.hours()
        self.hours(self.DOC2)
        self.policy(horizonDays=14, minNoticeMin=60, cancelBeforeH=2, maxActive=9, requireCheckin=False)
        db = self.e.app.db
        db.conn().execute("UPDATE bookings SET status='cancelled' WHERE slot_start IS NOT NULL")
        db.conn().execute("UPDATE visits SET status='left' WHERE status IN ('waiting','ready','with_doctor','done')")

    def queue(self, H, d_=None):
        s, d, _ = self.st("GET", "/clinic/queue?day=" + (d_ or day(0)), H)
        self.assertEqual(s, 200, d)
        return d

    def appt_call(self, H, bid, expect=200):
        s, d, _ = self.st("POST", "/clinic/appointments/%s/call" % bid, H)
        self.assertEqual(s, expect, d)
        return d

    def test_appointment_appears_by_itself_in_the_doctors_queue(self):
        dev, phone, d = self.book(day(0), "11:00", name="مراجع الموعد")
        bid = d["booking"]["id"]
        q = self.queue(self.D)
        self.assertEqual([(a["id"], a["time"], a["timeLabel"], a["min"], a["name"]) for a in q["appointments"]], [(bid, "11:00", "11:00 ص", 20, "مراجع الموعد")])
        self.assertNotIn(phone, str(q))                                                      # لا يُعرض جوال المراجع في طابور الطبيب
        self.assertEqual([x for x in q["visits"] if x["patientName"] == "مراجع الموعد"], [])
        self.assertEqual(self.queue(self.D2)["appointments"], [])                           # كل طبيب يرى مواعيده فقط
        self.assertEqual(self.queue(self.D, day(1))["appointments"], [])
        # مرتبة بالوقت
        self.book(day(0), "10:00")
        self.assertEqual([a["time"] for a in self.queue(self.D)["appointments"]], ["10:00", "11:00"])

    def test_call_creates_the_visit_and_notifies_the_patient(self):
        dev, phone, d = self.book(day(0), "11:00", name="مراجع الموعد")
        bid = d["booking"]["id"]
        r = self.appt_call(self.D, bid)
        v = r["visit"]
        self.assertEqual((v["status"], v["doctorId"]), ("with_doctor", self.DOC))
        self.assertTrue(r["provisional"])                                                    # لا ملف سابق: يُنشأ ملف مؤقت
        rec = self.e.app.db.record_get(v["mrn"])
        self.assertTrue(v["mrn"].startswith("DS-"))
        self.assertEqual((rec["source"], rec["phone"], rec["name"]), ("appointment", norm_phone(phone), "مراجع الموعد"))
        self.assertNotEqual(self.e.app.db.next_local_mrn(), v["mrn"])                        # التسلسل لا يتعارض
        q = self.queue(self.D)
        self.assertEqual(q["appointments"], [])                                              # خرج من قائمة المواعيد لأن له زيارة
        self.assertEqual([(x["id"], x["status"], x["apptTime"]) for x in q["visits"] if x["id"] == v["id"]], [(v["id"], "with_doctor", "11:00 ص")])
        card = self.cards(dev)[0]
        self.assertEqual((card["visit"]["status"], card["visit"]["doctorName"]), ("with_doctor", self.names[self.DOC]))
        self.assertTrue(any(n["kind"] == "visit" and n["title"] == "حان دورك" for n in self.notifs(dev)))
        self.assertEqual(self.appt_call(self.D, bid)["visit"]["id"], v["id"])               # الاستدعاء المتكرر لا ينشئ زيارة ثانية
        n = self.e.app.db.conn().execute("SELECT COUNT(*) FROM visits WHERE booking_id=?", (bid,)).fetchone()[0]
        self.assertEqual(n, 1)
        self.assertIn("appt_call", self.audit(v["id"]))
        det = [r["detail"] for r in self.e.app.db.conn().execute("SELECT detail FROM audit WHERE ref=? AND action='appt_call'", (v["id"],))][0]
        self.assertNotIn("مراجع الموعد", det)                                               # التدقيق بلا بيانات المراجع
        self.assertNotIn(phone, det)
        self.assertNotIn(norm_phone(phone), det)
        # الزيارة تكتمل كأي زيارة: تشخيص ثم إنهاء ثم يراه المراجع
        self.finish(self.D, v["id"], DX)
        self.assertTrue(self.cards(dev)[0]["visit"]["summary"])

    def test_call_uses_the_existing_record_when_one_matches(self):
        mrn = self.newrec("مراجع موجود ملفه")
        phone = self.e.app.db.record_get(mrn)["phone"]
        dev, _, d = self.book(day(0), "11:00", name="مراجع موجود ملفه", phone=phone)
        r = self.appt_call(self.D, d["booking"]["id"])
        self.assertEqual((r["visit"]["mrn"], r["provisional"]), (mrn, False))
        # ملفان بالجوال والاسم نفسيهما: لا تخمين، يُنشأ ملف مؤقت يراجعه الاستقبال
        self.e.app.db.conn().execute("UPDATE visits SET status='left'")
        m1, m2 = self.newrec("توأم الاسم"), self.newrec("توأم الاسم")
        ph = "0551112223"
        for m in (m1, m2):
            self.e.app.db.conn().execute("UPDATE records SET phone=? WHERE mrn=?", (ph, m))
        _, _, d2 = self.book(day(0), "12:00", name="توأم الاسم", phone=ph)
        r2 = self.appt_call(self.D, d2["booking"]["id"])
        self.assertTrue(r2["provisional"])
        self.assertNotIn(r2["visit"]["mrn"], (m1, m2))

    def test_guards_on_calling(self):
        _, _, d = self.book(day(0), "11:00")
        bid = d["booking"]["id"]
        self.appt_call(self.R, bid, expect=403)                                              # الاستقبال ليس طبيباً
        self.appt_call(self.D2, bid, expect=404)                                             # موعد طبيب آخر
        self.appt_call(self.D, "DS-ZZZZZZ", expect=404)
        _, _, d1 = self.book(day(1), "11:00")
        self.appt_call(self.D, d1["booking"]["id"], expect=409)                              # ليس موعد اليوم
        self.assertEqual(self.appt_call(self.D, d1["booking"]["id"], expect=409)["error"], "not_today")
        # لا يستدعى موعد ملغى
        dev, _, d2 = self.book(day(0), "12:00")
        self.e.adm("PATCH", "/bookings/" + d2["booking"]["id"], {"status": "cancelled"})
        self.assertEqual(self.appt_call(self.D, d2["booking"]["id"], expect=409)["error"], "state")

    def test_one_patient_at_a_time(self):
        _, _, a = self.book(day(0), "11:00", name="الأول")
        _, _, b = self.book(day(0), "11:20", name="الثاني")
        self.appt_call(self.D, a["booking"]["id"])
        self.assertEqual(self.appt_call(self.D, b["booking"]["id"], expect=409)["error"], "busy")
        v = self.e.app.db.conn().execute("SELECT id FROM visits WHERE booking_id=?", (a["booking"]["id"],)).fetchone()["id"]
        self.finish(self.D, v, DX)
        self.appt_call(self.D, b["booking"]["id"])

    def test_require_checkin_setting_sends_patients_through_reception(self):
        self.policy(requireCheckin=True)
        self.hours()
        self.assertTrue(self.slots()["policy"]["checkin"])                                    # التطبيق يعرف فيطلب من المراجع تسجيل وصوله
        dev, phone, d = self.book(day(0), "11:00", name="مراجع الاستقبال")
        bid = d["booking"]["id"]
        self.assertEqual(self.appt_call(self.D, bid, expect=409)["error"], "checkin_required")
        # الاستقبال يسجّل وصوله من الحجز (المسار القديم) فيظهر في طابور الطبيب مع وقت موعده
        mrn, v = self.checkin(self.DOC, name="مراجع الاستقبال", booking=bid)
        q = self.queue(self.D)
        self.assertEqual(q["appointments"], [])
        self.assertEqual([(x["id"], x["apptTime"]) for x in q["visits"] if x["id"] == v["id"]], [(v["id"], "11:00 ص")])
        self.call(self.D, v["id"])                                                           # ثم يستدعيه كالمعتاد
        # والاستدعاء المباشر بعد وصوله يعمل حتى مع الشرط
        self.assertEqual(self.appt_call(self.D, bid)["visit"]["id"], v["id"])

    def test_reception_sees_slot_and_state(self):
        dev, _, d = self.book(day(0), "11:00", name="مراجع الاستقبال")
        s, r, _ = self.st("GET", "/bookings", self.R)
        self.assertEqual(s, 200, r)
        b = next(x for x in r["bookings"] if x["id"] == d["booking"]["id"])
        self.assertEqual((b["slotLabel"], b["slotStart"], b["status"], b["visitId"], b["payStatus"]), ("11:00 ص", 660, "confirmed", "", ""))
        mrn, v = self.checkin(self.DOC, name="مراجع الاستقبال", booking=d["booking"]["id"])
        s, r, _ = self.st("GET", "/visits?day=" + day(0), self.R)
        self.assertEqual([x["apptTime"] for x in r["visits"] if x["id"] == v["id"]], ["11:00 ص"])
        b = next(x for x in self.st("GET", "/bookings", self.R)[1]["bookings"] if x["id"] == d["booking"]["id"])
        self.assertEqual((b["visitId"], b["visitStatus"]), (v["id"], "waiting"))
        # وبعد تسجيل الوصول لا يلغي المراجع من التطبيق
        self.cancel(dev, d["booking"]["id"], expect=409)

    def test_walk_in_does_not_consume_a_slot(self):
        before = self.free(self.DOC, 0)
        self.checkin(self.DOC, name="بلا موعد")                                              # يصل بلا حجز
        self.assertEqual(self.free(self.DOC, 0), before)


if __name__ == "__main__":
    unittest.main()
