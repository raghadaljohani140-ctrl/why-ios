#!/usr/bin/env python3
"""أدوات إدارة من سطر الأوامر: تهيئة، كلمة المرور، نسخ احتياطي، تصدير/استيراد."""
import argparse
import getpass
import json
import os
import secrets
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import app as appmod  # noqa: E402
import scheddb as sd  # noqa: E402


def cmd_init(a, app):
    if app.admin_record() and not a.reset:
        print("كلمة مرور الإدارة مضبوطة مسبقاً. لإعادة ضبطها: set-password")
        return 0
    pw = a.password or secrets.token_urlsafe(12)
    app.set_admin_password(pw)
    print("تم إنشاء قاعدة البيانات وتحميل البيانات الأولية.")
    if not a.password:
        print("كلمة مرور لوحة الإدارة (تُعرض مرة واحدة فقط، احفظها الآن): " + pw)
    return 0


def cmd_set_password(a, app):
    pw = a.password or getpass.getpass("كلمة المرور الجديدة: ")
    if len(pw) < 10:
        print("قصيرة: 10 أحرف على الأقل")
        return 1
    app.set_admin_password(pw)
    print("تم تغيير كلمة المرور.")
    return 0


def cmd_backup(a, app):
    dest = a.out or str(app.cfg.db_path.parent / "backups" / ("clinic-%s.db" % time.strftime("%Y%m%d-%H%M%S")))
    print("نسخة احتياطية:", app.db.backup_to(dest))
    return 0


def cmd_export(a, app):
    Path(a.out).write_text(json.dumps(app.db.export_all(), ensure_ascii=False, indent=1), encoding="utf-8")
    print("تم التصدير إلى", a.out)
    return 0


def cmd_import(a, app):
    data = json.loads(Path(a.file).read_text(encoding="utf-8"))
    if not a.yes:
        print("الاستيراد يكتب فوق بيانات الكيانات والإعدادات الحالية. أضف --yes للتأكيد (يُنصح بتنفيذ backup أولاً).")
        return 1
    n = 0
    for kind in appmod.dbmod.KINDS:
        for e in data.get(kind, []):
            app.db.upsert_entity(kind, e, "import")
            n += 1
    if "settings" in data:
        app.db.set_kv("settings", data["settings"])
    if "qamar" in data:
        app.db.set_kv("qamar", data["qamar"])
    app.db._bump()
    print("تم استيراد %d عنصراً" % n)
    return 0


def cmd_stats(a, app):
    print(json.dumps({"bookings": app.db.booking_stats(), "dataVersion": app._data_version(), "qamarToday": app.db.usage_get("qamar:msgs"),
                      "llmToday": app.db.usage_get("llm")}, ensure_ascii=False, indent=1))
    return 0


# ---------------------------------------------------------------------------- الدوام القياسي (بطلب الإدارة)
STD_SHIFTS = ((9 * 60, 12 * 60 + 30), (16 * 60, 22 * 60))     # شفتان: 09:00–12:30 و16:00–22:00
ALL_DAY = ((0, 24 * 60),)                                      # الطبيب العام: 24 ساعة (يتناوبون)


def _off_days(text):
    """«الجمعة» أو «5» أو «الجمعة,السبت» ← {5, 6} (0 = الأحد … 6 = السبت)."""
    names = {n: i for i, n in enumerate(sd.AR_WEEKDAYS)}
    out = set()
    for part in str(text or "").replace("،", ",").split(","):
        part = part.strip()
        if not part:
            continue
        if part.isdigit() and int(part) <= 6:
            out.add(int(part))
        elif part in names:
            out.add(names[part])
        else:
            raise ValueError(part)
    return out


def _branch_by_weekday(doc, old_rows, default_br, branches):
    """فرع الطبيب لكل يوم: ما حدّدته الإدارة سابقاً في جدوله، وإلا أول فرع مسجّل للطبيب، وإلا الفرع الافتراضي."""
    allowed = [b for b in (doc.get("branchIds") or []) if b in branches] or list(branches)
    mine = [r["branch_id"] for r in old_rows if r["branch_id"] in allowed]
    base = mine[0] if mine else (default_br if default_br in allowed else allowed[0])
    by_wd = {}
    for r in old_rows:
        if r["branch_id"] in allowed:
            by_wd.setdefault(r["weekday"], r["branch_id"])
    return {wd: by_wd.get(wd, base) for wd in range(7)}


def _std_rows(general, by_wd, slot, off):
    wins = ALL_DAY if general else STD_SHIFTS
    return [{"branch_id": by_wd[wd], "weekday": wd, "start_min": s, "end_min": e, "slot_min": slot}
            for wd in range(7) if general or wd not in off for s, e in wins]


def _wins_text(wins):
    return " و".join("%s–%s" % (sd.hhmm(s), sd.hhmm(e)) for s, e in wins)


def cmd_sched_standard(a, app):
    """يضبط دوام كل الأطباء النشطين: شفتان يومياً، والطبيب العام 24 ساعة. معاينة فقط ما لم تُضَف --yes (ومعها نسخة احتياطية تلقائية قبل أي تغيير).
    المواعيد المحجوزة لا تُمسّ ولا تُلغى."""
    db = app.db
    if a.slot not in sd.SLOT_CHOICES:
        print("مدة الموعد غير صحيحة. الخيارات: " + "، ".join(str(x) for x in sd.SLOT_CHOICES))
        return 1
    try:
        off = _off_days(a.off)
    except ValueError as ex:
        print("يوم غير مفهوم: %s (اكتب مثلاً: الجمعة أو 5)" % ex)
        return 1
    brs = db.list_entities("branches")
    branches = [b["id"] for b in brs]
    names = {b["id"]: (b.get("shortName") or b["name"]) for b in brs}
    if not branches:
        print("لا توجد فروع مفعّلة.")
        return 1
    default_br = a.branch or branches[0]
    if default_br not in branches:
        print("فرع غير معروف: %s. المتاح: %s" % (default_br, "، ".join(branches)))
        return 1
    general = {x["id"] for x in db.list_entities("specialties", include_inactive=True)
               if x["id"] == "general" or sd.norm_ar(x.get("name")) == sd.norm_ar("الطب العام")}
    plan, skipped = [], []
    today = sd.riyadh_now().date().isoformat()
    for doc in db.list_entities("doctors"):
        old_rows, old_days = db.sched_get(doc["id"])
        if old_rows and a.skip_existing:
            skipped.append(doc)
            continue
        gp = bool(set(doc.get("specialtyIds") or []) & general)
        rows = _std_rows(gp, _branch_by_weekday(doc, old_rows, default_br, branches), a.slot, off)
        plan.append({"doc": doc, "gp": gp, "rows": rows, "days": old_days, "had": bool(old_rows)})
    if not plan:
        print("لا يوجد أطباء لضبط دوامهم.")
        return 0
    gps = [p for p in plan if p["gp"]]
    std = [p for p in plan if not p["gp"]]
    replaced = [p for p in plan if p["had"]]
    booked = 0
    for p in plan:
        booked += db.conn().execute("SELECT COUNT(*) FROM bookings WHERE doctor_id=? AND slot_start IS NOT NULL AND date>=? AND status IN " + sd.ACTIVE_STATUS,
                                    (p["doc"]["id"], today)).fetchone()[0]
    per_branch = {}
    for p in plan:
        per_branch[p["rows"][0]["branch_id"]] = per_branch.get(p["rows"][0]["branch_id"], 0) + 1
    if not a.yes:
        print("معاينة فقط — لم يتغير شيء في بياناتك.")
    print("أطباء سيُضبط دوامهم: %d" % len(plan))
    if gps:
        print("• الطبيب العام (%d): %s كل يوم" % (len(gps), _wins_text(ALL_DAY)))
    if std:
        print("• بقية الأطباء (%d): %s%s" % (len(std), _wins_text(STD_SHIFTS), (" ما عدا " + "، ".join(sd.AR_WEEKDAYS[d] for d in sorted(off))) if off else " كل يوم"))
    print("• مدة الموعد: %d دقيقة" % a.slot)
    print("• الفرع: " + "، ".join("%s (%d طبيباً)" % (names.get(b, b), n) for b, n in per_branch.items()))
    if replaced:
        print("• يستبدل جدولاً موجوداً لدى %d: %s" % (len(replaced), "، ".join(p["doc"]["name"] for p in replaced[:8]) + (" …" if len(replaced) > 8 else "")))
    if skipped:
        print("• تُركوا كما هم (لهم جدول): %d" % len(skipped))
    print("• مواعيد محجوزة قادمة بموعد محدد: %d (لا يُلغى منها شيء)" % booked)
    if a.list:
        for p in plan:
            print("  - %s: %s، %s" % (p["doc"]["name"], "عام 24 ساعة" if p["gp"] else "شفتان", names.get(p["rows"][0]["branch_id"], "")))
    if not a.yes:
        print("لتطبيقه (تؤخذ نسخة احتياطية تلقائياً قبل التغيير): أعد الأمر وأضف --yes")
        return 0
    dest = app.cfg.db_path.parent / "backups" / ("before-hours-%s.db" % time.strftime("%Y%m%d-%H%M%S"))
    old_umask = os.umask(0o077)       # النسخة فيها بيانات مراجعين: لصاحبها فقط (والمجلد كذلك إن أُنشئ الآن)
    try:
        path = db.backup_to(dest)
        ok = Path(path).exists() and Path(path).stat().st_size > 0
    except Exception as ex:      # noqa: BLE001 — أي فشل في النسخ يوقف العملية قبل أي تغيير
        print("فشل أخذ النسخة الاحتياطية (%s). لم يتغير شيء." % type(ex).__name__)
        return 1
    finally:
        os.umask(old_umask)
    if not ok:
        print("النسخة الاحتياطية فارغة. لم يتغير شيء.")
        return 1
    db.sched_replace_many([(p["doc"]["id"], p["rows"], p["days"]) for p in plan])
    db.audit("cli", "sched-standard", "schedules", "", "doctors=%d general=%d slot=%d off=%s" % (len(plan), len(gps), a.slot, ",".join(str(d) for d in sorted(off))))
    print("تم ضبط الدوام لـ %d طبيباً." % len(plan))
    print("نسخة احتياطية قبل التغيير: " + path)
    outside = {}
    for p in plan:
        o = db.sched_outside(p["doc"]["id"])
        if o:
            outside[p["doc"]["name"]] = len(o)
    if outside:
        print("تنبيه: مواعيد محجوزة صارت خارج الدوام الجديد (لم يُلغَ منها شيء، تواصل مع أصحابها):")
        for n, c in outside.items():
            print("  - %s: %d" % (n, c))
    return 0


def main():
    ap = argparse.ArgumentParser(description="إدارة تطبيق دار السلام")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("init", help="إنشاء قاعدة البيانات وكلمة مرور الإدارة")
    p.add_argument("--password")
    p.add_argument("--reset", action="store_true")
    p.set_defaults(fn=cmd_init)
    p = sub.add_parser("set-password")
    p.add_argument("--password")
    p.set_defaults(fn=cmd_set_password)
    p = sub.add_parser("backup")
    p.add_argument("--out")
    p.set_defaults(fn=cmd_backup)
    p = sub.add_parser("export")
    p.add_argument("out")
    p.set_defaults(fn=cmd_export)
    p = sub.add_parser("import")
    p.add_argument("file")
    p.add_argument("--yes", action="store_true")
    p.set_defaults(fn=cmd_import)
    p = sub.add_parser("stats")
    p.set_defaults(fn=cmd_stats)
    p = sub.add_parser("sched-standard", help="ضبط دوام الأطباء: شفتان يومياً والطبيب العام 24 ساعة (معاينة ثم --yes)")
    p.add_argument("--yes", action="store_true", help="تطبيق التغيير (مع نسخة احتياطية تلقائية قبله)")
    p.add_argument("--slot", type=int, default=30, help="مدة الموعد بالدقائق (الافتراضي 30)")
    p.add_argument("--branch", help="فرع من لم يُحدَّد له فرع (الافتراضي: أول فرع)")
    p.add_argument("--off", default="", help="أيام إجازة لغير الطبيب العام، مثل: الجمعة")
    p.add_argument("--skip-existing", action="store_true", help="اترك من لديه جدول ساعات حالياً كما هو")
    p.add_argument("--list", action="store_true", help="اعرض كل طبيب")
    p.set_defaults(fn=cmd_sched_standard)
    a = ap.parse_args()
    return a.fn(a, appmod.App())


if __name__ == "__main__":
    sys.exit(main())
