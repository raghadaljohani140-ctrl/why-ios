/* بوابة الموظفين — دار السلام (الاستقبال، والطبيب عبر doctor.js). واجهة فقط: كل التحقق من الصلاحيات والنطاق يتم في الخادم (/api/staff).
   التوكن في sessionStorage (يزول بإغلاق التبويب) لأن أجهزة الاستقبال مشتركة. */
(function () {
  'use strict';
  var API = '/api/staff';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var S = { token: '', user: null, lk: null, tab: 'board', timer: null, visits: [], branch: '', ci: { rec: null, booking: null }, bookings: [] };
  var F = {}; // معالجات الأزرار (data-a) والنماذج (data-f)

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function ls(k, v) { try { if (v === undefined) return sessionStorage.getItem(k) || ''; if (v === null) sessionStorage.removeItem(k); else sessionStorage.setItem(k, v); } catch (e) { /* تجاهل */ } return ''; }
  var toastT;
  function toast(msg, bad) { var t = $('#toast'); t.textContent = msg; t.className = 'toast on' + (bad ? ' bad' : ''); clearTimeout(toastT); toastT = setTimeout(function () { t.className = 'toast'; }, 3400); }
  function hm(iso) { try { return new Date(iso).toLocaleTimeString('ar-SA-u-nu-latn', { timeZone: 'Asia/Riyadh', hour: '2-digit', minute: '2-digit' }); } catch (e) { return ''; } }
  function dt(iso) { try { return new Date(iso).toLocaleString('ar-SA-u-nu-latn-ca-gregory', { timeZone: 'Asia/Riyadh', day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }); } catch (e) { return iso || ''; } }
  function mins(iso) { return Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60000)); }
  function can(p) { if (!S.user) return false; if (Array.isArray(p)) return p.some(can); return S.user.perms.indexOf(p) >= 0; } // p نص أو قائمة (يكفي واحد منها)
  function debounce(fn, ms) { var t; return function () { clearTimeout(t); t = setTimeout(fn, ms); }; }
  function localPhone(p) { return String(p || '').indexOf('966') === 0 ? '0' + String(p).slice(3) : String(p || ''); }

  /* ---------- الاتصال بالخادم ---------- */
  function api(method, path, body) {
    var h = { 'Accept': 'application/json' };
    if (body !== undefined) h['Content-Type'] = 'application/json';
    if (S.token) h['Authorization'] = 'Bearer ' + S.token;
    return fetch(API + path, { method: method, headers: h, body: body === undefined ? undefined : JSON.stringify(body), cache: 'no-store' }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (!r.ok) {
          var e = new Error(j.message || ('HTTP ' + r.status)); e.status = r.status; e.code = j.error; e.data = j;
          if (r.status === 401 && j.error === 'unauthorized' && S.token) { logout('انتهت الجلسة، سجّل الدخول من جديد'); }
          if (r.status === 403 && j.error === 'must_change') { pwScreen(true); }
          throw e;
        }
        return j;
      });
    }, function () { throw new Error('تعذر الاتصال بالخادم'); });
  }
  function logout(msg) {
    S.token = ''; S.user = null; ls('ds.staff.token', null); clearInterval(S.timer); closeModal();
    loginScreen(msg);
  }

  /* ---------- نافذة منبثقة ---------- */
  function openModal(title, html) {
    closeModal();
    var d = document.createElement('div'); d.className = 'modal-bg'; d.id = 'modal';
    d.innerHTML = '<div class="modal" role="dialog" aria-modal="true" aria-label="' + esc(title) + '"><div class="head"><h2>' + esc(title) + '</h2><button class="x" data-a="modal-close" aria-label="إغلاق">×</button></div>' + html + '</div>';
    document.body.appendChild(d);
    d.addEventListener('mousedown', function (e) { if (e.target === d) closeModal(); });
    var f = $('input,select,textarea', d); if (f) f.focus();
    return d;
  }
  function closeModal() { var d = $('#modal'); if (d) d.remove(); }
  function fieldErr(e) { return (e.data && e.data.fields && Object.keys(e.data.fields).map(function (k) { return e.data.fields[k]; }).join(' · ')) || e.message; }

  /* ---------- الدخول وكلمة المرور ---------- */
  function loginScreen(msg) {
    $('#root').innerHTML = '<div class="login"><img src="/app/img/logo.svg" alt="دار السلام الطبية"><h1>بوابة الموظفين</h1><p class="muted sm">سجّل الدخول بحسابك الخاص</p>' +
      '<form data-f="login"><div class="fld"><label for="lg-user">اسم المستخدم</label><input class="in ltr" id="lg-user" autocomplete="username" autocapitalize="none" spellcheck="false"></div>' +
      '<div class="fld"><label for="lg-pw">كلمة المرور</label><input class="in ltr" id="lg-pw" type="password" autocomplete="current-password"></div>' +
      '<div class="alert danger sm" id="lg-err" role="alert"' + (msg ? '' : ' hidden') + '>' + esc(msg || '') + '</div><button class="btn pri" type="submit">دخول</button></form></div>';
  }
  F.login = function () {
    var err = $('#lg-err'); err.hidden = true;
    api('POST', '/login', { username: $('#lg-user').value, password: $('#lg-pw').value }).then(function (r) {
      S.token = r.token; ls('ds.staff.token', r.token); S.user = r.user;
      if (r.user.mustChange) pwScreen(true); else start();
    }).catch(function (e) { err.textContent = e.message; err.hidden = false; });
  };
  function pwScreen(forced) {
    var el = $('#root');
    el.innerHTML = '<div class="login"><img src="/app/img/logo.svg" alt="دار السلام الطبية"><h1>' + (forced ? 'غيّر كلمة المرور المؤقتة' : 'تغيير كلمة المرور') + '</h1>' +
      '<form data-f="pw" data-forced="' + (forced ? '1' : '') + '"><div class="fld"><label for="pw-old">كلمة المرور الحالية</label><input class="in ltr" id="pw-old" type="password" autocomplete="current-password"></div>' +
      '<div class="fld"><label for="pw-new">الجديدة (10 أحرف على الأقل)</label><input class="in ltr" id="pw-new" type="password" autocomplete="new-password"></div>' +
      '<div class="alert danger sm" id="pw-err" role="alert" hidden></div><button class="btn pri" type="submit">حفظ</button>' + (forced ? '' : ' <button class="btn ghost" type="button" data-a="pw-cancel">رجوع</button>') + '</form></div>';
  }
  F.pw = function () {
    var err = $('#pw-err'); err.hidden = true;
    api('POST', '/password', { old: $('#pw-old').value, new: $('#pw-new').value }).then(function (r) {
      S.token = r.token; ls('ds.staff.token', r.token); S.user = r.user; toast('تم تغيير كلمة المرور'); start();
    }).catch(function (e) { err.textContent = e.message; err.hidden = false; });
  };

  /* ---------- الهيكل ---------- */
  var TABS = [['clinic', 'عيادتي', 'clinical.read'], ['results', 'النتائج', 'results.review'], ['unit', 'الطلبات', ['unit.lab', 'unit.radiology']], ['board', 'اللوحة', 'visits.read'], ['checkin', 'تسجيل وصول', 'visits.create'], ['bookings', 'الحجوزات', 'bookings.read'], ['patients', 'المراجعون', 'records.read'], ['audit', 'التدقيق', 'audit.read']];
  var VIEWS = {}, POLLS = {}; // يملؤها كل ملف: العرض الرئيسي للتبويب، ودالة تحديث دورية اختيارية
  function start() {
    Promise.all([api('GET', '/me'), api('GET', '/lookups')]).then(function (r) {
      S.user = r[0].user; S.lk = r[1];
      if (S.user.mustChange) return pwScreen(true);
      var br = S.lk.branches.filter(function (b) { return b.id === S.user.branchId; })[0];
      $('#root').innerHTML = '<div class="top"><img src="/app/img/mark-white.svg" alt="" width="38" height="30"><div class="who"><b>' + esc(S.user.name) + '</b>' + esc(S.user.roleLabel) + ' · ' + esc(br ? br.name : 'كل الفروع') + '</div>' +
        '<button class="btn sm" data-a="pw-open">كلمة المرور</button><button class="btn sm" data-a="logout">خروج</button></div>' +
        '<nav class="tabs" id="tabs">' + TABS.filter(tabOk).map(function (t) { return '<a href="#/' + t[0] + '" data-t="' + t[0] + '">' + t[1] + '</a>'; }).join('') + '</nav>' +
        '<main class="wrap" id="view"></main>';
      clearInterval(S.timer); S.timer = setInterval(function () { if (!document.hidden && !$('#modal') && POLLS[S.tab]) POLLS[S.tab](); }, 15000);
      route();
    }).catch(function (e) { if (e.status !== 401 && e.code !== 'must_change') { loginScreen(e.message); } });
  }
  function route() {
    var t = (location.hash || '#/board').slice(2).split('/')[0], ok = TABS.filter(function (x) { return x[0] === t && tabOk(x); })[0];
    if (!ok) { var first = TABS.filter(tabOk)[0]; if (!first) { $('#view').innerHTML = '<div class="card">لا توجد أدوات متاحة لدورك في هذه المرحلة.</div>'; return; } t = first[0]; }
    S.tab = t;
    Array.prototype.forEach.call(document.querySelectorAll('#tabs a'), function (a) { a.classList.toggle('on', a.getAttribute('data-t') === t); });
    VIEWS[t]();
  }
  window.addEventListener('hashchange', function () { if (S.user) route(); });
  VIEWS.board = boardView; VIEWS.checkin = checkinView; VIEWS.bookings = bookingsView; VIEWS.patients = patientsView; VIEWS.audit = auditView; POLLS.board = function () { loadBoard(); };
  function tabOk(t) { return can(t[2]) && !!VIEWS[t[0]]; }

  function docName(id) { var d = S.lk.doctors.filter(function (x) { return x.id === id; })[0]; return d ? d.name : id; }
  function brName(id) { var b = S.lk.branches.filter(function (x) { return x.id === id; })[0]; return b ? b.name : (id || ''); }
  function docOpts(sel, branchId, exclude) {
    return '<option value="">اختر الطبيب</option>' + S.lk.doctors.filter(function (d) { return d.id !== exclude && (!branchId || !d.branchIds.length || d.branchIds.indexOf(branchId) >= 0); }).map(function (d) {
      return '<option value="' + esc(d.id) + '"' + (d.id === sel ? ' selected' : '') + '>' + esc(d.name) + (d.specialties.length ? ' — ' + esc(d.specialties.join('، ')) : '') + '</option>'; }).join('');
  }

  /* ---------- اللوحة: طوابير الأطباء ---------- */
  function boardView() {
    $('#view').innerHTML = '<div class="tools"><h1 style="font-size:1.2rem;flex:1">لوحة اليوم</h1>' +
      (S.user.branchId ? '' : '<select class="in" id="bd-branch" style="max-width:220px"><option value="">كل الفروع</option>' + S.lk.branches.map(function (b) { return '<option value="' + esc(b.id) + '"' + (b.id === S.branch ? ' selected' : '') + '>' + esc(b.name) + '</option>'; }).join('') + '</select>') +
      '<button class="btn ghost sm" data-a="bd-refresh">تحديث</button></div><div id="bd-sum"></div><div id="bd-box"><p class="muted">جارٍ التحميل…</p></div>';
    loadBoard(false);
  }
  function loadBoard() {
    api('GET', '/visits' + (S.branch ? '?branch=' + encodeURIComponent(S.branch) : '')).then(function (r) {
      S.visits = r.visits; renderBoard();
    }).catch(function (e) { var b = $('#bd-box'); if (b && e.status !== 401) b.innerHTML = '<div class="alert danger">' + esc(e.message) + '</div>'; });
  }
  function actionsFor(v) {
    var b = '';
    var btn = function (st, label, cls) { return '<button class="btn ' + (cls || 'ghost') + ' sm" data-a="vs" data-id="' + v.id + '" data-st="' + st + '">' + label + '</button>'; };
    if (v.status === 'waiting' && can('visits.advance')) b += btn('ready', 'جاهز للطبيب');
    if ((v.status === 'waiting' || v.status === 'ready') && can('visits.advance')) b += btn('with_doctor', 'عند الطبيب', 'pri');
    if (v.status === 'with_doctor' && can('visits.advance')) b += (v.doctorWriting ? '' : btn('done', 'انتهت الزيارة', 'pri')) + btn('ready', 'رجوع للانتظار');
    if (v.status === 'done' && v.hasSummary && can('visits.summary')) b += '<button class="btn pri sm" data-a="vprint" data-id="' + v.id + '">طباعة الوصفة والتعليمات</button>';
    if (v.status === 'done' && can('visits.checkout')) b += btn('left', 'غادر المراجع', v.hasSummary ? 'ghost' : 'pri');
    if ((v.status === 'waiting' || v.status === 'ready') && can('visits.transfer')) b += '<button class="btn ghost sm" data-a="vt" data-id="' + v.id + '" data-doc="' + esc(v.doctorId) + '">تحويل</button>';
    if ((v.status === 'waiting' || v.status === 'ready') && can('visits.cancel')) b += btn('cancelled', 'إلغاء', 'dangero');
    return b;
  }
  /* حالة طلبات التحليل والأشعة للزيارة كما تصل من الخادم (orderStat): تساعد الاستقبال يعرف هل ينتظر المراجع نتائجه أم أنها اكتملت */
  function ordersChips(v) {
    var o = v.orderStat;
    if (!o || !o.total) return v.orderCount ? '<span class="chip rx">طلبات ' + v.orderCount + '</span>' : ''; // زيارات قديمة: طلبات بلا متابعة حالة
    var c = '';
    if (o.open) c += '<span class="chip waiting">طلبات عند الأقسام (' + o.open + ')</span>';
    if (o.await) c += '<span class="chip ready">نتائج عند الطبيب (' + o.await + ')</span>';
    if (!o.open && !o.await) c += o.done ? '<span class="chip with_doctor">اكتملت الطلبات</span>' : '<span class="chip cancelled">طلبات ملغاة</span>';
    return ' ' + c;
  }
  function renderBoard() {
    var sum = $('#bd-sum'), box = $('#bd-box'); if (!box) return;
    var c = { waiting: 0, ready: 0, with_doctor: 0, done: 0, left: 0 };
    S.visits.forEach(function (v) { if (c[v.status] != null) c[v.status]++; });
    sum.innerHTML = '<div class="sumbar"><div><b>' + c.waiting + '</b>ينتظر</div><div><b>' + c.ready + '</b>جاهز للطبيب</div><div><b>' + c.with_doctor + '</b>عند الطبيب</div><div><b>' + c.done + '</b>بانتظار التسليم</div><div><b>' + c.left + '</b>غادروا</div></div>';
    if (!S.visits.length) { box.innerHTML = '<div class="card muted">لا زيارات مسجّلة اليوم بعد. سجّل وصول أول مراجع من تبويب «تسجيل وصول».</div>'; return; }
    var by = {}, RANK = { with_doctor: 0, waiting: 1, ready: 1, done: 2, left: 3, cancelled: 3 };
    S.visits.forEach(function (v) { (by[v.doctorId] = by[v.doctorId] || []).push(v); });
    Object.keys(by).forEach(function (d) { by[d].sort(function (a, b) { return (RANK[a.status] - RANK[b.status]) || (a.queueNo - b.queueNo); }); });
    box.innerHTML = Object.keys(by).sort(function (a, b) { return by[a][0].doctorName.localeCompare(by[b][0].doctorName, 'ar'); }).map(function (d) {
      var list = by[d], live = list.filter(function (v) { return v.status === 'waiting' || v.status === 'ready' || v.status === 'with_doctor'; });
      return '<section class="dcard" data-doc="' + esc(d) + '"><h3><span>' + esc(list[0].doctorName) + '</span><span class="sm">' + live.length + ' في الطابور</span></h3>' + list.map(function (v) {
        var active = v.status === 'waiting' || v.status === 'ready';
        return '<div class="vrow ' + v.status + '" data-vid="' + v.id + '"><div class="no" title="رقم الطابور">' + v.queueNo + '</div><div><b>' + esc(v.patientName) + '</b> <span class="chip ' + v.status + '">' + esc(v.statusLabel) + '</span>' +
          (v.doctorWriting ? ' <span class="chip with_doctor">الطبيب يكتب</span>' : '') + (v.hasSummary ? ' <span class="chip rx">وصفة ' + v.rxCount + '</span>' + ordersChips(v) : '') +
          '<div class="xs muted"><span class="ltr">' + esc(v.mrn) + '</span> · وصل ' + hm(v.arrivedAt) + (v.apptTime ? ' · موعده ' + esc(v.apptTime) : '') + (active ? ' · ينتظر ' + mins(v.arrivedAt) + ' د' : '') + (v.status === 'left' && v.leftAt ? ' · غادر ' + hm(v.leftAt) : '') + (v.reason ? ' · ' + esc(v.reason) : '') + (!S.user.branchId && v.branchId ? ' · ' + esc(brName(v.branchId)) : '') + '</div></div>' +
          '<div class="acts">' + actionsFor(v) + '</div></div>'; }).join('') + '</section>';
    }).join('');
  }
  F.vs = function (el) {
    var st = el.getAttribute('data-st');
    if (st === 'cancelled' && !window.confirm('إلغاء هذه الزيارة؟')) return;
    if (st === 'left') {
      var vv = S.visits.filter(function (x) { return x.id === el.getAttribute('data-id'); })[0], os = vv && vv.orderStat;
      if (!window.confirm('تأكيد: المراجع غادر المجمع؟' + (os && os.open ? '\n\nتنبيه: له ' + os.open + ' طلب تحليل/أشعة لم يُنجز بعد في الأقسام. تأكد أنه لن ينتظر نتيجته.' : ''))) return;
    }
    api('POST', '/visits/' + el.getAttribute('data-id') + '/status', { status: st }).then(function () { loadBoard(); toast(st === 'left' ? 'تم تسجيل المغادرة' : 'تم تحديث الحالة'); }).catch(function (e) { toast(e.message, true); loadBoard(); });
  };
  F.vt = function (el) {
    var v = S.visits.filter(function (x) { return x.id === el.getAttribute('data-id'); })[0]; if (!v) return;
    openModal('تحويل ' + v.patientName, '<form data-f="transfer" data-id="' + v.id + '" class="form"><div class="fld"><label>إلى الطبيب</label><select class="in" id="tr-doc">' + docOpts('', v.branchId, v.doctorId) + '</select></div><div class="alert danger sm" id="tr-err" hidden></div><button class="btn pri" type="submit">تحويل (يدخل آخر الطابور)</button></form>');
  };
  F.transfer = function (f) {
    var err = $('#tr-err'); err.hidden = true;
    api('POST', '/visits/' + f.getAttribute('data-id') + '/transfer', { doctorId: $('#tr-doc').value }).then(function () { closeModal(); toast('تم التحويل'); loadBoard(); }).catch(function (e) { err.textContent = e.message; err.hidden = false; });
  };

  /* ---------- تسجيل وصول ---------- */
  function checkinView() {
    var c = S.ci;
    $('#view').innerHTML = '<h1 style="font-size:1.2rem;margin-bottom:10px">تسجيل وصول مراجع</h1>' +
      (c.booking ? '<div class="alert info sm">لحجز <b>' + esc(c.booking.id) + '</b> — ' + esc(c.booking.name) + ' <span class="ltr">' + esc(localPhone(c.booking.phone)) + '</span> <button class="btn sm ghost" data-a="ci-nobk">إزالة الربط</button></div>' : '') +
      (c.rec ? checkinForm() : '<div class="card"><div class="fld"><label for="ci-q">ابحث عن المراجع (الاسم أو الجوال أو رقم الملف)</label><input class="in" id="ci-q" autocomplete="off" value="' + esc(c.q || '') + '"></div><div id="ci-res" class="pick" style="margin-top:10px"></div>' +
        (can('records.write') ? '<div style="margin-top:12px"><button class="btn ghost" data-a="ci-new">+ مراجع جديد</button></div>' : '') + '</div>');
    if (!c.rec) { var q = $('#ci-q'); q.addEventListener('input', debounce(function () { c.q = q.value; searchRecs(q.value, '#ci-res', 'ci-pick'); }, 350)); if (c.q) searchRecs(c.q, '#ci-res', 'ci-pick', true); }
  }
  function searchRecs(q, sel, act, autopick) {
    var box = $(sel); if (!box) return;
    if (String(q).trim().length < 2) { box.innerHTML = ''; return; }
    api('GET', '/records?q=' + encodeURIComponent(q.trim())).then(function (r) {
      if (!$(sel)) return;
      if (autopick && r.records.length === 1 && S.ci.booking) { S.ci.rec = r.records[0]; S.ci.q = ''; checkinView(); return; }
      box.innerHTML = r.records.length ? r.records.map(function (x) {
        return '<button type="button" data-a="' + act + '" data-mrn="' + esc(x.mrn) + '"><b>' + esc(x.name) + '</b><span class="xs muted"><span class="ltr">' + esc(x.mrn) + '</span> · <span class="ltr">' + esc(localPhone(x.phone)) + '</span>' + (x.birthDate ? ' · ' + esc(x.birthDate) : '') + '</span></button>'; }).join('')
        : '<p class="muted sm">لا نتائج.' + (can('records.write') ? ' سجّله كمراجع جديد.' : '') + '</p>';
      box._recs = r.records;
    }).catch(function (e) { box.innerHTML = '<div class="alert danger sm">' + esc(e.message) + '</div>'; });
  }
  F['ci-pick'] = function (el) {
    var recs = ($('#ci-res') || {})._recs || [];
    S.ci.rec = recs.filter(function (x) { return x.mrn === el.getAttribute('data-mrn'); })[0] || null; checkinView();
  };
  F['ci-nobk'] = function () { S.ci.booking = null; checkinView(); };
  F['ci-reset'] = function () { S.ci = { rec: null, booking: null }; checkinView(); };
  function checkinForm() {
    var c = S.ci, r = c.rec, preDoc = c.booking && c.booking.doctorId || '', preBr = (c.booking && c.booking.branchId) || S.user.branchId || (S.lk.branches.length === 1 ? S.lk.branches[0].id : '');
    return '<div class="card"><div class="row" style="display:flex;justify-content:space-between;gap:8px;align-items:center"><div><b>' + esc(r.name) + '</b><div class="xs muted"><span class="ltr">' + esc(r.mrn) + '</span> · <span class="ltr">' + esc(localPhone(r.phone)) + '</span>' + (r.nationalIdMasked ? ' · هوية <span class="ltr">' + esc(r.nationalIdMasked) + '</span>' : '') + '</div></div><button class="btn sm ghost" data-a="ci-reset">تغيير المراجع</button></div></div>' +
      '<form class="card form" data-f="checkin" style="margin-top:10px">' +
      (S.user.branchId ? '' : '<div class="fld"><label for="ci-br">الفرع</label><select class="in" id="ci-br"><option value="">اختر الفرع</option>' + S.lk.branches.map(function (b) { return '<option value="' + esc(b.id) + '"' + (b.id === preBr ? ' selected' : '') + '>' + esc(b.name) + '</option>'; }).join('') + '</select></div>') +
      '<div class="fld"><label for="ci-doc">الطبيب</label><select class="in" id="ci-doc">' + docOpts(preDoc, S.user.branchId || preBr) + '</select></div>' +
      '<div class="fld"><label for="ci-reason">سبب الزيارة (اختياري)</label><input class="in" id="ci-reason" maxlength="200"></div>' +
      '<div class="alert danger sm" id="ci-err" role="alert" hidden></div><button class="btn pri" type="submit">تسجيل الوصول</button></form>';
  }
  F.checkin = function () {
    var err = $('#ci-err'); err.hidden = true;
    api('POST', '/visits', { mrn: S.ci.rec.mrn, doctorId: $('#ci-doc').value, branchId: $('#ci-br') ? $('#ci-br').value : '', reason: $('#ci-reason').value, bookingId: S.ci.booking ? S.ci.booking.id : '' }).then(function (r) {
      toast('تم تسجيل الوصول — رقم الطابور ' + r.visit.queueNo + ' عند ' + r.visit.doctorName); S.ci = { rec: null, booking: null }; location.hash = '#/board';
    }).catch(function (e) { err.textContent = e.message; err.hidden = false; });
  };
  document.addEventListener('change', function (ev) {
    if (ev.target && ev.target.id === 'ci-br') { var d = $('#ci-doc'); if (d) d.innerHTML = docOpts('', ev.target.value); }
    if (ev.target && ev.target.id === 'bd-branch') { S.branch = ev.target.value; loadBoard(); }
  });

  /* ---------- تسجيل/تعديل مراجع ---------- */
  function recForm(r, force) {
    r = r || {};
    return '<form data-f="recsave" class="form"><input type="hidden" id="rf-mrn" value="' + esc(r.mrn || '') + '">' +
      '<div class="fld"><label for="rf-name">الاسم الكامل</label><input class="in" id="rf-name" maxlength="80" value="' + esc(r.name || '') + '"></div>' +
      '<div class="two"><div class="fld"><label for="rf-phone">الجوال</label><input class="in ltr" id="rf-phone" type="tel" placeholder="05xxxxxxxx" value="' + esc(localPhone(r.phone || '')) + '"></div>' +
      '<div class="fld"><label for="rf-nid">الهوية / الإقامة</label><input class="in ltr" id="rf-nid" inputmode="numeric" maxlength="10" placeholder="' + esc(r.nationalIdMasked || '') + '"></div></div>' +
      '<div class="two"><div class="fld"><label for="rf-bd">تاريخ الميلاد</label><input class="in ltr" id="rf-bd" type="date" value="' + esc(r.birthDate || '') + '"></div>' +
      '<div class="fld"><label for="rf-g">الجنس</label><select class="in" id="rf-g"><option value="">—</option><option value="male"' + (r.gender === 'male' ? ' selected' : '') + '>ذكر</option><option value="female"' + (r.gender === 'female' ? ' selected' : '') + '>أنثى</option></select></div></div>' +
      '<p class="help">يلزم الهوية أو تاريخ الميلاد على الأقل.' + (r.mrn ? ' (اترك الهوية فارغة للإبقاء على المسجّلة.)' : '') + '</p>' +
      '<div id="rf-dup"></div><div class="alert danger sm" id="rf-err" role="alert" hidden></div><button class="btn pri" type="submit">' + (r.mrn ? 'حفظ التعديل' : 'تسجيل المراجع') + '</button></form>';
  }
  F['ci-new'] = function () {
    var b = S.ci.booking; openModal('مراجع جديد', recForm(b ? { name: b.name, phone: b.phone } : {}));
  };
  F.recsave = function (f, force) {
    var err = $('#rf-err'); err.hidden = true; $('#rf-dup').innerHTML = '';
    var body = { mrn: $('#rf-mrn').value, name: $('#rf-name').value, phone: $('#rf-phone').value, nationalId: $('#rf-nid').value, birthDate: $('#rf-bd').value, gender: $('#rf-g').value };
    if (force === true) body.force = true;
    api('POST', '/records', body).then(function (r) {
      closeModal(); toast(r.state === 'new' ? 'تم التسجيل — رقم الملف ' + r.record.mrn : 'تم حفظ التعديل');
      if (S.tab === 'checkin') { S.ci.rec = r.record; checkinView(); } else if (S.tab === 'patients') patientsView();
    }).catch(function (e) {
      if (e.code === 'duplicate') {
        $('#rf-dup').innerHTML = '<div class="alert warn sm"><b>يوجد مراجع بنفس الاسم والجوال:</b> ' + e.data.existing.map(function (x) { return '<button type="button" class="btn sm ghost" data-a="rf-use" data-rec="' + esc(JSON.stringify(x)) + '">استخدم ' + esc(x.mrn) + '</button>'; }).join(' ') + ' <button type="button" class="btn sm dangero" data-a="rf-force">سجّل كمراجع جديد رغم ذلك</button></div>';
      } else { err.textContent = e.message; err.hidden = false; }
    });
  };
  F['rf-force'] = function () { F.recsave($('form[data-f=recsave]'), true); };
  F['rf-use'] = function (el) {
    closeModal(); S.ci.rec = JSON.parse(el.getAttribute('data-rec'));
    if (S.tab === 'checkin') checkinView(); else location.hash = '#/checkin';
  };

  /* ---------- الحجوزات ---------- */
  function bookingsView() {
    $('#view').innerHTML = '<div class="tools"><h1 style="font-size:1.2rem;flex:1">طلبات الحجز</h1><button class="btn ghost sm" data-a="bk-refresh">تحديث</button></div><div id="bk-box"><p class="muted">جارٍ التحميل…</p></div>';
    loadBookings();
  }
  var PERIOD = { morning: 'صباحاً', evening: 'مساءً', any: 'أي وقت' };
  function todayRiyadh() { try { return new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Riyadh' }); } catch (e) { return new Date().toISOString().slice(0, 10); } }
  function loadBookings() {
    api('GET', '/bookings').then(function (r) {
      S.bookings = r.bookings; var box = $('#bk-box'); if (!box) return;
      var need = r.bookings.filter(function (b) { return b.status === 'new' || b.status === 'contacted'; }), today = todayRiyadh();
      /* المؤكدة: مواعيد التطبيق (بوقت محدد) أولاً بترتيب التاريخ ثم الوقت، ثم الطلبات المؤكدة يدوياً */
      var ok = r.bookings.filter(function (b) { return b.status === 'confirmed'; }).sort(function (a, b) {
        return ((a.slotStart < 0) - (b.slotStart < 0)) || String(a.date || '9999').localeCompare(String(b.date || '9999')) || (a.slotStart - b.slotStart);
      });
      var card = function (b) {
        return '<div class="bk"><div class="row"><b>' + esc(b.name) + '</b><span><span class="chip ' + (b.status === 'confirmed' ? 'with_doctor' : 'waiting') + '">' + (b.status === 'new' ? 'جديد' : b.status === 'contacted' ? 'تم التواصل' : 'مؤكد') + '</span>' + (b.visitId ? ' <span class="chip ready">وصل</span>' : '') + (b.status === 'confirmed' && b.date === today && b.slotLabel && !b.visitId ? ' <span class="chip ready">موعد اليوم</span>' : '') + (b.payStatus === 'pending' ? ' <span class="chip waiting">بانتظار الدفع</span>' : '') + '</span></div>' +
          '<div class="sm"><a class="ltr" href="tel:' + esc(b.phone) + '">' + esc(localPhone(b.phone)) + '</a> · ' + esc(b.id) + (b.slotLabel ? ' · الموعد <bdi class="nw">' + esc(b.date) + '</bdi> · <b>' + esc(b.slotLabel) + '</b>' : (b.date ? ' · الموعد المطلوب <bdi class="nw">' + esc(b.date) + '</bdi> ' + esc(PERIOD[b.period] || '') : '')) + '</div>' +
          '<div class="sm muted">' + (b.doctorId ? esc(docName(b.doctorId)) + ' · ' : '') + (b.branchId ? esc(brName(b.branchId)) : '') + (b.note ? ' · ' + esc(b.note) : '') + '</div>' + (b.appointmentText ? '<div class="sm"><b>الموعد المؤكد:</b> ' + esc(b.appointmentText) + '</div>' : '') +
          '<div class="row" style="justify-content:flex-start">' + (can('bookings.manage') && b.status !== 'confirmed' ? (b.payStatus === 'pending' ? '<button class="btn pri sm" data-a="bk-paid" data-id="' + b.id + '">تأكيد الموعد (دفع في الاستقبال)</button>' : '<button class="btn pri sm" data-a="bk-confirm" data-id="' + b.id + '">تأكيد الموعد</button>') : '') +
          (can('bookings.manage') && b.status === 'new' ? '<button class="btn ghost sm" data-a="bk-st" data-id="' + b.id + '" data-st="contacted">تم التواصل</button>' : '') +
          (can('visits.create') && !b.visitId ? '<button class="btn ghost sm" data-a="bk-arrive" data-id="' + b.id + '">تسجيل وصول</button>' : '') +
          (can('bookings.manage') ? '<button class="btn dangero sm" data-a="bk-st" data-id="' + b.id + '" data-st="cancelled">إلغاء</button>' : '') + '</div></div>';
      };
      box.innerHTML = '<h2 style="font-size:1.05rem;margin:6px 0">تحتاج تواصلاً (' + need.length + ')</h2>' + (need.map(card).join('') || '<div class="card muted">لا طلبات جديدة.</div>') +
        '<h2 style="font-size:1.05rem;margin:14px 0 6px">مؤكدة (' + ok.length + ')</h2>' + (ok.map(card).join('') || '<div class="card muted">لا مواعيد مؤكدة.</div>');
    }).catch(function (e) { var b = $('#bk-box'); if (b && e.status !== 401) b.innerHTML = '<div class="alert danger">' + esc(e.message) + '</div>'; });
  }
  function bk(id) { return S.bookings.filter(function (b) { return b.id === id; })[0]; }
  F['bk-st'] = function (el) {
    var st = el.getAttribute('data-st');
    if (st === 'cancelled' && !window.confirm('إلغاء طلب الحجز؟ سيصل المراجع إشعار.')) return;
    api('PATCH', '/bookings/' + el.getAttribute('data-id'), { status: st }).then(function () { toast('تم التحديث'); loadBookings(); }).catch(function (e) { toast(e.message, true); });
  };
  F['bk-paid'] = function (el) {
    var b = bk(el.getAttribute('data-id')); if (!b) return;
    if (!window.confirm('تأكيد موعد ' + b.name + ' (' + (b.slotLabel || '') + ') على أن المراجع دفع في الاستقبال؟')) return;
    api('PATCH', '/bookings/' + b.id, { status: 'confirmed' }).then(function () { toast('تم تأكيد الموعد'); loadBookings(); }).catch(function (e) { toast(e.message, true); loadBookings(); });
  };
  F['bk-confirm'] = function (el) {
    var b = bk(el.getAttribute('data-id')); if (!b) return;
    openModal('تأكيد موعد ' + b.name, '<form data-f="bkconfirm" data-id="' + b.id + '" class="form"><div class="fld"><label for="bc-t">تفاصيل الموعد (اليوم والوقت والطبيب) — تصل للمراجع كما هي</label><textarea class="in" id="bc-t" maxlength="200" rows="3">' + esc(b.appointmentText || '') + '</textarea></div><div class="alert danger sm" id="bc-err" hidden></div><button class="btn pri" type="submit">تأكيد وإشعار المراجع</button></form>');
  };
  F.bkconfirm = function (f) {
    var err = $('#bc-err'); err.hidden = true;
    api('PATCH', '/bookings/' + f.getAttribute('data-id'), { status: 'confirmed', appointmentText: $('#bc-t').value }).then(function () { closeModal(); toast('تم التأكيد'); loadBookings(); }).catch(function (e) { err.textContent = e.message; err.hidden = false; });
  };
  F['bk-arrive'] = function (el) {
    var b = bk(el.getAttribute('data-id')); if (!b) return;
    S.ci = { rec: null, booking: b, q: localPhone(b.phone) }; location.hash = '#/checkin';
  };

  /* ---------- المراجعون ---------- */
  function patientsView() {
    $('#view').innerHTML = '<div class="tools"><h1 style="font-size:1.2rem;flex:1">المراجعون</h1>' + (can('records.write') ? '<button class="btn pri sm" data-a="pt-new">+ مراجع جديد</button>' : '') + '</div>' +
      '<div class="card"><div class="fld"><label for="pt-q">بحث بالاسم أو الجوال أو رقم الملف</label><input class="in" id="pt-q" autocomplete="off"></div><div id="pt-res" class="pick" style="margin-top:10px"></div></div>';
    var q = $('#pt-q'); q.addEventListener('input', debounce(function () { searchRecs(q.value, '#pt-res', 'pt-open'); }, 350));
  }
  F['pt-new'] = function () { openModal('مراجع جديد', recForm({})); };
  F['pt-open'] = function (el) {
    var mrn = el.getAttribute('data-mrn');
    api('GET', '/records/' + encodeURIComponent(mrn)).then(function (r) {
      var x = r.record;
      openModal(x.name, '<div class="sm"><div>رقم الملف: <b class="ltr">' + esc(x.mrn) + '</b></div><div>الجوال: <span class="ltr">' + esc(localPhone(x.phone)) + '</span></div>' + (x.nationalIdMasked ? '<div>الهوية: <span class="ltr">' + esc(x.nationalIdMasked) + '</span></div>' : '') +
        (x.birthDate ? '<div>الميلاد: ' + esc(x.birthDate) + '</div>' : '') + '</div><h3 style="margin:12px 0 4px;font-size:1rem">آخر الزيارات</h3>' +
        (r.visits.length ? '<ul class="sm" style="margin:0;padding-inline-start:18px">' + r.visits.map(function (v) { return '<li>' + esc(v.day) + ' — ' + esc(v.doctorName) + ' — ' + esc(v.statusLabel) + '</li>'; }).join('') + '</ul>' : '<p class="muted sm">لا زيارات سابقة.</p>') +
        '<div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap">' + (can('visits.create') ? '<button class="btn pri sm" data-a="pt-arrive" data-rec="' + esc(JSON.stringify(x)) + '">تسجيل وصول</button>' : '') + (can('records.write') ? '<button class="btn ghost sm" data-a="pt-edit" data-rec="' + esc(JSON.stringify(x)) + '">تعديل البيانات</button>' : '') + '</div>');
    }).catch(function (e) { toast(e.message, true); });
  };
  F['pt-arrive'] = function (el) { closeModal(); S.ci = { rec: JSON.parse(el.getAttribute('data-rec')), booking: null }; location.hash = '#/checkin'; if (S.tab === 'checkin') checkinView(); };
  F['pt-edit'] = function (el) { var r = JSON.parse(el.getAttribute('data-rec')); openModal('تعديل ' + r.name, recForm(r)); };

  /* ---------- التدقيق (المشرف) ---------- */
  function auditView() {
    $('#view').innerHTML = '<h1 style="font-size:1.2rem;margin-bottom:10px">سجل التدقيق</h1><div id="au-box"><p class="muted">جارٍ التحميل…</p></div>';
    api('GET', '/audit?limit=150').then(function (r) {
      $('#au-box').innerHTML = '<table class="tbl stack"><thead><tr><th>الوقت</th><th>المنفّذ</th><th>العملية</th><th>المرجع</th></tr></thead><tbody>' + r.audit.map(function (a) {
        return '<tr><td data-l="الوقت">' + esc(dt(a.ts)) + '</td><td data-l="المنفّذ" class="ltr">' + esc(a.who) + '</td><td data-l="العملية" class="ltr">' + esc(a.action) + '</td><td data-l="المرجع" class="ltr">' + esc(a.ref || '') + '</td></tr>'; }).join('') + '</tbody></table>';
    }).catch(function (e) { $('#au-box').innerHTML = '<div class="alert danger">' + esc(e.message) + '</div>'; });
  }

  /* ---------- طباعة ملخص الزيارة (وصفة + تعليمات): نسخة تجريبية وليست وصفة رسمية ---------- */
  var GENDER = { male: 'ذكر', female: 'أنثى' };
  function printHtml(m) {
    var th = function (a) { return '<tr>' + a.map(function (x) { return '<th>' + x + '</th>'; }).join('') + '</tr>'; };
    var rx = m.rx.length ? '<table class="ptbl"><thead>' + th(['#', 'الدواء', 'الجرعة', 'التكرار', 'المدة', 'ملاحظة']) + '</thead><tbody>' + m.rx.map(function (r, i) {
      return '<tr><td>' + (i + 1) + '</td><td><b>' + esc(r.drug) + '</b></td><td>' + esc(r.dose) + '</td><td>' + esc(r.freq) + '</td><td>' + esc(r.duration) + '</td><td>' + esc(r.note) + '</td></tr>'; }).join('') + '</tbody></table>' : '<p class="muted">لا أدوية في هذه الزيارة.</p>';
    var od = m.orders.length ? '<ul>' + m.orders.map(function (o) { return '<li><b>' + (o.type === 'lab' ? 'تحليل' : 'أشعة') + ':</b> ' + esc(o.name) + (o.note ? ' — ' + esc(o.note) : '') + '</li>'; }).join('') + '</ul>' : '<p class="muted">لا طلبات تحاليل أو أشعة.</p>';
    return '<div class="pr-sheet"><div class="pr-mark">نسخة تجريبية — ليست وصفة رسمية</div>' +
      '<header><h1>' + esc(m.clinic) + '</h1><div>' + esc(m.branch) + '</div><div class="ltr">' + esc(m.day) + '</div></header>' +
      '<section class="pr-pt"><div><b>المراجع:</b> ' + esc(m.patient.name) + '</div><div><b>رقم الملف:</b> <span class="ltr">' + esc(m.patient.mrn) + '</span></div>' +
      '<div>' + (m.patient.age ? '<b>العمر:</b> ' + esc(m.patient.age) + ' ' : '') + (GENDER[m.patient.gender] ? '· ' + GENDER[m.patient.gender] : '') + '</div><div><b>الطبيب:</b> ' + esc(m.doctor) + '</div><div><b>رقم الطابور:</b> ' + esc(m.queueNo) + '</div></section>' +
      (m.diagnosis ? '<h2>التشخيص</h2><p>' + esc(m.diagnosis) + '</p>' : '') + '<h2>الأدوية</h2>' + rx + '<h2>التحاليل والأشعة المطلوبة</h2>' + od +
      (m.advice ? '<h2>تعليمات الطبيب</h2><p class="pre">' + esc(m.advice) + '</p>' : '') + (m.followUp ? '<h2>موعد المراجعة</h2><p>' + esc(m.followUp) + '</p>' : '') +
      '<footer>هذه نسخة تجريبية من منظومة المستوصف ولا تُعدّ وصفة رسمية. التزم بتعليمات طبيبك ولا تغيّر جرعة دون استشارته.</footer></div>';
  }
  function printSummary(vid) {
    return api('GET', '/visits/' + encodeURIComponent(vid) + '/summary').then(function (r) {
      var a = $('#print-area'); if (!a) { a = document.createElement('div'); a.id = 'print-area'; document.body.appendChild(a); }
      a.innerHTML = printHtml(r.summary);
      setTimeout(function () { window.print(); }, 80);
    }).catch(function (e) { toast(e.message, true); });
  }
  window.addEventListener('afterprint', function () { var a = $('#print-area'); if (a) a.innerHTML = ''; });
  F.vprint = function (el) { printSummary(el.getAttribute('data-id')); };

  /* ---------- عرض طلبات التحليل والأشعة ونتائجها (مشترك بين شاشات القسم والطبيب) ---------- */
  var ST_CHIP = { sent: 'waiting', in_progress: 'ready', resulted: 'with_doctor', reviewed: 'done', cancelled: 'cancelled' };
  var FLAG = { normal: 'طبيعي', high: 'مرتفع', low: 'منخفض', critical: 'حرج' };
  function stChip(o) { return '<span class="chip ' + (ST_CHIP[o.status] || '') + '">' + esc(o.statusLabel || o.status) + '</span>'; }
  function resultHtml(o) {
    var rows = o.rows || [], h = '';
    if (rows.length) {
      h += '<div class="scrollx"><table class="tbl rtbl"><thead><tr><th>الفحص</th><th>النتيجة</th><th>الوحدة</th><th>المعدل الطبيعي</th><th>التقييم</th></tr></thead><tbody>' + rows.map(function (r) {
        return '<tr class="fl-' + esc(r.flag || 'none') + '"><td><b>' + esc(r.name) + '</b></td><td class="ltr"><b>' + esc(r.value) + '</b></td><td class="ltr">' + esc(r.unit) + '</td><td class="ltr">' + esc(r.ref) + '</td><td>' + esc(FLAG[r.flag] || '') + '</td></tr>'; }).join('') + '</tbody></table></div>';
    }
    if (o.text) h += '<p class="sm pre rtxt">' + esc(o.text) + '</p>';
    return h || '<p class="muted sm">لم تُسجَّل نتيجة بعد.</p>';
  }

  /* ---------- توزيع الأحداث ---------- */
  F['modal-close'] = closeModal;
  F.logout = function () { logout(''); };
  F['pw-open'] = function () { pwScreen(false); };
  F['pw-cancel'] = function () { start(); };
  F['bd-refresh'] = function () { loadBoard(); };
  F['bk-refresh'] = function () { loadBookings(); };
  document.addEventListener('click', function (ev) {
    var el = ev.target.closest && ev.target.closest('[data-a]'); if (!el) return;
    var h = F[el.getAttribute('data-a')];
    if (h) { ev.preventDefault(); h(el); }
  });
  document.addEventListener('submit', function (ev) {
    var f = ev.target.closest && ev.target.closest('[data-f]'); if (!f) return;
    ev.preventDefault(); var k = f.getAttribute('data-f'); if (F[k]) F[k](f);
  });

  /* ---------- الإقلاع ---------- */
  /* واجهة داخلية لملفات الشاشات الإضافية (doctor.js) */
  window.DSX = { S: S, F: F, api: api, $: $, esc: esc, toast: toast, hm: hm, dt: dt, mins: mins, can: can, debounce: debounce, openModal: openModal, closeModal: closeModal, fieldErr: fieldErr,
    printSummary: printSummary, localPhone: localPhone, views: VIEWS, polls: POLLS, stChip: stChip, resultHtml: resultHtml, gender: GENDER };

  S.token = ls('ds.staff.token');
  function boot() { if (S.token) start(); else loginScreen(''); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot(); // بعد تحميل doctor.js
})();
