/* شاشات المختبر والأشعة في بوابة الموظفين: قائمة عمل القسم، بدء التنفيذ، إدخال النتيجة (صفوف للمختبر / تقرير للأشعة)،
   حفظ مسودة تلقائي، واعتماد النتيجة وإرسالها للطبيب.
   واجهة فقط: الخادم يحصر الحساب في طلبات قسمه وفرعه، ولا يُظهر له التشخيص ولا الوصفة ولا الملاحظات الداخلية للطبيب. يعتمد على window.DSX. */
(function () {
  'use strict';
  var X = window.DSX;
  if (!X) return;
  var F = X.F, api = X.api, $ = X.$, esc = X.esc, toast = X.toast, hm = X.hm;
  var U = { list: [], kind: '', label: '', today: '', q: '', cur: null, form: null, dirty: false, saving: null, again: false, timer: null };
  var FLAGS = [['', '—'], ['normal', 'طبيعي'], ['high', 'مرتفع'], ['low', 'منخفض'], ['critical', 'حرج']];
  var MAX_ROWS = 40;

  function find(id) { return U.list.filter(function (o) { return o.id === id; })[0]; }
  function who(o) { return [o.age, X.gender[o.gender]].filter(Boolean).map(esc).join(' · '); }
  function sec(title, inner, help) { return '<section class="card clsec"><h3>' + title + '</h3>' + inner + (help ? '<p class="help">' + help + '</p>' : '') + '</section>'; }
  function take(r) { U.list = r.orders; U.kind = r.unit; U.label = r.unitLabel; U.today = r.today; }

  /* ---------- قائمة العمل ---------- */
  function listView() {
    leave(); U.cur = null; U.form = null;
    $('#view').innerHTML = '<div class="tools"><h1 style="font-size:1.2rem;flex:1">الطلبات <span class="muted sm" id="un-label"></span></h1><button class="btn ghost sm" data-a="un-refresh">تحديث</button></div>' +
      '<div id="un-sum"></div><div class="fld"><input class="in" id="un-q" type="search" placeholder="ابحث باسم المراجع أو رقم الملف أو اسم الفحص" autocomplete="off" value="' + esc(U.q) + '"></div>' +
      '<div id="un-box"><p class="muted">جارٍ التحميل…</p></div>';
    var q = $('#un-q'); q.addEventListener('input', X.debounce(function () { U.q = q.value; renderList(); }, 200));
    loadList();
  }
  function loadList() {
    return api('GET', '/unit/orders').then(function (r) { take(r); if (!U.cur) renderList(); })
      .catch(function (e) { var b = $('#un-box'); if (b && e.status !== 401) b.innerHTML = '<div class="alert danger">' + esc(e.message) + '</div>'; });
  }
  function card(o) {
    var old = o.day && U.today && o.day !== U.today, acts, done = o.status === 'resulted' || o.status === 'reviewed';
    var dang = '<button class="btn dangero sm" data-a="un-cancel" data-id="' + o.id + '">تعذّر التنفيذ</button>';
    if (o.status === 'sent') acts = '<button class="btn pri sm" data-a="un-start" data-id="' + o.id + '">بدء التنفيذ</button>' + dang;
    else if (o.status === 'in_progress') acts = '<button class="btn pri sm" data-a="un-open" data-id="' + o.id + '">' + (o.kind === 'radiology' ? 'كتابة التقرير' : 'إدخال النتيجة') + '</button>' + dang;
    else if (o.status === 'resulted') acts = '<button class="btn ghost sm" data-a="un-open" data-id="' + o.id + '">عرض / تعديل النتيجة</button>';
    else acts = '<button class="btn ghost sm" data-a="un-open" data-id="' + o.id + '">عرض النتيجة</button>';
    return '<div class="ucard ' + o.status + '" data-oid="' + o.id + '"><span class="seq" title="رقم الطلب في قسمك اليوم">' + o.seq + '</span><div class="ubody"><div><b>' + esc(o.name) + '</b> ' + X.stChip(o) +
      (old ? ' <span class="chip left">من ' + esc(o.day) + '</span>' : '') + '</div>' +
      '<div class="sm"><b>' + esc(o.patientName) + '</b>' + (who(o) ? ' · ' + who(o) : '') + ' · <span class="ltr">' + esc(o.mrn) + '</span></div>' +
      '<div class="xs muted">الطبيب: ' + esc(o.doctorName) + ' · أُرسل ' + hm(o.sentAt) + (done && o.resultedAt ? ' · النتيجة ' + hm(o.resultedAt) : '') + '</div>' +
      (o.note ? '<div class="sm"><b>ملاحظة الطبيب:</b> ' + esc(o.note) + '</div>' : '') + '</div><div class="acts">' + acts + '</div></div>';
  }
  function renderList() {
    var box = $('#un-box'), sum = $('#un-sum'); if (!box || !sum) return;
    var lab = $('#un-label'); if (lab) lab.textContent = U.label ? '— ' + U.label : '';
    var n = { sent: 0, prog: 0, done: 0 };
    U.list.forEach(function (o) { if (o.status === 'sent') n.sent++; else if (o.status === 'in_progress') n.prog++; else n.done++; });
    sum.innerHTML = '<div class="sumbar three"><div><b>' + n.sent + '</b>بانتظار البدء</div><div><b>' + n.prog + '</b>قيد التنفيذ</div><div><b>' + n.done + '</b>أُنجزت اليوم</div></div>';
    var q = U.q.trim().toLowerCase();
    var vis = U.list.filter(function (o) { return !q || (o.patientName + ' ' + o.mrn + ' ' + o.name).toLowerCase().indexOf(q) >= 0; });
    var open = vis.filter(function (o) { return o.status === 'sent' || o.status === 'in_progress'; }), fin = vis.filter(function (o) { return o.status === 'resulted' || o.status === 'reviewed'; });
    box.innerHTML = '<h2 class="sech">قائمة العمل (' + open.length + ')</h2>' +
      (open.length ? open.map(card).join('') : '<div class="card muted">' + (q ? 'لا نتائج للبحث.' : 'لا طلبات بانتظارك الآن. تصل هنا الطلبات تلقائياً حين ينهي الطبيب زيارة مراجعه.') + '</div>') +
      '<h2 class="sech">أُنجزت اليوم (' + fin.length + ')</h2>' + (fin.length ? fin.map(card).join('') : '<div class="card muted">لا شيء بعد.</div>');
  }
  F['un-refresh'] = function () { loadList(); };
  F['un-open'] = function (el) { location.hash = '#/unit/' + el.getAttribute('data-id'); };
  F['un-back'] = function () {
    if (U.dirty && U.cur && !draftable() && !window.confirm('لديك تعديلات على النتيجة لم تُحفظ. تجاهلها والرجوع للقائمة؟')) return;
    if (!draftable()) U.dirty = false;
    location.hash = '#/unit';
  };
  F['un-start'] = function (el) {
    var id = el.getAttribute('data-id'); el.disabled = true;
    api('POST', '/unit/orders/' + id + '/start').then(function () { location.hash = '#/unit/' + id; }).catch(function (e) { toast(e.message, true); loadList(); });
  };
  F['un-cancel'] = function (el) {
    var o = find(el.getAttribute('data-id')) || U.cur; if (!o) return;
    X.openModal('تعذّر تنفيذ: ' + o.name, '<form data-f="un-cancel-do" data-id="' + esc(o.id) + '" class="form"><p class="sm">المراجع: <b>' + esc(o.patientName) + '</b>. سيُلغى الطلب، ويظهر للطبيب في تبويب «النتائج» أنه تعذّر مع السبب.</p>' +
      '<div class="fld"><label for="uc-r">السبب (يراه الطبيب)</label><textarea class="in" id="uc-r" maxlength="200" rows="3" placeholder="مثال: لم يحضر المراجع، أو العينة غير صالحة"></textarea></div>' +
      '<div class="alert danger sm" id="uc-err" hidden></div><button class="btn dangero" type="submit">إلغاء الطلب</button></form>');
  };
  F['un-cancel-do'] = function (f) {
    var err = $('#uc-err'); err.hidden = true;
    api('POST', '/unit/orders/' + f.getAttribute('data-id') + '/cancel', { reason: $('#uc-r').value }).then(function () {
      X.closeModal(); toast('أُلغي الطلب وسيراه الطبيب'); U.dirty = false;
      if (U.cur) location.hash = '#/unit'; else loadList();
    }).catch(function (e) { err.textContent = X.fieldErr(e); err.hidden = false; if (e.status === 409) loadList(); });
  };

  /* ---------- شاشة إدخال النتيجة ---------- */
  function editView(oid) {
    leave(); U.cur = null; U.form = null;
    $('#view').innerHTML = '<p class="muted">جارٍ التحميل…</p>';
    api('GET', '/unit/orders').then(function (r) {
      take(r);
      if (!$('#view') || location.hash.indexOf(oid) < 0) return;
      var o = find(oid);
      if (!o) { toast('الطلب غير موجود في قائمتك (ربما أُنجز في يوم سابق أو أُلغي)', true); location.hash = '#/unit'; return; }
      U.cur = o; U.form = formFrom(o); U.dirty = false; renderEditor();
    }).catch(function (e) { if ($('#view') && e.status !== 401) $('#view').innerHTML = '<div class="alert danger">' + esc(e.message) + '</div>'; });
  }
  function formFrom(o) {
    var rows = (o.rows || []).map(function (r) { return { name: r.name || '', value: r.value || '', unit: r.unit || '', ref: r.ref || '', flag: r.flag || '' }; });
    if (!rows.length && o.kind === 'lab') rows.push({ name: o.name, value: '', unit: '', ref: '', flag: '' }); // أول سطر باسم الفحص المطلوب: يكتب الفني النتيجة فقط
    return { rows: rows, text: o.text || '' };
  }
  function renderEditor() {
    var o = U.cur;
    var head = '<div class="tools"><button class="btn ghost sm" data-a="un-back">→ القائمة</button><span style="flex:1"></span><span id="un-chip">' + X.stChip(o) + '</span></div>' +
      '<div class="card ptcard"><span class="seq big">' + o.seq + '</span><div><h2>' + esc(o.name) + '</h2><div class="sm"><b>' + esc(o.patientName) + '</b>' + (who(o) ? ' · ' + who(o) : '') + ' · <span class="ltr">' + esc(o.mrn) + '</span></div>' +
      '<div class="xs muted">الطبيب: ' + esc(o.doctorName) + ' · أُرسل ' + esc(X.dt(o.sentAt)) + '</div>' + (o.note ? '<div class="sm"><b>ملاحظة الطبيب:</b> ' + esc(o.note) + '</div>' : '') + '</div></div>';
    var body, locked = o.status === 'reviewed' || o.status === 'cancelled';
    if (o.status === 'cancelled') body = '<div class="alert danger">أُلغي هذا الطلب' + (o.cancelReason ? ': ' + esc(o.cancelReason) : '') + '</div>';
    else if (o.status === 'reviewed') body = '<div class="alert ok">راجع الطبيب هذه النتيجة فأُقفلت ولا يمكن تعديلها من القسم.</div><section class="card"><h3>النتيجة</h3>' + X.resultHtml(o) + '</section>';
    else body = formHtml(o);
    $('#view').innerHTML = head + body;
    if (!locked) { renderRows(); setState(''); }
  }
  function formHtml(o) {
    var f = U.form, lab = o.kind === 'lab', re = o.status === 'resulted';
    return '<form class="clform" data-f="un-noop" autocomplete="off">' +
      (re ? '<div class="alert info sm">النتيجة مُرسلة للطبيب وبانتظار مراجعته. يمكنك تصحيحها إلى أن يراجعها، وبعدها تُقفل.</div>' : '') +
      '<div class="alert danger" id="un-err" role="alert" hidden></div>' +
      (lab ? sec('نتائج التحليل', '<div id="un-rows"></div>', 'سطر لكل فحص: اسم الفحص ونتيجته مطلوبان، والوحدة والمعدل الطبيعي والتقييم اختيارية وتظهر للطبيب والمراجع كما تكتبها.') +
          sec('ملاحظة المختبر (اختياري)', '<div class="fld"><textarea class="in" data-ut="1" maxlength="3000" rows="3" aria-label="ملاحظة المختبر">' + esc(f.text) + '</textarea></div>')
        : sec('تقرير الأشعة', '<div class="fld"><textarea class="in" data-ut="1" maxlength="3000" rows="9" aria-label="تقرير الأشعة" placeholder="الوصف والانطباع…">' + esc(f.text) + '</textarea></div>', 'التقرير نصي فقط في هذه النسخة؛ لا تُرفق صور الأشعة.')) +
      '<div class="clbar"><span id="un-state" class="sm muted" aria-live="polite"></span>' + (re ? '' : '<button class="btn ghost" type="button" data-a="un-save">حفظ مسودة</button>') +
      '<button class="btn pri" type="button" data-a="' + (re ? 'un-resave' : 'un-complete') + '">' + (re ? 'حفظ التعديل' : 'اعتماد وإرسال للطبيب') + '</button></div></form>';
  }
  function renderRows() {
    var box = $('#un-rows'); if (!box) return;
    var f = U.form;
    box.innerHTML = f.rows.map(function (r, i) {
      var a = function (k) { return 'data-ur="' + k + '" data-i="' + i + '"'; };
      var inp = function (label, k, max, ltr) { return '<label class="mini">' + label + '<input class="in' + (ltr ? ' ltr' : '') + '" ' + a(k) + ' maxlength="' + max + '" value="' + esc(r[k]) + '"></label>'; };
      return '<div class="rxrow"><div class="rxh"><b>سطر ' + (i + 1) + '</b><button type="button" class="btn ghost sm" data-a="un-row-del" data-i="' + i + '">حذف</button></div><div class="rgrid">' +
        inp('الفحص', 'name', 60) + inp('النتيجة', 'value', 60, true) + inp('الوحدة', 'unit', 20, true) + inp('المعدل الطبيعي', 'ref', 40, true) +
        '<label class="mini">التقييم<select class="in" ' + a('flag') + '>' + FLAGS.map(function (x) { return '<option value="' + x[0] + '"' + (r.flag === x[0] ? ' selected' : '') + '>' + x[1] + '</option>'; }).join('') + '</select></label></div></div>';
    }).join('') + (f.rows.length < MAX_ROWS ? '<button type="button" class="btn ghost sm" data-a="un-row-add">+ إضافة سطر</button>' : '<p class="help">وصلت الحد الأقصى (' + MAX_ROWS + ' سطراً).</p>');
  }
  F['un-row-add'] = function () { U.form.rows.push({ name: '', value: '', unit: '', ref: '', flag: '' }); renderRows(); var l = document.querySelectorAll('[data-ur=name]'); if (l.length) l[l.length - 1].focus(); };
  F['un-row-del'] = function (el) { U.form.rows.splice(+el.getAttribute('data-i'), 1); renderRows(); markDirty(); };
  F['un-noop'] = function () { /* لا إرسال بزر Enter */ };

  document.addEventListener('input', function (ev) {
    var t = ev.target; if (!U.cur || !U.form || !t || !t.getAttribute) return;
    var rk = t.getAttribute('data-ur'), i = +t.getAttribute('data-i');
    if (rk && U.form.rows[i]) U.form.rows[i][rk] = t.value; else if (t.getAttribute('data-ut')) U.form.text = t.value; else return;
    markDirty();
  });
  document.addEventListener('change', function (ev) {
    var t = ev.target; if (!U.cur || !U.form || !t || !t.getAttribute || t.getAttribute('data-ur') !== 'flag') return;
    var i = +t.getAttribute('data-i'); if (U.form.rows[i]) { U.form.rows[i].flag = t.value; markDirty(); }
  });

  /* ---------- الحفظ: مسودة تلقائية قبل الاعتماد؛ بعد إرسالها للطبيب يكون الحفظ بزر صريح حتى لا يرى الطبيب نتيجة نصف مكتوبة ---------- */
  function draftable() { return !!U.cur && (U.cur.status === 'sent' || U.cur.status === 'in_progress'); }
  function setState(msg, bad) { var s = $('#un-state'); if (s) { s.textContent = msg; s.className = 'sm ' + (bad ? 'bad' : 'muted'); } }
  function markDirty() {
    U.dirty = true;
    if (!draftable()) { setState('تعديلات لم تُحفظ بعد — اضغط «حفظ التعديل»'); return; }
    setState('تعديلات لم تُحفظ بعد…'); clearTimeout(U.timer); U.timer = setTimeout(saveNow, 1800);
  }
  function payload(full) {
    var t = function (s) { return String(s || '').trim(); };
    // أثناء الكتابة لا نرسل إلا الأسطر المكتملة (اسم + نتيجة) كي لا يرفضها الخادم؛ عند الاعتماد تُرسل كلها ويُبلَّغ الفني بالناقص
    var keep = function (r) { return full ? (t(r.name) || t(r.value) || t(r.unit) || t(r.ref)) : (t(r.name) && t(r.value)); };
    return { rows: U.form.rows.filter(keep).map(function (r) { return { name: r.name, value: r.value, unit: r.unit, ref: r.ref, flag: r.flag }; }), text: U.form.text };
  }
  function problems() {
    var o = U.cur, f = U.form, out = [], t = function (s) { return String(s || '').trim(); };
    f.rows.forEach(function (r, i) { var any = t(r.name) || t(r.value) || t(r.unit) || t(r.ref); if (any && (!t(r.name) || !t(r.value))) out.push('أكمل اسم الفحص ونتيجته في السطر ' + (i + 1)); });
    if (o.kind === 'lab' && !payload(true).rows.length && t(f.text).length < 2) out.push('أدخل نتيجة واحدة على الأقل');
    if (o.kind === 'radiology' && t(f.text).length < 2) out.push('اكتب تقرير الأشعة');
    return out;
  }
  function saveNow() {
    clearTimeout(U.timer);
    if (!U.cur || !U.form || !U.dirty || !draftable()) return Promise.resolve(true);
    if (U.saving) { U.again = true; return U.saving; }
    var oid = U.cur.id, body = payload(false);
    U.dirty = false; setState('جارٍ الحفظ…');
    U.saving = api('PUT', '/unit/orders/' + oid + '/result', body).then(function (r) {
      U.saving = null;
      if (U.cur && U.cur.id === oid) {
        U.cur.status = r.order.status; U.cur.statusLabel = r.order.statusLabel;
        var c = $('#un-chip'); if (c) c.innerHTML = X.stChip(U.cur);
        setState('تم حفظ المسودة ' + hm(new Date().toISOString()));
      }
      if (U.again) { U.again = false; if (U.dirty) return saveNow(); }
      return true;
    }).catch(function (e) {
      U.saving = null; U.again = false;
      if (U.cur && U.cur.id === oid) {
        if (e.code === 'locked' || e.code === 'bad_transition') { U.dirty = false; toast(e.message, true); editView(oid); }
        else { U.dirty = true; setState('تعذّر الحفظ: ' + X.fieldErr(e) + ' — نعيد المحاولة عند أي تعديل', true); }
      }
      return false;
    });
    return U.saving;
  }
  F['un-save'] = function () { U.dirty = true; saveNow().then(function (ok) { if (ok) toast('تم حفظ المسودة'); }); };
  function leave() { if (U.dirty && draftable()) saveNow(); clearTimeout(U.timer); }
  window.addEventListener('beforeunload', function (ev) { if (U.dirty && U.cur) { ev.preventDefault(); ev.returnValue = ''; } });
  document.addEventListener('visibilitychange', function () { if (document.hidden && U.dirty && draftable()) saveNow(); });

  /* ---------- الاعتماد والإرسال للطبيب ---------- */
  function showProblems() {
    var e = $('#un-err'), p = problems(); e.hidden = !p.length; e.textContent = p.join(' · ');
    if (p.length) e.scrollIntoView({ block: 'center' });
    return !p.length;
  }
  F['un-complete'] = function () {
    if (!showProblems()) return;
    var o = U.cur, n = payload(true).rows.length;
    X.openModal('اعتماد نتيجة ' + o.name, '<p class="sm"><b>المراجع:</b> ' + esc(o.patientName) + '<br>' + (o.kind === 'lab' ? n + ' سطر نتيجة' : 'تقرير نصي') + '</p>' +
      '<p class="sm">ستصل النتيجة إلى الطبيب (' + esc(o.doctorName) + ') ليراجعها، ولا تظهر للمراجع إلا بعد مراجعته ونشره لها. يمكنك تصحيحها إلى أن يراجعها.</p>' +
      '<div class="alert danger sm" id="un-fin-err" hidden></div><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn pri" data-a="un-complete-yes">اعتماد وإرسال</button><button class="btn ghost" data-a="modal-close">رجوع للتعديل</button></div>');
  };
  F['un-complete-yes'] = function (el) {
    el.disabled = true; var o = U.cur, box = $('#un-fin-err'); clearTimeout(U.timer);
    Promise.resolve(U.saving).then(function () { return api('POST', '/unit/orders/' + o.id + '/complete', payload(true)); }).then(function () {
      X.closeModal(); U.dirty = false; toast('أُرسلت النتيجة للطبيب'); location.hash = '#/unit';
    }).catch(function (e) { el.disabled = false; box.textContent = X.fieldErr(e); box.hidden = false; if (e.code === 'locked') { U.dirty = false; } });
  };
  F['un-resave'] = function () {
    if (!showProblems()) return;
    var o = U.cur, e = $('#un-err');
    api('PUT', '/unit/orders/' + o.id + '/result', payload(true)).then(function () {
      U.dirty = false; setState('تم حفظ التعديل ' + hm(new Date().toISOString())); toast('تم حفظ التعديل');
    }).catch(function (x) {
      if (x.code === 'locked') { U.dirty = false; toast('راجع الطبيب النتيجة قبل لحظات فلم تُحفظ تعديلاتك', true); editView(o.id); }
      else { e.textContent = X.fieldErr(x); e.hidden = false; }
    });
  };

  /* ---------- التسجيل في الهيكل ---------- */
  X.views.unit = function () {
    var oid = (location.hash || '').split('/')[2];
    if (oid) editView(oid); else listView();
  };
  X.polls.unit = function () { if (!U.cur) loadList(); };
})();
