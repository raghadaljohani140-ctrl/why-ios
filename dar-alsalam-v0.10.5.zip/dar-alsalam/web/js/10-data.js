/* طبقة البيانات: ذاكرة محلية ← نسخة مضمّنة ← تحديث من الخادم (ETag). التطبيق يعمل بدون إنترنت بالبيانات المضمّنة. */
(function (root) {
  'use strict';
  var DS = root.DS, D = DS.data = { ds: null, kb: null, lex: null, source: '', etag: null, by: {}, listeners: [] };

  /* صور الأقسام (من تصاميم المجمع). تُربط بمعرّف التخصص/الخدمة؛ ومن لا صورة له يبقى بأيقونته. حقل image (رابط https) إن وُجد يتقدّم عليها */
  var DEPT_IMG = { internal: 'img/dept/internal.jpg', pediatrics: 'img/dept/pediatrics.jpg', obgyn: 'img/dept/obgyn.jpg', ent: 'img/dept/ent.jpg', surgery: 'img/dept/surgery.jpg', general: 'img/dept/general.jpg', emergency: 'img/dept/emergency.jpg', lab: 'img/dept/lab.jpg', xray: 'img/dept/xray.jpg' };
  D.deptImg = function (e) { if (!e) return ''; if (typeof e.image === 'string' && /^https:\/\//.test(e.image)) return e.image; return DEPT_IMG[e.id] || ''; };

  function bySort(a) { return (a || []).slice().sort(function (x, y) { return (x.sort || 0) - (y.sort || 0); }); }
  function fetchJson(url) { return fetch(url, { cache: 'no-cache' }).then(function (r) { if (!r.ok) throw new Error(url); return r.json(); }); }

  D.set = function (ds, source, etag) {
    ['branches', 'specialties', 'services', 'doctors', 'faqs', 'banners'].forEach(function (k) { ds[k] = bySort(ds[k]); });
    D.ds = ds; D.source = source; D.etag = etag || null;
    D.by = {};
    ['branches', 'specialties', 'services', 'doctors', 'faqs', 'banners'].forEach(function (k) {
      D.by[k] = {}; ds[k].forEach(function (e) { D.by[k][e.id] = e; });
    });
    if (D.lex && DS.kbmod) D.kb = new DS.kbmod.KB(ds, D.lex);
  };
  D.branch = function (id) { return D.by.branches && D.by.branches[id]; };
  D.specialty = function (id) { return D.by.specialties && D.by.specialties[id]; };
  D.service = function (id) { return D.by.services && D.by.services[id]; };
  D.doctor = function (id) { return D.by.doctors && D.by.doctors[id]; };
  D.settings = function () { return (D.ds && D.ds.settings) || {}; };
  D.mainPhone = function () {
    var ph = D.settings().phones || [];
    var m = ph.filter(function (p) { return p.type === 'main'; })[0] || ph[0];
    return m ? m.number : '';
  };
  D.doctorsOfSpecialty = function (id) { return D.ds.doctors.filter(function (d) { return (d.specialtyIds || []).indexOf(id) >= 0; }); };
  D.doctorsOfService = function (id) { return D.ds.doctors.filter(function (d) { return (d.serviceIds || []).indexOf(id) >= 0; }); };
  D.docTitle = function (d) { return 'د. ' + d.name; };
  D.doctorSpecs = function (d) {
    return (d.specialtyIds || []).map(D.specialty).concat((d.serviceIds || []).map(D.service)).filter(Boolean);
  };
  D.bookingMode = function () { var b = D.settings().booking || {}; return { mode: b.mode || 'requests', url: b.externalUrl || '', label: b.externalLabel || 'الحجز عبر بوابة المريض', periods: b.periods || [] }; };
  D.onChange = function (fn) { D.listeners.push(fn); };

  D.loadLexicon = function () {
    if (root.DS_LEXICON) return Promise.resolve(root.DS_LEXICON);
    return fetchJson('data/lexicon.json').catch(function () { return DS.api.get('/lexicon').then(function (r) { return r.data; }); });
  };
  D.loadSeed = function () {
    if (root.DS_SEED) return Promise.resolve(root.DS_SEED);
    return fetchJson('data/seed.public.json');
  };

  D.load = function () {
    return D.loadLexicon().then(function (lx) {
      D.lex = new DS.kbmod.Lexicon(lx);
      var cached = DS.store.get('dataset');
      if (cached && cached.v === 2 && cached.ds && cached.ds.settings) { D.set(cached.ds, 'cache', cached.etag); return; }
      return D.loadSeed().then(function (seed) { D.set(seed, 'seed', null); });
    });
  };

  D.refresh = function () {
    if (DS.cfg.demo) return Promise.resolve(false);
    return DS.api.get('/clinic', { etag: D.etag, timeout: 8000 }).then(function (r) {
      if (r.status === 304) { D.online = true; return false; }
      D.online = true;
      var changed = !D.etag || r.etag !== D.etag;
      D.set(r.data, 'network', r.etag);
      DS.store.set('dataset', { v: 2, etag: r.etag, ds: r.data });
      if (changed) D.listeners.forEach(function (fn) { try { fn(); } catch (e) { /* تجاهل */ } });
      return changed;
    }).catch(function () { D.online = false; return false; });
  };
})(window);
