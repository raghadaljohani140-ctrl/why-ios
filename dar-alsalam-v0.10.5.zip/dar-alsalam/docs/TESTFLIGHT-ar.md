# آيفون: من GitHub إلى TestFlight (بلا جهاز Mac)

> **الحالة بصراحة:** هذا المسار **لم يُجرَّب على أجهزة Apple** (لا macOS ولا حساب Apple في بيئة عملي). كتبته على نمط أمثلة منشورة نجحت عند أصحابها (بناء Capacitor 8 على `macos-26` بتوقيع سحابي)، واختبرت منطق السكربت هنا بأوامر وهمية. توقّع أن يحتاج **أول تشغيل** تعديلاً بسيطاً، وسجل التشغيل يدلّني عليه.
> **لا يُنشر شيء في App Store.** كل بناء يُصدَّر بعلامة «TestFlight للاختبار الداخلي فقط»، فلا يمكن حتى إرساله للمراجعة. النشر يتم لاحقاً بموافقتك وبخطوة منفصلة.

## الفكرة

ترفع ملف المشروع (`dar-alsalam-v….zip`) إلى GitHub كما تفعل دائماً ← تضغط **Run workflow** ← يبني GitHub التطبيق على جهاز Mac تابع له، ويوقّعه توقيعاً سحابياً بمفتاحك، ويرفعه إلى TestFlight ← تثبّته من تطبيق **TestFlight** على جوالك. لا تحتاج Mac، ولا شهادات، ولا جهازاً مسجّلاً في حسابك.

## التجهيز (مرة واحدة فقط)

كلها من جوالك. الأسرار تضيفها **أنت** إلى GitHub؛ لا ترسلها لي ولا لأي أحد.

1. **Team ID:** developer.apple.com ← Account ← **Membership details** ← انسخ **Team ID** (10 خانات).
2. **سجّل معرّف الحزمة:** developer.apple.com ← Account ← Certificates, Identifiers & Profiles ← **Identifiers** ← **+** ← App IDs ← App ← الوصف أي اسم، و**Explicit Bundle ID** = `com.daralsalam.clinic` ← اترك الصلاحيات كما هي ← Register.
   *المعرّف يُحدَّد قبل أول رفع ولا يتغير بعده. إن أردت غير هذا فقل لي قبل التشغيل الأول وأغيّره داخل المشروع.*
3. **أنشئ التطبيق في App Store Connect:** appstoreconnect.apple.com ← Apps ← **+** ← New App ← iOS، الاسم (مثلاً «دار السلام»؛ إن كان محجوزاً فاختر «مجمعات دار السلام الطبية»)، اللغة الأساسية العربية، **Bundle ID** = المعرّف الذي سجّلته، SKU أي نص (مثل `daralsalam-clinic`)، وصول كامل ← Create.
4. **أنشئ مفتاح API:** App Store Connect ← **Users and Access** ← **Integrations** ← App Store Connect API ← Team Keys ← **Generate API Key** (قد يطلب «Request Access» أولاً لصاحب الحساب).
   - الاسم أي شيء (مثل GitHub)، والصلاحية **Admin** (مهم: صلاحية App Manager لا تكفي للتوقيع السحابي).
   - انسخ **Key ID** و**Issuer ID** (أعلى الصفحة)، ثم اضغط **Download API Key**. **يُنزَّل مرة واحدة فقط**، ويُحفظ في تطبيق «الملفات» باسم `AuthKey_XXXXXXXXXX.p8`.
5. **أضف 4 أسرار في GitHub:** المستودع ← **Settings** ← Secrets and variables ← **Actions** ← New repository secret، وأنشئ بهذه الأسماء بالضبط:

   | اسم السر | قيمته |
   |---|---|
   | `APPLE_TEAM_ID` | Team ID من الخطوة 1 |
   | `ASC_KEY_ID` | Key ID من الخطوة 4 |
   | `ASC_ISSUER_ID` | Issuer ID من الخطوة 4 |
   | `ASC_KEY_P8` | **محتوى** ملف `.p8` كاملاً: في «الملفات» اضغط مطولاً على الملف ← إعادة تسمية ← غيّر `.p8` إلى `.txt` ← افتحه ← حدّد الكل ← انسخ ← الصق (من أول سطر BEGIN إلى آخر سطر END) |

   بعد الحفظ احذف نسخة الملف من جوالك. إن شككت أن المفتاح تسرّب: App Store Connect ← Integrations ← Revoke، وأنشئ غيره.
6. **أنشئ ملف التشغيل (مرة واحدة):** مستودعك ← **Add file** ← **Create new file** ← في خانة الاسم اكتب `.github/workflows/ios-testflight.yml` (الشرطة المائلة تنشئ المجلدات) ← الصق نص الملف الموجود في آخر هذا الدليل ← **Commit changes**.

## كل مرة تريد نسخة جديدة على جوالك

1. ارفع ملف الإصدار الجديد إلى GitHub كالعادة (يبني من **أحدث** ملف `dar-alsalam-v….zip` تلقائياً).
2. GitHub ← **Actions** ← «**iOS — TestFlight**» ← **Run workflow** ← اترك الخانات كما هي (الخادم معبّأ، والرفع مفعّل) ← **Run workflow**.
3. انتظر نحو 10–20 دقيقة (لم أقِس الزمن الفعلي). علامة ✅ الخضراء = رُفع إلى Apple.
4. App Store Connect ← تطبيقك ← **TestFlight**: سيظهر البناء بحالة Processing لدقائق. وعند أول مرة: **Internal Testing** ← **+** لإنشاء مجموعة ← أضف نفسك (ومن تريد من أعضاء الحساب) ← اختر البناء.
5. على الآيفون ثبّت تطبيق **TestFlight** من App Store، وادخل بنفس Apple ID ← يظهر «دار السلام» ← **Install**.

خيار **upload**: أزل علامته لتبني وتوقّع فقط دون رفع (للتجربة). رقم البناء يزيد تلقائياً في كل تشغيل، ورقم الإصدار يؤخذ من الحزمة.

## إن فشل التشغيل

افتح التشغيل الفاشل ← الخطوة الحمراء. تظهر أعلى صفحة التشغيل أسطر حمراء بالعربية تشرح السبب المرجّح. أرسل لي **لقطة** منها (لا ترسل أي مفاتيح). الأسباب الشائعة:

| ما يظهر | السبب | الحل |
|---|---|---|
| التوقيع السحابي مرفوض | المفتاح ليس Admin | أنشئ مفتاحاً بصلاحية **Admin** وحدّث الأسرار الثلاثة |
| تعذّر تجهيز ملف التوفير | Team ID خاطئ، أو المعرّف غير مسجّل، أو الاشتراك منتهٍ | راجع الخطوتين 1 و2 وصلاحية حساب المطوّر |
| فشل الدخول إلى Apple | Key ID/Issuer ID خاطئ أو `.p8` ناقص | أعد نسخ القيم والمحتوى كاملاً |
| لا يوجد تطبيق بهذا المعرّف | لم تُنشأ بطاقة التطبيق | الخطوة 3 |
| رقم البناء مكرر | رُفع البناء فعلاً | تحقق من TestFlight قبل الإعادة |

## ما لا يفعله هذا المسار

- **لا ينشر في App Store ولا يرسل للمراجعة.** (للنشر العام خطوات أخرى في `STORE_RELEASE.md`، منها قرار «باسم من يُنشر التطبيق».)
- **لا يفعّل إشعارات الدفع** على الآيفون (تحتاج مفتاح APNs وإعداداً إضافياً لاحقاً بموافقتك). الإشعارات داخل التطبيق تعمل.
- **الأيقونة مؤقتة** (الشعار الحالي) حتى يصل الشعار الرسمي.
- **التجربة على أجهزة حقيقية لم تحدث بعد:** شاشة البداية والأيقونة ولوحة المفاتيح وغيرها تُفحص من TestFlight أول ما يصل البناء.
- **التكلفة:** المستودع العام يبني مجاناً. إن جعلتَه خاصاً فدقائق macOS تُحتسب بمعامل أعلى (انظر `COSTS.md`).
- **الأمان:** لا يعمل إلا بضغطك أنت. الأسرار تُستعمل في خطوة البناء وحدها، ويُحذف ملف المفتاح من الجهاز المؤقت عند الانتهاء، ولا يُطبع أي سر في السجل. **لكن** من يستطيع الرفع إلى المستودع يستطيع تشغيل البناء بأسرارك؛ فلا تضف أحداً متعاوناً فيه، وفعّل **التحقق بخطوتين** في حساب GitHub.

## ملحق: نص ملف التشغيل (للصقه في الخطوة 6)

```yaml
# بناء تطبيق دار السلام على الآيفون ورفعه إلى TestFlight. يدوي فقط (لا يعمل من تلقاء نفسه) ولا ينشر شيئاً في App Store.
# يبني من أحدث ملف dar-alsalam-v*.zip في جذر هذا المستودع. المنطق كله داخل الحزمة (mobile/ci/ios-build.sh)، وهذا الملف يُنشأ مرة واحدة فقط.
# الدليل: docs/TESTFLIGHT-ar.md داخل الحزمة. لم يُجرَّب على أجهزة Apple بعد: إن فشل أول تشغيل فأرسل لقطة السطر الأحمر.
name: iOS — TestFlight

on:
  workflow_dispatch:
    inputs:
      version:
        description: "رقم الإصدار مثل 0.10.1 (أو latest لأحدث ملف zip)"
        default: "latest"
        type: string
      api_base:
        description: "عنوان الخادم (بلا / في الآخر)"
        required: true
        default: "https://daralsalamclinic.duckdns.org"
        type: string
      upload:
        description: "ارفع إلى TestFlight؟ (أزل العلامة للبناء والتوقيع فقط)"
        type: boolean
        default: true

permissions:
  contents: read

concurrency:
  group: ios-testflight
  cancel-in-progress: false

jobs:
  ios:
    runs-on: macos-26
    timeout-minutes: 60
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-node@v4
        with:
          node-version: 22

      - name: فك حزمة المشروع
        env:
          VERSION: ${{ inputs.version }}
        run: |
          set -euo pipefail
          if [ -z "$VERSION" ] || [ "$VERSION" = latest ]; then
            ZIP=$(ls -1 dar-alsalam-v*.zip 2>/dev/null | sed -nE 's/^dar-alsalam-v([0-9]+)\.([0-9]+)\.([0-9]+)\.zip$/\1 \2 \3 &/p' | sort -n -k1,1 -k2,2 -k3,3 | tail -n 1 | cut -d' ' -f4 || true)
          else
            ZIP="dar-alsalam-v${VERSION#v}.zip"
          fi
          if [ -z "$ZIP" ] || [ ! -f "$ZIP" ]; then echo "::error::لم أجد حزمة المشروع في جذر المستودع (dar-alsalam-v....zip). ارفعها أولاً."; exit 1; fi
          echo "الحزمة: $ZIP"
          shasum -a 256 "$ZIP"
          mkdir -p "$RUNNER_TEMP/src"
          unzip -oq "$ZIP" -d "$RUNNER_TEMP/src"
          SRC="$RUNNER_TEMP/src/dar-alsalam"
          if [ ! -f "$SRC/mobile/ci/ios-build.sh" ]; then echo "::error::هذه الحزمة قديمة ولا تحوي مسار بناء iOS. استعمل 0.10.1 أو أحدث."; exit 1; fi
          echo "SRC=$SRC" >> "$GITHUB_ENV"

      - name: بناء iOS ثم توقيع سحابي ثم رفع
        env:
          API_BASE: ${{ inputs.api_base }}
          UPLOAD: ${{ inputs.upload }}
          APPLE_TEAM_ID: ${{ secrets.APPLE_TEAM_ID }}
          ASC_KEY_ID: ${{ secrets.ASC_KEY_ID }}
          ASC_ISSUER_ID: ${{ secrets.ASC_ISSUER_ID }}
          ASC_KEY_P8: ${{ secrets.ASC_KEY_P8 }}
        run: bash "$SRC/mobile/ci/ios-build.sh"
```
