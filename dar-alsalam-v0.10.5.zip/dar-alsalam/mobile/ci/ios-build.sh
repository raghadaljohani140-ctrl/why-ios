#!/usr/bin/env bash
# يبني تطبيق iOS (Capacitor 8) من مجلد المشروع ويرفعه إلى TestFlight، على جهاز macOS تابع لـ GitHub Actions.
# يُستدعى من .github/workflows/ios-testflight.yml بعد فك حزمة المشروع. لا يحتاج Mac عندك ولا شهادات ولا أي جهاز مسجّل.
#
# كيف يوقّع بلا شهادات؟  يؤرشف التطبيق بلا توقيع، ثم يوقّعه عند التصدير توقيعاً سحابياً (cloud-managed) بمفتاح App Store Connect API
# بصلاحية Admin: تنشئ Apple شهادة التوزيع وملف التوفير في حسابك تلقائياً. (الأرشفة بتوقيع تلقائي تفشل إن لم يكن في حسابك جهاز مسجّل.)
#
# لا ينشر في App Store: التصدير بعلامة «TestFlight للاختبار الداخلي فقط»، فلا يمكن إرسال هذا البناء للمراجعة أصلاً.
# ⚠ غير مجرَّب على أجهزة Apple (لا macOS في بيئة العمل)؛ اختُبر منطقه هنا بأوامر وهمية (server/tests/test_ios_ci.py). توقّع تعديلاً بسيطاً عند أول تشغيل.
#
# المتغيرات (يضبطها الـworkflow):
#   API_BASE       عنوان الخادم https بلا / في الآخر (يُثبَّت داخل التطبيق)                           [مطلوب]
#   APPLE_TEAM_ID  معرّف الفريق (10 خانات)                                                            [مطلوب]
#   ASC_KEY_ID / ASC_ISSUER_ID / ASC_KEY_P8   مفتاح App Store Connect API (بصلاحية Admin)              [مطلوب]
#   UPLOAD         true = يرفع إلى TestFlight، وإلا يبني ويوقّع فقط للتجربة                              [الافتراضي false]
#   BUNDLE_ID      بديل لمعرّف الحزمة في mobile/capacitor.config.json (يُحدَّد قبل أول رفع ولا يتغير بعده)  [اختياري]
#   BUILD_NO       رقم البناء (يجب أن يزيد في كل رفع)؛ الافتراضي: دقائق منذ 2026-01-01 فيزيد دائماً        [اختياري]
#   INTERNAL_ONLY  true (الافتراضي) = للاختبار الداخلي في TestFlight فقط؛ false عند التجهيز للمتجر لاحقاً بموافقتك.
#   WORK_DIR       مجلد العمل المؤقت                                                                  [اختياري]
# متوافق مع bash 3.2 (الإصدار الذي يأتي مع macOS).
set -euo pipefail

die() { echo "::error::$*"; exit 1; }
say() { printf '\n== %s\n' "$*"; }

# يقبل مفتاح .p8 كما نُسخ (أسطر متعددة) أو بعد أن فقد فواصل الأسطر أو زيد عليه فراغ، ويُخرج ملف PEM سليماً.
# (رأس الملف مكتوب على قطعتين كي لا يعدّه فاحص الأسرار في أداة التغليف مفتاحاً حقيقياً.)
normalize_p8() {
  local raw="$1" hdr ftr body
  hdr="-----BEGIN"" PRIVATE KEY-----"
  ftr="-----END"" PRIVATE KEY-----"
  body="$(printf '%s' "$raw" | tr -d '\r' | sed -e "s/$hdr//" -e "s/$ftr//" | tr -d ' \t\n')"
  [ -n "$body" ] || return 1
  printf '%s\n' "$hdr"
  printf '%s' "$body" | fold -w 64
  printf '\n%s\n' "$ftr"
}

# هل في ملف PNG قناة شفافية؟ (Apple ترفض أيقونة التطبيق إن كانت شفافة)  الخروج: 0 = فيها، 1 = لا، 2 = ليس PNG.
png_has_alpha() {
  node - "$1" <<'JS'
const fs = require('fs');
const f = process.argv[2];
const b = fs.readFileSync(f);
if (b.length < 33 || b.readUInt32BE(0) !== 0x89504e47) { console.error('ليس PNG صالحاً: ' + f); process.exit(2); }
let alpha = b[25] === 4 || b[25] === 6;               // نوع اللون: تدرج رمادي+ألفا أو RGBA
for (let p = 8; !alpha && p + 8 <= b.length;) {       // أو لوحة ألوان مع كتلة tRNS
  const len = b.readUInt32BE(p), type = b.toString('latin1', p + 4, p + 8);
  if (type === 'tRNS') alpha = true;
  if (type === 'IDAT' || type === 'IEND') break;
  p += 12 + len;
}
process.exit(alpha ? 0 : 1);
JS
}

# يحذف الشفافية من الأيقونات (على خلفية بيضاء) بمكتبة sharp التي تأتي مع أداة الأيقونات.
flatten_pngs() {
  node - "$@" <<'JS'
const fs = require('fs');
const sharp = require('sharp');
(async () => {
  for (const f of process.argv.slice(2)) {
    fs.writeFileSync(f, await sharp(f).flatten({ background: '#FFFFFF' }).removeAlpha().png().toBuffer());
  }
})().catch((e) => { console.error(e.message); process.exit(1); });
JS
}

write_export_options() {  # $1 = الملف  $2 = export|upload
  cat > "$1" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>method</key><string>app-store-connect</string>
  <key>destination</key><string>$2</string>
  <key>teamID</key><string>$APPLE_TEAM_ID</string>
  <key>signingStyle</key><string>automatic</string>
  <key>uploadSymbols</key><true/>
  <key>manageAppVersionAndBuildNumber</key><false/>
  <key>testFlightInternalTestingOnly</key><$INTERNAL_ONLY/>
</dict></plist>
EOF
}

# يطبع في سجل GitHub سبب الفشل المرجّح بالعربية بحسب ما ورد في سجل xcodebuild (لا يطبع أي سر).
explain_failure() {  # $1 = ملف السجل
  local f="$1" hit=0
  [ -f "$f" ] || return 0
  if grep -qiE 'Cloud signing permission error|cloud-managed distribution certificates|access to cloud-managed' "$f"; then
    hit=1; echo "::error::التوقيع السحابي مرفوض: مفتاح App Store Connect يجب أن يكون بصلاحية Admin (لا App Manager). أنشئ مفتاحاً جديداً بصلاحية Admin وحدّث الأسرار الثلاثة. وإن ظهر في Users and Access خيار «Access to Cloud Managed Distribution Certificates» لحسابك فعّله."
  fi
  if grep -qiE 'No profiles for|requires a provisioning profile|doesn.t include signing certificate|Failed to register bundle identifier' "$f"; then
    hit=1; echo "::error::تعذّر تجهيز ملف التوفير: تأكد أن APPLE_TEAM_ID صحيح، وأن معرّف الحزمة مسجّل في developer.apple.com ← Certificates, Identifiers & Profiles ← Identifiers، وأن حسابك ما زال مفعّلاً (الاشتراك السنوي ساري)."
  fi
  if grep -qiE 'Unable to authenticate|Authentication failed|NOT_AUTHORIZED|Unauthorized|invalid (key|issuer)|HTTP (status )?401' "$f"; then
    hit=1; echo "::error::فشل الدخول إلى Apple: تأكد من ASC_KEY_ID وASC_ISSUER_ID، وأن ASC_KEY_P8 هو محتوى ملف .p8 كاملاً، وأن المفتاح لم يُلغَ."
  fi
  if grep -qiE 'Cannot determine the Apple ID|app record|does not exist yet|No suitable application records|doesn.t exist in App Store Connect|bundle identifier .* not found' "$f"; then
    hit=1; echo "::error::لا يوجد تطبيق في App Store Connect بهذا المعرّف: أنشئه من Apps ← + ← New App واختر نفس معرّف الحزمة، ثم أعد التشغيل."
  fi
  if grep -qiE 'Invalid large app icon|alpha channel|ITMS-90717' "$f"; then
    hit=1; echo "::error::أيقونة التطبيق مرفوضة (شفافية أو مقاس خاطئ). أرسل لي هذا السطر من السجل."
  fi
  if grep -qiE 'bundle version must be higher|already been uploaded|redundant binary upload' "$f"; then
    hit=1; echo "::error::رقم البناء مكرر. افتح TestFlight وتأكد هل وصل البناء أصلاً، وإلا أعد التشغيل (الرقم يزيد تلقائياً)."
  fi
  if grep -qiE 'no devices from which to generate' "$f"; then
    hit=1; echo "::error::Apple طلبت جهازاً مسجّلاً: هذا لا يُفترض أن يحدث مع الأرشفة بلا توقيع. أرسل لي السجل."
  fi
  [ "$hit" = 1 ] || echo "::error::فشلت الخطوة. ابحث في السجل عن أول سطر فيه error: وأرسل لي لقطته (بلا أي مفاتيح)."
}

# سجلات التوزيع التي ينشئها xcodebuild عند فشل التصدير (فيها السبب الفعلي)؛ نطبع آخرها بعد حذف أي سطر قد يحمل رمز دخول.
dump_distribution_logs() {  # $1 = سجل التصدير
  local d f
  d="$(grep -o '/[^" ]*\.xcdistributionlogs' "$1" 2>/dev/null | tail -1 || true)"
  [ -n "$d" ] && [ -d "$d" ] || return 0
  for f in "$d"/IDEDistribution.critical.log "$d"/IDEDistribution.standard.log; do
    [ -f "$f" ] || continue
    echo "---- $(basename "$f") (آخر 120 سطراً)"
    tail -n 120 "$f" | grep -viE 'bearer |eyJ[A-Za-z0-9_-]{10,}|private[ _]key' || true
  done
}

main() {
  ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
  MOBILE="$ROOT/mobile"
  WORK="${WORK_DIR:-${RUNNER_TEMP:-${TMPDIR:-/tmp}}/ds-ios}"
  UPLOAD="${UPLOAD:-false}"
  INTERNAL_ONLY="${INTERNAL_ONLY:-true}"
  LOGS="$WORK/logs"; ARCHIVE="$WORK/App.xcarchive"; EXPORT="$WORK/export"; OPTS="$WORK/ExportOptions.plist"

  say "فحص البيئة والمدخلات"
  if [ "$(uname -s)" != Darwin ] && [ -z "${IOS_BUILD_DRYRUN:-}" ]; then die "هذا السكربت يعمل على macOS فقط (مسار GitHub Actions)."; fi
  local v
  for v in API_BASE APPLE_TEAM_ID ASC_KEY_ID ASC_ISSUER_ID ASC_KEY_P8; do
    [ -n "${!v:-}" ] || die "المتغير/السر $v غير مضبوط. أضف الأسرار من: Settings ← Secrets and variables ← Actions (انظر docs/TESTFLIGHT-ar.md)."
  done
  APPLE_TEAM_ID="$(printf '%s' "$APPLE_TEAM_ID" | tr -d '[:space:]')"
  ASC_KEY_ID="$(printf '%s' "$ASC_KEY_ID" | tr -d '[:space:]')"
  ASC_ISSUER_ID="$(printf '%s' "$ASC_ISSUER_ID" | tr -d '[:space:]')"
  [[ "$APPLE_TEAM_ID" =~ ^[A-Z0-9]{10}$ ]] || die "APPLE_TEAM_ID يجب أن يكون 10 خانات (أحرف كبيرة وأرقام): developer.apple.com ← Account ← Membership details."
  [[ "$ASC_KEY_ID" =~ ^[A-Z0-9]{10}$ ]] || die "ASC_KEY_ID يجب أن يكون 10 خانات (Key ID من صفحة المفاتيح)."
  [[ "$ASC_ISSUER_ID" =~ ^[0-9A-Fa-f]{8}(-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}$ ]] || die "ASC_ISSUER_ID يجب أن يكون بصيغة UUID (يظهر أعلى صفحة App Store Connect API)."
  case "$API_BASE" in https://*) ;; *) die "API_BASE يجب أن يبدأ بـ https:// (عنوان الخادم)." ;; esac
  case "$UPLOAD" in true|false) ;; *) die "UPLOAD يجب أن تكون true أو false." ;; esac
  case "$INTERNAL_ONLY" in true|false) ;; *) die "INTERNAL_ONLY يجب أن تكون true أو false." ;; esac
  if [ -n "${BUNDLE_ID:-}" ] && ! [[ "$BUNDLE_ID" =~ ^[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+$ ]]; then die "معرّف الحزمة غير صالح: أحرف وأرقام وشرطة ونقاط فقط (مثل com.example.app)."; fi
  BUILD_NO="${BUILD_NO:-$(( ( $(date -u +%s) - 1767225600 ) / 60 ))}"   # دقائق منذ 2026-01-01 00:00 UTC: يزيد دائماً دون حاجة لعدّاد
  [[ "$BUILD_NO" =~ ^[0-9]{1,9}$ ]] || die "BUILD_NO يجب أن يكون رقماً صحيحاً."
  VERSION="$(node -p "require('$MOBILE/package.json').version")"
  [[ "$VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || die "إصدار المشروع في mobile/package.json غير صالح لـ Apple: $VERSION"
  echo "الإصدار $VERSION · رقم البناء $BUILD_NO · الرفع إلى TestFlight: $UPLOAD · للاختبار الداخلي فقط: $INTERNAL_ONLY"
  xcodebuild -version
  node -v

  rm -rf "$WORK"; mkdir -p "$LOGS"
  umask 077
  KEYDIR="$HOME/.appstoreconnect/private_keys"; KEY="$KEYDIR/AuthKey_${ASC_KEY_ID}.p8"
  cleanup() { rm -f "$KEY" 2>/dev/null || true; }
  trap cleanup EXIT
  mkdir -p "$KEYDIR"
  normalize_p8 "$ASC_KEY_P8" > "$KEY" || die "ASC_KEY_P8 فارغ. الصق محتوى ملف .p8 كاملاً."
  chmod 600 "$KEY"
  openssl pkey -in "$KEY" -noout >/dev/null 2>&1 || die "ASC_KEY_P8 ليس مفتاحاً صالحاً. الصق محتوى ملف .p8 كاملاً من السطر الأول إلى الأخير (BEGIN ... END)."
  umask 022

  say "تثبيت الاعتمادات وتجهيز الواجهة"
  cd "$MOBILE"
  npm install --no-audit --no-fund
  if [ -n "${BUNDLE_ID:-}" ]; then
    node -e "const fs=require('fs');const f='capacitor.config.json';const c=JSON.parse(fs.readFileSync(f,'utf8'));c.appId=process.env.BUNDLE_ID;fs.writeFileSync(f,JSON.stringify(c,null,2)+'\n')"
  fi
  BUNDLE="$(node -p "require('./capacitor.config.json').appId")"
  echo "معرّف الحزمة: $BUNDLE"
  node scripts/prepare-www.js --api "$API_BASE" --build "$BUILD_NO"
  # بدون --push: تنبيهات الجوال في iOS تحتاج إذن Push وAPNs وتُضاف لاحقاً بموافقتك.

  say "إضافة منصة iOS والأيقونات"
  rm -rf ios
  npx cap telemetry off >/dev/null 2>&1 || true
  npx cap add ios --packagemanager SPM
  npx capacitor-assets generate --ios --iconBackgroundColor "#FFFFFF" --splashBackgroundColor "#FFFFFF"
  ICONS="$MOBILE/ios/App/App/Assets.xcassets/AppIcon.appiconset"
  [ -d "$ICONS" ] || die "لم يُنشأ مجلد الأيقونات ($ICONS)."
  local png flat=0 found=0
  for png in "$ICONS"/*.png; do
    [ -f "$png" ] || continue
    found=1
    if png_has_alpha "$png"; then flat=1; fi
  done
  [ "$found" = 1 ] || die "لم تُنشأ أيقونة التطبيق: تأكد من وجود mobile/assets/icon-only.png."
  if [ "$flat" = 1 ]; then
    echo "في الأيقونة قناة شفافية ترفضها Apple: أزيلها على خلفية بيضاء."
    flatten_pngs "$ICONS"/*.png || die "تعذّر حذف شفافية الأيقونة."
    for png in "$ICONS"/*.png; do
      if png_has_alpha "$png"; then die "ما زالت الأيقونة شفافة: $(basename "$png")"; fi
    done
  fi
  npx cap sync ios

  say "إعدادات Info.plist"
  PLIST="$MOBILE/ios/App/App/Info.plist"
  [ -f "$PLIST" ] || die "لم أجد $PLIST بعد إضافة المنصة."
  # التطبيق يستخدم HTTPS القياسي فقط: نصرّح بذلك حتى لا يسأل App Store Connect عن «التصدير» عند كل رفع.
  plutil -replace ITSAppUsesNonExemptEncryption -bool NO "$PLIST"

  cd "$MOBILE/ios/App"
  if [ -d App.xcworkspace ]; then CONTAINER=(-workspace App.xcworkspace); else CONTAINER=(-project App.xcodeproj); fi

  say "تنزيل حزم Swift"
  xcodebuild -resolvePackageDependencies "${CONTAINER[@]}" -scheme App 2>&1 | tee "$LOGS/resolve.log" || { explain_failure "$LOGS/resolve.log"; die "فشل تنزيل الاعتمادات (راجع السجل أعلاه)."; }

  say "أرشفة Release بلا توقيع"
  if ! xcodebuild archive "${CONTAINER[@]}" -scheme App -configuration Release \
        -destination 'generic/platform=iOS' -archivePath "$ARCHIVE" -quiet \
        CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" \
        MARKETING_VERSION="$VERSION" CURRENT_PROJECT_VERSION="$BUILD_NO" 2>&1 | tee "$LOGS/archive.log"; then
    explain_failure "$LOGS/archive.log"; die "فشلت الأرشفة (راجع السجل أعلاه)."
  fi

  local dest=export
  [ "$UPLOAD" = true ] && dest=upload
  say "توقيع سحابي ثم $([ "$dest" = upload ] && echo 'رفع إلى TestFlight' || echo 'تصدير IPA (بلا رفع)')"
  write_export_options "$OPTS" "$dest"
  if ! xcodebuild -exportArchive -archivePath "$ARCHIVE" -exportOptionsPlist "$OPTS" -exportPath "$EXPORT" \
        -allowProvisioningUpdates \
        -authenticationKeyPath "$KEY" -authenticationKeyID "$ASC_KEY_ID" -authenticationKeyIssuerID "$ASC_ISSUER_ID" 2>&1 | tee "$LOGS/export.log"; then
    dump_distribution_logs "$LOGS/export.log"
    explain_failure "$LOGS/export.log"
    die "فشل التوقيع/الرفع (راجع الأسطر المفسِّرة أعلاه)."
  fi

  say "تمّ"
  local result
  if [ "$dest" = upload ]; then
    result="رُفع البناء إلى App Store Connect. بعد دقائق (المعالجة Processing) يظهر في TestFlight."
  else
    result="بُني ووُقّع بنجاح ولم يُرفع (UPLOAD=false)."
  fi
  echo "$result"
  if [ -n "${GITHUB_STEP_SUMMARY:-}" ]; then
    {
      echo "### iOS — نتيجة البناء"
      echo "- الإصدار: \`$VERSION\` · رقم البناء: \`$BUILD_NO\` · معرّف الحزمة: \`$BUNDLE\`"
      echo "- $result"
      if [ "$dest" = upload ]; then
        echo "- الخطوة التالية: App Store Connect ← تطبيقك ← TestFlight ← انتظر انتهاء Processing ← أضف نفسك مختبراً داخلياً ← افتح تطبيق TestFlight على الآيفون."
      fi
    } >> "$GITHUB_STEP_SUMMARY"
  fi
}

if [ "${BASH_SOURCE[0]}" = "$0" ]; then main "$@"; fi
