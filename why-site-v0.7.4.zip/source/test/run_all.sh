#!/bin/bash
# Every automatic check, one after another, each on a fresh server and an empty database.
#   server unit tests, installer (on a pretend server), customer page, reception + driver pages, admin page
# Prints the last line of each run; exits with an error if any of them failed.
cd "$(dirname "$0")"
ROOT=$(pwd)/..
fail=0
run() {
  local name=$1; shift
  local out; out=$("$@" 2>&1); local rc=$?
  echo "$name: $(echo "$out" | tail -1)"
  if [ $rc -ne 0 ]; then fail=1; echo "$out" | grep -v '^PASS' | tail -30; fi
}
run "server   " bash -c "cd '$ROOT/server' && python3 -W error::ResourceWarning -I test_server.py"
run "installer" bash -c "cd '$ROOT/deploy' && python3 -I test_install.py"
for t in smoke staff_e2e admin_e2e; do
  bash ./serve.sh 8790 >/dev/null 2>&1
  run "$t" node "$t.js"
done
pkill -f "why_server.py serve --db /tmp/whytest" 2>/dev/null
exit $fail
