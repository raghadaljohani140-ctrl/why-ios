// End-to-end test of the admin page, in its own browser, against the real server.
// Start the server first:  test/serve.sh 8790     (fresh database every time)
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const BASE = (process.env.WHY_BASE || 'http://127.0.0.1:8790').replace(/\/$/, '');
const OUT = path.join(__dirname, 'admin');
fs.rmSync(OUT, { recursive: true, force: true });
fs.mkdirSync(OUT, { recursive: true });
const CATALOG = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'server', 'catalog.json'), 'utf8'));

const results = [];
const check = (name, ok, extra) => { results.push({ name, ok: !!ok, extra }); console.log((ok ? 'PASS ' : 'FAIL ') + name + (extra !== undefined && !ok ? '  -> ' + JSON.stringify(extra) : '')); };
const wait = ms => new Promise(r => setTimeout(r, ms));
const until = async (f, ms = 6000, step = 120) => { const t = Date.now(); for (;;) { try { const v = await f(); if (v) return v; } catch (e) {} if (Date.now() - t > ms) return false; await wait(step); } };
const near = (a, b) => Math.abs(a - b) < 0.006;
const zlib = require('zlib');
// a real PNG photo: "product" = a dark box on a white background (plain corners), "photo" = colours out to the edges
function png(w, h, kind) {
  const row = y => {
    const b = Buffer.alloc(1 + w * 3);
    for (let x = 0; x < w; x++) {
      const inner = x > w * 0.3 && x < w * 0.7 && y > h * 0.25 && y < h * 0.75;
      const c = kind === 'photo' ? [Math.round(255 * x / w), Math.round(255 * y / h), 120] : (inner ? [90, 50, 30] : [255, 255, 255]);
      b[1 + x * 3] = c[0]; b[2 + x * 3] = c[1]; b[3 + x * 3] = c[2];
    }
    return b;
  };
  const chunk = (t, d) => { const len = Buffer.alloc(4); len.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]); const crc = Buffer.alloc(4); crc.writeUInt32BE(zlib.crc32(td) >>> 0); return Buffer.concat([len, td, crc]); };
  const ih = Buffer.alloc(13); ih.writeUInt32BE(w, 0); ih.writeUInt32BE(h, 4); ih[8] = 8; ih[9] = 2;
  return Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), chunk('IHDR', ih), chunk('IDAT', zlib.deflateSync(Buffer.concat(Array.from({ length: h }, (_, y) => row(y))))), chunk('IEND', Buffer.alloc(0))]);
}

// ---- a customer phone, straight against the API
const DEV = crypto.randomBytes(16).toString('hex');
async function raw(p, body, headers) {
  const r = await fetch(BASE + '/api' + p, { method: body === undefined ? 'GET' : 'POST', headers: Object.assign({ 'Content-Type': 'application/json' }, headers || {}), body: body === undefined ? undefined : JSON.stringify(body) });
  const j = await r.json().catch(() => ({})); j._status = r.status; return j;
}
const cust = (p, b) => raw(p, b, { 'X-Dev': DEV });
let n = 0;
async function tryOrder(x) {
  const body = Object.assign({ cid: 'c' + (++n) + crypto.randomBytes(6).toString('hex'), mode: 'pickup', branch: 'b2', serve: 'in', payM: 'card', cust: { name: 'خالد', phone: '566000111' }, items: [{ pid: 'latte', sel: {}, qty: 1 }] }, x || {});
  return cust('/orders', body);
}
async function place(x) { const r = await tryOrder(x); if (!r.ok) throw new Error('order failed ' + JSON.stringify(r)); return r.order; }
const mine = async id => (await cust('/my/sync', { since: 0, srev: -1 })).orders.find(o => o.id === id);
const pub = () => raw('/public');

// ---- staff sessions, straight against the API
async function staffLogin(role, body) {
  const r = await fetch(BASE + '/api/' + role + '/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) return Object.assign({ _status: r.status }, j);
  const cookie = r.headers.get('set-cookie').split(';')[0];
  return { _status: 200, cookie, call: async (p, b) => { const x = await fetch(BASE + '/api' + p, { method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: cookie }, body: JSON.stringify(b) }); const j2 = await x.json().catch(() => ({})); j2._status = x.status; return j2; } };
}

(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const errors = [];
  async function open(name, viewport, url, opts) {
    const ctx = await browser.newContext(Object.assign({ viewport, deviceScaleFactor: 1, acceptDownloads: true }, opts || {}));
    const page = await ctx.newPage();
    page.on('pageerror', e => errors.push(name + ' pageerror: ' + e.message));
    page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errors.push(name + ' console: ' + m.text()); });
    await page.route('**/*', r => r.request().url().startsWith(BASE + '/') ? r.continue() : r.abort());
    await page.goto(BASE + url, { waitUntil: 'domcontentloaded' });
    await wait(500);
    return {
      page, ctx,
      ev: (f, a) => page.evaluate(f, a),
      txt: async () => page.locator('#view').innerText(),
      has: async s => (await page.locator('#view').innerText()).includes(s),
      said: async s => (await page.locator('#toasts').innerText()).includes(s),
      click: async sel => { await page.locator(sel).last().click({ timeout: 8000 }); await wait(250); },
      nav: async id => { await page.locator(`.adm-side [data-a="adSec"][data-id="${id}"]:visible, .adm-tabs [data-a="adSec"][data-id="${id}"]:visible`).first().click({ timeout: 8000 }); await wait(250); },
      fill: async (sel, v) => { await page.locator(sel).last().fill(v); await wait(120); },
      shot: async nm => { await wait(300); await page.screenshot({ path: path.join(OUT, name + '-' + nm + '.png') }); }
    };
  }

  // ---- things to look at on the page
  const kpi = (ad, label) => ad.ev(l => { const k = [...document.querySelectorAll('.kpi')].find(x => x.querySelector('small').textContent.includes(l)); return k ? k.querySelector('b').textContent.trim() : null; }, label);
  const heroSales = ad => ad.ev(() => parseFloat(document.querySelector('.hero-v').innerText.replace(/[^\d.]/g, '')));
  const publicMenu = async () => (await pub()).menu || {};

  // ---- some orders first, so the page has something to show
  const orders = [];
  orders.push(await place({ branch: 'b2', items: [{ pid: 'latte', sel: { size: 'm', milk: 'oat' }, qty: 2 }, { pid: 'brownie', sel: {}, qty: 1 }], serve: 'take' }));
  orders.push(await place({ branch: 'b1', items: [{ pid: 'cap', sel: {}, qty: 1 }] }));
  orders.push(await place({ mode: 'delivery', branch: 'b2', addr: { city: 'المدينة المنورة', street: 'حي الخزامى', note: 'البوابة الزرقاء', lat: 24.4672, lng: 39.6024 }, items: [{ pid: 'cap', sel: {}, qty: 1 }, { pid: 'yirg', sel: {}, qty: 1 }] }));
  const [oA, oB, oC] = orders;
  const recv = await staffLogin('recv', { pin: '654321' });
  check('reception account works (set up by the server test script)', recv._status === 200);
  check('reception rejects the second order (a rejected order never counts as a sale)', (await recv.call('/recv/order', { id: oB.id, op: 'reject', reason: 'busy' })).ok);

  // ======================================================================= sign-in
  const ad = await open('admin', { width: 1180, height: 900 }, '/admin/');
  check('admin: own page, own title', (await ad.page.title()) === 'واي! | الإدارة');
  check('admin: the sign-in page shows the W with MANAGEMENT', await ad.page.locator('.gate-logo .im-lockup[aria-label="Why! Management"]').count() === 1);
  check('admin: sign-in with the admin code only, nothing of the other apps', await ad.has('لوحة الإدارة') && await ad.has('الرمز السري') && await ad.page.locator('#lgname').count() === 0 && await ad.page.locator('a[href]').count() === 0 && !(await ad.has('تطبيق العميل')));
  await ad.shot('1-login');
  await ad.page.fill('#pin', '000000'); await ad.click('[data-a="login"]');
  check('admin: wrong code refused', await until(() => ad.has('الاسم أو الرمز غير صحيح')) && await ad.ev(() => UI.mode === 'login'));
  await ad.page.fill('#pin', '654321'); await ad.click('[data-a="login"]');
  check('admin: the reception code does not open the admin page', await until(() => ad.has('الاسم أو الرمز غير صحيح')) && await ad.ev(() => UI.mode === 'login'));
  await ad.page.fill('#pin', '123456'); await ad.page.press('#pin', 'Enter');
  check('admin: right code opens the dashboard', await until(() => ad.ev(() => UI.mode === 'main')) && await until(() => ad.has('مبيعات اليوم')));
  check('admin: code is not kept in the page, cookie not readable', await ad.ev(() => UI.lg.pin === '' && !JSON.stringify(localStorage).includes('123456') && !document.cookie.includes('why_admin')));

  // ======================================================================= overview
  const sold = list => list.filter(o => !o.rej);
  let expected = [oA, oC].reduce((a, o) => a + o.total, 0);
  check('overview: sales today are the real orders, a rejected one left out', await until(async () => near(await heroSales(ad), expected)), { hero: await heroSales(ad), expected });
  check('overview: orders today = 2', await kpi(ad, 'الطلبات اليوم') === '2');
  check('overview: average order', await until(async () => near(parseFloat(await kpi(ad, 'متوسط')), Math.round(expected / 2 * 100) / 100)), await kpi(ad, 'متوسط'));
  check('overview: waiting to be accepted = 2 (pickup + delivery)', await kpi(ad, 'بانتظار القبول') === '2');
  check('overview: items sold = 5 (2 lattes, brownie, cap, yirg)', await kpi(ad, 'الأصناف المباعة') === '5', await kpi(ad, 'الأصناف المباعة'));
  check('overview: deliveries today = 1', await kpi(ad, 'طلبات التوصيل') === '1');
  check('overview: most ordered shows the latte first', await ad.ev(() => document.querySelector('.top li .nm').textContent.includes('لاتيه') || document.querySelector('.top li .nm').textContent.length > 0));
  check('overview: all three branches listed', await ad.page.locator('.ov-a .tbl tbody tr').count() === 3);
  const dOrder = await place({ branch: 'b1', items: [{ pid: 'latte', sel: {}, qty: 1 }] });
  expected += dOrder.total;
  check('overview: a new order shows up by itself, no reload', await until(async () => near(await heroSales(ad), expected)) && await kpi(ad, 'الطلبات اليوم') === '3', { hero: await heroSales(ad), expected });
  await ad.shot('2-home');
  // the seven-day chart
  check('chart: seven bars, today is the last', await ad.page.locator('.bars .bar').count() === 7 && await ad.ev(() => document.querySelector('.bars .bar:last-child').classList.contains('now')));
  await ad.click('.bars .bar:last-child');
  check('chart: tapping the last bar shows today’s total', await ad.ev(v => { const b = document.querySelector('.bars .bar:last-child'); return b.classList.contains('sel') && Math.abs(parseFloat(b.querySelector('.tip').textContent) - v) < 0.006; }, expected));
  check('chart: the other six days are empty', await ad.ev(() => [...document.querySelectorAll('.bars .bar')].slice(0, 6).every(b => parseFloat(b.querySelector('.tip').textContent) === 0)));
  await ad.click('[data-a="adTbl"]');
  check('chart: table view has seven rows, today’s row has the total', await ad.page.locator('.tbl.dk tbody tr').count() === 7 && await ad.ev(v => { const r = document.querySelector('.tbl.dk tbody tr:last-child'); return r.textContent.includes('اليوم') && r.textContent.includes('3') && Math.abs(parseFloat(r.lastElementChild.innerText.replace(/[^\d.]/g, '')) - v) < 0.006; }, expected));
  await ad.click('[data-a="adTbl"]');
  await ad.click('[data-a="adGoNew"]');
  check('overview: tapping "waiting to be accepted" goes to the new orders', await ad.ev(() => UI.ad.sec === 'orders' && UI.ad.f === 'new') && await ad.page.locator('.aor').count() === 3);

  // ======================================================================= orders
  await ad.click('[data-a="adF"][data-id="all"]');
  check('orders: all four orders listed, newest first', await ad.page.locator('.aor').count() === 4 && await ad.ev(id => document.querySelector('.aor').dataset.id === id, dOrder.id));
  check('orders: filter counts (all 4, new 3, rejected 1)', await ad.ev(() => { const c = id => document.querySelector(`.chip[data-id="${id}"] .cn`).textContent; return c('all') === '4' && c('new') === '3' && c('rej') === '1'; }));
  await ad.page.fill('[data-bind="ad.oq"]', 'خالد'); await wait(250);
  check('orders: search by customer name', await ad.page.locator('.aor').count() === 4);
  await ad.page.fill('[data-bind="ad.oq"]', oC.no.replace(/\D/g, '').slice(-3)); await wait(250);
  check('orders: search by order number finds it', await ad.page.locator(`.aor[data-id="${oC.id}"]`).count() === 1);
  await ad.page.fill('[data-bind="ad.oq"]', 'zzzz'); await wait(250);
  check('orders: nothing found says so', await ad.has('لا توجد طلبات') && await ad.page.locator('.aor').count() === 0);
  await ad.page.fill('[data-bind="ad.oq"]', ''); await wait(250);
  await ad.click('[data-a="adF"][data-id="rej"]');
  check('orders: rejected filter shows only the rejected order', await ad.page.locator('.aor').count() === 1 && await ad.page.locator(`.aor[data-id="${oB.id}"]`).count() === 1);
  await ad.click('[data-a="adF"][data-id="all"]');
  await ad.click(`.aor[data-id="${oA.id}"]`);
  check('orders: tapping an order opens its ticket with the branch and customer', await ad.page.locator(`.sheet .tk[data-id="${oA.id}"]`).count() === 1 && await ad.ev(() => { const t = document.querySelector('.sheet .tk').innerText; return t.includes('خالد') && t.includes('لاتيه') && t.includes('براوني') && t.includes('0111'); }));
  check('orders: the admin sees the ticket but never the pickup code', await ad.ev(c => !document.body.innerHTML.includes('>' + c + '<') && !document.body.innerHTML.includes('"' + c + '"'), oA.code));
  await ad.shot('3-order-sheet');
  await ad.click(`.sheet [data-a="rcAccept"][data-id="${oA.id}"]`);
  check('orders: accepting from the admin moves it on for the customer too', await until(async () => (await mine(oA.id)).st === 1) && await until(() => ad.page.locator(`.sheet [data-a="rcReady"][data-id="${oA.id}"]`).count().then(c => c === 1)));
  await ad.click(`.sheet [data-a="rcReady"][data-id="${oA.id}"]`);
  check('orders: ready, then the admin can hand over with the code', await until(async () => (await mine(oA.id)).st === 2) && await until(() => ad.page.locator(`.sheet [data-bind="rc.code.${oA.id}"]`).count().then(c => c === 1)));
  await ad.fill(`.sheet [data-bind="rc.code.${oA.id}"]`, oA.code === '0000' ? '1111' : '0000');
  await ad.click(`.sheet [data-a="rcDeliver"][data-id="${oA.id}"]`);
  check('orders: a wrong code is refused', await until(() => ad.said('الرمز غير صحيح')) && (await mine(oA.id)).st === 2);
  await ad.fill(`.sheet [data-bind="rc.code.${oA.id}"]`, oA.code);
  await ad.click(`.sheet [data-a="rcDeliver"][data-id="${oA.id}"]`);
  check('orders: the right code hands it over', await until(async () => (await mine(oA.id)).fin === true));
  await ad.click('.sheet [data-a="close"]');
  check('orders: sheet closes', await ad.page.locator('.sheet').count() === 0);
  await ad.click(`.aor[data-id="${dOrder.id}"]`);
  await ad.click(`.sheet [data-a="rcReject"][data-id="${dOrder.id}"]`);
  check('orders: rejecting from the admin asks for a reason', await ad.has('سبب رفض الطلب'));
  await ad.click('[data-a="rejPick"][data-id="out"]'); await ad.click(`[data-a="rejOk"][data-id="${dOrder.id}"]`);
  check('orders: customer gets the rejection', await until(async () => (await mine(dOrder.id)).rej));
  expected -= dOrder.total + 0; // the rejected order leaves today's sales
  await ad.nav('home');
  check('overview: the rejected order leaves the sales', await until(async () => near(await heroSales(ad), expected)) && await kpi(ad, 'الطلبات اليوم') === '2', { hero: await heroSales(ad), expected });
  await ad.nav('orders');

  // ======================================================================= products
  await ad.nav('menu');
  await ad.shot('4-menu');
  check('menu: products listed with price and an availability switch', await ad.page.locator('.apr').count() > 5 && await ad.page.locator('.apr [data-a="adStock"][data-id="latte"]').count() === 1);
  await ad.click('[data-a="adStock"][data-id="latte"]');
  check('menu: switching the latte off reaches the customer menu', await until(async () => ((await publicMenu()).latte || {}).stock === false));
  const noStock = await tryOrder({ items: [{ pid: 'latte', sel: {}, qty: 1 }] });
  check('menu: the server refuses an order with it', noStock._status === 409 && noStock.error === 'stock', noStock);
  check('menu: the row looks unavailable', await ad.ev(() => document.querySelector('.apr [data-a="adStock"][data-id="latte"]').closest('.apr').classList.contains('out')));
  await ad.click('[data-a="adStock"][data-id="latte"]');
  check('menu: back on, the override is gone', await until(async () => !(await publicMenu()).latte) && (await tryOrder({ items: [{ pid: 'latte', sel: {}, qty: 1 }] }))._status === 200);
  // an item that is out in the first menu can be switched on
  const SEED = CATALOG.seed;
  const outP = SEED.products.find(p => p.stock === false);
  await ad.page.fill('[data-bind="ad.q"]', ''); await ad.click(`[data-a="adCat"][data-id="${outP.cats[0]}"]`);
  const hasOut = await ad.page.locator(`.apr [data-a="adStock"][data-id="${outP.id}"]`).count();
  if (hasOut) {
    await ad.click(`[data-a="adStock"][data-id="${outP.id}"]`);
    check('menu: an item that is out by default can be switched on', await until(async () => ((await publicMenu())[outP.id] || {}).stock === true));
    await ad.click(`[data-a="adStock"][data-id="${outP.id}"]`);
    check('menu: and back off again', await until(async () => !(await publicMenu())[outP.id]));
  } else check('menu: out-of-stock item row found', false, outP.id);

  // ---- a customer phone keeps the customer page open the whole time: changes reach it without a reload
  const menuNow = () => raw('/catalog');
  const prodOf = async id => (await menuNow()).products.find(p => p.id === id);
  const cu = await open('customer', { width: 390, height: 800 }, '/');
  await cu.click('[data-a="guest"]'); await cu.click('[data-a="toMenu"]');
  const cuSync = () => cu.ev(() => custSync());   // the page asks the server every little while; ask now
  check('customer: the menu is open, with the server menu', await until(() => cu.ev(() => SRV.crev > 0 && UI.stack.length > 0)));
  const imgSize = (page, url) => page.ev(async u => { const im = new Image(); im.src = u; await im.decode(); return [im.naturalWidth, im.naturalHeight]; }, url);

  // ---- add a product, with a photo
  await ad.click('[data-a="adCat"][data-id="cold"]');
  await ad.click('[data-a="pNew"]');
  check('add: the form opens empty, in the category being viewed, saving not possible yet', await ad.ev(() => UI.sheet.k === 'prod' && UI.pe.id === null && UI.pe.v.cats.join() === 'cold' && document.querySelector('[data-a="peSave"]').disabled));
  check('add: the form asks for both names, the price, the category, both descriptions, the options, availability', await ad.page.locator('#pe-ar').count() === 1 && await ad.page.locator('#pe-en').count() === 1 && await ad.page.locator('#pe-price').count() === 1 && await ad.page.locator('.pe-cats .chip').count() === SEED.cats.length && await ad.page.locator('#pe-dar').count() === 1 && await ad.page.locator('#pe-den').count() === 1 && await ad.page.locator('[data-a="peOpt"]').count() === 6 && await ad.page.locator('[data-a="peFlag"][data-k="stock"].on').count() === 1);
  check('add: no free-shipping switch for a branch drink', await ad.page.locator('[data-a="peFlag"][data-k="fship"]').count() === 0);
  await ad.shot('5a-product-new');
  await ad.fill('#pe-ar', 'موهيتو القهوة');
  await ad.fill('#pe-en', 'Coffee mojito');
  await ad.fill('#pe-price', '٢٤٫٥');
  check('add: Arabic digits in the price are taken', await ad.ev(() => document.querySelector('#pe-price').value === '24.5'));
  await ad.fill('#pe-dar', 'إسبريسو مع نعناع وليمون\nيُقدَّم باردًا');
  await ad.fill('#pe-den', 'Espresso with mint and lime');
  await ad.click('[data-a="peOpt"][data-id="size"]');
  let [fc] = await Promise.all([ad.page.waitForEvent('filechooser'), ad.page.locator('[data-a="pePhoto"]').click()]);
  await fc.setFiles({ name: 'mojito.png', mimeType: 'image/png', buffer: png(1600, 1200, 'product') });
  check('add: the photo is made small here and uploaded', await until(() => ad.ev(() => UI.pe && !UI.pe.up && !!UI.pe.v.img), 20000));
  const up = await ad.ev(() => UI.pe.v.img);
  check('photo: on a plain background it is shown whole, on that colour', up.f === 'c' && up.bg === '#ffffff' && Math.abs(up.r - 1.3333) < 0.001, up);
  check('photo: a large copy of 1000 px and a small one of 320 px', JSON.stringify(await imgSize(ad, '/api/img/' + up.id)) === '[1000,750]' && JSON.stringify(await imgSize(ad, '/api/img/' + up.id + '/t')) === '[320,240]');
  const head = await fetch(BASE + '/api/img/' + up.id);
  check('photo: served as WebP, kept by the phone for a long time', head.headers.get('content-type') === 'image/webp' && /immutable/.test(head.headers.get('cache-control')));
  await until(() => ad.page.locator('.pe-pv .im').count());
  check('add: the form shows the photo and offers to change or remove it', await ad.page.locator('.pe-pv .im').count() === 1 && await ad.has('تغيير الصورة') && await ad.has('حذف الصورة'));
  await ad.shot('5b-product-filled');
  await ad.click('[data-a="peSave"]');
  check('add: saved, the form closes and the list shows it', await until(() => ad.ev(() => !UI.sheet && !!document.querySelector('.apr [data-a="pEdit"]') && [...document.querySelectorAll('.apr b')].some(b => b.textContent === 'موهيتو القهوة'))));
  const added = (await menuNow()).products.find(p => p.ar === 'موهيتو القهوة');
  check('add: the server has it as typed', added && added.en === 'Coffee mojito' && added.price === 24.5 && added.cats.join() === 'cold' && added.opts.join() === 'size' && added.desc.ar === 'إسبريسو مع نعناع وليمون\nيُقدَّم باردًا' && added.desc.en === 'Espresso with mint and lime' && added.img.id === up.id && added.stock === true, added);
  const o1 = await place({ items: [{ pid: added.id, sel: { size: 'l' }, qty: 2 }] });
  check('add: the server prices an order with it ((24.5 + 5 large) × 2)', near(o1.total, 59), o1.total);
  await cuSync();
  await cu.click('[data-a="cat"][data-id="cold"]');
  check('customer: the new product is on the menu, with its small photo, without a reload', await until(async () => { await cuSync(); return cu.ev(id => { const r = document.querySelector(`[data-a="product"][data-id="${id}"] .im`); return !!r && r.style.backgroundImage.includes('/t'); }, added.id); }));
  await cu.click(`[data-a="product"][data-id="${added.id}"]`);
  check('customer: its page shows the large photo, the description and the three sizes', await cu.has('إسبريسو مع نعناع وليمون') && await cu.has('يُقدَّم باردًا') && await cu.page.locator('.phero.ph .im.fe').count() === 1 && await cu.page.locator('.sheet [data-a="opt"]').count() === 3);
  await cu.shot('1-new-product');
  await cu.click('[data-a="sadd"]');
  check('customer: it goes into the cart', await cu.ev(id => S.cart.some(c => c.pid === id), added.id));

  // ---- change a product of the first menu
  await ad.click('[data-a="adCat"][data-id="hot"]');
  await ad.click('[data-a="pEdit"][data-id="latte"]');
  check('edit: the form shows the latte as it is', await ad.ev(() => UI.pe.id === 'latte' && UI.pe.v.ar === 'لاتيه' && UI.pe.v.en === 'Latte' && UI.pe.v.price === '17' && UI.pe.v.opts.join() === 'size,milk,extras' && UI.pe.v.cats.join() === 'hot'));
  await ad.fill('#pe-ar', 'لاتيه واي');
  await ad.fill('#pe-price', '0');
  check('edit: a price of 0 cannot be saved', await ad.ev(() => document.querySelector('[data-a="peSave"]').disabled));
  await ad.fill('#pe-price', '19');
  await ad.click('[data-a="peOpt"][data-id="extras"]');
  await ad.click('[data-a="peSave"]');
  check('edit: the server has the new name, price and options', await until(async () => { const p = await prodOf('latte'); return p.ar === 'لاتيه واي' && p.price === 19 && p.opts.join() === 'size,milk'; }));
  const o2 = await place({ items: [{ pid: 'latte', sel: { size: 'm', extras: ['shot'] }, qty: 1 }] });
  check('edit: the next order costs 19 + 3 (medium), the removed extra is not charged', near(o2.items[0].unit, 22) && !o2.items[0].sel.extras, o2.items[0]);
  check('edit: an order made before keeps the name it had', await until(() => ad.ev(id => { const o = SRV.orders.find(x => x.id === id); return o && o.items[0].n.ar === 'لاتيه'; }, oA.id)));
  await cu.click('[data-a="cat"][data-id="hot"]');
  check('customer: the new name and price show without a reload', await until(async () => { await cuSync(); return cu.has('لاتيه واي'); }));
  // closing with changes asks first
  await ad.click('[data-a="pEdit"][data-id="cap"]');
  await ad.fill('#pe-ar', 'كابتشينو تجربة');
  await ad.click('.sheet [data-a="close"]');
  check('edit: closing with unsaved changes asks first', await ad.page.locator('.dlg').count() === 1 && await ad.has('تجاهل التعديلات؟'));
  await ad.click('[data-a="dlgNo"]');
  check('edit: "cancel" keeps the form with what was typed', await ad.ev(() => UI.sheet && UI.sheet.k === 'prod' && UI.pe.v.ar === 'كابتشينو تجربة'));
  await ad.click('.sheet [data-a="close"]'); await ad.click('[data-a="dlgYes"]');
  check('edit: "discard" closes it and nothing changed', await ad.ev(() => !UI.sheet && !UI.pe) && (await prodOf('cap')).ar === 'كابتشينو');
  await ad.click('[data-a="pEdit"][data-id="cap"]'); await ad.click('.sheet [data-a="close"]');
  check('edit: closing without changes does not ask', await ad.ev(() => !UI.sheet && !UI.dlg));

  // ---- photos: replace (here as Safari on the iPhone does it: it writes no WebP, so the page sends JPEG), remove
  await ad.ev(() => { const o = HTMLCanvasElement.prototype.toBlob; window.__toBlob = o; HTMLCanvasElement.prototype.toBlob = function (cb, type, q) { return o.call(this, cb, type === 'image/webp' ? 'image/png' : type, q); }; });
  await ad.click('[data-a="adCat"][data-id="goods"]');
  await ad.click('[data-a="pEdit"][data-id="cup16"]');
  const oldImg = await ad.ev(() => UI.pe.v.img && UI.pe.v.img.id);
  check('photo: a product of the first menu has its photo in the form', /^[0-9a-f]{32}$/.test(oldImg || ''));
  [fc] = await Promise.all([ad.page.waitForEvent('filechooser'), ad.page.locator('[data-a="pePhoto"]').click()]);
  await fc.setFiles({ name: 'cups.png', mimeType: 'image/png', buffer: png(900, 1200, 'photo') });
  check('photo: replaced in the form', await until(() => ad.ev(o => UI.pe && !UI.pe.up && UI.pe.v.img && UI.pe.v.img.id !== o, oldImg), 20000));
  const rep = await ad.ev(() => UI.pe.v.img);
  await ad.click('[data-a="peSave"]');
  check('photo: saved on the product; a photo to the edges fills the tile', await until(async () => ((await prodOf('cup16')).img || {}).id === rep.id) && rep.f === 'v');
  check('photo: the Safari way arrives as JPEG', (await fetch(BASE + '/api/img/' + rep.id)).headers.get('content-type') === 'image/jpeg' && JSON.stringify(await imgSize(ad, '/api/img/' + rep.id)) === '[750,1000]');
  await ad.ev(() => { HTMLCanvasElement.prototype.toBlob = window.__toBlob; });
  await ad.click('[data-a="pEdit"][data-id="matchapowder"]');
  await ad.click('[data-a="peNoPhoto"]');
  check('photo: removing it shows the drawing instead', await ad.page.locator('.pe-pv .im').count() === 0 && await ad.page.locator('.pe-pv svg').count() === 1 && await ad.has('إضافة صورة'));
  await ad.click('[data-a="peSave"]');
  check('photo: saved without a photo', await until(async () => (await prodOf('matchapowder')).img === null));
  await cu.click('[data-a="cat"][data-id="goods"]');
  check('customer: the replaced photo and the drawing show without a reload', await until(async () => { await cuSync(); return cu.ev(([a, b]) => { const r = document.querySelector(`[data-a="product"][data-id="${a}"] .im`), m = document.querySelector(`[data-a="product"][data-id="${b}"] .pt`); return !!r && !!m && !m.querySelector('.im') && !!m.querySelector('svg'); }, ['cup16', 'matchapowder']); }));
  check('customer: the photo of the cups is the new one', await cu.ev(id => document.querySelector('[data-a="product"][data-id="cup16"] .im').style.backgroundImage.includes(id), rep.id));
  await cu.shot('2-photos');

  // ---- delete a product
  await ad.click('[data-a="adCat"][data-id="cold"]');
  await ad.click(`[data-a="pEdit"][data-id="${added.id}"]`);
  await ad.click('[data-a="peDel"]');
  check('delete: asks first and says the old orders stay', await ad.page.locator('.dlg').count() === 1 && await ad.has('الطلبات السابقة تبقى كما هي'));
  await ad.click('[data-a="dlgYes"]');
  check('delete: gone from the list and from the menu (kept for the old orders)', await until(async () => !(await ad.ev(id => !!document.querySelector(`[data-a="pEdit"][data-id="${id}"]`), added.id)) && (await prodOf(added.id)).gone === 1));
  const refused = await tryOrder({ items: [{ pid: added.id, sel: {}, qty: 1 }] });
  check('delete: the server refuses a new order with it', refused._status === 409 && refused.error === 'stock', refused);
  await ad.nav('orders');
  check('delete: the order made before still shows the name on the admin page', await until(() => ad.ev(id => { const r = document.querySelector(`.aor[data-id="${id}"]`); return !!r && r.textContent.includes('موهيتو القهوة'); }, o1.id)));
  await ad.nav('menu');
  await cu.click('[data-a="cat"][data-id="cold"]');
  check('customer: it leaves the menu and the cart, with a note', await until(async () => { await cuSync(); return cu.ev(id => !document.querySelector(`[data-a="product"][data-id="${id}"]`) && !S.cart.some(c => c.pid === id), added.id); }) && await until(() => cu.said('أزلنا من السلة')));

  // ---- categories
  await ad.click('[data-a="catMgr"]');
  check('categories: listed in menu order with their kind and product count', await ad.page.locator('.sheet .cat-r').count() === SEED.cats.length && await ad.has('طلبات الفرع') && await ad.has('منتجات المحمصة'));
  check('categories: the first cannot move up, the last cannot move down', await ad.ev(() => { const up = document.querySelectorAll('.sheet [data-a="catMove"][data-d="-1"]'), dn = document.querySelectorAll('.sheet [data-a="catMove"][data-d="1"]'); return up[0].disabled && dn[dn.length - 1].disabled && !up[1].disabled; }));
  await ad.shot('5c-categories');
  await ad.click('.sheet [data-a="catAdd"]');
  await ad.fill('.sheet [data-bind="fm.v.ar"]', 'أدوات التحضير');
  await ad.fill('.sheet [data-bind="fm.v.en"]', 'Brewing tools');
  check('categories: the kind has to be picked', await ad.ev(() => document.querySelector('[data-a="fmSave"]').disabled));
  await ad.click('[data-a="fmPick"][data-v="retail"]');
  await ad.click('[data-a="fmSave"]');
  check('categories: added, last, and the list is back', await until(() => ad.ev(() => UI.sheet && UI.sheet.k === 'cats' && CATS[CATS.length - 1].ar === 'أدوات التحضير')));
  const nc = (await menuNow()).cats.find(c => c.ar === 'أدوات التحضير');
  check('categories: the server has it, as roastery products', nc && nc.kind === 'retail' && nc.en === 'Brewing tools', nc);
  await ad.click(`.sheet [data-a="catMove"][data-id="${nc.id}"][data-d="-1"]`);
  const liveCats = async () => (await menuNow()).cats.filter(c => !c.gone).map(c => c.id);
  check('categories: moved up one', await until(async () => { const l = await liveCats(); return l[l.length - 2] === nc.id && l[l.length - 1] === 'goods'; }));
  await ad.click(`.sheet [data-a="catEdit"][data-id="${nc.id}"]`);
  await ad.fill('.sheet [data-bind="fm.v.ar"]', 'أدوات القهوة');
  await ad.click('[data-a="fmSave"]');
  check('categories: renamed', await until(async () => (await menuNow()).cats.find(c => c.id === nc.id).ar === 'أدوات القهوة'));
  await cuSync();
  check('customer: an empty category is not shown', await until(async () => { await cuSync(); return cu.ev(id => CAT[id] && !document.querySelector(`.chips [data-a="cat"][data-id="${id}"]`), nc.id); }));
  await ad.click('.sheet [data-a="close"]');
  await ad.click(`[data-a="adCat"][data-id="${nc.id}"]`);
  check('categories: the admin sees it, empty, with a button to add a product', await ad.has('لا توجد منتجات في هذا القسم بعد'));
  await ad.click('#admenu [data-a="pNew"]');
  check('add: the free-shipping switch shows for roastery products', await ad.ev(id => UI.pe.v.cats.join() === id, nc.id) && await ad.page.locator('[data-a="peFlag"][data-k="fship"]').count() === 1);
  await ad.click('.pe-cats [data-a="peCat"][data-id="hot"]');
  check('add: a category of the other kind replaces the choice, with a note', await ad.ev(() => UI.pe.v.cats.join() === 'hot') && await until(() => ad.said('من نوع آخر')));
  await ad.click(`.pe-cats [data-a="peCat"][data-id="${nc.id}"]`);
  await ad.click('.pe-cats [data-a="peCat"][data-id="goods"]');
  check('add: two categories of the same kind, in menu order', await ad.ev(id => UI.pe.v.cats.join() === id + ',goods', nc.id));
  await ad.fill('#pe-ar', 'مطحنة يدوية'); await ad.fill('#pe-price', '150');
  await ad.click('[data-a="peFlag"][data-k="fship"]');
  await ad.click('[data-a="peMore"]');
  await ad.fill('#pe-sar', 'قطعة واحدة');
  await ad.click('[data-a="peDetAdd"]');
  await ad.page.locator('.pe-dr select').last().selectOption('origin');
  await ad.fill('[data-bind="pe.v.d.0.ar"]', 'اليابان');
  await ad.fill('#pe-bar', 'جديد');
  await ad.shot('5d-product-more');
  await ad.click('[data-a="peSave"]');
  const grinder = await until(async () => (await menuNow()).products.find(p => p.ar === 'مطحنة يدوية'));
  check('add: saved with free shipping, the line under the name, a detail row and a badge', grinder && grinder.fship === true && grinder.cats.join() === nc.id + ',goods' && grinder.sub.ar === 'قطعة واحدة' && grinder.d[0].k.ar === 'المنشأ' && grinder.d[0].v.ar === 'اليابان' && grinder.badge.ar === 'جديد', grinder);
  const shipped = await place({ mode: 'ship', carrier: 'Aramex', addr: { city: 'المدينة', street: 'شارع' }, items: [{ pid: grinder.id, sel: {}, qty: 1 }] });
  check('add: a shipped order with it pays no shipping', near(shipped.ship, 0) && near(shipped.total, 150), shipped);
  check('customer: the category shows once it has a product, renamed', await until(async () => { await cuSync(); return cu.ev(id => { const c = document.querySelector(`.chips [data-a="cat"][data-id="${id}"]`); return !!c && c.textContent.includes('أدوات القهوة'); }, nc.id); }));
  await cu.click(`[data-a="cat"][data-id="${nc.id}"]`);
  await cu.click(`[data-a="product"][data-id="${grinder.id}"]`);
  check('customer: its page shows the badge, the line under the name and the detail row', await cu.has('قطعة واحدة') && await cu.has('اليابان') && await cu.has('المنشأ'));
  await cu.shot('3-grinder');
  await cu.click('.sheet [data-a="close"]');
  await ad.click('[data-a="catMgr"]');
  await ad.click(`.sheet [data-a="catDel"][data-id="${nc.id}"]`);
  check('categories: one with products cannot be deleted (it says why)', await until(() => ad.said('انقلها إلى قسم آخر أو احذفها أولًا')) && await ad.page.locator('.dlg').count() === 0);
  await ad.click(`.sheet [data-a="catEdit"][data-id="${nc.id}"]`);
  check('categories: its kind cannot change while it has products', await ad.ev(() => [...document.querySelectorAll('.sheet [data-a="fmPick"]')].every(b => b.disabled)) && await ad.has('لا يتغيّر نوع قسم فيه منتجات'));
  await ad.click('.sheet [data-a="close"]');
  await ad.click(`[data-a="adCat"][data-id="${nc.id}"]`);
  await ad.click(`[data-a="pEdit"][data-id="${grinder.id}"]`); await ad.click('[data-a="peDel"]'); await ad.click('[data-a="dlgYes"]');
  await until(async () => (await prodOf(grinder.id)).gone === 1);
  await ad.click('[data-a="catMgr"]');
  await ad.click(`.sheet [data-a="catDel"][data-id="${nc.id}"]`);
  check('categories: an empty one asks, then goes', await ad.page.locator('.dlg').count() === 1);
  await ad.click('[data-a="dlgYes"]');
  check('categories: deleted on the server', await until(async () => (await menuNow()).cats.find(c => c.id === nc.id).gone === 1) && await ad.page.locator('.sheet .cat-r').count() === SEED.cats.length);
  await ad.click('.sheet [data-a="close"]');
  check('menu: back on a category that exists', await ad.ev(() => CATS.some(c => c.id === UI.ad.cat)));
  await ad.shot('5-menu-after');

  // ======================================================================= branches
  await ad.nav('branches');
  check('branches: three branches with hours and counts', await ad.page.locator('.adm-sc section.ac').count() === 3);
  await ad.click('[data-a="branchPause"][data-id="b2"]');
  check('branches: pausing b2 reaches customers', await until(async () => ((await pub()).br.b2 || {}).pause === true) && await until(() => ad.has('متوقف مؤقتًا')));
  check('branches: the server refuses orders to the paused branch', (await tryOrder({ branch: 'b2' })).error === 'paused');
  await ad.shot('6-branches');
  await ad.click('[data-a="branchPause"][data-id="b2"]');
  check('branches: resuming works', await until(async () => !((await pub()).br.b2 || {}).pause));

  // ---- add a branch: name, address, hours and its place on the map
  await ad.click('[data-a="brNew"]');
  check('branch: the form opens; saving needs a name and an address', await ad.ev(() => UI.sheet.k === 'brf' && document.querySelector('[data-a="brSave"]').disabled));
  await ad.fill('#bf-ar', 'فرع قباء');
  await ad.fill('#bf-en', 'Quba branch');
  await ad.fill('#bf-aar', 'طريق قباء، المدينة المنورة');
  check('branch: opening and closing times are asked unless it is open all day', await ad.page.locator('#bf-open').count() === 1 && await ad.page.locator('#bf-close').count() === 1 && await ad.page.locator('[data-a="bfAllDay"].on').count() === 0);
  await ad.page.fill('#bf-open', '07:00'); await ad.page.fill('#bf-close', '01:30'); await wait(150);
  await ad.fill('#bf-loc', '24.4398, 39.6172');
  check('branch: pasted coordinates are read and shown', await until(() => ad.ev(() => UI.bf && UI.bf.v.lat === 24.4398 && UI.bf.v.lng === 39.6172)) && await until(() => ad.has('تم تحديد الموقع')));
  await ad.shot('6b-branch-form');
  await ad.click('[data-a="brSave"]');
  const nb = await until(async () => (await menuNow()).branches.find(b => b.ar === 'فرع قباء'));
  check('branch: saved with its hours and place', nb && JSON.stringify(nb.h) === '[420,1530]' && nb.lat === 24.4398 && nb.lng === 39.6172 && nb.en === 'Quba branch' && nb.addr.ar === 'طريق قباء، المدينة المنورة', nb);
  check('branch: listed with its hours and its place', await until(() => ad.has('فرع قباء')) && await ad.has('من 07:00 إلى 01:30') && await ad.page.locator(`[data-a="brEdit"][data-id="${nb.id}"]`).count() === 1);
  const ob = await place({ branch: nb.id });
  check('branch: takes orders straight away', ob.branch === nb.id);
  // the customer phone: the new branch, its hours, the way there, the distance
  await cu.ctx.grantPermissions(['geolocation'], { origin: BASE }); await cu.ctx.setGeolocation({ latitude: 24.4672, longitude: 39.6111 });
  await cu.ev(() => { UI.sheet = null; UI.stack = []; UI.tab = 'branches'; render(); });
  check('customer: the new branch shows without a reload, with its hours and directions', await until(async () => { await cuSync(); return cu.has('فرع قباء'); }) && await cu.has('من 07:00 إلى 01:30') && await cu.page.locator(`.br[data-id="${nb.id}"] a.dir`).count() === 1);
  check('customer: the directions open Google Maps at the branch', (await cu.page.locator(`.br[data-id="${nb.id}"] a.dir`).getAttribute('href')).includes('destination=24.4398,39.6172'));
  await cu.click('[data-a="nearMe"]');
  check('customer: from the phone\'s location, the distance shows and the nearest comes first', await until(() => cu.has('يبعد عنك')) && await cu.ev(id => document.querySelector('.br').dataset.id === id, nb.id) && /3\.\d\d كم/.test(await cu.txt()));
  await cu.shot('4-branches');
  await cu.click(`.br[data-id="${nb.id}"] b`);
  check('customer: picks it', await cu.ev(id => S.branch === id, nb.id));
  // change it: all day, a place from a full Google Maps link; a short link the server cannot open here says so
  await ad.click(`[data-a="brEdit"][data-id="${nb.id}"]`);
  check('branch: the form shows it as saved', await ad.ev(() => UI.bf.v.ar === 'فرع قباء' && UI.bf.v.open === '07:00' && UI.bf.v.close === '01:30' && UI.bf.v.lat === 24.4398 && !UI.bf.v.allDay));
  await ad.fill('#bf-ar', 'فرع قباء الجديد');
  await ad.click('[data-a="bfAllDay"]');
  check('branch: open all day hides the times', await ad.page.locator('#bf-open').count() === 0);
  await ad.click('[data-a="bfNoLoc"]');
  await ad.fill('#bf-loc', 'https://maps.app.goo.gl/WhyQuba');
  check('branch: a short link goes to the server, which cannot reach the internet here: it says so and keeps the form', await until(() => ad.ev(() => UI.bf && !UI.bf.busy && !!UI.bf.msg && UI.bf.v.lat === null), 15000) && await ad.page.locator('.sheet .em').count() === 1);
  await ad.fill('#bf-loc', 'https://www.google.com/maps/place/Quba/@24.43,39.61,17z/data=!3m1!4b1!3d24.4391!4d39.6177');
  check('branch: a full Google Maps link is read here', await until(() => ad.ev(() => UI.bf && UI.bf.v.lat === 24.4391 && UI.bf.v.lng === 39.6177)));
  await ad.click('[data-a="brSave"]');
  check('branch: changed on the server', await until(async () => { const b = (await menuNow()).branches.find(x => x.id === nb.id); return b.ar === 'فرع قباء الجديد' && b.h === '24' && b.lat === 24.4391; }));
  check('customer: the new name and hours show without a reload', await until(async () => { await cuSync(); return (await cu.has('فرع قباء الجديد')) && (await cu.ev(id => document.querySelector(`.br[data-id="${id}"]`).textContent.includes('24 ساعة'), nb.id)); }));
  // delete it: not while an order there is unfinished
  await ad.click(`[data-a="brEdit"][data-id="${nb.id}"]`);
  await ad.click('[data-a="brDel"]');
  check('branch: deleting asks first', await ad.page.locator('.dlg').count() === 1 && await ad.has('الطلبات السابقة تبقى كما هي'));
  await ad.click('[data-a="dlgYes"]');
  check('branch: not while it has an unfinished order (it says why)', await until(() => ad.said('لم تكتمل')) && (await menuNow()).branches.find(x => x.id === nb.id).gone === undefined);
  await recv.call('/recv/order', { id: ob.id, op: 'reject', reason: 'close' });
  await ad.click('[data-a="brDel"]'); await ad.click('[data-a="dlgYes"]');
  check('branch: deleted, kept on the server for the old orders', await until(async () => (await menuNow()).branches.find(x => x.id === nb.id).gone === 1) && await until(async () => !(await ad.ev(id => !!document.querySelector(`[data-a="brEdit"][data-id="${id}"]`), nb.id))));
  check('customer: it leaves the list and the phone picks another branch', await until(async () => { await cuSync(); return cu.ev(id => !document.querySelector(`.br[data-id="${id}"]`) && S.branch !== id && !!BR[S.branch] && !BR[S.branch].gone, nb.id); }));
  check('customer: the rejected order still names it', await (async () => { const o = (await cust('/my/sync', { since: 0, srev: -1 })).orders.find(x => x.id === ob.id); return !!o && o.rej; })());

  // ======================================================================= offers and fees
  await ad.nav('promo');
  check('offers: the starting code is listed', await ad.has('WHY10'));
  // membership tiers: the management page changes them; the customer page and the next orders follow
  check('tiers: listed with the start values (basic 8, silver 9 from 500, gold 10 from 1,000)', await ad.ev(() => document.querySelectorAll('[data-a="edTier"]').length === 3 && JSON.stringify(SRV.tiers) === JSON.stringify(TIERS)) && await ad.has('عضوية فضية') && await ad.has('تفتح عند 500 نقطة') && await ad.has('تفتح عند 1,000 نقطة'));
  await ad.click('[data-a="edTier"][data-id="silver"]');
  await ad.fill('.sheet [data-bind="fm.v.min"]', '1500');
  check('tiers: silver cannot need more points than gold', await ad.ev(() => document.querySelector('[data-a="fmSave"]').disabled));
  await ad.fill('.sheet [data-bind="fm.v.min"]', '400'); await ad.fill('.sheet [data-bind="fm.v.per"]', '7');
  check('tiers: silver cannot give fewer points than basic', await ad.ev(() => document.querySelector('[data-a="fmSave"]').disabled));
  await ad.fill('.sheet [data-bind="fm.v.per"]', '9');
  await ad.click('[data-a="fmSave"]');
  check('tiers: silver now opens at 400, for customers too', await until(async () => (await pub()).tiers[1].min === 400) && await until(() => ad.has('تفتح عند 400 نقطة')));
  await ad.click('[data-a="edTier"][data-id="basic"]');
  check('tiers: basic always opens at zero (no field for it)', await ad.page.locator('.sheet [data-bind="fm.v.min"]').count() === 0);
  await ad.fill('.sheet [data-bind="fm.v.per"]', '9'); await ad.click('[data-a="fmSave"]');
  check('tiers: basic now earns 9 for every 10 SAR', await until(async () => (await pub()).tiers[0].per10 === 9));
  const tPhone = '5' + String(10000000 + Math.floor(Math.random() * 89999999));
  const t9 = await place({ cust: { name: 'سارة', phone: tPhone }, items: [{ pid: 'latte', sel: {}, qty: 3 }] });
  check('tiers: the next order of a new customer is basic and earns 9 for every 10 SAR', t9.tier === 'basic' && t9.earn === Math.floor(Math.round(t9.pay * 100) * 9 / 1000) && t9.earn > 0, { pay: t9.pay, earn: t9.earn, tier: t9.tier });
  check('tiers: the customer page shows the new values on its cards', await until(async () => { await cuSync(); return cu.ev(() => SRV.tiers[0].per10 === 9 && SRV.tiers[1].min === 400); }));
  // back to the start values: the rest of this test expects them
  await ad.click('[data-a="edTier"][data-id="basic"]'); await ad.fill('.sheet [data-bind="fm.v.per"]', '8'); await ad.click('[data-a="fmSave"]');
  await until(async () => (await pub()).tiers[0].per10 === 8);
  await ad.click('[data-a="edTier"][data-id="silver"]'); await ad.fill('.sheet [data-bind="fm.v.min"]', '500'); await ad.click('[data-a="fmSave"]');
  check('tiers: back to the start values', await until(async () => JSON.stringify((await pub()).tiers) === JSON.stringify([{ id: 'basic', min: 0, per10: 8 }, { id: 'silver', min: 500, per10: 9 }, { id: 'gold', min: 1000, per10: 10 }])));
  // 0.6: rewards are managed here
  await ad.click('[data-a="rwAdd"][data-k="p"]');
  check('rewards: a product reward needs a product and points', await ad.ev(() => document.querySelector('[data-a="fmSave"]').disabled));
  await ad.click('.sheet [data-a="fmPick"][data-k="pid"][data-v="cookie"]');
  await ad.fill('.sheet [data-bind="fm.v.pts"]', '90'); await ad.click('[data-a="fmSave"]');
  check('rewards: the new product reward is public, named after the product', await until(async () => (await pub()).rewards.some(r => r.pid === 'cookie' && r.pts === 90 && r.ar === 'كوكيز شوكولاتة')));
  const nrw = (await pub()).rewards.find(r => r.pid === 'cookie' && r.pts === 90);
  check('rewards: the customer page lists it', await until(async () => { await cuSync(); return cu.ev(id => REWARDS.some(r => r.id === id), nrw.id); }));
  await ad.click(`[data-a="rwOn"][data-id="${nrw.id}"]`);
  check('rewards: switched off, customers no longer get it', await until(async () => !(await pub()).rewards.some(r => r.id === nrw.id)) && await until(async () => { await cuSync(); return cu.ev(id => !REWARDS.some(r => r.id === id), nrw.id); }));
  await ad.click(`[data-a="rwEdit"][data-id="${nrw.id}"]`); await ad.click('[data-a="fmExtra"]');
  check('rewards: deleted', await until(() => ad.ev(id => !SRV.rewards.some(r => r.id === id), nrw.id)));
  await ad.click('[data-a="rwAdd"][data-k="c"]');
  await ad.fill('.sheet [data-bind="fm.v.credit"]', '15'); await ad.fill('.sheet [data-bind="fm.v.pts"]', '300'); await ad.click('[data-a="fmSave"]');
  check('rewards: a wallet credit reward gets its name by itself', await until(async () => (await pub()).rewards.some(r => r.credit === 15 && r.pts === 300 && r.ar === 'رصيد 15 ريال في المحفظة')));
  // 0.6: home banners are managed here
  check('banners: the five first banners are listed with edit and order buttons', await ad.ev(() => document.querySelectorAll('[data-a="bnEdit"]').length === 5 && document.querySelectorAll('[data-a="bnMove"]').length === 10));
  await ad.click('[data-a="bnAdd"]');
  check('banners: a new banner needs a picture or a title', await ad.ev(() => document.querySelector('[data-a="bnSave"]').disabled));
  await ad.fill('.sheet [data-bind="bnf.v.tar"]', 'عرض الشتاء');
  const [bfc] = await Promise.all([ad.page.waitForEvent('filechooser'), ad.page.locator('[data-a="bnPhoto"]').click()]);
  await bfc.setFiles({ name: 'winter.png', mimeType: 'image/png', buffer: png(1200, 600, 'photo') });
  check('banners: the photo uploads and shows in the form', await until(() => ad.ev(() => !!(UI.bnf && UI.bnf.v.img) && !!document.querySelector('.bf-pv[style*="/api/img/"]')), 15000));
  await ad.click('[data-a="bnTo"][data-v="prod"]');
  check('banners: pointing to a product needs the product', await ad.ev(() => document.querySelector('[data-a="bnSave"]').disabled));
  await ad.page.selectOption('.sheet select[data-bind="bnf.v.pid"]', 'cookie'); await wait(200);
  await ad.click('[data-a="bnSave"]');
  check('banners: the new banner is public with its photo and product', await until(async () => (await pub()).banners.some(b => (b.t || {}).ar === 'عرض الشتاء' && b.a === 'cookie' && b.img && Math.abs(b.img.r - 2) < 0.01)));
  const nbn = (await pub()).banners.find(b => (b.t || {}).ar === 'عرض الشتاء');
  check('banners: the customer home shows it with the photo', await until(async () => { await cuSync(); await cu.ev(() => { UI.tab = 'home'; render(); }); return cu.ev(id => bannersLive().some(b => b.id === id && b.img) && !!document.querySelector(`.bn[style*="${'/api/img/'}"]`), nbn.id); }));
  await ad.click(`[data-a="bnMove"][data-id="${nbn.id}"][data-d="up"]`);
  check('banners: moved up one place', await until(async () => { const l = (await pub()).banners; return l[l.length - 2].id === nbn.id; }));
  await ad.click('[data-a="bnEdit"][data-id="bn3"]');
  await ad.fill('.sheet [data-bind="bnf.v.tar"]', 'هدية لمن تحب'); await ad.click('[data-a="bnSave"]');
  check('banners: a first banner takes new words and keeps its place', await until(async () => { const l = (await pub()).banners; return l[2].id === 'bn3' && (l[2].t || {}).ar === 'هدية لمن تحب'; }));
  await ad.click(`[data-a="bnEdit"][data-id="${nbn.id}"]`); await ad.click('[data-a="bnDel"]'); await ad.click('[data-a="dlgYes"]');
  check('banners: deleted', await until(async () => !(await pub()).banners.some(b => b.id === nbn.id)));
  await ad.click('[data-a="codeAdd"]');
  await ad.fill('.sheet [data-bind="fm.v.c"]', 'ab');
  check('offers: a two-letter code cannot be saved', await ad.ev(() => document.querySelector('[data-a="fmSave"]').disabled));
  await ad.fill('.sheet [data-bind="fm.v.c"]', 'why 20');
  check('offers: a code with a space cannot be saved', await ad.ev(() => document.querySelector('[data-a="fmSave"]').disabled));
  await ad.fill('.sheet [data-bind="fm.v.c"]', 'why20'); await ad.fill('.sheet [data-bind="fm.v.n"]', '95');
  check('offers: a discount above 90 cannot be saved', await ad.ev(() => document.querySelector('[data-a="fmSave"]').disabled));
  await ad.fill('.sheet [data-bind="fm.v.n"]', '20');
  await ad.click('[data-a="fmSave"]');
  check('offers: new code is live for customers (upper-cased, 20%)', await until(async () => ((await pub()).codes.WHY20 || {}).pct === 20));
  const withCode = await place({ code: 'why20', items: [{ pid: 'latte', sel: {}, qty: 2 }] });
  check('offers: an order with it gets 20% off', near(withCode.disc, Math.round(withCode.sub * 0.2 * 100) / 100) && withCode.disc > 0, { sub: withCode.sub, disc: withCode.disc });
  await ad.click('[data-a="adCode"][data-id="WHY20"]');
  check('offers: switching it off makes it invalid for customers', await until(async () => !(await pub()).codes.WHY20) && (await tryOrder({ code: 'WHY20' })).error === 'bad_code');
  await ad.click('[data-a="adCode"][data-id="WHY20"]');
  await until(async () => ((await pub()).codes.WHY20 || {}).pct === 20);
  await ad.click('[data-a="edPct"][data-id="WHY20"]');
  await ad.fill('.sheet [data-bind="fm.v.n"]', '15'); await ad.click('[data-a="fmSave"]');
  check('offers: changing the percentage works', await until(async () => ((await pub()).codes.WHY20 || {}).pct === 15));
  // banners
  const bnIds = await ad.ev(() => BANNERS.map(b => b.id));
  for (const id of bnIds.slice(0, -1)) await ad.click(`[data-a="adBn"][data-id="${id}"]`);
  check('offers: four banners switched off reach the customer app', await until(async () => { const b = (await pub()).bn; return bnIds.slice(0, -1).every(id => b[id] === false); }));
  await ad.click(`[data-a="adBn"][data-id="${bnIds[bnIds.length - 1]}"]`);
  check('offers: the last banner cannot be switched off', await until(() => ad.said('إعلان واحد')) && !((await pub()).bn[bnIds[bnIds.length - 1]] === false));
  for (const id of bnIds.slice(0, -1)) await ad.click(`[data-a="adBn"][data-id="${id}"]`);
  check('offers: banners back on', await until(async () => Object.values((await pub()).bn).every(v => v !== false)));
  // delivery switch and fee
  await ad.click('[data-a="adDelOn"]');
  check('offers: delivery off reaches customers', await until(async () => (await pub()).delivery.on === false));
  const noDel = await tryOrder({ mode: 'delivery', addr: { city: 'المدينة المنورة', street: 'حي قباء' } });
  check('offers: the server refuses delivery orders while it is off', noDel._status === 409 && noDel.error === 'delivery_off', noDel);
  await ad.click('[data-a="adDelOn"]');
  check('offers: delivery back on', await until(async () => (await pub()).delivery.on === true));
  await ad.click('[data-a="edDel"]');
  await ad.fill('.sheet [data-bind="fm.v.n"]', '250');
  check('offers: a delivery fee above 200 cannot be saved', await ad.ev(() => document.querySelector('[data-a="fmSave"]').disabled));
  await ad.fill('.sheet [data-bind="fm.v.n"]', '15'); await ad.click('[data-a="fmSave"]');
  check('offers: new delivery fee is public', await until(async () => (await pub()).delivery.fee === 15));
  const del15 = await place({ mode: 'delivery', addr: { city: 'المدينة المنورة', street: 'حي قباء' } });
  check('offers: the next delivery order carries the 15 SAR fee', near(del15.ship, 15), del15.ship);
  await ad.click('[data-a="edShip"]');
  await ad.fill('.sheet [data-bind="fm.v.n"]', '30'); await ad.click('[data-a="fmSave"]');
  check('offers: new shipping fee is public', await until(async () => (await pub()).ship === 30));
  // 0.7: the smallest delivery order and how far the drivers go
  check('offers: no minimum and no distance limit at first', await ad.has('الحد الأدنى لطلب التوصيل') && await ad.has('نطاق التوصيل') && await ad.has('بدون حد أدنى') && await ad.has('بدون حد للمسافة'));
  await ad.click('[data-a="edDelMin"]');
  await ad.fill('.sheet [data-bind="fm.v.n"]', '1500');
  check('offers: a minimum above 1000 cannot be saved', await ad.ev(() => document.querySelector('[data-a="fmSave"]').disabled));
  await ad.fill('.sheet [data-bind="fm.v.n"]', '40'); await ad.click('[data-a="fmSave"]');
  check('offers: the minimum is public', await until(async () => (await pub()).delivery.min === 40));
  const small = await tryOrder({ mode: 'delivery', addr: { city: 'المدينة المنورة', street: 'حي قباء' }, items: [{ pid: 'latte', sel: {}, qty: 1 }] });
  check('offers: a delivery under it is refused', small._status === 409 && small.error === 'below_min', small);
  await ad.click('[data-a="edDelKm"]');
  await ad.fill('.sheet [data-bind="fm.v.n"]', '7.5'); await ad.click('[data-a="fmSave"]');
  check('offers: the delivery area is public', await until(async () => (await pub()).delivery.km === 7.5) && await until(() => ad.has('حتى 7.5 كم من الفرع')));
  await ad.shot('7b-delivery-limits');
  await ad.click('[data-a="edDelMin"]'); await ad.fill('.sheet [data-bind="fm.v.n"]', '0'); await ad.click('[data-a="fmSave"]');
  await ad.click('[data-a="edDelKm"]'); await ad.fill('.sheet [data-bind="fm.v.n"]', '0'); await ad.click('[data-a="fmSave"]');
  check('offers: both back to no limit', await until(async () => { const d = (await pub()).delivery; return d.min === 0 && d.km === 0; }));
  await ad.shot('7-offers');

  // ======================================================================= news (0.6.4): written here, read in the customer's News tab
  await ad.nav('news');
  check('news: the three first news are listed, newest on top, with order, edit and on/off', await ad.ev(() => document.querySelectorAll('[data-a="nwEdit"]').length === 3 && document.querySelectorAll('[data-a="nwMove"]').length === 6 && document.querySelectorAll('[data-a="nwOn"]').length === 3));
  await ad.click('[data-a="nwAdd"]');
  check('news: a new item needs its title', await ad.ev(() => document.querySelector('[data-a="nwSave"]').disabled));
  await ad.fill('.sheet [data-bind="nwf.v.tar"]', 'افتتاح فرع جديد');
  await ad.fill('.sheet [data-bind="nwf.v.bar"]', 'افتتحنا فرعًا جديدًا في حي العزيزية.\nالافتتاح يوم الخميس الساعة 4 العصر.');
  const [nfc] = await Promise.all([ad.page.waitForEvent('filechooser'), ad.page.locator('[data-a="nwPhoto"]').click()]);
  await nfc.setFiles({ name: 'branch.png', mimeType: 'image/png', buffer: png(1200, 750, 'photo') });
  check('news: the photo uploads and shows in the form', await until(() => ad.ev(() => !!(UI.nwf && UI.nwf.v.img) && !!document.querySelector('.bf-pv[style*="/api/img/"]')), 15000));
  await ad.shot('7b-news-form');
  await ad.click('[data-a="nwSave"]');
  check('news: published on top for the customers, with its photo and two paragraphs', await until(async () => { const l = (await pub()).news; return l[0] && l[0].t.ar === 'افتتاح فرع جديد' && l[0].img && l[0].b.ar.split('\n').length === 2; }));
  const nn = (await pub()).news[0];
  check('news: the customer reads it in the News tab, photo and paragraphs', await until(async () => { await cuSync(); await cu.ev(() => { setStack([]); UI.tab = 'news'; render(); }); return cu.ev(id => document.querySelector('.nw').dataset.id === id && !!document.querySelector('.nw .cov[style*="/api/img/"]'), nn.id); }));
  await cu.click(`.nw[data-id="${nn.id}"]`);
  check('news: the article shows both paragraphs', await cu.ev(() => document.querySelectorAll('.article p').length === 2 && document.querySelector('.article').innerText.includes('العزيزية')));
  await cu.shot('5-news');
  await cu.ev(() => { setStack([]); render(); });
  await ad.click(`[data-a="nwOn"][data-id="${nn.id}"]`);
  check('news: switched off, customers no longer get it', await until(async () => !(await pub()).news.some(n => n.id === nn.id)) && await ad.ev(id => document.querySelector(`[data-a="nwOn"][data-id="${id}"]`).getAttribute('aria-checked') === 'false', nn.id));
  await ad.click(`[data-a="nwOn"][data-id="${nn.id}"]`);
  check('news: on again', await until(async () => (await pub()).news.some(n => n.id === nn.id)));
  await ad.click(`[data-a="nwMove"][data-id="${nn.id}"][data-d="down"]`);
  check('news: moved down one place', await until(async () => (await pub()).news[1].id === nn.id));
  await ad.click('[data-a="nwEdit"][data-id="n3"]');
  await ad.fill('.sheet [data-bind="nwf.v.tar"]', 'تطبيق واي! صار متاحًا'); await ad.click('[data-a="nwSave"]');
  check('news: a first news item takes a new title and keeps its place and its own picture', await until(async () => { const l = (await pub()).news, x = l.find(n => n.id === 'n3'); return x && x.t.ar === 'تطبيق واي! صار متاحًا' && !x.img && l.indexOf(x) === l.length - 1; }));
  await ad.shot('7c-news');
  await ad.click(`[data-a="nwEdit"][data-id="${nn.id}"]`); await ad.click('[data-a="nwDel"]'); await ad.click('[data-a="dlgYes"]');
  check('news: deleted', await until(async () => !(await pub()).news.some(n => n.id === nn.id)));

  // ======================================================================= drivers
  await ad.nav('drivers');
  check('drivers: none yet, and it says how it works', await ad.has('لا يوجد مناديب بعد') && await ad.has('أول من يأخذه'));
  await ad.click('[data-a="drvAdd"]');
  await ad.fill('.sheet [data-bind="fm.v.name"]', 'نايف'); await ad.fill('.sheet [data-bind="fm.v.pin"]', '12345');
  check('drivers: a five-digit code cannot be saved', await ad.ev(() => document.querySelector('[data-a="fmSave"]').disabled));
  check('drivers: the code field hides what is typed', await ad.ev(() => document.querySelector('.sheet [data-bind="fm.v.pin"]').type === 'password'));
  await ad.fill('.sheet [data-bind="fm.v.pin"]', '555666'); await ad.click('[data-a="fmSave"]');
  check('drivers: added, listed as free', await until(() => ad.has('نايف')) && await ad.has('متاح'));
  const naif = await staffLogin('driver', { name: 'نايف', pin: '555666' });
  check('drivers: he can sign in on the driver link with those', naif._status === 200);
  await ad.click('[data-a="drvAdd"]');
  await ad.fill('.sheet [data-bind="fm.v.name"]', 'نايف'); await ad.fill('.sheet [data-bind="fm.v.pin"]', '999000'); await ad.click('[data-a="fmSave"]');
  check('drivers: the same name twice is refused with a message', await until(async () => ad.said(await ad.ev(() => ERR.exists[0]))));
  await ad.click('.sheet [data-a="close"]');
  const id = (await ad.ev(() => SRV.drivers.find(d => d.name === 'نايف').id));
  await ad.click(`[data-a="drvPin"][data-id="${id}"]`);
  await ad.fill('.sheet [data-bind="fm.v.pin"]', '777888'); await ad.click('[data-a="fmSave"]');
  check('drivers: changing his code signs him out and the old code stops working', await until(async () => (await staffLogin('driver', { name: 'نايف', pin: '555666' }))._status === 401) && (await staffLogin('driver', { name: 'نايف', pin: '777888' }))._status === 200);
  check('drivers: his old session is dead', (await naif.call('/driver/order', { id: oC.id, op: 'take' }))._status === 401);
  await ad.click(`[data-a="drvOn"][data-id="${id}"]`);
  check('drivers: switched off, listed as off, cannot sign in', await until(() => ad.has('موقوف')) && (await staffLogin('driver', { name: 'نايف', pin: '777888' }))._status !== 200);
  await ad.click(`[data-a="drvOn"][data-id="${id}"]`);
  check('drivers: switched on again, can sign in', await until(async () => (await staffLogin('driver', { name: 'نايف', pin: '777888' }))._status === 200));
  // a driver with an order on the road cannot be removed
  await ad.click('[data-a="drvAdd"]');
  await ad.fill('.sheet [data-bind="fm.v.name"]', 'ماجد'); await ad.fill('.sheet [data-bind="fm.v.pin"]', '333444'); await ad.click('[data-a="fmSave"]');
  await until(() => ad.has('ماجد'));
  const maj = await staffLogin('driver', { name: 'ماجد', pin: '333444' });
  const oE = await place({ mode: 'delivery', branch: 'b2', addr: { city: 'المدينة المنورة', street: 'حي قباء' }, items: [{ pid: 'cap', sel: {}, qty: 1 }] });
  await recv.call('/recv/order', { id: oE.id, op: 'accept' }); await recv.call('/recv/order', { id: oE.id, op: 'ready' });
  check('drivers: a driver takes an order', (await maj.call('/driver/order', { id: oE.id, op: 'take' })).ok);
  check('drivers: the list says he has an order now', await until(() => ad.has('معه 1 طلب الآن')));
  await ad.shot('8-drivers');
  const majId = await ad.ev(() => SRV.drivers.find(d => d.name === 'ماجد').id);
  await ad.click(`[data-a="drvDel"][data-id="${majId}"]`);
  check('drivers: removing asks first', await ad.page.locator('.dlg').count() === 1 && await ad.has('ماجد'));
  await ad.click('[data-a="dlgNo"]');
  check('drivers: cancelling keeps him', await ad.page.locator('.dlg').count() === 0 && await ad.has('ماجد'));
  await ad.click(`[data-a="drvDel"][data-id="${majId}"]`); await ad.click('[data-a="dlgYes"]');
  check('drivers: with an order on the road he cannot be removed', await until(async () => ad.said(await ad.ev(() => ERR.busy[0])))  && await ad.has('ماجد'));
  check('drivers: the delivery is finished with the code', (await maj.call('/driver/order', { id: oE.id, op: 'deliver', code: oE.code })).ok);
  await until(() => ad.has('متاح'));
  await ad.click(`[data-a="drvDel"][data-id="${majId}"]`); await ad.click('[data-a="dlgYes"]');
  check('drivers: free again, he is removed and cannot sign in', await until(async () => !(await ad.has('ماجد'))) && (await staffLogin('driver', { name: 'ماجد', pin: '333444' }))._status !== 200);

  // ======================================================================= customers
  // the customer's phone sends what was typed in the sign-up form (email is kept lower-case, the invite code upper-case)
  await cust('/my/sync', { since: 0, srev: -1, name: 'خالد', phone: '566000111', email: 'Khaled@Example.com', birth: '1990-12-25', gender: 'm', invite: 'friend7', mk: true });
  await ad.nav('cust');
  check('customers: the sign-up details reach the admin screen', await until(() => ad.ev(() => { const c = SRV.cust[0]; return !!c && c.email === 'khaled@example.com' && c.birth === '1990-12-25' && c.gender === 'm' && c.invite === 'FRIEND7' && c.mk === true; })));
  check('customers: the customer is listed with last digits, orders and spend', await ad.ev(() => { const t = document.querySelector('.acu').innerText; return t.includes('خالد') && t.includes('0111') && /\d+ طلب/.test(t); }));
  check('customers: each one shows the tier of his last 30 days', await ad.ev(() => SRV.cust.length > 0 && SRV.cust.every(c => ['basic', 'silver', 'gold'].includes(c.tier) && Number.isInteger(c.tpts)) && /عضوية (أساسية|فضية|ذهبية)/.test(document.querySelector('.acu').innerText)));
  const spent = await ad.ev(() => SRV.cust[0].spent), pts0 = await ad.ev(() => SRV.cust[0].pts);
  check('customers: spend is the sum of orders that were not rejected', spent > 0);
  await ad.shot('9-customers');
  const cid = await ad.ev(() => SRV.cust[0].id);
  await ad.click(`[data-a="edPts"][data-id="${cid}"]`);
  check('customers: the sheet shows email, birth date, gender, invite code and marketing consent', await ad.ev(() => { const k = document.querySelector('.sheet .kvs'); const t = k ? k.innerText : ''; return t.includes('khaled@example.com') && t.includes('1990-12-25') && t.includes('ذكر') && t.includes('FRIEND7') && t.includes('موافق') && !t.includes('غير موافق'); }));
  await ad.shot('9b-customer-sheet');
  await ad.fill('.sheet [data-bind="fm.v.n"]', '6000');
  check('customers: more than 5000 points cannot be saved', await ad.ev(() => document.querySelector('[data-a="fmSave"]').disabled));
  await ad.fill('.sheet [data-bind="fm.v.n"]', '0');
  check('customers: zero points cannot be saved', await ad.ev(() => document.querySelector('[data-a="fmSave"]').disabled));
  check('customers: the points field shows what is typed', await ad.ev(() => document.querySelector('.sheet [data-bind="fm.v.n"]').type === 'text'));
  await ad.fill('.sheet [data-bind="fm.v.n"]', '50'); await ad.click('[data-a="fmSave"]');
  check('customers: the customer’s phone is told about the 50 points', await until(async () => ((await cust('/my/sync', { since: 0, srev: -1 })).bonus || []).some(b => b.pts === 50)));

  // ======================================================================= reports
  // the server adds up any period; here every order of the test is from today
  const todaySales = () => ad.ev(() => Math.round(SRV.orders.filter(o => !o.rej && o.day === SRV.today).reduce((a, o) => a + o.total, 0) * 100) / 100);
  const todayN = () => ad.ev(() => SRV.orders.filter(o => !o.rej && o.day === SRV.today).length);
  await ad.nav('home');
  check('reports: the overview points to them (older days live there)', await ad.page.locator('.hero [data-a="adSec"][data-id="report"]').count() === 1);
  await ad.click('.hero [data-a="adSec"][data-id="report"]');
  check('reports: open on this month, from its first day to today', await until(() => ad.ev(() => UI.ad.sec === 'report' && !!document.querySelector('.hero-v'))) && await ad.ev(() => UI.rp.p === 'month' && rpPeriod()[0] === SRV.today.slice(0, 8) + '01' && rpPeriod()[1] === SRV.today));
  const exp = await todaySales(), expN = await todayN();
  check('reports: this month’s sales are the orders that were not rejected', await until(async () => near(await heroSales(ad), exp)), { hero: await heroSales(ad), exp });
  check('reports: orders and average order', await kpi(ad, 'عدد الطلبات') === String(expN) && near(parseFloat(await kpi(ad, 'متوسط قيمة الطلب')), Math.round(exp / expN * 100) / 100), [await kpi(ad, 'عدد الطلبات'), expN]);
  check('reports: one bar for each day of the month so far', await ad.page.locator('.rpc .bar').count() === await ad.ev(() => +SRV.today.slice(8)));
  check('reports: the best day carries its figure', await ad.ev(v => { const b = document.querySelector('.rpc .bar.sel'); return !!b && Math.abs(parseFloat(b.querySelector('.tip').textContent) - v) < 0.006; }, exp));
  await ad.click('[data-a="rpTbl"]');
  check('reports: the table has one row a day, today marked', await ad.page.locator('.hero .tbl tbody tr').count() === await ad.ev(() => +SRV.today.slice(8)) && await ad.ev(() => document.querySelector('.hero .tbl tbody tr:last-child').innerText.includes('اليوم')));
  await ad.click('[data-a="rpTbl"]');
  check('reports: branches add up to the sales', await ad.ev(v => { const rows = [...document.querySelectorAll('.rp-br tbody tr')]; return rows.length === 3 && Math.abs(rows.reduce((a, r) => a + parseFloat(r.children[2].innerText.replace(/[^\d.]/g, '')), 0) - v) < 0.02; }, exp));
  check('reports: best sellers listed with their quantities', await ad.page.locator('.rp-top .top li').count() > 0);
  check('reports: amounts show VAT and the sales without it', await ad.ev(() => { const t = document.querySelector('.rp-amt').innerText; return t.includes('ضريبة القيمة المضافة') && t.includes('بدون الضريبة'); }));
  check('reports: rejected orders are counted apart', await ad.ev(() => /طلبات مرفوضة/.test(document.querySelector('.rp-amt').innerText)));
  await ad.shot('11-reports');
  await ad.click('[data-a="rpP"][data-id="last"]');
  check('reports: last month is empty here (no orders then)', await until(async () => (await heroSales(ad)) === 0) && await ad.has('لا توجد مبيعات في هذه الفترة') && await ad.ev(() => document.querySelector('.rp-bar b').innerText.includes(MONTHS.ar[(+SRV.today.slice(5, 7) + 10) % 12])));
  await ad.click('[data-a="rpP"][data-id="today"]');
  check('reports: today matches the overview', await until(async () => near(await heroSales(ad), exp)));
  await ad.click('[data-a="rpP"][data-id="custom"]');
  check('reports: picking dates starts from the period on screen', await ad.ev(() => UI.rp.f === SRV.today && UI.rp.t === SRV.today) && await ad.page.locator('#rpf').count() === 1);
  const dayBefore = await ad.ev(() => { const d = new Date(SRV.today + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() - 1); return d.toISOString().slice(0, 10); });
  await ad.page.fill('#rpf', await ad.ev(() => SRV.today)); await ad.page.fill('#rpt', dayBefore); await wait(150);
  check('reports: an end before the start cannot be shown', await ad.ev(() => document.querySelector('[data-a="rpApply"]').disabled));
  await ad.page.fill('#rpf', '2020-01-01'); await ad.page.fill('#rpt', await ad.ev(() => SRV.today)); await wait(150);
  check('reports: more than a year cannot be shown', await ad.ev(() => document.querySelector('[data-a="rpApply"]').disabled));
  await ad.page.fill('#rpf', dayBefore); await wait(150);
  check('reports: a valid period can', await ad.ev(() => !document.querySelector('[data-a="rpApply"]').disabled));
  await ad.click('[data-a="rpApply"]');
  check('reports: the chosen period is shown', await until(() => ad.ev(() => UI.rp.cf && document.querySelectorAll('.rpc .bar').length === 2)) && near(await heroSales(ad), exp));
  check('reports: the server refuses a period backwards too', (await (await staffLogin('admin', { pin: '123456' })).call('/admin/report', { from: '2026-02-02', to: '2026-02-01' })).error === 'bad_range');
  // the Excel file (a computer downloads it)
  const [dl] = await Promise.all([ad.page.waitForEvent('download', { timeout: 15000 }), ad.click('[data-a="rpXlsx"]')]);
  const xf = path.join(OUT, 'report.xlsx');
  await dl.saveAs(xf);
  check('reports: Excel is downloaded under the period’s name', /^Why-report-\d{4}-\d{2}-\d{2}_\d{4}-\d{2}-\d{2}\.xlsx$/.test(dl.suggestedFilename()), dl.suggestedFilename());
  const xl = JSON.parse(require('child_process').execFileSync('python3', ['-I', '-c', `
import json, sys, zipfile, re
z = zipfile.ZipFile(sys.argv[1])
book = z.read('xl/workbook.xml').decode()
names = re.findall(r'<sheet name="([^"]+)"', book)
s1 = z.read('xl/worksheets/sheet1.xml').decode()
m = re.search(r'<c r="B9"[^>]*><f>[^<]*</f><v>([^<]+)</v>', s1)
print(json.dumps({"names": names, "sales": float(m.group(1)) if m else None, "ok": z.testzip() is None}))
`, xf]).toString());
  check('reports: the file opens, five sheets, the sales as on screen', xl.ok && xl.names.join(',') === 'الملخص,الأيام,الفروع,المنتجات,الطلبات' && near(xl.sales, exp), xl);

  // ======================================================================= settings
  await ad.nav('set');
  const sound0 = await ad.ev(() => S.sound);
  await ad.click('[data-a="sound"]');
  check('settings: the sound switch flips and is remembered on this device', await ad.ev(s => S.sound === !s && JSON.parse(localStorage.getItem(KEY)).sound === !s, sound0));
  await ad.click('[data-a="pinChange"][data-id="recv"]');
  await ad.fill('.sheet [data-bind="fm.v.cur"]', '111111'); await ad.fill('.sheet [data-bind="fm.v.pin"]', '135790'); await ad.fill('.sheet [data-bind="fm.v.pin2"]', '135791');
  check('settings: two different new codes cannot be saved', await ad.ev(() => document.querySelector('[data-a="fmSave"]').disabled));
  await ad.fill('.sheet [data-bind="fm.v.pin2"]', '135790'); await ad.click('[data-a="fmSave"]');
  check('settings: a wrong current admin code is refused, nothing changes', await until(async () => ad.said(await ad.ev(() => ERR.bad_pin_confirm[0])))  && (await staffLogin('recv', { pin: '654321' }))._status === 200 && await ad.page.locator('.sheet').count() === 1);
  await ad.fill('.sheet [data-bind="fm.v.cur"]', '123456'); await ad.click('[data-a="fmSave"]');
  check('settings: reception code changed: new one works, old one does not', await until(async () => (await staffLogin('recv', { pin: '654321' }))._status === 401) && (await staffLogin('recv', { pin: '135790' }))._status === 200);
  check('settings: the old reception session was signed out', (await recv.call('/recv/order', { id: oC.id, op: 'accept' }))._status === 401);
  await ad.shot('10-settings');

  // wipe
  await ad.click('[data-a="wipeAsk"]');
  check('settings: wiping asks first, in words', await ad.page.locator('.dlg').count() === 1 && await ad.has('لا يمكن التراجع'));
  await ad.click('[data-a="dlgNo"]');
  check('settings: cancel keeps the orders', (await cust('/my/sync', { since: 0, srev: -1 })).orders.length > 0);
  await ad.click('[data-a="wipeAsk"]'); await ad.click('[data-a="dlgYes"]');
  await ad.fill('.sheet [data-bind="fm.v.pin"]', '999999'); await ad.click('[data-a="fmSave"]');
  check('settings: wrong admin code does not wipe', await until(async () => ad.said(await ad.ev(() => ERR.bad_pin_confirm[0]))) && (await cust('/my/sync', { since: 0, srev: -1 })).orders.length > 0);
  await ad.fill('.sheet [data-bind="fm.v.pin"]', '123456'); await ad.click('[data-a="fmSave"]');
  check('settings: the right code deletes orders and customers', await until(async () => (await cust('/my/sync', { since: 0, srev: -1 })).orders.length === 0));
  await ad.nav('orders');
  check('settings: the admin lists are empty at once', await until(async () => await ad.page.locator('.aor').count() === 0));
  await ad.nav('home');
  check('settings: sales go back to zero', await until(async () => (await heroSales(ad)) === 0) && await kpi(ad, 'الطلبات اليوم') === '0');
  check('settings: the drivers and prices stay', await ad.ev(() => SRV.drivers.length === 1 && SRV.codes.WHY20 !== undefined));
  const nextNo = await place({});
  check('settings: order numbers start again from 1001', /1001$/.test(nextNo.no.replace(/\D/g, '')), nextNo.no);

  // ======================================================================= the line drops
  await ad.page.context().setOffline(true);
  check('offline: the chip shows when the line drops', await until(() => ad.has('بلا اتصال'), 8000));
  await ad.page.context().setOffline(false);
  check('offline: back by itself, with the order that came meanwhile', await until(async () => !(await ad.has('بلا اتصال')), 12000) && await until(async () => (await kpi(ad, 'الطلبات اليوم')) === '1'));

  // ======================================================================= phone layout
  const ph = await open('adminphone', { width: 390, height: 780 }, '/admin/');
  await ph.page.fill('#pin', '123456'); await ph.click('[data-a="login"]');
  check('phone: signs in', await until(() => ph.ev(() => UI.mode === 'main')));
  check('phone: bottom tabs show, the side menu is hidden', await until(() => ph.page.locator('.adm-tabs').isVisible()) && !(await ph.page.locator('.adm-side').isVisible()));
  const noScroll = () => ph.ev(() => document.documentElement.scrollWidth <= window.innerWidth + 1);
  check('phone: nothing wider than the screen on the overview', await noScroll());
  await ph.shot('1-home');
  for (const sec of ['orders', 'menu', 'branches']) { await ph.nav(sec); check(`phone: ${sec} fits the screen`, await noScroll()); await ph.shot('2-' + sec); }
  await ph.nav('menu');
  await ph.click('[data-a="adCat"][data-id="esp"]');
  await ph.click('[data-a="pEdit"][data-id="arsi"]');
  check('phone: the product form fits the screen, the save button stays in view', await noScroll() && await ph.ev(() => { const b = document.querySelector('[data-a="peSave"]').getBoundingClientRect(); return b.bottom <= window.innerHeight && b.top > 0; }));
  await ph.shot('2-product-form');
  if (!(await ph.ev(() => UI.pe.more))) await ph.click('[data-a="peMore"]');
  await ph.ev(() => { const s = document.querySelector('.sheet .sbody'); s.scrollTop = s.scrollHeight; });
  check('phone: the detail rows of the beans show and fit too', await ph.page.locator('.pe-dr').count() >= 3 && await noScroll());
  await ph.shot('2-product-form-more');
  await ph.click('.sheet [data-a="close"]');
  await ph.nav('branches');
  await ph.click('[data-a="brEdit"][data-id="b1"]');
  check('phone: the branch form fits the screen', await noScroll() && await ph.ev(() => { const b = document.querySelector('[data-a="brSave"]').getBoundingClientRect(); return b.bottom <= window.innerHeight && b.top > 0; }));
  await ph.shot('2-branch-form');
  await ph.click('.sheet [data-a="close"]');
  await ph.nav('menu');
  await ph.click('[data-a="catMgr"]');
  check('phone: the categories fit', await noScroll());
  await ph.shot('2-categories');
  await ph.click('.sheet [data-a="close"]');
  await ph.click('[data-a="adMore"]');
  check('phone: "more" lists reports, news, offers, drivers, customers, settings', await ph.page.locator('.sheet .mi').count() === 6 && await ph.page.locator('.sheet [data-a="adSec"][data-id="report"]').count() === 1 && await ph.page.locator('.sheet [data-a="adSec"][data-id="news"]').count() === 1);
  await ph.click('.sheet [data-a="adSec"][data-id="drivers"]');
  check('phone: more → drivers opens it and closes the sheet', await ph.ev(() => UI.ad.sec === 'drivers') && await ph.page.locator('.sheet').count() === 0 && await noScroll());
  await ph.shot('3-drivers');
  await ph.click('[data-a="adMore"]'); await ph.click('.sheet [data-a="adSec"][data-id="promo"]');
  check('phone: offers fit the screen', await noScroll());
  await ph.shot('4-offers');
  await ph.click('[data-a="edDel"]');
  await ph.shot('5-form');
  check('phone: a form sheet fits and the keyboard field is focused', await ph.ev(() => document.activeElement && document.activeElement.matches('.sheet input')) && await noScroll());
  await ph.click('.sheet [data-a="close"]');
  check('phone: closing the form forgets what was typed', await ph.ev(() => UI.fm === null));

  // reports on a phone: the Excel file goes to the share sheet (save to Files, WhatsApp, Mail...)
  const pt = await open('adminshare', { width: 390, height: 780 }, '/admin/', { hasTouch: true, isMobile: true });
  await pt.page.evaluate(() => {
    window.__shared = []; window.__deny = 1;
    navigator.canShare = d => !!(d && d.files && d.files.length);
    navigator.share = async d => { if (window.__deny-- > 0) { const e = new Error('no tap'); e.name = 'NotAllowedError'; throw e; } const f = d.files[0]; window.__shared.push([f.name, f.type, f.size]); };
  });
  await pt.page.fill('#pin', '123456'); await pt.page.tap('[data-a="login"]');
  check('phone reports: signs in', await until(() => pt.ev(() => UI.mode === 'main')));
  await pt.page.tap('[data-a="adMore"]'); await wait(250);
  await pt.page.tap('.sheet [data-a="adSec"][data-id="report"]');
  check('phone reports: open from "more", fit the screen', await until(() => pt.ev(() => !!document.querySelector('.hero-v'))) && await pt.ev(() => document.documentElement.scrollWidth <= window.innerWidth + 1));
  check('phone reports: the four periods fit in one row', await pt.ev(() => { const b = [...document.querySelectorAll('.rp-seg button')]; return b.length === 4 && b.every(x => x.scrollWidth <= x.clientWidth + 1 && x.getBoundingClientRect().right <= innerWidth && x.getBoundingClientRect().left >= 0); }));
  check('phone reports: the figures come right after the sales', await pt.ev(() => document.querySelector('.kpis').getBoundingClientRect().top > document.querySelector('.hero').getBoundingClientRect().bottom && document.querySelector('.kpis').getBoundingClientRect().top < document.querySelector('.rp-br').getBoundingClientRect().top));
  await pt.shot('1-reports');
  await pt.page.tap('[data-a="rpXlsx"]');
  check('phone reports: when the tap went stale while the file was made, one more tap is asked for', await until(() => pt.has('الملف جاهز، اضغط لحفظه')));
  await pt.page.tap('[data-a="rpXlsx"]');
  check('phone reports: the second tap shares the Excel file', await until(() => pt.ev(() => window.__shared.length === 1)) && await pt.ev(() => /^Why-report-.+\.xlsx$/.test(window.__shared[0][0]) && window.__shared[0][1] === XLSX_TYPE && window.__shared[0][2] > 2000), await pt.ev(() => window.__shared));
  check('phone reports: the button is back to normal', await until(() => pt.has('تنزيل Excel')));
  await pt.page.tap('[data-a="rpXlsx"]');
  check('phone reports: a later tap shares straight away', await until(() => pt.ev(() => window.__shared.length === 2)));
  await pt.ctx.close();

  // ======================================================================= 0.7: a branch's own order desk, a product a branch does not make, the ratings
  await ad.nav('branches');
  check('branches: each branch can have its own order desk', await until(() => ad.ev(() => document.querySelectorAll('[data-a="deskAdd"]').length === BRANCHES.length)) && await ad.has('شاشة استقبال خاصة بالفرع'));
  await ad.click('[data-a="deskAdd"][data-id="b1"]');
  await ad.fill('.sheet [data-bind="fm.v.pin"]', '13579'); 
  check('branches: the desk needs a code of 6 to 10 digits', await ad.ev(() => document.querySelector('[data-a="fmSave"]').disabled));
  await ad.fill('.sheet [data-bind="fm.v.pin"]', '135790'); await ad.click('[data-a="fmSave"]');
  check('branches: the desk is made, with its code, switch and remove', await until(() => ad.ev(() => !!document.querySelector('[data-a="deskOn"][data-id="b1"]') && !!document.querySelector('[data-a="deskPin"][data-id="b1"]'))) && (await raw('/recv/desks')).desks.includes('b1'));
  const dsk = await raw('/recv/login', { pin: '135790', branch: 'b1' });
  check('branches: the branch signs in with it', dsk.ok === true && dsk.me.branch === 'b1', dsk);
  await ad.click('[data-a="deskOn"][data-id="b1"]');
  check('branches: switched off it no longer opens', await until(async () => !(await raw('/recv/desks')).desks.includes('b1')));
  await ad.shot('9-branch-desk');
  await ad.click('[data-a="deskDel"][data-id="b1"]'); await ad.click('[data-a="dlgYes"]');
  check('branches: removed', await until(() => ad.ev(() => !!document.querySelector('[data-a="deskAdd"][data-id="b1"]'))));
  await ad.nav('menu');
  await ad.click('[data-a="pEdit"][data-id="latte"]');
  check('menu: the product form lists the branches that have it, all on', await ad.ev(() => document.querySelectorAll('.sheet [data-a="peOff"]').length === BRANCHES.length && [...document.querySelectorAll('.sheet [data-a="peOff"]')].every(b => b.classList.contains('on'))));
  await ad.click('.sheet [data-a="peOff"][data-id="b3"]');
  await ad.click('[data-a="peSave"]');
  check('menu: saved, the branch is off for that product', await until(async () => ((await prodOf('latte')).off || []).join() === 'b3') && await until(() => ad.has('غير متوفر في')));
  await ad.click('[data-a="pEdit"][data-id="latte"]'); await ad.click('.sheet [data-a="peOff"][data-id="b3"]'); await ad.click('[data-a="peSave"]');
  check('menu: and back on', await until(async () => !(await prodOf('latte')).off));
  await ad.nav('home');
  check('overview: the ratings card says how to get ratings', await ad.has('تقييمات العملاء'));

  // ======================================================================= 0.7: the tax invoice details, and a copy of the database
  await ad.nav('set');
  check('settings: the tax invoice waits for the VAT number, and the backups say where they are', await ad.has('الفاتورة الضريبية') && await ad.has('إدخال الرقم الضريبي') && await ad.has('النسخ الاحتياطي') && await ad.has('تنزيل نسخة الآن'));
  await ad.click('[data-a="taxEdit"]');
  await ad.fill('.sheet [data-bind="fm.v.name"]', 'مؤسسة واي للتحميص');
  await ad.fill('.sheet [data-bind="fm.v.vat"]', '123456789012345');
  check('settings: a VAT number not like 3…3 cannot be saved', await ad.ev(() => document.querySelector('[data-a="fmSave"]').disabled));
  await ad.fill('.sheet [data-bind="fm.v.vat"]', '310122393500003'); await ad.click('[data-a="fmSave"]');
  check('settings: saved, shown, and new orders carry the invoice', await until(() => ad.has('310122393500003')) && !!(await place()).inv);
  await ad.shot('10-tax');
  await ad.click('[data-a="taxOff"]'); await ad.click('[data-a="dlgYes"]');
  check('settings: switched off', await until(() => ad.has('إدخال الرقم الضريبي')) && !(await place()).inv);
  await ad.click('[data-a="dbCopy"]');
  await ad.fill('.sheet [data-bind="fm.v.pin"]', '000000'); await ad.click('[data-a="fmSave"]');
  check('settings: the copy needs the right admin code', await until(() => ad.said('الرمز السري للإدارة غير صحيح')));
  await ad.fill('.sheet [data-bind="fm.v.pin"]', '123456');
  const [cpDl] = await Promise.all([ad.page.waitForEvent('download'), ad.click('[data-a="fmSave"]')]);
  const dlPath = path.join(OUT, 'copy.zip'); await cpDl.saveAs(dlPath);
  check('settings: the copy downloads as a zip with the database and a note', /^why-backup-\d{4}-\d{2}-\d{2}\.zip$/.test(cpDl.suggestedFilename()) && fs.readFileSync(dlPath).slice(0, 2).toString() === 'PK' && await ad.has('لا للقراءة'));
  fs.rmSync(dlPath, { force: true });

  // ======================================================================= the admin code changes, then sign-out
  await ad.nav('set');
  await ad.click('[data-a="pinChange"][data-id="admin"]');
  await ad.fill('.sheet [data-bind="fm.v.cur"]', '123456'); await ad.fill('.sheet [data-bind="fm.v.pin"]', '246810'); await ad.fill('.sheet [data-bind="fm.v.pin2"]', '246810'); await ad.click('[data-a="fmSave"]');
  check('settings: changing the admin code signs this page out', await until(() => ad.ev(() => UI.mode === 'login'), 8000) && await ad.has('الرمز السري'));
  check('settings: the typed codes are gone from the page', await ad.ev(() => UI.fm === null && UI.lg.pin === ''));
  check('settings: the phone page was signed out too', await until(() => ph.ev(() => UI.mode === 'login'), 8000));
  await ad.page.fill('#pin', '123456'); await ad.click('[data-a="login"]');
  check('settings: the old admin code no longer opens it', await until(() => ad.has('الاسم أو الرمز غير صحيح')));
  await ad.page.fill('#pin', '246810'); await ad.click('[data-a="login"]');
  check('settings: the new admin code does', await until(() => ad.ev(() => UI.mode === 'main')));
  await ad.nav('set');
  await ad.click('[data-a="signOut"]');
  check('sign-out: asks first', await ad.page.locator('.dlg').count() === 1);
  await ad.click('[data-a="dlgYes"]');
  check('sign-out: back to the sign-in page', await until(() => ad.ev(() => UI.mode === 'login')) && await ad.has('الرمز السري'));
  await ad.page.reload({ waitUntil: 'domcontentloaded' });
  check('sign-out: still signed out after a reload, nothing shown', await until(() => ad.has('الرمز السري')) && !(await ad.has('مبيعات اليوم')));

  check('no page errors in any page', errors.length === 0, errors);
  const failed = results.filter(r => !r.ok);
  console.log(`\n${results.length - failed.length}/${results.length} passed`);
  if (failed.length) console.log('FAILED:\n' + failed.map(f => ' - ' + f.name).join('\n'));
  await browser.close();
  process.exit(failed.length ? 1 : 0);
})().catch(e => { console.error('TEST CRASH', e); process.exit(2); });
