/* Shared by every app: sheets, dialogs, the busy overlay and a few small builders. */

const NEED = {};
const needAttr = k => `data-need="${k}" ${NEED[k]() ? '' : 'disabled'}`;

const emptyHTML = (kind, tone, msg, btn) => `<div class="empty"><div class="eart">${art(kind, tone)}</div><h2>${msg}</h2>${btn || ''}</div>`;
const fld = (label, bind, val, ph, extra = '') => `<div class="field"><label>${label}</label><input class="inp" data-bind="${bind}" value="${esc(val)}" placeholder="${esc(ph || '')}" ${extra}></div>`;
const payLabel = m => ({apple:'Apple Pay', card:T('بطاقة الدفع', 'Payment card'), wallet:T('رصيد المحفظة', 'Wallet'), points:T('النقاط', 'Points')}[m] || m);
const itemsSummary = o => { const n = o.items.map(itemName); return n.slice(0, 2).join(T('، ', ', ')) + (n.length > 2 ? ` +${n.length - 2}` : ''); };
const openChip = b => { const on = isOpen(b); return `<span class="chip-o ${on ? 'on' : 'off'}">${on ? T('مفتوح', 'Open') : T('مغلق', 'Closed')}</span>`; };
const sheetWrap = (inner, label, cls = '') => `<div class="shade" data-a="close"></div><div class="sheet ${cls} ${UI.fresh.sheet ? 'enter' : ''}" role="dialog" aria-modal="true" aria-label="${esc(label || '')}">${inner}<button class="xbtn" data-a="close" aria-label="${T('إغلاق', 'Close')}">${ic('x', 18)}</button></div>`;
const miRow = (ico, title, sub, attrs, cls = '') => `<button class="mi ${cls}" ${attrs}><span class="ic-b">${ic(ico, 22)}</span><span class="grow"><b>${title}</b>${sub ? `<small>${sub}</small>` : ''}</span></button>`;
function dlgHTML() {
  const d = UI.dlg; if (!d) return '';
  return `<div class="shade" style="z-index:49" data-a="dlgNo"></div><div class="dlg" role="alertdialog" aria-modal="true"><h2>${d.t}</h2><p class="grey">${d.b}</p><div class="row"><button class="btn line sm" style="flex:1" data-a="dlgNo">${T('إلغاء', 'Cancel')}</button><button class="btn sm ${d.danger ? 'danger' : ''}" style="flex:1" data-a="dlgYes">${d.ok}</button></div></div>`;
}
const procHTML = () => UI.proc ? `<div class="proc"><div><div class="spin"></div><b>${UI.proc.msg}</b></div></div>` : '';

/* ---------- printing (0.7): what to print goes into #print, and the page prints only that ---------- */
function printHTML(html) {
  let el = document.getElementById('print');
  if (!el) { el = document.createElement('div'); el.id = 'print'; el.setAttribute('aria-hidden', 'true'); document.body.appendChild(el); }
  el.innerHTML = html;
  setTimeout(() => { try { window.print(); } catch (e) {} }, 80);
}
/* the simplified tax invoice of an order (ZATCA phase 1): in Arabic, with the QR code; only orders made after the VAT number was entered have one */
function invoiceHTML(o) {
  const v = o.inv; if (!v) return '';
  const d = new Date(o.ts), when = `${dISO(o.ts)} ${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
  const row = (l, x, cls) => `<div class="iv-r ${cls || ''}"><span>${l}</span><b class="ltr">${x}</b></div>`;
  const items = o.items.map(it => { const so = selText(it.sel); return `<tr><td>${esc((it.n && (it.n.ar || it.n.en)) || itemName(it))}${it.rw ? ' (مكافأة)' : ''}${it.gift ? ' (هدية)' : ''}${so ? `<small>${esc(so)}</small>` : ''}</td><td class="q"><span class="ltr">${it.qty}</span></td><td class="nm"><span class="ltr">${it.rw || it.gift ? '0.00' : fmt2(it.unit * it.qty)}</span></td></tr>`; }).join('');   /* .ltr inside the cell: on the cell it breaks the table */
  return `<div class="inv" dir="rtl" lang="ar">
    <h2>فاتورة ضريبية مبسطة<small>Simplified Tax Invoice</small></h2>
    <p class="iv-s"><b>${esc(v.name)}</b>الرقم الضريبي: <span class="ltr">${esc(v.vat)}</span>${v.cr ? `<br>السجل التجاري: <span class="ltr">${esc(v.cr)}</span>` : ''}${v.addr ? `<br>${esc(v.addr)}` : ''}</p>
    ${row('رقم الفاتورة', esc(o.no.replace(/[\u200e#]/g, '')))}${row('التاريخ', when)}${o.cust && o.cust.name ? row('العميل', esc(o.cust.name)) : ''}
    <table><thead><tr><th>الصنف</th><th class="q">الكمية</th><th class="nm">المبلغ</th></tr></thead><tbody>${items}</tbody></table>
    ${row('المجموع شامل الضريبة', fmt2(o.sub))}${o.ship ? row(o.mode === 'delivery' ? 'رسوم التوصيل' : 'رسوم الشحن', fmt2(o.ship)) : ''}${o.disc ? row('الخصم', '-' + fmt2(o.disc)) : ''}
    ${row('الإجمالي غير شامل الضريبة', fmt2(r2(o.total - o.vat)))}${row('ضريبة القيمة المضافة (15%)', fmt2(o.vat))}${row('الإجمالي شامل الضريبة (ر.س)', fmt2(o.total), 'tot')}
    ${o.bal ? row('مدفوع من المحفظة', fmt2(o.bal)) : ''}
    <div class="iv-q">${qrSVG(v.qr, 168)}</div></div>`;
}
