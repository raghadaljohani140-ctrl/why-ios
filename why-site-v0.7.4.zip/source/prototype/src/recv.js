/* Order desk: new orders arrive by themselves, the staff accept them, prepare them and hand them over. */

const COLMSG = {
  new:() => T('لا توجد طلبات جديدة', 'No new orders'), prep:() => T('لا توجد طلبات قيد التحضير', 'Nothing is being prepared'),
  ready:() => T('لا توجد طلبات جاهزة', 'No orders are ready'), done:() => T('لا توجد طلبات مكتملة اليوم', 'No completed orders today')
};

const myDesk = () => (SRV.me && SRV.me.branch) || '';   /* 0.7: the desk of one branch ('' = every branch) */
function scrMain() {
  const own = myDesk(), br = own || S.rcBr, list = SRV.orders.filter(o => br === 'all' || o.branch === br);
  const cols = {new:[], prep:[], ready:[], done:[]};
  list.forEach(o => cols[colOf(o)].push(o));
  /* the order that has waited longest comes first; finished ones show the newest first */
  ['new', 'prep', 'ready'].forEach(k => cols[k].sort((a, b) => a.ts - b.ts));
  cols.done = cols.done.filter(isToday).sort((a, b) => b.ts - a.ts).slice(0, 40);
  const tabs = [['new', T('جديد', 'New')], ['prep', T('قيد التحضير', 'Preparing')], ['ready', T('جاهز', 'Ready')], ['done', T('المكتملة', 'Done')]];
  const chips = [['all', T('كل الفروع', 'All branches')]].concat(BRANCHES.map(b => [b.id, brName(b)]));
  const paused = br !== 'all' && bPaused(br);
  const wait = SRV.orders.filter(o => o.mode === 'delivery' && o.st === 2 && !o.rej && !o.fin && !o.driver).length;
  return `<div class="screen sx rcv">
    ${sbar(T('شاشة الاستقبال', 'Order desk'), br === 'all' ? T('كل الفروع', 'All branches') : esc(L(BR[br])) + (own ? T(' · شاشة الفرع', ' · branch desk') : ''), (br !== 'all' ? `<button class="sbb" data-a="rcMenu" aria-label="${T('المنتجات في الفرع', 'Products at the branch')}">${ic('cup', 19)}</button>` : '') + sbarBtns())}
    ${own ? '' : `<div class="sfil">${chips.map(([id, lb]) => `<button class="chip ${br === id ? 'on' : ''}" data-a="rcBr" data-id="${id}">${esc(lb)}</button>`).join('')}</div>`}
    ${br !== 'all' ? `<div class="pz"><span class="grow"><b>${T('استقبال الطلبات', 'Accepting orders')}</b><small>${paused ? T('متوقف: يظهر الفرع مغلقًا للعملاء', 'Paused: customers see this branch as closed') : T('يعمل: يستقبل الفرع طلبات العملاء', 'On: customers can order from this branch')}</small></span>${sw(!paused, 'rcPause', '', T('استقبال الطلبات', 'Accepting orders'))}</div>` : ''}
    ${pushStrip()}
    ${!deliveryOn() ? `<div class="pz off">${ic('truck', 18)}<span class="grow"><small>${T('التوصيل متوقف من الإدارة', 'Delivery is switched off by the admin')}</small></span></div>` : ''}
    ${wait ? `<div class="pz warn">${ic('moto', 18)}<span class="grow"><b>${T(`${wait} طلب توصيل بانتظار مندوب`, `${wait} delivery order(s) waiting for a driver`)}</b></span></div>` : ''}
    <div class="rtabs" role="tablist">${tabs.map(([id, lb]) => `<button role="tab" aria-selected="${UI.rc.tab === id}" class="${UI.rc.tab === id ? 'on' : ''} ${id === 'new' && cols.new.length ? 'has' : ''}" data-a="rcTab" data-id="${id}"><b>${cols[id].length}</b><span>${lb}</span></button>`).join('')}</div>
    <div class="scols">${tabs.map(([id, lb]) => `<section class="col ${UI.rc.tab === id ? 'on' : ''}" aria-label="${lb}"><h2 class="col-h">${lb}<span class="n">${cols[id].length}</span></h2><div class="col-b" data-sk="rc-${id}">${cols[id].map(o => ticket(o)).join('') || `<div class="colx">${ic('receipt', 30)}<p>${COLMSG[id]()}</p></div>`}</div></section>`).join('')}</div>
  </div>`;
}

/* what this branch makes today: a product switched off here shows as "not at this branch" to the customers who chose it */
function rcMenuRows(bid) {
  const q = (UI.rc.mq || '').trim().toLowerCase();
  const list = PRODUCTS.filter(p => (CAT[p.cat] || {}).kind !== 'retail' && (!q || (p.ar + ' ' + p.en).toLowerCase().includes(q)));
  return list.map(p => `<div class="srow"><span class="grow"><b>${esc(L(p))}</b><small>${p.stock === false ? T('نفد في كل الفروع (من الإدارة)', 'Sold out everywhere (set by the admin)') : offAt(p, bid) ? T('غير متوفر في هذا الفرع', 'Not available at this branch') : T('متوفر', 'Available')}</small></span>${sw(!offAt(p, bid), 'rcHere', `data-id="${p.id}"`, L(p))}</div>`).join('') || `<p class="grey" style="padding:12px 0">${T('لا يوجد منتج بهذا الاسم', 'No product by that name')}</p>`;
}
SHEETS.rcmenu = function () {
  const bid = myDesk() || S.rcBr, b = BR[bid]; if (!b) return '';
  const offN = PRODUCTS.filter(p => offAt(p, bid)).length;
  return sheetWrap(`<div class="sbody" data-sk="sheet"><h2 class="sttl">${T('المنتجات في', 'Products at')} ${esc(brName(b))}</h2><p class="ssub">${offN ? T(`${offN} غير متوفر الآن في هذا الفرع`, `${offN} not available at this branch now`) : T('كل المنتجات متوفرة في هذا الفرع', 'Everything is available at this branch')}</p>
    <div class="srch" style="margin:8px 0">${ic('search', 20)}<input type="text" data-bind="rc.mq" data-on="rcMq" value="${esc(UI.rc.mq || '')}" placeholder="${T('بحث', 'Search')}" autocomplete="off" aria-label="${T('بحث', 'Search')}"></div>
    <div id="rcml">${rcMenuRows(bid)}</div></div>`, T('المنتجات في الفرع', 'Products at the branch'), 'tall');
};

Object.assign(A, {
  rcTab(d) { UI.rc.tab = d.id; render(); },
  rcBr(d) { S.rcBr = d.id; save(); render(); },
  rcPause() { const bid = myDesk() || S.rcBr; if (bid !== 'all') A.branchPause({id:bid}); },
  rcMenu() { UI.rc.mq = ''; openSheet({k:'rcmenu'}); },
  rcMq() { const el = $('#rcml'); if (el) el.innerHTML = rcMenuRows(myDesk() || S.rcBr); },
  async rcHere(d) {
    const bid = myDesk() || S.rcBr, p = PROD[d.id]; if (!p || !BR[bid]) return;
    const on = offAt(p, bid);   /* it is off here now: the switch puts it back */
    const r = await doStaff('/recv/here', {id:p.id, branch:bid, on}, on ? T(`${L(p)} متوفر الآن في الفرع`, `${L(p)} is available at the branch again`) : T(`${L(p)} غير متوفر في الفرع`, `${L(p)} is off at the branch`));
    if (r && r.product) { p.off = r.product.off; render(); }
  }
});

/* the branches came from the server (with the menu): a filter on a branch that is gone goes back to all branches */
function afterCatalog() {
  if (S.rcBr !== 'all' && !liveB(S.rcBr)) { S.rcBr = 'all'; save(); }
  UI.dirty = true;
}

function boot() {
  applyLang(); UI.mode = 'boot'; render(); startPoll(); pushInit();
}
