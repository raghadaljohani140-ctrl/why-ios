/* Staff pages (order desk, management, delivery): what they share.
   Each page is a link of its own. It signs in with a secret code, then the server pushes every change (see net.js). */

Object.assign(IC, {
  tv:'<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',
  chart:'<path d="M5 20v-9M11 20V4M17 20v-6"/><path d="M3 20h18"/>',
  gear:'<circle cx="12" cy="12" r="3"/><path d="M10.3 3h3.4l.5 2.3 1.9.8 2-1.2 2.4 2.4-1.2 2 .8 1.9 2.3.5v3.4l-2.3.5-.8 1.9 1.2 2-2.4 2.4-2-1.2-1.9.8-.5 2.3h-3.4l-.5-2.3-1.9-.8-2 1.2-2.4-2.4 1.2-2-.8-1.9L3 13.7v-3.4l2.3-.5.8-1.9-1.2-2 2.4-2.4 2 1.2 1.9-.8z"/>',
  pencil:'<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="m13.5 6.5 4 4"/>',
  swap:'<path d="M7 7h12l-3-3M17 17H5l3 3"/>',
  bellx:'<path d="M6 16v-5a6 6 0 0 1 12 0v5l2 2H4z"/><path d="M10 21a2 2 0 0 0 4 0"/><path d="M4 4l16 16"/>',
  dots:'<circle cx="5" cy="12" r="1.3"/><circle cx="12" cy="12" r="1.3"/><circle cx="19" cy="12" r="1.3"/>',
  key:'<circle cx="8" cy="15" r="4"/><path d="m11 12 8-8M16 7l2 2M14 9l2 2"/>',
  moto:'<circle cx="6" cy="17" r="3"/><circle cx="18" cy="17" r="3"/><path d="M9 17h6l-3-7H8M13 6h3l2 4 0 4"/>',
  printer:'<path d="M7 9V3h10v6"/><rect x="3" y="9" width="18" height="8" rx="2"/><path d="M7 14h10v7H7z"/>'
});

/* ---------- small helpers ---------- */
const hhmm = ts => { const d = new Date(ts); return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`; };
const brName = b => L(b).replace(/^فرع\s+/, '').replace(/\s*\((مثال|sample)\)/, '').replace(/\s+branch$/i, '');
const custOf = o => o.cust || {name:T('عميل', 'Customer'), tail:''};
const colOf = o => o.rej ? 'done' : ['new', 'prep', 'ready', 'done'][o.st];
const isToday = o => o.day === SRV.today;
const sLabel = o => {
  if (o.rej) return T('مرفوض', 'Rejected');
  const ship = o.mode === 'ship', del = o.mode === 'delivery';
  if (del && o.st === 2) return o.driver ? T('مع المندوب', 'With the driver') : T('بانتظار مندوب', 'Waiting for a driver');
  return [T('جديد', 'New'), ship ? T('قيد التجهيز', 'Packing') : T('قيد التحضير', 'Preparing'), ship ? T('تم الشحن', 'Shipped') : T('جاهز للاستلام', 'Ready'), del ? T('تم التوصيل', 'Delivered') : T('تم التسليم', 'Handed over')][o.st];
};
const sChip = o => `<span class="st ${o.rej ? 'rej' : ['new', 'prep', 'ready', 'done'][o.st]}"><i></i>${sLabel(o)}</span>`;
const bChip = b => bPaused(b.id) ? `<span class="chip-o off">${T('متوقف مؤقتًا', 'Paused')}</span>` : openChip(b);
const sw = (on, a, attrs, label) => `<button class="sw ${on ? 'on' : ''}" role="switch" aria-checked="${on ? 'true' : 'false'}" aria-label="${esc(label || '')}" data-a="${a}" ${attrs || ''}><i></i></button>`;
const mapLink = a => a && a.lat != null ? `https://www.google.com/maps/search/?api=1&query=${a.lat},${a.lng}` : '';
const phoneLink = p => `<a class="tel ltr" href="tel:+966${esc(p)}">${phoneFmt(p)}</a>`;

/* the alert for a new order: two soft notes. Browsers only allow sound after a tap, so the first tap wakes the sound up. */
function beep() {
  try {
    const C = window.AudioContext || window.webkitAudioContext; if (!C) return;
    const a = beep.ctx || (beep.ctx = new C());
    if (a.state === 'suspended') a.resume();
    const t = a.currentTime;
    [[880, 0], [1175, .17]].forEach(([f, d]) => {
      const o = a.createOscillator(), g = a.createGain();
      o.type = 'sine'; o.frequency.value = f;
      g.gain.setValueAtTime(.0001, t + d); g.gain.exponentialRampToValueAtTime(.25, t + d + .02); g.gain.exponentialRampToValueAtTime(.0001, t + d + .3);
      o.connect(g); g.connect(a.destination); o.start(t + d); o.stop(t + d + .32);
    });
  } catch (e) {}
}
document.addEventListener('pointerdown', () => {
  try { const C = window.AudioContext || window.webkitAudioContext; if (!C) return; const a = beep.ctx || (beep.ctx = new C()); if (a.state === 'suspended') a.resume(); } catch (e) {}
}, {passive:true});

/* a tablet at the counter or a driver's phone should not go to sleep while the page is open */
let wake = null;
async function keepAwake() {
  try { if (navigator.wakeLock && !document.hidden && UI.mode === 'main' && (!wake || wake.released)) wake = await navigator.wakeLock.request('screen'); } catch (e) {}
}
document.addEventListener('visibilitychange', keepAwake);

/* ---------- top bar ---------- */
const sbar = (title, sub, right) => `<header class="sbar"><span class="lk">${APPLOGO(44, true)}</span><div class="tt2"><b>${title}</b><small>${sub}</small></div>${UI.offline ? `<span class="chip-o off" role="status">${T('بلا اتصال', 'Offline')}</span>` : ''}${right}</header>`;
const sbarBtns = () => `<button class="sbb ${S.sound ? 'on' : ''}" data-a="sound" aria-label="${T('التنبيه الصوتي', 'Sound alert')}">${ic(S.sound ? 'bell' : 'bellx', 19)}</button><button class="sbb" data-a="signOut" aria-label="${T('تسجيل الخروج', 'Sign out')}">${ic('logout', 18)}</button>`;

/* ---------- notifications on this tablet or phone (0.7): new orders even with the page closed ---------- */
function pushStrip() {
  const st = pushState(), what = APP === 'driver' ? T('طلبات التوصيل الجديدة', 'new delivery orders') : T('الطلبات الجديدة', 'new orders');
  if (st === 'on' || st === 'no') return '';
  if (st === 'ios') return `<div class="pz">${ic('bell', 18)}<span class="grow"><small>${T(`لتصلك ${what} والشاشة مغلقة: أضف الصفحة إلى الشاشة الرئيسية (زر المشاركة ← «إضافة إلى الشاشة الرئيسية») وافتحها من هناك.`, `To get ${what} with the screen off: add this page to the Home Screen (Share → “Add to Home Screen”) and open it from there.`)}</small></span></div>`;
  if (st === 'denied') return `<div class="pz">${ic('bellx', 18)}<span class="grow"><small>${T('التنبيهات مرفوضة لهذا الموقع في إعدادات المتصفح.', 'Notifications are blocked for this site in the browser settings.')}</small></span></div>`;
  return `<div class="pz">${ic('bell', 18)}<span class="grow"><b>${T('تنبيهات على هذا الجهاز', 'Alerts on this device')}</b><small>${T(`تصلك ${what} حتى والشاشة مغلقة`, `Get ${what} even with the screen off`)}</small></span><button class="btn sm" data-a="pushOn">${T('تفعيل', 'Turn on')}</button></div>`;
}

/* ---------- sign in ---------- */
NEED.login = () => /^\d{6,10}$/.test(UI.lg.pin) && (APP !== 'driver' || UI.lg.name.trim().length >= 2);
const APP_NAME = () => ({recv:T('شاشة الاستقبال', 'Order desk'), admin:T('لوحة الإدارة', 'Management'), driver:T('تطبيق المندوب', 'Delivery')}[APP]);
/* 0.7: a branch can have an order desk of its own (its own code; it sees that branch only) */
async function loadDesks() {
  if (APP !== 'recv') return;
  try {
    const r = await api('/recv/desks');
    if (SRV.crev < 0) { try { applyCatalog(await api('/catalog'), true); } catch (e) {} }   /* the branch names, before signing in */
    UI.lg.desks = (r.desks || []).filter(id => BR[id]);
    if (UI.lg.br && !UI.lg.desks.includes(UI.lg.br)) UI.lg.br = '';
    if (UI.mode === 'login') render();
  } catch (e) {}
}
function scrLogin() {
  const drv = APP === 'driver', desks = APP === 'recv' ? (UI.lg.desks || []) : [];
  const pick = desks.length ? `<div class="field" role="radiogroup" aria-label="${T('الشاشة', 'Desk')}"><label>${T('الشاشة', 'Desk')}</label><div class="chips">${[''].concat(desks).map(id => `<button type="button" class="chip ${UI.lg.br === id ? 'on' : ''}" data-a="lgBr" data-id="${id}" role="radio" aria-checked="${UI.lg.br === id}">${id ? esc(brName(BR[id])) : T('كل الفروع', 'All branches')}</button>`).join('')}</div></div>` : '';
  return `<div class="screen gate"><div class="gate-in">
    <div class="gate-logo">${APPLOGO(104)}</div>
    <h1>${APP_NAME()}</h1>
    <p class="grey">${T('للعاملين في واي! فقط. أدخل الرمز السري للدخول.', 'For Why! staff only. Enter your secret code to sign in.')}</p>
    ${drv ? fld(T('الاسم', 'Name'), 'lg.name', UI.lg.name, '', 'autocomplete="username" data-enter="login" id="lgname"') : ''}${pick}
    <div class="field"><label>${T('الرمز السري (من 6 إلى 10 أرقام)', 'Secret code (6 to 10 digits)')}</label><input class="inp ltr pinin" id="pin" type="password" inputmode="numeric" pattern="[0-9]*" autocomplete="current-password" maxlength="10" data-bind="lg.pin" data-fmt="digits" data-enter="login" value="${esc(UI.lg.pin)}" placeholder="••••••"></div>
    ${UI.lg.err ? `<div class="hint lgerr" role="alert">${esc(UI.lg.err)}</div>` : ''}
    ${UI.lg.br ? `<small class="grey" style="text-align:center">${T(`تدخل شاشة ${L(BR[UI.lg.br])}: ترى طلباته فقط، برمزه الخاص.`, `Signing in to the desk of ${L(BR[UI.lg.br])}: its orders only, with its own code.`)}</small>` : ''}
    <button type="button" class="btn" ${needAttr('login')} data-a="login">${UI.lg.busy ? T('جاري الدخول…', 'Signing in…') : T('دخول', 'Sign in')}</button>
    <small class="grey" style="text-align:center">${drv ? T('الاسم والرمز السري تعطيك إياهما الإدارة.', 'The admin gives you your name and secret code.') : T('الرمز السري تضعه الإدارة. لا تشاركه مع أحد.', 'The admin sets the secret code. Do not share it.')}</small>
  </div></div>`;
}
const scrBoot = () => `<div class="screen gate"><div class="gate-in" style="justify-content:center;align-items:center;gap:18px"><div class="gate-logo">${APPLOGO(104)}</div><div class="spin"></div><p class="grey">${UI.offline ? T('لا يوجد اتصال، نعيد المحاولة…', 'No connection. Trying again…') : T('جاري التحميل…', 'Loading…')}</p></div></div>`;

/* the root: boot (asking the server if we are still signed in), sign-in, or the page of this app */
function view() {
  const layers = () => sheetHTML() + dlgHTML() + procHTML();
  if (UI.mode === 'boot') return scrBoot();
  if (UI.mode === 'login') return scrLogin() + layers();
  return scrMain() + layers();
}
const SHEETS = {};
function sheetHTML() { const s = UI.sheet; return s && SHEETS[s.k] ? SHEETS[s.k]() : ''; }

function onSignedOut() {
  const was = UI.mode === 'main';
  stopPoll();
  Object.assign(SRV, {rev:-1, me:null, orders:[], avail:[], mine:[], done:[], cust:[], drivers:[], week:[]});
  UI.sheet = null; UI.dlg = null; UI.proc = null; UI.fm = null; UI.busy = false; UI.offline = false; UI.mode = 'login';
  UI.lg.pin = ''; UI.lg.busy = false; UI.lg.err = was ? errText({code:'auth'}) : '';
  if (APP === 'recv') { if (UI.lg.br == null || (UI.lg.desks == null && S.desk)) UI.lg.br = S.desk || ''; loadDesks(); }
  render();
}
async function doSignOut() {
  await pushUnsubscribe();
  try { await api(`/${APP}/logout`, {}); } catch (e) {}
  stopPoll(); onSignedOut(); UI.lg.err = '';
  render();
}

/* one action: ask the server, show what it says, take the order it sends back */
function putOrder(o) {
  if (!o) return;
  const swap = (arr, rm) => { const i = arr.findIndex(x => x.id === o.id); if (i >= 0) { if (rm) arr.splice(i, 1); else arr[i] = o; } return i >= 0; };
  if (APP === 'driver') {
    swap(SRV.avail, true); swap(SRV.mine, true); swap(SRV.done, true);
    if (o.fin) SRV.done.unshift(o); else if (o.driver) SRV.mine.unshift(o); else if (o.st === 2 && o.mode === 'delivery' && !o.rej) {   /* handed back: free for every driver, as they see it (city and street only) */
      const a = o.addr || {}; SRV.avail.unshift(Object.assign({}, o, {driver:null, cust:{name:o.cust.name, tail:o.cust.tail}, addr:{city:a.city, street:a.street}}));
    }
  } else if (!swap(SRV.orders, false)) SRV.orders.unshift(o);
}
async function doStaff(path, body, ok) {
  if (UI.busy) return null;
  UI.busy = true; UI.dirty = true;
  try {
    const r = await api(path, body);
    /* the screen may already hold a newer picture than this answer (the push can arrive first): then the answer adds nothing */
    if (r.order && !(typeof r.rev === 'number' && SRV.rev >= r.rev)) putOrder(r.order);
    if (ok) toast(ok);
    return r;
  } catch (e) {
    if (e.status === 401) { onSignedOut(); return null; }
    toast(errText(e));
    if (['bad_state', 'not_found', 'taken', 'too_many', 'busy'].includes(e.code)) startPoll();   /* the screen is out of date: ask again now */
    return null;
  } finally { UI.busy = false; UI.dirty = true; }
}

/* ---------- order ticket (reception and admin share it) ---------- */
function tkItems(o) {
  return o.items.map(it => {
    const sub = selText(it.sel);
    return `<li><b class="q ltr">${it.qty}×</b><span class="n"><b>${esc(itemName(it))}</b>${it.rw ? `<em>${T('مكافأة', 'Reward')}</em>` : ''}${it.gift ? `<em>${T('هدية', 'Gift')}</em>` : ''}${sub ? `<small>${esc(sub)}</small>` : ''}</span></li>`;
  }).join('');
}
function tkActions(o) {
  const ship = o.mode === 'ship', del = o.mode === 'delivery';
  if (o.rej) return o.rej.by === 'cust' ? `<div class="tk-n rj">${ic('x', 18)}<span><b>${T('ألغاه العميل', 'Cancelled by the customer')}</b><small>${T('قبل أن يقبله الفرع', 'Before the branch accepted it')}</small></span></div>`
    : `<div class="tk-n rj">${ic('x', 18)}<span><b>${T('تم رفض الطلب', 'Order rejected')}</b><small>${esc(L(o.rej.why))}</small></span></div>`;
  if (o.st === 0) return `<div class="tk-a"><button class="btn" data-a="rcAccept" data-id="${o.id}">${ic('check', 20)}${ship ? T('قبول وتجهيز الطلب', 'Accept and pack') : T('قبول وبدء التحضير', 'Accept and start')}</button><button class="btn line danger" data-a="rcReject" data-id="${o.id}">${T('رفض', 'Reject')}</button></div>`;
  if (o.st === 1) return `<div class="tk-a"><button class="btn" data-a="rcReady" data-id="${o.id}">${ic(ship || del ? 'truck' : 'bag', 20)}${ship ? T('تم الشحن', 'Mark as shipped') : del ? T('جاهز للتوصيل', 'Ready for delivery') : T('جاهز للاستلام', 'Ready for pickup')}</button></div>`;
  if (o.st === 2 && o.mode === 'pickup') return `<div class="tk-v"><div class="field"><label>${T('رمز الإستلام من العميل', 'Customer pickup code')}</label><input class="inp ltr" type="text" inputmode="numeric" maxlength="4" autocomplete="off" data-bind="rc.code.${o.id}" data-fmt="digits" data-enter="rcDeliver" data-id="${o.id}" value="${esc(UI.rc.code[o.id] || '')}" placeholder="••••"></div><button class="btn" data-a="rcDeliver" data-id="${o.id}">${ic('check', 20)}${T('تأكيد التسليم', 'Confirm handover')}</button><button class="btn text" data-a="rcSkip" data-id="${o.id}">${T('تسليم بدون رمز', 'Hand over without the code')}</button></div>`;
  if (o.st === 2 && ship) return `<div class="tk-n">${ic('truck', 18)}<span><b class="ltr">${esc(o.code)}</b><small>${esc(o.carrier)}</small></span></div><div class="tk-a"><button class="btn" data-a="rcDeliver" data-id="${o.id}">${ic('check', 20)}${T('تم التسليم للعميل', 'Mark as delivered')}</button></div>`;
  if (o.st === 2 && del) {
    const d = o.driver;
    return `<div class="tk-n ${d ? '' : 'wait'}">${ic('moto', 20)}<span><b>${d ? esc(d.name) : T('بانتظار مندوب', 'Waiting for a driver')}</b><small>${d ? T(`أخذ الطلب ${ago(d.ts)}`, `Took it ${ago(d.ts)}`) : T('يظهر الطلب لكل المندوبين الآن', 'Every driver can see it now')}</small></span></div>
      <div class="tk-a">${d ? `<button class="btn line" data-a="rcUnassign" data-id="${o.id}">${T('إلغاء إسناد المندوب', 'Take it off the driver')}</button>` : ''}<button class="btn text" data-a="rcSkip" data-id="${o.id}">${T('تم التسليم بدون رمز', 'Delivered, without the code')}</button></div>`;
  }
  return `<div class="tk-n ok">${ic('check', 18)}<span><b>${T('اكتمل الطلب', 'Order complete')}</b><small class="ltr">${hhmm((o.at && o.at[3]) || o.ts)}</small></span></div>`;
}
/* a pickup at a time the customer chose (0.7): the desk prepares it for then */
function pickLine(o) {
  if (!o.pick || o.rej || o.fin) return '';
  const m = Math.round((o.pick - nowS()) / 6e4);
  const when = m <= 0 ? T('حان وقت الاستلام', 'It is time') : m < 60 ? T(`بعد ${m} دقيقة`, `in ${m} min`) : T(`بعد ${Math.floor(m / 60)} س ${m % 60 ? `و${m % 60} د` : ''}`, `in ${Math.floor(m / 60)} h ${m % 60 ? `${m % 60} min` : ''}`);
  return `<div class="tk-n pk ${m <= 15 ? 'soon' : ''}">${ic('clock', 18)}<span><b>${T('الاستلام الساعة', 'Pickup at')} ${clockAt(o.pick)}</b><small>${when}</small></span></div>`;
}
/* the customer's stars and words once the order is done */
const starsRow = n => `<span class="rstars" aria-label="${T(`${n} من 5`, `${n} of 5`)}">${[1, 2, 3, 4, 5].map(k => `<i class="${k <= n ? 'on' : ''}">${ic('star', 14)}</i>`).join('')}</span>`;
const rateLine = o => o.rate ? `<div class="tk-n rt">${starsRow(o.rate.s)}<span><b>${T('تقييم العميل', 'The customer’s rating')}</b>${o.rate.c ? `<small>«${esc(o.rate.c)}»</small>` : ''}</span></div>` : '';
/* a gift brought to someone else: who gets it and the sender's message (to write on the card) */
const giftLine = o => o.gift ? `<div class="tk-n gift">${ic('gift', 18)}<span><b>${T('هدية إلى', 'Gift to')} ${esc(o.gift.name || T('المستلم', 'the recipient'))}${o.gift.phone ? ` · ${phoneLink(o.gift.phone)}` : o.gift.tail ? ` <span class="ltr">•••${esc(o.gift.tail)}</span>` : ''}</b>${o.gift.msg ? `<small>«${esc(o.gift.msg)}»</small>` : ''}</span></div>` : '';
function ticket(o) {
  const c = custOf(o), b = BR[o.branch], ship = o.mode === 'ship', del = o.mode === 'delivery', showBr = APP === 'admin' || S.rcBr === 'all';
  const type = ship ? `${T('شحن', 'Shipping')} · ${o.carrier}` : del ? T('توصيل', 'Delivery') : (o.serve === 'take' ? T('تيك أواي', 'Takeaway') : T('داخل الفرع', 'Dine in'));
  const mins = Math.floor((nowS() - o.ts) / 6e4), late = !o.rej && !o.fin && o.st < 2 && (o.pick ? nowS() >= o.pick - 5 * 6e4 : mins >= 10);
  const addr = o.addr ? `<div class="tk-ad">${ic('pin', 15)}<span>${esc(o.addr.city)}، ${esc(o.addr.street)}${o.addr.note ? `<small>${esc(o.addr.note)}</small>` : ''}${del && o.addr.lat != null ? ` <a class="tel" href="${mapLink(o.addr)}" target="_blank" rel="noopener noreferrer">${T('الخريطة', 'Map')}</a>` : ''}</span></div>` : '';
  return `<article class="tk ${o.rej ? 'rj' : 's' + o.st}" data-id="${o.id}">
    <div class="tk-h"><b class="tk-no">${o.no}</b><span class="tk-ty">${ic(ship || del ? 'truck' : 'bag', 15)}${esc(type)}</span><span class="tk-age ${late ? 'late' : ''}" data-ago="${o.ts}">${ago(o.ts)}</span>${o.rej ? '' : `<button class="tk-pr" data-a="rcPrint" data-id="${o.id}" aria-label="${T(`طباعة الطلب ${o.no}`, `Print order ${o.no}`)}">${ic('printer', 17)}</button>`}</div>
    <div class="tk-c"><span class="av">${esc(c.name.charAt(0))}</span><span class="grow"><b>${esc(c.name)}</b><small>${showBr ? esc(brName(b)) : ''}${showBr && c.tail ? ' · ' : ''}${c.tail ? `<span class="ltr">•••${esc(c.tail)}</span>` : ''}</small></span>${sChip(o)}</div>
    ${pickLine(o)}${giftLine(o)}<ul class="tk-i">${tkItems(o)}</ul>
    ${addr}${rateLine(o)}
    <div class="tk-f"><span class="grey">${esc(payLabel(o.payM))} · ${o.disc ? T('بعد الخصم', 'after discount') : T('شامل الضريبة', 'incl. VAT')}</span><b>${money2(o.total)}</b></div>
    ${tkActions(o)}</article>`;
}

/* ---------- printing a ticket (0.7): for the bar, and with the tax invoice when there is one, for the customer ---------- */
function receiptHTML(o) {
  const b = BR[o.branch], c = custOf(o), ship = o.mode === 'ship', del = o.mode === 'delivery';
  const type = ship ? `شحن · ${o.carrier}` : del ? 'توصيل' : (o.serve === 'take' ? 'تيك أواي' : 'داخل الفرع');
  const items = o.items.map(it => { const so = selText(it.sel); return `<li><b class="ltr">${it.qty}×</b> <span>${esc((it.n && (it.n.ar || it.n.en)) || itemName(it))}${it.rw ? ' (مكافأة)' : ''}${it.gift ? ' (هدية)' : ''}${so ? `<small>${esc(so)}</small>` : ''}</span></li>`; }).join('');
  return `<div class="rcpt" dir="rtl" lang="ar"><div class="rc-h"><b>${o.no}</b><span>${esc(type)}</span></div>
    <p>${esc(b ? L(b) : '')} · <span class="ltr">${dISO(o.ts)} ${hhmm(o.ts)}</span></p>
    ${o.pick ? `<p class="rc-pk">الاستلام الساعة ${clockAt(o.pick)}</p>` : ''}
    <p>${esc(c.name)}${c.tail ? ` <span class="ltr">•••${esc(c.tail)}</span>` : ''}</p>
    <ul>${items}</ul>
    ${o.gift ? `<p class="rc-g">هدية إلى ${esc(o.gift.name || 'المستلم')}${o.gift.msg ? `<br>«${esc(o.gift.msg)}»` : ''}</p>` : ''}
    ${o.addr ? `<p>${esc(o.addr.city)}، ${esc(o.addr.street)}${o.addr.note ? `<br>${esc(o.addr.note)}` : ''}</p>` : ''}
    ${o.inv ? invoiceHTML(o) : `<p class="rc-t">الإجمالي <b class="ltr">${fmt2(o.total)}</b> ر.س · ${esc(payLabel(o.payM))}</p>`}</div>`;
}

/* ---------- rejecting an order ---------- */
SHEETS.reject = function () {
  const o = ordById(UI.sheet.id); if (!o) return '';
  const sel = UI.rj.reason;
  return sheetWrap(`<div class="sbody"><h2 class="sttl">${T('سبب رفض الطلب', 'Why reject this order?')}</h2><p class="ssub">${o.no} · ${esc(custOf(o).name)}</p>
    ${REASONS.map(r => `<button class="opt ${sel === r.id ? 'on' : ''}" data-a="rejPick" data-id="${r.id}"><span class="mk"></span><span class="grow">${L(r)}</span></button>`).join('')}
    <button class="btn dng" style="margin-top:6px" data-a="rejOk" data-id="${o.id}">${T('رفض الطلب', 'Reject the order')}</button>
    <p class="grey" style="text-align:center;margin-top:10px;font-size:13px">${T('يصل العميل إشعار ويُرد له المبلغ.', 'The customer is notified and refunded.')}</p></div>`, T('رفض الطلب', 'Reject the order'));
};

/* ---------- actions shared by the staff pages ---------- */
Object.assign(A, {
  async login() {
    if (UI.lg.busy || !NEED.login()) return;
    UI.lg.busy = true; UI.lg.err = ''; render();
    try {
      const body = {pin:UI.lg.pin}; if (APP === 'driver') body.name = UI.lg.name.trim();
      if (APP === 'recv' && UI.lg.br) body.branch = UI.lg.br;
      const r = await api(`/${APP}/login`, body);
      if (APP === 'driver') { S.lastName = UI.lg.name.trim(); save(); }
      if (APP === 'recv') { S.desk = UI.lg.br || ''; save(); }
      UI.lg.pin = ''; UI.lg.busy = false; UI.lg.err = '';
      SRV.me = r.me; SRV.rev = -1; UI.mode = 'boot'; render(); startPoll(); keepAwake();
    } catch (e) {
      UI.lg.busy = false; UI.lg.pin = ''; UI.lg.err = errText(e); UI.focus = '#pin'; render();
    }
  },
  signOut() {
    UI.dlg = {t:T('تسجيل الخروج', 'Sign out'), b:T('ستحتاج الرمز السري للدخول مرة أخرى.', 'You will need the secret code to sign in again.'), ok:T('تسجيل الخروج', 'Sign out'), danger:true, fn() { doSignOut(); }};
    render();
  },
  sound() { S.sound = !S.sound; save(); render(); if (S.sound) beep(); },
  lgBr(d) { UI.lg.br = d.id || ''; UI.lg.err = ''; render(); },
  async pushOn() {
    try { await pushSubscribe(`/${APP}/push`); toast(T('تم تفعيل التنبيهات على هذا الجهاز', 'Alerts are on for this device')); }
    catch (e) { toast(errText(e)); }
    render();
  },

  /* the order ticket */
  rcAccept(d) { const o = ordById(d.id); if (o && !o.rej && o.st === 0) doStaff(`/${APP}/order`, {id:o.id, op:'accept'}, T(`تم قبول الطلب ${o.no}`, `Order ${o.no} accepted`)); },
  rcReady(d) {
    const o = ordById(d.id); if (!o || o.rej || o.st !== 1) return;
    doStaff(`/${APP}/order`, {id:o.id, op:'ready'}, o.mode === 'ship' ? T(`تم شحن الطلب ${o.no}`, `Order ${o.no} shipped`) : o.mode === 'delivery' ? T(`الطلب ${o.no} جاهز للتوصيل`, `Order ${o.no} is ready for delivery`) : T(`الطلب ${o.no} جاهز للاستلام`, `Order ${o.no} is ready`));
  },
  async rcDeliver(d) {
    const o = ordById(d.id); if (!o || o.rej || o.st !== 2) return;
    const body = {id:o.id, op:'deliver'};
    if (d.skip) body.skip = true;
    else if (o.mode === 'pickup') {
      const v = String(UI.rc.code[o.id] || '').trim();
      if (v.length < 4) { toast(T('أدخل رمز الإستلام من العميل (4 أرقام)', 'Enter the customer’s 4-digit pickup code')); return; }
      body.code = v;
    }
    const r = await doStaff(`/${APP}/order`, body, T(`تم تسليم الطلب ${o.no}`, `Order ${o.no} handed over`));
    if (r) delete UI.rc.code[o.id];
    else if (o.mode === 'pickup' && !d.skip) { UI.rc.code[o.id] = ''; const el = $(`[data-bind="rc.code.${o.id}"]`); if (el) { el.value = ''; el.focus(); } }
  },
  rcSkip(d) {
    const o = ordById(d.id); if (!o) return;
    UI.dlg = {t:T('تسليم بدون رمز', 'Hand over without the code'), b:T('هل تريد تأكيد التسليم بدون التحقق من رمز العميل؟ استخدمه فقط إذا تأكدت أن الطلب وصل لصاحبه.', 'Confirm the handover without checking the customer’s code? Only do this if you are sure the order reached its owner.'), ok:T('تأكيد التسليم', 'Confirm'),
      fn() { A.rcDeliver({id:d.id, skip:'1'}); }};
    render();
  },
  rcUnassign(d) {
    const o = ordById(d.id); if (!o || !o.driver) return;
    UI.dlg = {t:T('إلغاء إسناد المندوب', 'Take the order off the driver'), b:T(`سيعود الطلب ${o.no} إلى قائمة المندوبين المتاحين.`, `Order ${o.no} goes back to the list the free drivers see.`), ok:T('إلغاء الإسناد', 'Take it off'), danger:true,
      fn() { doStaff(`/${APP}/order`, {id:o.id, op:'unassign'}, T('عاد الطلب إلى المندوبين', 'Back with the drivers')); }};
    render();
  },
  rcReject(d) { UI.rj = {reason:'out'}; openSheet({k:'reject', id:d.id}); },
  rcPrint(d) { const o = ordById(d.id); if (o) printHTML(receiptHTML(o)); },
  rejPick(d) { UI.rj.reason = d.id; render(); },
  async rejOk(d) {
    const o = ordById(d.id); if (!o || !UI.rj.reason) return;
    UI.sheet = null;
    await doStaff(`/${APP}/order`, {id:o.id, op:'reject', reason:UI.rj.reason}, T(`تم رفض الطلب ${o.no}`, `Order ${o.no} rejected`));
    render();
  },
  async branchPause(d) {
    const was = bPaused(d.id);
    const r = await doStaff(`/${APP}/branch`, {id:d.id, pause:!was});
    if (r) { (SRV.br[d.id] = SRV.br[d.id] || {}).pause = !was; toast(!was ? T('تم إيقاف استقبال الطلبات مؤقتًا', 'Orders paused') : T('عاد الفرع لاستقبال الطلبات', 'Orders resumed')); }
  }
});

/* ---------- timers ---------- */
setInterval(() => $$('[data-ago]').forEach(el => { el.textContent = ago(Number(el.dataset.ago)); }), 15000);
setInterval(() => { if (UI.mode === 'main') UI.dirty = true; }, 60000);   /* the "late" marks follow the clock */
