#!/usr/bin/env python3
"""App Store Connect, for build.sh (standard library only).

  python3 asc.py prepare BUNDLE_PREFIX  target:suffix:name ...
      registers the apps' bundle IDs if they are missing, and writes ready.txt: the targets whose app already exists in
      App Store Connect (only those can be sent to TestFlight). Missing apps are reported as GitHub annotations.

The key comes from the environment: ASC_KEY_ID, ASC_ISSUER_ID and ASC_KEY_FILE (the .p8 file). It is never printed.
"""
import base64
import hashlib
import json
import os
import re
import secrets
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

API = "https://api.appstoreconnect.apple.com/v1/"
P = 0xFFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF
N = 0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551
G = (0x6B17D1F2E12C4247F8BCE6E563A440F277037D812DEB33A0F4A13945D898C296,
     0x4FE342E2FE1A7F9B8EE7EB4A7C0F9E162BCE33576B315ECECBB6406837BF51F5)


def _dbl(A):
    X, Y, Z = A
    if not Z or not Y:
        return (0, 1, 0)
    YY = Y * Y % P
    S = 4 * X * YY % P
    ZZ = Z * Z % P
    M = 3 * (X - ZZ) * (X + ZZ) % P
    X3 = (M * M - 2 * S) % P
    return (X3, (M * (S - X3) - 8 * YY * YY) % P, 2 * Y * Z % P)


def _add(A, B):
    if not A[2]:
        return B
    if not B[2]:
        return A
    X1, Y1, Z1 = A
    X2, Y2, Z2 = B
    Z1Z1, Z2Z2 = Z1 * Z1 % P, Z2 * Z2 % P
    U1, U2 = X1 * Z2Z2 % P, X2 * Z1Z1 % P
    S1, S2 = Y1 * Z2 * Z2Z2 % P, Y2 * Z1 * Z1Z1 % P
    if U1 == U2:
        return _dbl(A) if S1 == S2 else (0, 1, 0)
    H, R = (U2 - U1) % P, (S2 - S1) % P
    HH = H * H % P
    HHH, V = H * HH % P, U1 * HH % P
    X3 = (R * R - HHH - 2 * V) % P
    return (X3, (R * (V - X3) - S1 * HHH) % P, H * Z1 * Z2 % P)


def _mul(k):
    R, Q = (0, 1, 0), (G[0], G[1], 1)
    for b in bin(k)[2:]:
        R = _dbl(R)
        if b == "1":
            R = _add(R, Q)
    zi = pow(R[2], -1, P)
    return (R[0] * zi * zi % P, R[1] * zi * zi * zi % P)


def b64u(b):
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode("ascii")


def private_number(pem):
    """The secret number of an Apple .p8 key (PKCS#8, P-256)."""
    body = re.sub(r"-----[^-]+-----|\s", "", pem)
    der = base64.b64decode(body)
    at = der.find(b"\x02\x01\x01\x04\x20")   # ECPrivateKey: version 1, then the 32-byte secret
    if at < 0:
        raise SystemExit("ASC_KEY_P8 does not look like an App Store Connect key (.p8)")
    return int.from_bytes(der[at + 5:at + 37], "big")


def token():
    kid, iss = os.environ["ASC_KEY_ID"], os.environ["ASC_ISSUER_ID"]
    d = private_number(open(os.environ["ASC_KEY_FILE"], encoding="utf-8").read())
    head = b64u(json.dumps({"alg": "ES256", "kid": kid, "typ": "JWT"}).encode())
    now = int(time.time())
    body = b64u(json.dumps({"iss": iss, "iat": now, "exp": now + 1000, "aud": "appstoreconnect-v1"}).encode())
    msg = ("%s.%s" % (head, body)).encode()
    z = int.from_bytes(hashlib.sha256(msg).digest(), "big")
    while True:
        k = secrets.randbelow(N - 1) + 1
        r = _mul(k)[0] % N
        s = pow(k, -1, N) * (z + r * d) % N
        if r and s:
            return "%s.%s" % (msg.decode(), b64u(r.to_bytes(32, "big") + s.to_bytes(32, "big")))


def call(tok, path, body=None):
    req = urllib.request.Request(API + path, method="POST" if body else "GET",
                                 data=json.dumps(body).encode() if body else None,
                                 headers={"Authorization": "Bearer " + tok, "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        text = e.read().decode("utf-8", "replace")
        if e.code == 401:
            raise SystemExit("::error::App Store Connect refused the key (401): check ASC_KEY_ID, ASC_ISSUER_ID and ASC_KEY_P8")
        raise SystemExit("::error::App Store Connect said %s for %s: %s" % (e.code, path, text[:400]))


def prepare(prefix, specs):
    tok = token()
    ready, missing = [], []
    for spec in specs:
        target, suffix, name = spec.split(":", 2)
        ident = "%s.%s" % (prefix, suffix)
        q = urllib.parse.quote(ident)
        found = [x for x in call(tok, "bundleIds?filter[identifier]=%s&limit=50" % q).get("data", [])
                 if x["attributes"]["identifier"] == ident]
        if not found:
            # Apple takes only letters, digits and spaces in a bundle ID's name ("Why!" is refused)
            label = re.sub(r"\s+", " ", re.sub(r"[^A-Za-z0-9 ]+", " ", name)).strip() or "Why"
            call(tok, "bundleIds", {"data": {"type": "bundleIds", "attributes": {"identifier": ident, "name": label, "platform": "IOS"}}})
            print("registered the bundle ID", ident)
        apps = [x for x in call(tok, "apps?filter[bundleId]=%s&limit=50" % q).get("data", [])
                if x["attributes"]["bundleId"] == ident]
        if apps:
            ready.append(target)
            print("app found in App Store Connect:", name, ident)
        else:
            missing.append((name, ident))
    open("ready.txt", "w").write("\n".join(ready) + "\n")
    for name, ident in missing:
        print("::error::Create the app «%s» in App Store Connect (Apps → + → New App) with the Bundle ID %s, then run this again." % (name, ident))
    return 0


if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "prepare":
        sys.exit(prepare(sys.argv[2], sys.argv[3:]))
    sys.exit(__doc__)
