import Foundation

// Put into every page before it runs: the phone's location and printing go through the app instead of the web view,
// so the page asks once (the app's own question) and printing works.
enum Bridge {
    static let script = """
    (function () {
      if (!window.webkit || !window.webkit.messageHandlers || !window.webkit.messageHandlers.why) return;
      var post = function (m) { window.webkit.messageHandlers.why.postMessage(m); };
      var cbs = {}, n = 0;
      window.WHY_APP = 'ios';
      window.__whyGeo = function (id, ok, d) {
        var c = cbs[id]; if (!c) return;
        if (c.once) delete cbs[id];
        if (ok) { if (c.s) c.s({coords: {latitude: d.lat, longitude: d.lng, accuracy: d.acc, altitude: null, altitudeAccuracy: null, heading: null, speed: null}, timestamp: d.ts}); }
        else if (c.e) c.e({code: d.code, message: d.msg || '', PERMISSION_DENIED: 1, POSITION_UNAVAILABLE: 2, TIMEOUT: 3});
      };
      var geo = {
        getCurrentPosition: function (s, e, o) { var id = ++n; cbs[id] = {s: s, e: e, once: true}; post({t: 'geo1', id: id, to: (o && o.timeout) || 20000}); },
        watchPosition: function (s, e) { var id = ++n; cbs[id] = {s: s, e: e}; post({t: 'geoW', id: id}); return id; },
        clearWatch: function (id) { delete cbs[id]; post({t: 'geoC', id: id}); }
      };
      try { Object.defineProperty(navigator, 'geolocation', {value: geo, configurable: true}); } catch (e) {}
      window.print = function () { post({t: 'print'}); };
    })();
    """
}
