import CoreLocation
import UIKit
import WebKit

// The phone's location for the page (the customer's "my location", the driver's position on the customer's map).
// In DELIVERY (WhyBackgroundLocation) it goes on while the driver is in another app, such as Google Maps: then the app
// sends the position to the server itself, every 10 seconds at most, as the page does while it is open.
final class Location: NSObject, CLLocationManagerDelegate {
    private weak var web: WKWebView?
    private let start: URL
    private let manager = CLLocationManager()
    private let background = Bundle.main.object(forInfoDictionaryKey: "WhyBackgroundLocation") as? Bool == true
    private var onceIds: [Int: Bool] = [:]
    private var watchIds = Set<Int>()
    private var lastSent = Date.distantPast

    init(start: URL, web: WKWebView) {
        self.start = start
        self.web = web
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.distanceFilter = 10
        if background {
            manager.activityType = .otherNavigation
            manager.pausesLocationUpdatesAutomatically = false
        }
    }

    // ---- what the page asks for
    func once(_ id: Int, timeoutMs: Double) {
        onceIds[id] = true
        guard allowed(id) else { return }
        DispatchQueue.main.asyncAfter(deadline: .now() + max(1, timeoutMs / 1000)) { [weak self] in
            guard let self = self, self.onceIds.removeValue(forKey: id) != nil else { return }
            self.fail(id, code: 3, msg: "timeout")
            self.update()
        }
        update()
    }

    func watch(_ id: Int) {
        watchIds.insert(id)
        guard allowed(id) else { return }
        update()
    }

    func clear(_ id: Int) {
        watchIds.remove(id)
        update()
    }

    private var status: CLAuthorizationStatus { manager.authorizationStatus }

    private func allowed(_ id: Int) -> Bool {
        switch status {
        case .denied, .restricted:
            onceIds.removeValue(forKey: id)
            watchIds.remove(id)
            fail(id, code: 1, msg: "denied")
            return false
        case .notDetermined:
            manager.requestWhenInUseAuthorization()   // the answer comes to locationManagerDidChangeAuthorization
            return true
        default:
            return true
        }
    }

    private func update() {
        let need = !onceIds.isEmpty || !watchIds.isEmpty
        let ok = status == .authorizedWhenInUse || status == .authorizedAlways
        if need && ok {
            if background && !watchIds.isEmpty {
                manager.allowsBackgroundLocationUpdates = true
                manager.showsBackgroundLocationIndicator = true
            }
            manager.startUpdatingLocation()
        } else {
            manager.stopUpdatingLocation()
            if background { manager.allowsBackgroundLocationUpdates = false }
        }
    }

    // ---- what the phone answers
    func locationManagerDidChangeAuthorization(_ m: CLLocationManager) {
        switch status {
        case .denied, .restricted:
            let ids = Array(onceIds.keys) + Array(watchIds)
            onceIds.removeAll()
            watchIds.removeAll()
            for id in ids { fail(id, code: 1, msg: "denied") }
            update()
        case .notDetermined:
            break
        default:
            update()
        }
    }

    func locationManager(_ m: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let l = locations.last else { return }
        let ids = Array(onceIds.keys) + Array(watchIds)
        onceIds.removeAll()
        let d = String(format: "{lat:%.7f,lng:%.7f,acc:%.1f,ts:%.0f}", l.coordinate.latitude, l.coordinate.longitude,
                       max(0, l.horizontalAccuracy), l.timestamp.timeIntervalSince1970 * 1000)
        for id in ids { run("window.__whyGeo&&window.__whyGeo(\(id),true,\(d))") }
        if background && !watchIds.isEmpty && UIApplication.shared.applicationState != .active { send(l) }
        update()
    }

    func locationManager(_ m: CLLocationManager, didFailWithError error: Error) {
        if (error as? CLError)?.code == .locationUnknown { return }   // the phone keeps trying
        let ids = Array(onceIds.keys)
        onceIds.removeAll()
        for id in ids { fail(id, code: 2, msg: "unavailable") }
        update()
    }

    private func fail(_ id: Int, code: Int, msg: String) {
        run("window.__whyGeo&&window.__whyGeo(\(id),false,{code:\(code),msg:'\(msg)'})")
    }

    private func run(_ js: String) {
        web?.evaluateJavaScript(js, completionHandler: nil)
    }

    // ---- the driver's position while the app is in the background: straight to the server, with the page's sign-in
    private func send(_ l: CLLocation) {
        guard Date().timeIntervalSince(lastSent) >= 10,
              let url = URL(string: "/api/driver/loc", relativeTo: start)?.absoluteURL,
              let host = url.host else { return }
        lastSent = Date()
        let body: [String: Any] = ["lat": l.coordinate.latitude, "lng": l.coordinate.longitude,
                                   "acc": Int(max(0, l.horizontalAccuracy).rounded())]
        WKWebsiteDataStore.default().httpCookieStore.getAllCookies { cookies in
            let mine = cookies.filter { c in
                let d = c.domain.hasPrefix(".") ? String(c.domain.dropFirst()) : c.domain
                return host == d || host.hasSuffix("." + d)
            }
            var req = URLRequest(url: url, timeoutInterval: 15)
            req.httpMethod = "POST"
            req.setValue("application/json", forHTTPHeaderField: "Content-Type")
            for (k, v) in HTTPCookie.requestHeaderFields(with: mine) { req.setValue(v, forHTTPHeaderField: k) }
            req.httpBody = try? JSONSerialization.data(withJSONObject: body)
            let task = BackgroundTask()
            URLSession.shared.dataTask(with: req) { _, _, _ in
                DispatchQueue.main.async { task.end() }
            }.resume()
        }
    }
}

// a little time to finish sending when the phone wants to pause the app
final class BackgroundTask {
    private var id = UIBackgroundTaskIdentifier.invalid

    init() {
        id = UIApplication.shared.beginBackgroundTask { [weak self] in self?.end() }
    }

    func end() {
        if id != .invalid {
            UIApplication.shared.endBackgroundTask(id)
            id = .invalid
        }
    }
}
