import UIKit
import WebKit

final class WebViewController: UIViewController, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler, WKDownloadDelegate {
    private var web: WKWebView!
    private var location: Location!
    private var errorView: UIView?
    private var downloads: [WKDownload: URL] = [:]

    private let start: URL = {
        let s = Bundle.main.object(forInfoDictionaryKey: "WhyStartURL") as? String ?? ""
        return URL(string: s) ?? URL(string: "https://whycoffee.duckdns.org/")!
    }()

    override func loadView() {
        let conf = WKWebViewConfiguration()
        conf.websiteDataStore = .default()                     // the page keeps what it saved (sign-in, cart) between launches
        conf.allowsInlineMediaPlayback = true
        conf.applicationNameForUserAgent = "WhyApp/1 (iOS)"
        let ucc = WKUserContentController()
        ucc.addUserScript(WKUserScript(source: Bridge.script, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        ucc.add(WeakHandler(self), name: "why")
        conf.userContentController = ucc

        web = WKWebView(frame: .zero, configuration: conf)
        web.navigationDelegate = self
        web.uiDelegate = self
        web.allowsBackForwardNavigationGestures = false
        web.scrollView.contentInsetAdjustmentBehavior = .never   // the page places itself around the notch (viewport-fit=cover)
        web.backgroundColor = .white
        web.isOpaque = true

        // a swipe in from the edge goes back, as in other iPhone apps: from the right edge in Arabic (pages come in from
        // the left), from the left edge in English. The page decides what back means: a question, a sheet, then the page.
        for side in [UIRectEdge.left, UIRectEdge.right] {
            let edge = UIScreenEdgePanGestureRecognizer(target: self, action: #selector(edgeBack(_:)))
            edge.edges = side
            web.addGestureRecognizer(edge)
        }

        let root = UIView()
        root.backgroundColor = .white
        web.frame = root.bounds
        web.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        root.addSubview(web)
        view = root
        location = Location(start: start, web: web)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        if Bundle.main.object(forInfoDictionaryKey: "WhyKeepAwake") as? Bool == true {
            UIApplication.shared.isIdleTimerDisabled = true      // ORDER DESK and DELIVERY: the screen stays on
        }
        web.load(URLRequest(url: start))
    }

    @objc private func edgeBack(_ g: UIScreenEdgePanGestureRecognizer) {
        guard g.state == .ended else { return }
        let dx = g.translation(in: view).x
        let startX = g.location(in: view).x - dx            // where the finger came in, whatever the phone's language
        let side: String
        if startX < view.bounds.midX && dx > 60 { side = "left" }
        else if startX >= view.bounds.midX && dx < -60 { side = "right" }
        else { return }
        let js = "(function(s){var rtl=document.documentElement.dir==='rtl';if(s!==(rtl?'right':'left'))return false;"
            + "return !!(window.whyBack&&window.whyBack());})('\(side)')"
        web.evaluateJavaScript(js, completionHandler: nil)
    }

    // ---- messages from the page
    func userContentController(_ ucc: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let m = message.body as? [String: Any], let t = m["t"] as? String else { return }
        let id = (m["id"] as? NSNumber)?.intValue ?? 0
        switch t {
        case "geo1": location.once(id, timeoutMs: (m["to"] as? NSNumber)?.doubleValue ?? 20000)
        case "geoW": location.watch(id)
        case "geoC": location.clear(id)
        case "print": printPage()
        default: break
        }
    }

    // ---- where links go: our own pages stay here; phone calls, WhatsApp, maps and other sites open outside
    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if action.shouldPerformDownload { decisionHandler(.download); return }
        guard let url = action.request.url else { decisionHandler(.cancel); return }
        let scheme = (url.scheme ?? "").lowercased()
        let isWeb = scheme == "https" || scheme == "http"
        if scheme == "blob" || scheme == "data" || scheme == "about" { decisionHandler(.allow); return }
        if isWeb && url.host == start.host {
            if action.targetFrame == nil { webView.load(action.request); decisionHandler(.cancel); return }
            decisionHandler(.allow); return
        }
        if !isWeb || action.navigationType == .linkActivated || action.targetFrame == nil {
            UIApplication.shared.open(url)
            decisionHandler(.cancel); return
        }
        decisionHandler(.allow)   // a page the site itself moves to (later: the payment page)
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = action.request.url {
            if url.host == start.host { webView.load(action.request) } else { UIApplication.shared.open(url) }
        }
        return nil
    }

    // ---- files the page hands over (the Excel report, the backup copy): the share sheet, to save them in Files or send them
    func webView(_ webView: WKWebView, decidePolicyFor response: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        if let r = response.response as? HTTPURLResponse,
           let cd = r.value(forHTTPHeaderField: "Content-Disposition"), cd.lowercased().hasPrefix("attachment") {
            decisionHandler(.download); return
        }
        decisionHandler(response.canShowMIMEType ? .allow : .download)
    }

    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) { download.delegate = self }
    func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) { download.delegate = self }

    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse, suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let url = dir.appendingPathComponent(suggestedFilename.isEmpty ? "file" : suggestedFilename)
        downloads[download] = url
        completionHandler(url)
    }

    func downloadDidFinish(_ download: WKDownload) {
        guard let url = downloads.removeValue(forKey: download) else { return }
        let share = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        share.popoverPresentationController?.sourceView = view
        share.popoverPresentationController?.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
        topController().present(share, animated: true)
    }

    func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
        downloads.removeValue(forKey: download)
    }

    // ---- printing (the order ticket, the invoice): the phone's print sheet (AirPrint)
    private func printPage() {
        let info = UIPrintInfo(dictionary: nil)
        info.outputType = .general
        info.jobName = "Why!"
        let pc = UIPrintInteractionController.shared
        pc.printInfo = info
        pc.printFormatter = web.viewPrintFormatter()
        if UIDevice.current.userInterfaceIdiom == .pad {
            _ = pc.present(from: CGRect(x: view.bounds.midX, y: 80, width: 1, height: 1), in: view, animated: true, completionHandler: nil)
        } else {
            pc.present(animated: true, completionHandler: nil)
        }
    }

    // ---- no connection: a plain page with a retry button instead of an empty screen
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        let e = error as NSError
        if e.domain == NSURLErrorDomain && e.code != NSURLErrorCancelled { showError() }
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        errorView?.removeFromSuperview()
        errorView = nil
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        webView.reload()
    }

    private func showError() {
        guard errorView == nil else { return }
        let box = UIView(frame: view.bounds)
        box.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        box.backgroundColor = .white
        let title = UILabel()
        title.text = "تعذّر الاتصال"
        title.font = .systemFont(ofSize: 22, weight: .bold)
        title.textAlignment = .center
        let note = UILabel()
        note.text = "تأكد من اتصالك بالإنترنت ثم أعد المحاولة."
        note.font = .systemFont(ofSize: 16)
        note.textColor = .secondaryLabel
        note.textAlignment = .center
        note.numberOfLines = 0
        let retry = UIButton(type: .system)
        retry.setTitle("إعادة المحاولة", for: .normal)
        retry.titleLabel?.font = .systemFont(ofSize: 18, weight: .semibold)
        retry.addTarget(self, action: #selector(retryTapped), for: .touchUpInside)
        let stack = UIStackView(arrangedSubviews: [title, note, retry])
        stack.axis = .vertical
        stack.spacing = 14
        stack.translatesAutoresizingMaskIntoConstraints = false
        box.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.centerYAnchor.constraint(equalTo: box.centerYAnchor),
            stack.leadingAnchor.constraint(equalTo: box.leadingAnchor, constant: 32),
            stack.trailingAnchor.constraint(equalTo: box.trailingAnchor, constant: -32),
        ])
        view.addSubview(box)
        errorView = box
    }

    @objc private func retryTapped() {
        errorView?.removeFromSuperview()
        errorView = nil
        if web.url == nil { web.load(URLRequest(url: start)) } else { web.reload() }
    }

    private func topController() -> UIViewController {
        var top: UIViewController = self
        while let next = top.presentedViewController { top = next }
        return top
    }
}

// the page holds the app only weakly (a script handler is kept by the web view)
final class WeakHandler: NSObject, WKScriptMessageHandler {
    private weak var target: WKScriptMessageHandler?
    init(_ target: WKScriptMessageHandler) { self.target = target }
    func userContentController(_ ucc: WKUserContentController, didReceive message: WKScriptMessage) {
        target?.userContentController(ucc, didReceive: message)
    }
}
