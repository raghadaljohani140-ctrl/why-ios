#!/usr/bin/env python3
"""Build the package that goes to GitHub and then to the server:  dist/why-site-v<VERSION>.zip

  install.sh, caddy-block.tpl, why-server.service.tpl, VERSION, README.md    what runs on the server
  site/                                                                     the four pages Caddy serves:
      /  customers (Why!)    /reception/  ORDER DESK    /admin/  MANAGEMENT    /driver/  DELIVERY
      (each page has its own manifest, icons and start screens, so each installs on a phone as a separate app;
       names, colours and logos come from assets/brand/, made by tools/brand/brand.py)
  source/                                                                   everything needed to rebuild and keep developing:
      prototype/ assets/ server/ test/ tools/ deploy/

usage: python3 tools/package_site.py [version]      (default: the number in deploy/VERSION)
"""
import hashlib, json, shutil, subprocess, sys, tempfile, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEPLOY = ROOT / "deploy"
SERVER = ROOT / "server"
VERSION = sys.argv[1] if len(sys.argv) > 1 else (DEPLOY / "VERSION").read_text().strip()
STAMP = (2026, 11, 15, 18, 0, 0)          # fixed, so the same files always give the same zip (and the same checksum)

BRAND = json.loads((ROOT / "assets" / "brand" / "brand.json").read_text(encoding="utf-8"))
YELLOW = BRAND["colors"]["yellow"]
# app (as in build.py), folder inside site/ (the addresses stay as they were, so phones that already added a page keep it),
# icon-file suffix, description
APPS = [
    ("cust",   "",          "",        "تطبيق محمصة واي! — القهوة والحبوب"),
    ("recv",   "reception", "-recv",   "ORDER DESK — استلام طلبات واي! وتجهيزها داخل الكوفي"),
    ("admin",  "admin",     "-admin",  "MANAGEMENT — إدارة واي!: المبيعات والمنتجات والفروع والعملاء"),
    ("driver", "driver",    "-driver", "DELIVERY — تطبيق مندوب التوصيل في واي!"),
]
ICON_BASES = ["apple-touch-icon", "favicon-48", "icon-192", "icon-512", "icon-maskable-512"]

# ---- the package must agree with itself before anything is built
server_version = next(l.split('"')[1] for l in (SERVER / "why_server.py").read_text(encoding="utf-8").splitlines() if l.startswith("VERSION = "))
if server_version != VERSION:
    sys.exit(f"the server program says version {server_version} but the package is {VERSION}: change one of them")
for f in ("install.sh", "caddy-block.tpl", "why-server.service.tpl", "README.md"):
    if not (DEPLOY / f).is_file():
        sys.exit(f"deploy/{f} is missing")

# catalog.json (option prices, rewards, branches, and the first menu with its photos) is made from data.js and
# assets/products: it must match them
if shutil.which("node"):
    fresh = subprocess.run([sys.executable, str(ROOT / "tools" / "export_catalog.py"), "-"], check=True, capture_output=True).stdout
    if fresh != (SERVER / "catalog.json").read_bytes():
        sys.exit("server/catalog.json is out of date with prototype/src/data.js or assets/products: run  python3 tools/export_catalog.py")
else:
    print("note: node is not available here, so server/catalog.json was not compared with the menu in the app")

files = {}   # path in the zip -> (bytes, mode)


def add(name, data, mode=0o644):
    if isinstance(data, str):
        data = data.encode("utf-8")
    files[name] = (data, mode)


ANCHOR = '<meta name="theme-color" content="%s">\n' % ("#ECB444" if YELLOW.lower() == "#ecb444" else YELLOW.upper())
HEAD = """<meta name="robots" content="noindex, nofollow">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="{title}">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<link rel="manifest" href="manifest.webmanifest">
<link rel="icon" type="image/png" sizes="48x48" href="favicon-48.png">
<link rel="apple-touch-icon" href="apple-touch-icon.png">
{splash}"""

# ---- the four pages
with tempfile.TemporaryDirectory() as td:
    for app, folder, suffix, desc in APPS:
        names = BRAND["apps"][app]
        title, name, short = names["home"], names["name"], names["home"]
        sdir = ROOT / "assets" / "splash" / app
        if not (sdir / "media.json").is_file():
            sys.exit(f"missing start screens for {app}: run  python3 tools/brand/brand.py")
        screens = json.loads((sdir / "media.json").read_text())
        splash = "".join(f'<link rel="apple-touch-startup-image" media="screen and {q}" href="splash/{n}">\n' for n, q in screens)
        built = Path(td) / f"{app}.html"
        subprocess.run([sys.executable, str(ROOT / "prototype" / "build.py"), "--app", app, "--out", str(built)], check=True, stdout=subprocess.DEVNULL)
        html = built.read_text(encoding="utf-8")
        assert html.count(ANCHOR) == 1, "template.html changed: the theme-color line was not found"
        page = html.replace(ANCHOR, ANCHOR + HEAD.format(title=title, splash=splash), 1)
        assert 'id="app"' in page and f"const APP = '{app}';" in page
        prefix = f"site/{folder}/" if folder else "site/"
        add(prefix + "index.html", page)
        add(prefix + "manifest.webmanifest", json.dumps({
            "name": name, "short_name": short, "description": desc,
            "lang": "ar", "dir": "rtl",
            "start_url": "./", "scope": "./",
            "display": "standalone",
            "background_color": YELLOW, "theme_color": YELLOW,
            "icons": [
                {"src": "icon-192.png", "sizes": "192x192", "type": "image/png"},
                {"src": "icon-512.png", "sizes": "512x512", "type": "image/png"},
                {"src": "icon-maskable-512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable"},
            ],
        }, ensure_ascii=False, indent=2) + "\n")
        for base in ICON_BASES:
            src = ROOT / "assets" / "icons" / f"{base}{suffix}.png"
            if not src.is_file():
                sys.exit(f"missing icon: assets/icons/{src.name}  (python3 tools/brand/brand.py)")
            add(prefix + f"{base}.png", src.read_bytes())
        for n, _ in screens:
            add(prefix + f"splash/{n}", (sdir / n).read_bytes())
add("site/robots.txt", "User-agent: *\nDisallow: /\n")
add("site/sw.js", (ROOT / "prototype" / "sw.js").read_bytes())   # 0.7: the notifications worker, for every page (scope /)

# ---- what runs on the server
add("install.sh", (DEPLOY / "install.sh").read_bytes(), 0o755)
add("caddy-block.tpl", (DEPLOY / "caddy-block.tpl").read_bytes())
add("why-server.service.tpl", (DEPLOY / "why-server.service.tpl").read_bytes())
add("VERSION", VERSION + "\n")
add("README.md", (DEPLOY / "README.md").read_text(encoding="utf-8").replace("{{VERSION}}", VERSION))

# ---- the source, so a new chat can pick the work up from this one file
SKIP_DIRS = {"__pycache__", "node_modules", ".git"}


def add_tree(folder, prefix, patterns=None, skip=()):
    for p in sorted(folder.rglob("*")):
        if p.is_dir() or SKIP_DIRS & set(p.parts):
            continue
        rel = p.relative_to(folder)
        if patterns and not any(rel.match(x) for x in patterns):
            continue
        if rel.parts[0] in skip:
            continue
        add(f"source/{prefix}/{rel.as_posix()}", p.read_bytes(), 0o755 if p.suffix == ".sh" else 0o644)


add_tree(ROOT / "prototype", "prototype", ["build.py", "template.html", "sw.js", "src/*"])
add_tree(ROOT / "assets", "assets", skip=("store", "splash"))     # those two are made again by tools/brand/brand.py
add_tree(SERVER, "server", ["why_server.py", "catalog.json", "test_server.py"])
add_tree(ROOT / "test", "test", ["smoke.js", "staff_e2e.js", "admin_e2e.js", "serve.sh", "run_all.sh"])
add_tree(ROOT / "ios", "ios", ["project.yml", "build.sh", "asc.py", "testflight.yml", "README.txt", "Shared/*.swift"])   # the iPhone apps (icons come from assets/store)
add_tree(ROOT / "tools", "tools", ["package_site.py", "package_ios.py", "export_catalog.js", "export_catalog.py", "crop_products.py", "brand/*.py"])   # not the one-off patch*.py
add_tree(DEPLOY, "deploy", ["install.sh", "caddy-block.tpl", "why-server.service.tpl", "test_install.py", "README.md", "VERSION"])

out = ROOT / "dist"
out.mkdir(exist_ok=True)
zpath = out / f"why-site-v{VERSION}.zip"
with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name in sorted(files):
        data, mode = files[name]
        zi = zipfile.ZipInfo(name, STAMP)
        zi.compress_type = zipfile.ZIP_DEFLATED
        zi.external_attr = (0o100000 | mode) << 16
        z.writestr(zi, data)
sha = hashlib.sha256(zpath.read_bytes()).hexdigest()
(out / f"why-site-v{VERSION}.sha256").write_text(f"{sha}  why-site-v{VERSION}.zip\n")
print(f"{zpath.name}: {zpath.stat().st_size:,} bytes, {len(files)} files")
print(f"sha256 {sha}")

# ---- the store icons, for whoever builds the iPhone and Android apps (not needed on the server)
STORE_NAMES = {"cust": "why", "recv": "order-desk", "admin": "management", "driver": "delivery"}
STORE_README = """Why! — app icons for the App Store and Google Play  /  أيقونات تطبيقات واي! للمتجرين

why/          Why!         (customers  /  العملاء)
order-desk/   ORDER DESK   (orders in the café  /  طلبات الكوفي)
management/   MANAGEMENT   (admin  /  الإدارة)
delivery/     DELIVERY     (driver  /  المندوب)

Each folder:
  ios/AppIcon.appiconset/        drop into Assets.xcassets in Xcode (all iPhone and iPad sizes + 1024 for the App Store, no transparency)
  android/res/                   merge into app/src/main/res (launcher icons for every density, adaptive and themed icon, background colour)
  google-play/icon-512.png       the store listing icon
  google-play/feature-graphic-1024x500.png

Made from assets/brand/ by tools/brand/brand.py (version %s).
"""
spath = out / f"why-store-icons-v{VERSION}.zip"
store_root = ROOT / "assets" / "store"
with zipfile.ZipFile(spath, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    def put(name, data):
        zi = zipfile.ZipInfo(name, STAMP); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = (0o100644) << 16
        z.writestr(zi, data)
    put("why-store-icons/README.txt", STORE_README % VERSION)
    for app, folder in STORE_NAMES.items():
        base = store_root / app
        if not base.is_dir():
            sys.exit(f"missing store icons for {app}: run  python3 tools/brand/brand.py")
        for f in sorted(base.rglob("*")):
            if f.is_file():
                put(f"why-store-icons/{folder}/{f.relative_to(base).as_posix()}", f.read_bytes())
print(f"{spath.name}: {spath.stat().st_size:,} bytes")
