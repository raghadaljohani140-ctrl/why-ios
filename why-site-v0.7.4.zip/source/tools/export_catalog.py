#!/usr/bin/env python3
"""Writes server/catalog.json: what the server needs from prototype/src/data.js, and the first menu with its photos.

  The option groups, rewards, banners, branches, carriers and fees come from data.js (through export_catalog.js).
  "seed" is the first menu: categories, products and the photos in assets/products/<product id>.(png|jpg|webp).
  The server copies the seed into its database the first time it starts; after that the admin edits the menu there
  (products, categories, photos) and the seed is not read again.

usage: python3 tools/export_catalog.py [out.json | -]      (default server/catalog.json, - = print)
"""
import base64, io, json, subprocess, sys
from pathlib import Path

from PIL import Image, ImageOps

ROOT = Path(__file__).resolve().parent.parent
RASTER = {".png", ".jpg", ".jpeg", ".webp"}
FULL, THUMB = 1000, 320          # longest side of the product photo and of its small copy (lists, cart, tiles)


def has_alpha(im):
    if im.mode in ("RGBA", "LA") or (im.mode == "P" and "transparency" in im.info):
        lo, _ = im.convert("RGBA").getchannel("A").getextrema()
        return lo < 250
    return False


def corner_colour(rgb):
    """Average colour of the four corners and how far the corners differ from each other (the app does the same)."""
    w, h = rgb.size
    n = max(4, min(w, h) // 40)
    px = [rgb.crop((x, y, x + n, y + n)).resize((1, 1), Image.BOX).getpixel((0, 0))
          for x, y in ((0, 0), (w - n, 0), (0, h - n), (w - n, h - n))]
    avg = tuple(sum(p[i] for p in px) // 4 for i in range(3))
    spread = max(max(abs(p[i] - avg[i]) for i in range(3)) for p in px)
    return avg, spread


def webp(im, quality):
    buf = io.BytesIO()
    im.save(buf, "WEBP", quality=quality, method=6)
    return buf.getvalue()


def photo(path):
    """A product photo as the server keeps it: a large copy and a small one, both WebP, and how to show it.
    f "c": the photo sits on a plain background of colour bg (the whole photo shows); f "v": it fills the tile."""
    im = ImageOps.exif_transpose(Image.open(path))
    im.load()
    alpha = has_alpha(im)
    im = im.convert("RGBA" if alpha else "RGB")
    big, small = im.copy(), im.copy()
    big.thumbnail((FULL, FULL), Image.LANCZOS)
    small.thumbnail((THUMB, THUMB), Image.LANCZOS)
    if alpha:
        bg, f = None, "c"
    else:
        avg, spread = corner_colour(big)
        bg, f = "#%02x%02x%02x" % avg, ("c" if spread <= 26 else "v")
    full, thumb = webp(big, 84 if alpha else 82), webp(small, 80)
    return {"mime": "image/webp", "w": big.width, "h": big.height, "bg": bg, "f": f,
            "full": base64.b64encode(full).decode("ascii"), "thumb": base64.b64encode(thumb).decode("ascii")}


def build():
    raw = subprocess.run(["node", str(ROOT / "tools" / "export_catalog.js"), "-"], check=True, capture_output=True, text=True).stdout
    cat = json.loads(raw)
    ids = {p["id"] for p in cat["seed"]["products"]}
    images = {}
    folder = ROOT / "assets" / "products"
    for f in sorted(folder.glob("*")) if folder.is_dir() else []:
        if f.suffix.lower() not in RASTER:
            continue
        if f.stem not in ids:
            print(f"warning: assets/products/{f.name} does not match any product id in data.js", file=sys.stderr)
            continue
        images[f.stem] = photo(f)
    cat["seed"]["images"] = images
    return json.dumps(cat, ensure_ascii=False, indent=1) + "\n", cat


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else str(ROOT / "server" / "catalog.json")
    text, cat = build()
    if out == "-":
        sys.stdout.buffer.write(text.encode("utf-8"))
    else:
        Path(out).write_text(text, encoding="utf-8")
        print(f"catalog: {len(cat['seed']['products'])} products, {len(cat['seed']['cats'])} categories, {len(cat['seed']['images'])} photos -> {out}")
