#!/usr/bin/env python3
"""Everything that carries the Why! identity, made from assets/brand/:
brand.json (colours, font, app names, the style of the small words) and the three symbols
(wordmark.svg "why!", mark.svg "w", scooter.svg the delivery scooter with the w on its box).

Writes
  assets/logo.svg, assets/mark.svg            the wordmark and the w, embedded in the apps by prototype/build.py
  assets/brand/lockup-<app>.svg               W + ORDER DESK, W + MANAGEMENT, scooter + DELIVERY (sign-in, start screens)
  assets/brand/lockup-<app>-compact.svg       the same for small places such as the top bar: the words a little larger
  assets/icons/<name><suffix>.png             home-screen icons of the four web apps (what tools/package_site.py uses)
  assets/splash/<app>/<w>x<h>.png             iPhone and iPad start screens
  assets/store/<app>/                         App Store and Google Play icon sets, for when the phone apps are published
  assets/brand/preview.png                    one sheet with all of it, to look at

Needs rsvg-convert (librsvg), fontTools and Pillow.      usage: python3 tools/brand/brand.py
"""
import json, re, shutil, subprocess, sys
from io import BytesIO
from pathlib import Path

from PIL import Image, ImageDraw
from fontTools.pens.boundsPen import BoundsPen
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.ttLib import TTFont

ROOT = Path(__file__).resolve().parents[2]
BR = ROOT / "assets" / "brand"
CFG = json.loads((BR / "brand.json").read_text(encoding="utf-8"))
COL = CFG["colors"]
APPS = ["cust", "recv", "admin", "driver"]
SUFFIX = {"cust": "", "recv": "-recv", "admin": "-admin", "driver": "-driver"}
STAFF = ["recv", "admin", "driver"]


def fnum(v):
    return ("%.3f" % v).rstrip("0").rstrip(".")


# ------------------------------------------------------------------ symbols and the small words
class Symbol:
    def __init__(self, path):
        text = path.read_text(encoding="utf-8")
        if "<script" in text.lower():
            sys.exit(f"{path.name}: an SVG with a script tag is not allowed")
        self.vb = [float(v) for v in re.split(r"[\s,]+", re.search(r'viewBox="([^"]+)"', text).group(1).strip())]
        self.inner = re.search(r"<svg[^>]*>(.*)</svg>", text, re.S).group(1)
        self.w, self.h = self.vb[2], self.vb[3]
        self.text = text

    def place(self, x, y, w, h):
        vb = " ".join(fnum(v) for v in self.vb)
        return f'<svg x="{fnum(x)}" y="{fnum(y)}" width="{fnum(w)}" height="{fnum(h)}" viewBox="{vb}" overflow="visible">{self.inner}</svg>'


SYM = {k: Symbol(BR / v) for k, v in CFG["symbols"].items()}


def find_font(name):
    for d in (ROOT / "tools" / "brand" / "fonts", Path("/usr/share/fonts/truetype/google-fonts"), Path("/usr/share/fonts"),
              Path.home() / ".fonts", Path("/Library/Fonts")):
        if (d / name).is_file():
            return d / name
        if d.is_dir():
            hit = next(iter(sorted(d.rglob(name))), None)
            if hit:
                return hit
    sys.exit(f"font {name} not found (put it in tools/brand/fonts/)")


FONT = TTFont(find_font(CFG["caption"]["font"]))


def words(text, cap, tracking):
    """The text as outlines: (path data with the baseline at y=0, ink left, ink right, ink top, ink bottom)."""
    gs, cmap = FONT.getGlyphSet(), FONT.getBestCmap()
    k = cap / FONT["OS/2"].sCapHeight
    upm = FONT["head"].unitsPerEm
    pen = SVGPathPen(gs, ntos=fnum)
    x, box = 0.0, [None, None, 0.0, 0.0]
    for ch in text:
        g = cmap[ord(ch)]
        bp = BoundsPen(gs)
        gs[g].draw(bp)
        if bp.bounds:
            x0, y0, x1, y1 = bp.bounds
            box[0] = x + x0 * k if box[0] is None else min(box[0], x + x0 * k)
            box[1] = x + x1 * k if box[1] is None else max(box[1], x + x1 * k)
            box[2] = min(box[2], -y1 * k)
            box[3] = max(box[3], -y0 * k)
        gs[g].draw(TransformPen(pen, (k, 0, 0, -k, x, 0)))
        x += FONT["hmtx"][g][0] * k + tracking * upm * k
    return pen.getCommands(), box


# ------------------------------------------------------------------ lockups
Z = 100.0     # the height of the w; everything in a lockup is measured against it


def lockup(app, compact=False):
    """(width, height, svg body) of the app's logo: the wordmark alone, or the symbol with its word under it."""
    a = CFG["apps"][app]
    sym = SYM[a["symbol"]]
    if not a.get("caption"):
        return sym.w, sym.h, sym.place(0, 0, sym.w, sym.h)
    st = CFG["caption"]["compact"] if compact else CFG["caption"]
    if a["symbol"] == "scooter":                 # centred in the same zone as the w, so all three captions line up
        sh = Z * CFG["scooter_height"]
        sw, sy = sh * sym.w / sym.h, (Z - sh) / 2
    else:
        sh, sw, sy = Z, Z * sym.w / sym.h, 0.0
    cap, gap = Z * st["cap"], Z * st["gap"]
    d, (cx0, cx1, ctop, cbot) = words(a["caption"], cap, st["tracking"])
    cw = cx1 - cx0
    w = max(sw, cw)
    base = Z + gap + cap
    h = base + cbot
    body = (sym.place((w - sw) / 2, sy, sw, sh) +
            f'<path transform="translate({fnum((w - cw) / 2 - cx0)} {fnum(base)})" d="{d}" fill="#000"/>')
    return w, h, body


def svg_doc(w, h, body, size=None):
    wh = f' width="{fnum(size[0])}" height="{fnum(size[1])}"' if size else f' width="{fnum(w)}" height="{fnum(h)}"'
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {fnum(w)} {fnum(h)}"{wh}>{body}</svg>\n'


def render(svg, w, h):
    out = subprocess.run(["rsvg-convert", "-w", str(w), "-h", str(h)], input=svg.encode(), capture_output=True, check=True).stdout
    return Image.open(BytesIO(out)).convert("RGBA")


# ------------------------------------------------------------------ icons
# The staff icons share one scale, so the w is the same size in all of them and the words line up.
LK = {a: lockup(a) for a in APPS}


def common(fn):
    return min(fn(*LK[a][:2]) for a in STAFF)


def content(app, side, kind):
    """The logo placed in a side x side square for one kind of icon: (svg body, scale)."""
    w, h, body = LK[app]
    simple = kind == "small" and app != "cust"
    if simple:                                   # tiny icons: the symbol alone, the words would be a blur
        sym = SYM[CFG["apps"][app]["symbol"]]
        w, h, body = sym.w, sym.h, sym.place(0, 0, sym.w, sym.h)
    half_diag = lambda W, H: (W * W + H * H) ** .5 / 2
    if app == "cust":
        k = {"any": .70 * side / w, "small": .84 * side / w, "maskable": .40 * side / half_diag(w, h),
             "fg": 33 / 108 * side / half_diag(w, h), "feature": .90 * side / w}[kind]
    elif simple:
        k = (.60 * side / h) if CFG["apps"][app]["symbol"] == "mark" else (.78 * side / w)
    else:
        k = {"any": common(lambda W, H: min(.62 * side / W, .52 * side / H)),
             "maskable": common(lambda W, H: .40 * side / half_diag(W, H)),
             "fg": common(lambda W, H: 33 / 108 * side / half_diag(W, H)),
             "feature": common(lambda W, H: .56 * side / H)}[kind]
    return f'<g transform="translate({fnum((side - w * k) / 2)} {fnum((side - h * k) / 2)}) scale({k:.6f})">{body}</g>', k


def icon(app, px, kind="any", bg="square"):
    """kind: any | small | maskable | fg (Android adaptive foreground, also the monochrome layer)."""
    side = 1024
    g, _ = content(app, side, kind)
    back = {"square": f'<rect width="{side}" height="{side}" fill="{COL["yellow"]}"/>',
            "none": "",
            "circle": f'<circle cx="{side / 2}" cy="{side / 2}" r="{side / 2}" fill="{COL["yellow"]}"/>',
            "rounded": f'<rect x="{side * .04}" y="{side * .04}" width="{side * .92}" height="{side * .92}" rx="{side * .2}" fill="{COL["yellow"]}"/>'}[bg]
    return render(svg_doc(side, side, back + g, (px, px)), px, px)


def save(im, path, mode="RGB", optimize=True):
    path.parent.mkdir(parents=True, exist_ok=True)
    if mode == "RGB":
        flat = Image.new("RGB", im.size, COL["yellow"])
        flat.paste(im, mask=im.split()[3])
        im = flat
    im.save(path, "PNG", optimize=optimize)


def white_alpha(im):
    """The same shape in white (Android draws the monochrome layer in the colour of the user's theme)."""
    return Image.merge("RGBA", (Image.new("L", im.size, 255),) * 3 + (im.split()[3],))


# ------------------------------------------------------------------ start screens (iOS reads one per screen size)
PHONES = [(1320, 2868, 3), (1206, 2622, 3), (1290, 2796, 3), (1179, 2556, 3), (1284, 2778, 3), (1170, 2532, 3),
          (1080, 2340, 3), (1125, 2436, 3), (1242, 2688, 3), (828, 1792, 2), (1242, 2208, 3), (750, 1334, 2), (640, 1136, 2)]
TABLETS = [(2048, 2732, 2), (1668, 2388, 2), (1640, 2360, 2), (1668, 2224, 2), (1620, 2160, 2), (1536, 2048, 2), (1488, 2266, 2)]
SPLASH_SETS = {"cust": PHONES, "driver": PHONES, "recv": PHONES + TABLETS, "admin": PHONES + TABLETS}


def splash_list(app):
    """[(file name, width px, height px, media query)]"""
    out = []
    for w, h, r in SPLASH_SETS[app]:
        q = f"(device-width: {w // r}px) and (device-height: {h // r}px) and (-webkit-device-pixel-ratio: {r})"
        out.append((f"{w}x{h}.png", w, h, q + " and (orientation: portrait)"))
        if (w, h, r) in TABLETS:
            out.append((f"{h}x{w}.png", h, w, q + " and (orientation: landscape)"))
    return out


def splash(app, w, h):
    lw, lh, body = lockup(app)
    short = min(w, h)
    if app == "cust":
        k = .52 * short / lw
    else:
        k = (.25 if short < 1400 else .18) * short / Z
    g = f'<g transform="translate({fnum((w - lw * k) / 2)} {fnum((h - lh * k) / 2)}) scale({k:.6f})">{body}</g>'
    im = render(svg_doc(w, h, f'<rect width="{w}" height="{h}" fill="{COL["yellow"]}"/>' + g, (w, h)), w, h)
    return im.convert("RGB").convert("P", palette=Image.ADAPTIVE, colors=32)


# ------------------------------------------------------------------ store sets
IOS = [("iphone", "20x20", "2x", 40), ("iphone", "20x20", "3x", 60), ("iphone", "29x29", "2x", 58), ("iphone", "29x29", "3x", 87),
       ("iphone", "40x40", "2x", 80), ("iphone", "40x40", "3x", 120), ("iphone", "60x60", "2x", 120), ("iphone", "60x60", "3x", 180),
       ("ipad", "20x20", "1x", 20), ("ipad", "20x20", "2x", 40), ("ipad", "29x29", "1x", 29), ("ipad", "29x29", "2x", 58),
       ("ipad", "40x40", "1x", 40), ("ipad", "40x40", "2x", 80), ("ipad", "76x76", "1x", 76), ("ipad", "76x76", "2x", 152),
       ("ipad", "83.5x83.5", "2x", 167), ("ios-marketing", "1024x1024", "1x", 1024)]
ANDROID = [("mdpi", 48, 108), ("hdpi", 72, 162), ("xhdpi", 96, 216), ("xxhdpi", 144, 324), ("xxxhdpi", 192, 432)]
SMALL = 100     # below this many pixels an icon shows the symbol without its words


def store(app, out):
    ios = out / "ios" / "AppIcon.appiconset"
    done = {}
    for idiom, size, scale, px in IOS:
        if px not in done:
            done[px] = icon(app, px, "small" if px < SMALL else "any")
            save(done[px], ios / f"AppIcon-{px}.png")
    images = [{"idiom": i, "size": s, "scale": sc, "filename": f"AppIcon-{px}.png"} for i, s, sc, px in IOS]
    (ios / "Contents.json").write_text(json.dumps({"images": images, "info": {"version": 1, "author": "xcode"}}, indent=2) + "\n")
    res = out / "android" / "res"
    for dens, px, fg in ANDROID:
        d = res / f"mipmap-{dens}"
        kind = "small" if px < SMALL else "any"
        save(icon(app, px, kind, "rounded"), d / "ic_launcher.png", "RGBA")
        save(icon(app, px, kind if kind == "small" else "maskable", "circle"), d / "ic_launcher_round.png", "RGBA")
        fgi = icon(app, fg, "fg", "none")
        save(fgi, d / "ic_launcher_foreground.png", "RGBA")
        save(white_alpha(fgi), d / "ic_launcher_monochrome.png", "RGBA")
    xml = ('<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n'
           '    <background android:drawable="@color/ic_launcher_background"/>\n'
           '    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n'
           '    <monochrome android:drawable="@mipmap/ic_launcher_monochrome"/>\n</adaptive-icon>\n')
    (res / "mipmap-anydpi-v26").mkdir(parents=True, exist_ok=True)
    for n in ("ic_launcher.xml", "ic_launcher_round.xml"):
        (res / "mipmap-anydpi-v26" / n).write_text(xml)
    (res / "values").mkdir(parents=True, exist_ok=True)
    (res / "values" / "ic_launcher_background.xml").write_text(
        f'<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">{COL["yellow"]}</color>\n</resources>\n')
    play = out / "google-play"
    save(icon(app, 512, "any"), play / "icon-512.png", "RGBA")
    fw, fh = 1024, 500
    g, _ = content(app, fh, "feature")
    fx = (fw - fh) / 2
    feat = render(svg_doc(fw, fh, f'<rect width="{fw}" height="{fh}" fill="{COL["yellow"]}"/><g transform="translate({fnum(fx)} 0)">{g}</g>', (fw, fh)), fw, fh)
    save(feat, play / "feature-graphic-1024x500.png")


# ------------------------------------------------------------------ everything
def main():
    shutil.copyfile(BR / CFG["symbols"]["wordmark"], ROOT / "assets" / "logo.svg")
    shutil.copyfile(BR / CFG["symbols"]["mark"], ROOT / "assets" / "mark.svg")
    for app in STAFF:
        for compact in (False, True):
            w, h, body = lockup(app, compact)
            (BR / f"lockup-{app}{'-compact' if compact else ''}.svg").write_text(svg_doc(w, h, body), encoding="utf-8")
    icons = ROOT / "assets" / "icons"
    for app in APPS:
        sfx = SUFFIX[app]
        save(icon(app, 180), icons / f"apple-touch-icon{sfx}.png")
        save(icon(app, 192), icons / f"icon-192{sfx}.png")
        save(icon(app, 512), icons / f"icon-512{sfx}.png")
        save(icon(app, 512, "maskable"), icons / f"icon-maskable-512{sfx}.png")
        save(icon(app, 48, "small"), icons / f"favicon-48{sfx}.png")
    for app in APPS:
        d = ROOT / "assets" / "splash" / app
        if d.is_dir():
            shutil.rmtree(d)
        d.mkdir(parents=True)
        for name, w, h, _ in splash_list(app):
            splash(app, w, h).save(d / name, "PNG", optimize=True)
        (d / "media.json").write_text(json.dumps([[n, q] for n, _, _, q in splash_list(app)], indent=1) + "\n")
    st = ROOT / "assets" / "store"
    if st.is_dir():
        shutil.rmtree(st)
    for app in APPS:
        store(app, st / app)
    preview()
    print("brand: logos, lockups, icons, splash screens and store icons are up to date")


def preview():
    """One sheet: the four home-screen icons, the logos on white and on black, and two start screens."""
    W, H = 2200, 1500
    sheet = Image.new("RGB", (W, H), "#F4F2EE")
    d = ImageDraw.Draw(sheet)
    for i, app in enumerate(APPS):
        ic = icon(app, 360)
        m = Image.new("L", (360, 360), 0)
        ImageDraw.Draw(m).rounded_rectangle((0, 0, 359, 359), 80, fill=255)
        sheet.paste(ic.convert("RGB"), (80 + i * 520, 70), m)
    for i, app in enumerate(APPS):
        w, h, body = lockup(app, False)
        k = 150 / Z if app != "cust" else 300 / w
        im = render(svg_doc(w, h, body, (w * k, h * k)), round(w * k), round(h * k))
        x, y = 80 + i * 520 + (360 - im.width) // 2, 520 + (200 - im.height) // 2
        sheet.paste(im, (x, y), im)
        dark = Image.new("RGB", (440, 230), COL["black"])
        w2, h2, body2 = lockup(app, True)
        k2 = 92 / Z if app != "cust" else 240 / w2
        im2 = render(svg_doc(w2, h2, body2, (w2 * k2, h2 * k2)), round(w2 * k2), round(h2 * k2))
        tint = Image.new("RGBA", im2.size, COL["yellow"])
        tint.putalpha(im2.split()[3])
        dark.paste(tint, ((440 - im2.width) // 2, (230 - im2.height) // 2), tint)
        sheet.paste(dark, (40 + i * 520, 780))
    for i, app in enumerate(("cust", "admin")):
        sp = splash(app, 1179, 2556).convert("RGB").resize((240, 520), Image.LANCZOS)
        sheet.paste(sp, (40 + i * 280, 960 + 10))
    for i, app in enumerate(("recv", "driver")):
        ic = icon(app, 432, "fg", "none")
        bgc = Image.new("RGB", (432, 432), COL["yellow"])
        bgc.paste(ic, (0, 0), ic)
        m = Image.new("L", (432, 432), 0)
        ImageDraw.Draw(m).ellipse((72, 72, 360, 360), fill=255)
        crop = Image.new("RGB", (432, 432), "#F4F2EE")
        crop.paste(bgc, (0, 0), m)
        sheet.paste(crop.crop((60, 60, 372, 372)), (640 + i * 360, 1060))
    sheet.save(BR / "preview.png", "PNG", optimize=True)


if __name__ == "__main__":
    main()
