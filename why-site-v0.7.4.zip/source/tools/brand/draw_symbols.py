#!/usr/bin/env python3
"""Draw the three Why! brand symbols as clean vector art:  assets/brand/wordmark.svg, mark.svg, scooter.svg

The shapes were measured from the owner's images (assets/brand/src/why-logo.jpg and scooter.jpg, 2026-11-15):
  - wordmark  "why!" in one even stroke with round ends: every measure below was fitted to the image
              (stroke width, x-height, stems, the rounded top of the w, the arch of the h, the bowl of the y);
  - mark      the w of the wordmark on its own (the "W" logo of the staff apps);
  - scooter   the delivery scooter, rebuilt from exact circles, round bars and smooth curves that follow
              the image; the owner asked for the W on its delivery box, so the w is cut out of the box.
All units are pixels of the source images; each file's viewBox is the tight box around its ink.
When the owner sends official vector files, put them in assets/brand/ under the same names instead and
run  python3 tools/brand/brand.py  (lockups, icons and splash screens all follow from these three files).

usage: python3 tools/brand/draw_symbols.py
"""
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "assets" / "brand"
INK = "#000"     # the files are one-colour; the apps and brand.py colour them

# ------------------------------------------------------------------ wordmark (why!)
S = 15.3                      # stroke width
B, XH, ASC = 129.0, 65.8, 46.6  # centre line of the baseline, of the x-height and of the h's ascender
W_L, W_R, W_AY, W_RF = 139.6, 203.4, 96.2, 13.0   # w: stems, height of the inner peak, its rounding
H_X, H_R, H_CY = 233.1, 31.5, 104.0              # h: stem, arch radius, arch centre height
Y_A, Y_B, Y_CY = 322.0, 385.4, 73.7              # y: arms, bowl centre height
EX, ET, EB, ERT, ERB = 419.5, 82.9, 107.9, 6.8, 1.4   # !: tapered stroke, top and bottom radii
DOT_Y, DOT_R = 129.2, 8.65


def f(v):
    return ("%.2f" % v).rstrip("0").rstrip(".")


def w_path():
    ax = (W_L + W_R) / 2
    a = (ax, W_AY)
    u1 = (W_L - ax, B - W_AY); n1 = math.hypot(*u1); u1 = (u1[0] / n1, u1[1] / n1)
    u2 = (W_R - ax, B - W_AY); n2 = math.hypot(*u2); u2 = (u2[0] / n2, u2[1] / n2)
    half = math.acos(u1[0] * u2[0] + u1[1] * u2[1]) / 2
    t = W_RF / math.tan(half)
    p1 = (a[0] + u1[0] * t, a[1] + u1[1] * t); p2 = (a[0] + u2[0] * t, a[1] + u2[1] * t)
    return (f"M{f(W_L)} {f(XH)}V{f(B)}L{f(p1[0])} {f(p1[1])}A{f(W_RF)} {f(W_RF)} 0 0 1 {f(p2[0])} {f(p2[1])}"
            f"L{f(W_R)} {f(B)}V{f(XH)}")


def h_path():
    r = H_X + 2 * H_R
    return f"M{f(H_X)} {f(ASC)}V{f(B)}M{f(H_X)} {f(B)}V{f(H_CY)}A{f(H_R)} {f(H_R)} 0 0 1 {f(r)} {f(H_CY)}V{f(B)}"


def y_path():
    cx, r = (Y_A + Y_B) / 2, (Y_B - Y_A) / 2
    return (f"M{f(Y_A)} {f(XH)}V{f(Y_CY)}A{f(r)} {f(r)} 0 0 0 {f(Y_B)} {f(Y_CY)}V{f(XH)}"
            f"M{f(cx)} {f(Y_CY + r)}V{f(B)}")


def bang_path():
    s = (ERT - ERB) / (EB - ET); c = math.sqrt(1 - s * s)
    return (f"M{f(EX - ERT * c)} {f(ET + ERT * s)}A{f(ERT)} {f(ERT)} 0 1 1 {f(EX + ERT * c)} {f(ET + ERT * s)}"
            f"L{f(EX + ERB * c)} {f(EB + ERB * s)}A{f(ERB)} {f(ERB)} 0 0 1 {f(EX - ERB * c)} {f(EB + ERB * s)}Z")


STROKE = f'fill="none" stroke="{INK}" stroke-width="{f(S)}" stroke-linecap="round" stroke-linejoin="round"'


def svg(box, body):
    x, y, w, h = box
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{f(x)} {f(y)} {f(w)} {f(h)}" '
            f'width="{f(w)}" height="{f(h)}">{body}</svg>\n')


def wordmark():
    x0, y0 = W_L - S / 2, ASC - S / 2
    x1, y1 = EX + DOT_R, max(B + S / 2, DOT_Y + DOT_R)
    body = (f'<path d="{w_path()}{h_path()}{y_path()}" {STROKE}/>'
            f'<path d="{bang_path()}" fill="{INK}"/><circle cx="{f(EX)}" cy="{f(DOT_Y)}" r="{f(DOT_R)}" fill="{INK}"/>')
    return svg((x0, y0, x1 - x0, y1 - y0), body)


def mark():
    x0, y0 = W_L - S / 2, XH - S / 2
    return svg((x0, y0, W_R - W_L + S, B - XH + S), f'<path d="{w_path()}" {STROKE}/>')


# ------------------------------------------------------------------ scooter
TIRE, RIM, HUB = 13.55, 8.54, 4.71
WHEELS = [(79.81, 104.94), (140.31, 104.94)]
BOX = (67.5, 57.42, 99.46, 85.46, 3.23)                                  # x0 y0 x1 y1 corner
LINES = [(51.6, 66.1), (49.3, 74.35), (53.5, 82.6)]                       # speed lines: left end, height
LINE_R, LINE_X1 = 1.85, 62.0


def catmull(pts, closed=False):
    """Smooth path through the points (centripetal Catmull-Rom as cubic Beziers), starting with L to the first."""
    out = []
    P = pts
    for i in range(len(P) - 1):
        p0 = P[i - 1] if i > 0 else P[i]
        p1, p2 = P[i], P[i + 1]
        p3 = P[i + 2] if i + 2 < len(P) else P[i + 1]
        c1 = (p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6)
        c2 = (p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6)
        out.append(f"C{f(c1[0])} {f(c1[1])} {f(c2[0])} {f(c2[1])} {f(p2[0])} {f(p2[1])}")
    return "".join(out)


def tire_y(cx, cy, y, side):
    return cx + side * math.sqrt(TIRE ** 2 - (y - cy) ** 2)


def body_path():
    (rx, ry), (fx, fy) = WHEELS
    floor_bot = 108.8
    # column, left edge (bottom to top) and its fillet into the floor
    col_left = [(116.6, 99.0), (119.4, 98.3), (121.2, 97.0), (122.4, 95.6), (123.3, 93.6), (124.0, 91.2), (124.5, 88.4),
                (124.75, 85.4), (124.6, 82.0), (124.2, 78.4), (123.6, 74.6), (122.9, 70.6), (122.0, 66.6), (121.2, 62.8),
                (120.5, 60.0), (119.8, 58.6)]
    # column, back edge (top to bottom), the front fender and the nose
    col_right = [(127.3, 60.5), (127.6, 61.4), (128.3, 62.6), (129.6, 63.6), (131.5, 64.6), (133.6, 65.9), (135.6, 67.6),
                 (137.1, 69.8), (138.4, 72.2), (139.5, 74.6), (140.5, 77.0), (141.3, 79.4), (142.0, 81.4), (142.8, 82.9),
                 (144.2, 83.9), (146.2, 84.7), (148.3, 85.5), (150.4, 86.8), (152.4, 88.5), (154.2, 90.5), (155.6, 92.6),
                 (156.7, 94.9), (157.5, 97.2), (158.05, 99.3), (158.2, 100.5), (157.9, 101.7), (157.0, 102.8),
                 (155.6, 103.6), (154.3, 104.1), (153.6, 104.9)]
    y_join_f = 108.3
    return ("M67.0 88.0H97.5A4.7 4.7 0 0 1 102.2 92.7V95.2A3.8 3.8 0 0 0 106.0 99.0"
            f"L{f(col_left[0][0])} {f(col_left[0][1])}" + catmull(col_left) +
            "L119.8 57.0L127.0 57.0" + f"L{f(col_right[0][0])} {f(col_right[0][1])}" + catmull(col_right) +
            f"L{f(153.5)} {f(y_join_f)}" +
            f"A{f(TIRE)} {f(TIRE)} 0 0 1 {f(tire_y(fx, fy, floor_bot, -1))} {f(floor_bot)}" +
            f"L{f(tire_y(rx, ry, floor_bot, 1))} {f(floor_bot)}" +
            f"A{f(TIRE)} {f(TIRE)} 0 0 1 {f(tire_y(rx, ry, 106.5, -1))} 106.5" +
            catmull([(tire_y(rx, ry, 106.5, -1), 106.5), (65.2, 105.0), (64.1, 103.9), (63.75, 102.5), (63.85, 101.5)]) +
            "L67.3 92.5L67.6 88Z")


def head_path():
    return ("M119.0 57.4V53.6C119.0 50.6 121.4 48.5 124.4 48.5H130.5A4.1 4.1 0 0 1 134.6 52.6V55.6"
            "A4.6 4.6 0 0 1 130.4 60.0L127.2 60.45H121.2Z")


def scooter():
    x0, x1 = LINES[1][0] - LINE_R, 158.25
    y0, y1 = 48.5, WHEELS[0][1] + TIRE
    bx0, by0, bx1, by1, br = BOX
    # the w of the logo, centred on the box face
    mx0, my0, mw, mh = W_L - S / 2, XH - S / 2, W_R - W_L + S, B - XH + S
    k = (bx1 - bx0) * 0.58 / mw
    cx, cy = (bx0 + bx1) / 2, (by0 + by1) / 2
    tx, ty = cx - (mx0 + mw / 2) * k, cy - (my0 + mh / 2) * k
    white = 'fill="#fff"'
    parts = [
        f'<rect x="62.4" y="87.9" width="38" height="4.4" rx="2.2" {white}/>',                   # rack under the box
        f'<path d="{body_path()}" {white}/>',
        f'<path d="{head_path()}" {white}/>',
        f'<rect x="108.7" y="52.25" width="12" height="5.15" rx="2.575" {white}/>',             # handlebar
    ]
    for cxw, cyw in WHEELS:
        parts += [f'<circle cx="{f(cxw)}" cy="{f(cyw)}" r="{f(TIRE)}" {white}/>',
                  f'<circle cx="{f(cxw)}" cy="{f(cyw)}" r="{f(RIM)}" fill="#000"/>',
                  f'<circle cx="{f(cxw)}" cy="{f(cyw)}" r="{f(HUB)}" {white}/>']
    parts.append(f'<rect x="{f(bx0)}" y="{f(by0)}" width="{f(bx1 - bx0)}" height="{f(by1 - by0)}" rx="{f(br)}" {white}/>')
    parts.append(f'<g transform="translate({f(tx)} {f(ty)}) scale({k:.5f})"><path d="{w_path()}" fill="none" stroke="#000" '
                 f'stroke-width="{f(S)}" stroke-linecap="round" stroke-linejoin="round"/></g>')
    for lx, ly in LINES:
        parts.append(f'<rect x="{f(lx - LINE_R)}" y="{f(ly - LINE_R)}" width="{f(LINE_X1 - lx + 2 * LINE_R)}" '
                     f'height="{f(2 * LINE_R)}" rx="{f(LINE_R)}" {white}/>')
    w, h = x1 - x0, y1 - y0
    body = (f'<mask id="why-scooter" maskUnits="userSpaceOnUse" x="{f(x0)}" y="{f(y0)}" width="{f(w)}" height="{f(h)}">'
            + "".join(parts) + f'</mask><rect x="{f(x0)}" y="{f(y0)}" width="{f(w)}" height="{f(h)}" fill="{INK}" mask="url(#why-scooter)"/>')
    return svg((x0, y0, w, h), body)


if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    for name, fn in (("wordmark", wordmark), ("mark", mark), ("scooter", scooter)):
        (OUT / f"{name}.svg").write_text(fn(), encoding="utf-8")
        print("wrote", (OUT / f"{name}.svg").relative_to(ROOT))
