// End-to-end test of the three staff pages (reception, driver, admin), each in its own browser, against the real server.
// Start the server first:  test/serve.sh 8790     (fresh database every time)
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const BASE = (process.env.WHY_BASE || 'http://127.0.0.1:8790').replace(/\/$/, '');
const OUT = path.join(__dirname, 'staff');
fs.rmSync(OUT, { recursive: true, force: true });
fs.mkdirSync(OUT, { recursive: true });

const results = [];
const check = (name, ok, extra) => { results.push({ name, ok: !!ok, extra }); console.log((ok ? 'PASS ' : 'FAIL ') + name + (extra !== undefined && !ok ? '  -> ' + JSON.stringify(extra) : '')); };
const wait = ms => new Promise(r => setTimeout(r, ms));
const until = async (f, ms = 6000, step = 120) => { const t = Date.now(); for (;;) { try { const v = await f(); if (v) return v; } catch (e) {} if (Date.now() - t > ms) return false; await wait(step); } };

// ---- a customer phone, straight against the API
const DEV = crypto.randomBytes(16).toString('hex');
async function raw(p, body, headers) {
  const r = await fetch(BASE + '/api' + p, { method: body === undefined ? 'GET' : 'POST', headers: Object.assign({ 'Content-Type': 'application/json' }, headers || {}), body: body === undefined ? undefined : JSON.stringify(body) });
  const j = await r.json().catch(() => ({})); j._status = r.status; return j;
}
const cust = (p, b) => raw(p, b, { 'X-Dev': DEV });
let n = 0;
async function place(x) {
  const body = Object.assign({ cid: 'c' + (++n) + crypto.randomBytes(6).toString('hex'), mode: 'pickup', branch: 'b2', serve: 'in', payM: 'card', cust: { name: 'خالد', phone: '566000111' }, items: [{ pid: 'latte', sel: {}, qty: 1 }] }, x || {});
  const r = await cust('/orders', body);
  if (!r.ok) throw new Error('order failed ' + JSON.stringify(r));
  return r.order;
}
const mine = async id => (await cust('/my/sync', { since: 0, srev: -1 })).orders.find(o => o.id === id);

(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const errors = [];
  async function open(name, viewport, url) {
    const ctx = await browser.newContext({ viewport, deviceScaleFactor: 1, geolocation: { latitude: 24.4672, longitude: 39.6024 }, permissions: ['geolocation'] });
    const page = await ctx.newPage();
    page.on('pageerror', e => errors.push(name + ' pageerror: ' + e.message));
    page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errors.push(name + ' console: ' + m.text()); });
    await page.route('**/*', r => r.request().url().startsWith(BASE + '/') ? r.continue() : r.abort());
    await page.goto(BASE + url, { waitUntil: 'domcontentloaded' });
    await wait(500);
    const api = {
      page, ctx,
      ev: (f, a) => page.evaluate(f, a),
      txt: async () => page.locator('#view').innerText(),
      has: async s => (await page.locator('#view').innerText()).includes(s),
      said: async s => (await page.locator('#toasts').innerText()).includes(s),
      click: async sel => { await page.locator(sel).last().click({ timeout: 8000 }); await wait(250); },
      shot: async nm => { await wait(300); await page.screenshot({ path: path.join(OUT, name + '-' + nm + '.png') }); }
    };
    return api;
  }

  // ======================================================================= reception
  const rc = await open('recv', { width: 820, height: 1000 }, '/reception/');
  check('reception: own page, own title', (await rc.page.title()) === 'واي! | الاستقبال');
  check('reception: sign-in first, nothing else on screen', await rc.has('شاشة الاستقبال') && await rc.has('الرمز السري') && !(await rc.has('تطبيق العميل')) && !(await rc.has('لوحة الإدارة')));
  check('reception: no way into the other apps', await rc.page.locator('a[href]').count() === 0 && await rc.ev(() => !('staffOpen' in A) && !('toCust' in A)));
  check('reception: the sign-in page shows the W with ORDER DESK', await rc.page.locator('.gate-logo .im-lockup[aria-label="Why! Order Desk"]').count() === 1 && await rc.ev(() => IMG.lockup.r > .6 && IMG.lockup.r < 1.6));
  await rc.shot('1-login');
  check('reception: sign-in disabled until a valid code', await rc.ev(() => $('[data-a="login"]').disabled));
  await rc.page.fill('#pin', '111111');
  await rc.click('[data-a="login"]');
  check('reception: wrong code is refused with a message', await until(() => rc.has('الاسم أو الرمز غير صحيح')) && await rc.ev(() => UI.mode === 'login'));
  check('reception: the wrong code is cleared from the field', await rc.page.inputValue('#pin') === '');
  await rc.page.fill('#pin', '654321');
  await rc.page.press('#pin', 'Enter');
  check('reception: right code opens the screen', await until(() => rc.has('لا توجد طلبات جديدة')));
  check('reception: the top bar carries the W with ORDER DESK in yellow', await rc.page.locator('.sbar .lk .im-lockupc').count() === 1 && await rc.ev(() => getComputedStyle($('.sbar .lk .lk-i')).backgroundColor === 'rgb(236, 180, 68)'));
  check('reception: in English it is the Order desk, the word Reception is nowhere', await rc.ev(() => { S.lang = 'en'; applyLang(); render(); const ok = !/reception/i.test(document.body.innerText) && !/reception/i.test(document.title) && document.body.innerText.includes('Order desk'); S.lang = 'ar'; applyLang(); render(); return ok; }));
  check('reception: code is not kept in the page', await rc.ev(() => UI.lg.pin === '' && !JSON.stringify(localStorage).includes('654321')));
  check('reception: session cookie is not readable by the page', await rc.ev(() => !document.cookie.includes('why_recv')));
  await rc.shot('2-empty');
  // 0.7: alerts on this tablet even with the page closed (the push service is stood in for; the server's side is real)
  check('reception: this browser said no to notifications: the strip says where to allow them', await rc.has('التنبيهات مرفوضة لهذا الموقع'));
  check('reception: the notifications worker is running', await rc.ev(() => navigator.serviceWorker.ready.then(r => !!r.active)));
  await rc.ev(() => {
    Object.defineProperty(Notification, 'permission', { get: () => window.__perm || 'default', configurable: true });
    Notification.requestPermission = async () => (window.__perm = 'granted');
    SWREG = { pushManager: { getSubscription: async () => window.__sub || null, subscribe: async () => (window.__sub = { endpoint: 'https://fcm.googleapis.com/fcm/send/desk-' + Math.random().toString(36).slice(2), unsubscribe: async () => { window.__sub = null; return true; } }) } };
    render();
  });
  check('reception: not asked yet: it offers alerts on this device', await rc.has('تنبيهات على هذا الجهاز') && await rc.page.locator('[data-a="pushOn"]').count() === 1);
  await rc.shot('2b-alerts');
  await rc.click('[data-a="pushOn"]'); await wait(400);
  const deskEp = await rc.ev(() => window.__sub && window.__sub.endpoint);
  check('reception: alerts on, the strip goes', !!deskEp && await until(async () => !(await rc.has('تنبيهات على هذا الجهاز'))));

  // a customer orders: it must show up without any reload
  const o1 = await place({ branch: 'b2', items: [{ pid: 'latte', sel: { size: 'm', milk: 'oat' }, qty: 2 }, { pid: 'brownie', sel: {}, qty: 1 }], serve: 'take' });
  check('reception: the new order appears by itself', await until(() => rc.has(o1.no.replace(/‎/g, '')), 5000) || await until(() => rc.page.locator(`.tk[data-id="${o1.id}"]`).count().then(c => c === 1), 5000));
  const deskBox = (await raw('/push/inbox', { endpoint: deskEp })).items || [];
  check('reception: the tablet\'s push says a new order came, and opens the desk', deskBox.length === 1 && deskBox[0].t.includes('طلب جديد') && deskBox[0].url === '/reception/' && deskBox[0].b.includes('ر.س'), deskBox);
  check('reception: new tab has the count and highlight', await rc.ev(() => $('.rtabs button[data-id="new"] b').textContent === '1' && $('.rtabs button[data-id="new"]').classList.contains('has')));
  check('reception: ticket shows customer, items, options, takeaway, total', await rc.ev(id => { const t = $(`.tk[data-id="${id}"]`).innerText; return t.includes('خالد') && t.includes('لاتيه') && t.includes('براوني') && t.includes('تيك أواي') && /2×/.test(t); }, o1.id));
  check('reception: pickup code is never shown to staff', await rc.ev(code => !document.body.innerHTML.includes('>' + code + '<') && !document.body.innerHTML.includes('"' + code + '"'), o1.code));
  await rc.shot('3-new-order');
  await rc.click(`[data-a="rcAccept"][data-id="${o1.id}"]`);
  check('reception: accepted → moves to Preparing, customer sees it', await until(async () => (await mine(o1.id)).st === 1) && await rc.ev(() => $('.rtabs button[data-id="prep"] b').textContent === '1'));
  await rc.click('[data-a="rcTab"][data-id="prep"]');
  await rc.click(`[data-a="rcReady"][data-id="${o1.id}"]`);
  check('reception: ready → customer sees stage 2', await until(async () => (await mine(o1.id)).st === 2));
  await rc.click('[data-a="rcTab"][data-id="ready"]');
  await rc.shot('4-ready');
  await rc.page.fill(`[data-bind="rc.code.${o1.id}"]`, o1.code === '0000' ? '1111' : '0000');
  await rc.click(`[data-a="rcDeliver"][data-id="${o1.id}"]`);
  check('reception: wrong pickup code is refused', await until(() => rc.said('الرمز غير صحيح')) && (await mine(o1.id)).st === 2);
  await rc.page.fill(`[data-bind="rc.code.${o1.id}"]`, o1.code);
  await rc.click(`[data-a="rcDeliver"][data-id="${o1.id}"]`);
  check('reception: right code hands it over', await until(async () => (await mine(o1.id)).fin === true));
  await rc.click('[data-a="rcTab"][data-id="done"]');
  check('reception: finished order is in Done', await rc.ev(id => !!$(`.tk[data-id="${id}"]`), o1.id));

  // reject
  const o2 = await place({ branch: 'b2' });
  await until(() => rc.page.locator(`.tk[data-id="${o2.id}"]`).count().then(c => c === 1));
  await rc.click('[data-a="rcTab"][data-id="new"]');
  await rc.click(`[data-a="rcReject"][data-id="${o2.id}"]`);
  check('reception: reject asks for a reason', await rc.has('سبب رفض الطلب') && await rc.page.locator('.sheet .opt').count() === 5);
  await rc.click('[data-a="rejPick"][data-id="busy"]');
  await rc.click(`[data-a="rejOk"][data-id="${o2.id}"]`);
  const rj = await until(async () => (await mine(o2.id)).rej, 5000);
  check('reception: customer gets the rejection with its reason', rj && rj.why.ar === 'الفرع مزدحم حاليًا', rj);

  // delivery: waits for a driver
  const o3 = await place({ mode: 'delivery', branch: 'b2', addr: { city: 'المدينة المنورة', street: 'حي الخزامى، شارع الأمير نايف', note: 'البوابة الزرقاء', lat: 24.4672, lng: 39.6024 }, items: [{ pid: 'cap', sel: {}, qty: 1 }, { pid: 'yirg', sel: {}, qty: 1 }] });
  await until(() => rc.page.locator(`.tk[data-id="${o3.id}"]`).count().then(c => c === 1));
  check('reception: delivery ticket shows type, address and note', await rc.ev(id => { const t = $(`.tk[data-id="${id}"]`).innerText; return t.includes('توصيل') && t.includes('الخزامى') && t.includes('البوابة الزرقاء'); }, o3.id));
  await rc.click(`[data-a="rcAccept"][data-id="${o3.id}"]`);
  await rc.click('[data-a="rcTab"][data-id="prep"]');
  await rc.click(`[data-a="rcReady"][data-id="${o3.id}"]`);
  await rc.click('[data-a="rcTab"][data-id="ready"]');
  check('reception: ready delivery waits for a driver, with a warning banner', await rc.has('بانتظار مندوب') && await rc.has('بانتظار مندوب') && await rc.ev(() => !!$('.pz.warn')));
  await rc.shot('5-delivery-waiting');

  // branch pause
  await rc.click('[data-a="rcBr"][data-id="b2"]');
  check('reception: branch filter shows the pause switch', await rc.page.locator('.pz [data-a="rcPause"]').count() === 1);
  await rc.click('[data-a="rcPause"]');
  check('reception: pausing makes the customer app see the branch closed', await until(async () => (await raw('/public')).br.b2 && (await raw('/public')).br.b2.pause === true));
  const paused = await cust('/orders', { cid: 'p' + crypto.randomBytes(8).toString('hex'), mode: 'pickup', branch: 'b2', cust: { name: 'خالد', phone: '566000111' }, items: [{ pid: 'latte', sel: {}, qty: 1 }] });
  check('server refuses orders to a paused branch', paused._status === 409 && paused.error === 'paused', paused);
  await rc.click('[data-a="rcPause"]');
  check('reception: resuming works', await until(async () => !((await raw('/public')).br.b2 || {}).pause));
  await rc.click('[data-a="rcBr"][data-id="all"]');

  // the line drops: the chip appears, and everything comes back
  await rc.ctx.setOffline(true);
  check('reception: offline chip when the line drops', await until(() => rc.has('بلا اتصال'), 8000));
  await rc.shot('6-offline');
  await rc.ctx.setOffline(false);
  check('reception: back online by itself', await until(async () => !(await rc.has('بلا اتصال')), 12000));

  // ======================================================================= driver
  const adm = await (async () => { const a = { cookie: '' }; const r = await fetch(BASE + '/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ pin: '123456' }) }); a.cookie = r.headers.get('set-cookie').split(';')[0]; a.call = async (p, b) => { const x = await fetch(BASE + '/api' + p, { method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: a.cookie }, body: JSON.stringify(b) }); const j = await x.json().catch(() => ({})); j._status = x.status; return j; }; return a; })();
  check('admin adds two drivers', (await adm.call('/admin/driver', { op: 'add', name: 'سالم', pin: '111222' })).ok && (await adm.call('/admin/driver', { op: 'add', name: 'ماجد', pin: '333444' })).ok);
  const dv = await open('driver', { width: 390, height: 780 }, '/driver/');
  check('driver: own page, own title, sign-in with name and code', (await dv.page.title()) === 'واي! | المندوب' && await dv.has('تطبيق المندوب') && await dv.page.locator('#lgname').count() === 1);
  check('driver: the sign-in page shows the scooter with DELIVERY', await dv.page.locator('.gate-logo .im-lockup[aria-label="Why! Delivery"]').count() === 1);
  await dv.shot('1-login');
  await dv.page.fill('#lgname', 'سالم'); await dv.page.fill('#pin', '999999'); await dv.click('[data-a="login"]');
  check('driver: wrong code refused', await until(() => dv.has('الاسم أو الرمز غير صحيح')));
  await dv.page.fill('#pin', '111222'); await dv.click('[data-a="login"]');
  check('driver: signed in, sees the waiting delivery', await until(() => dv.page.locator(`.tk[data-id="${o3.id}"]`).count().then(c => c === 1)));
  check('driver: before taking he sees city and street but no phone, no note', await dv.ev(id => { const t = $(`.tk[data-id="${id}"]`); const h = t.innerHTML; return h.includes('الخزامى') && !h.includes('البوابة الزرقاء') && !h.includes('tel:') && !h.includes('566000111'); }, o3.id));
  check('driver: available tab is highlighted with the count', await dv.ev(() => $('.rtabs button[data-id="avail"] b').textContent === '1' && $('.rtabs button[data-id="avail"]').classList.contains('has')));
  await dv.shot('2-available');
  const dv2 = await (async () => { const r = await fetch(BASE + '/api/driver/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: 'ماجد', pin: '333444' }) }); const ck = r.headers.get('set-cookie').split(';')[0]; return { take: async id => { const x = await fetch(BASE + '/api/driver/order', { method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: ck }, body: JSON.stringify({ id, op: 'take' }) }); const j = await x.json(); j._status = x.status; return j; } }; })();
  await dv.click(`[data-a="drvTake"][data-id="${o3.id}"]`);
  check('driver: takes it, it moves to Mine', await until(() => dv.ev(id => UI.dv.tab === 'mine' && !!$(`.tk[data-id="${id}"] [data-a="drvDeliver"]`), o3.id)));
  check('driver: now sees phone, note, call and map links', await dv.ev(id => { const h = $(`.tk[data-id="${id}"]`).innerHTML; return h.includes('tel:+966566000111') && h.includes('البوابة الزرقاء') && h.includes('google.com/maps') && h.includes('24.4672'); }, o3.id));
  check('driver: says the order is already paid', await dv.has('مدفوع مسبقًا'));
  await dv.shot('3-mine');
  const lost = await dv2.take(o3.id);
  check('another driver cannot take the same order', lost._status === 409, lost);
  check('customer sees the driver name', await until(async () => ((await mine(o3.id)).driver) === 'سالم'));
  check('reception shows the driver on the ticket', await until(async () => { await rc.click('[data-a="rcTab"][data-id="ready"]'); return rc.ev(id => $(`.tk[data-id="${id}"]`).innerText.includes('سالم'), o3.id); }));
  await rc.shot('7-with-driver');
  await dv.page.fill(`[data-bind="dv.code.${o3.id}"]`, o3.code === '0000' ? '1111' : '0000');
  await dv.click(`[data-a="drvDeliver"][data-id="${o3.id}"]`);
  check('driver: wrong code refused with tries left', await until(() => dv.said('المتبقي 4')));
  await dv.click(`[data-a="drvRelease"][data-id="${o3.id}"]`);
  check('driver: release asks first', await dv.has('إرجاع الطلب') && await dv.page.locator('.dlg').count() === 1);
  await dv.click('[data-a="dlgYes"]');
  check('driver: released order is available again', await until(() => dv.ev(id => !!$(`.tk[data-id="${id}"] [data-a="drvTake"]`) || (UI.dv.tab !== 'avail' && SRV.avail.some(o => o.id === id)), o3.id)));
  check('customer sees no driver again', await until(async () => (await mine(o3.id)).driver === null));
  await dv.click('[data-a="drvTab"][data-id="avail"]');
  await dv.click(`[data-a="drvTake"][data-id="${o3.id}"]`);
  await until(() => dv.ev(id => !!$(`.tk[data-id="${id}"] [data-a="drvDeliver"]`), o3.id));
  await dv.page.fill(`[data-bind="dv.code.${o3.id}"]`, o3.code);
  await dv.click(`[data-a="drvDeliver"][data-id="${o3.id}"]`);
  check('driver: right code delivers', await until(async () => (await mine(o3.id)).fin === true));
  await dv.click('[data-a="drvTab"][data-id="done"]');
  check('driver: it is in Today', await dv.ev(id => !!$(`.tk[data-id="${id}"]`), o3.id));
  await dv.shot('4-done');

  // 0.6: a delivery reaches the drivers while it is being prepared; once ready his phone shares where he is
  const rcCall = (path, body) => rc.ev(([a, b]) => api(a, b), [path, body]);   // the order desk page, signed in
  const o4 = await place({ mode: 'delivery', branch: 'b2', addr: { city: 'المدينة المنورة', street: 'حي العزيزية', lat: 24.47, lng: 39.61 }, items: [{ pid: 'cap', sel: {}, qty: 1 }] });
  check('driver: a new order is not shown before the café accepts it', await dv.ev(id => !SRV.avail.some(o => o.id === id), o4.id));
  await rcCall('/recv/order', { id: o4.id, op: 'accept' });
  await dv.click('[data-a="drvTab"][data-id="avail"]');
  check('driver: accepted and being prepared, it already shows, to be booked', await until(() => dv.ev(id => { const t = $(`.tk[data-id="${id}"]`); return !!t && t.innerText.includes('قيد التحضير') && t.innerText.includes('احجز الطلب'); }, o4.id)));
  await dv.click(`[data-a="drvTake"][data-id="${o4.id}"]`);
  check('driver: booked, it waits in Mine without the code box until it is ready', await until(() => dv.ev(id => { const t = $(`.tk[data-id="${id}"]`); return UI.dv.tab === 'mine' && !!t && t.innerText.includes('استعد للاستلام') && !t.querySelector('[data-a="drvDeliver"]'); }, o4.id)));
  await dv.shot('6-booked-while-preparing');
  check('customer sees the driver while it is prepared', await until(async () => (await mine(o4.id)).driver === 'سالم'));
  await rcCall('/recv/order', { id: o4.id, op: 'ready' });
  check('driver: ready, the code box appears and his position is shared', await until(() => dv.ev(id => { const t = $(`.tk[data-id="${id}"]`); return !!t && !!t.querySelector('[data-a="drvDeliver"]') && t.innerText.includes('موقعك يظهر للعميل'); }, o4.id), 9000));
  check('customer: gets the driver position for the map', await until(async () => { const t = (await cust('/my/sync', { since: 0 })).track || {}; return !!t[o4.id] && Math.abs(t[o4.id].lat - 24.4672) < 0.001; }, 12000));
  await dv.shot('7-sharing');
  await dv.page.fill(`[data-bind="dv.code.${o4.id}"]`, o4.code);
  await dv.click(`[data-a="drvDeliver"][data-id="${o4.id}"]`);
  check('driver: delivered, the customer map ends', await until(async () => (await mine(o4.id)).fin === true) && !(((await cust('/my/sync', { since: 0 })).track || {})[o4.id]));

  // admin switches the account off: the driver is out at the next change
  const st = await (async () => { const x = await fetch(BASE + '/api/admin/state?rev=-1', { headers: { Cookie: adm.cookie } }); return x.json(); })();
  const sal = st.drivers.find(d => d.name === 'سالم');
  await adm.call('/admin/driver', { op: 'off', id: sal.id });
  await place({ branch: 'b2' });
  check('driver: signed out the moment the admin switches him off', await until(() => dv.ev(() => UI.mode === 'login'), 8000) && await dv.has('انتهت الجلسة'), await dv.ev(() => ({ mode: UI.mode, err: UI.lg.err, off: UI.offline, rev: SRV.rev })));
  await dv.shot('5-signed-out');
  await adm.call('/admin/driver', { op: 'on', id: sal.id });

  // a gift brought to someone else: the desk sees who it is for and the message to write on the card
  const gO = await place({ mode: 'delivery', branch: 'b2', addr: { city: 'المدينة المنورة', street: 'حي العزيزية' }, gift: { name: 'سارة', phone: '551234567', msg: 'كل عام وأنتِ بخير' }, items: [{ pid: 'latte', sel: {}, qty: 1 }] });
  await rc.click('[data-a="rcTab"][data-id="new"]');
  check('reception: a gift order says who it is for, with the last digits and the message', await until(() => rc.ev(id => { const t = $(`.tk[data-id="${id}"] .tk-n.gift`); return !!t && t.innerText.includes('هدية إلى سارة') && t.innerText.includes('4567') && t.innerText.includes('كل عام وأنتِ بخير') && !t.innerHTML.includes('tel:'); }, gO.id)));
  await rc.shot('8-gift');

  // 0.7 on the ticket: a pickup later today, an order the customer cancelled, the customer's rating
  const oP = await place({ branch: 'b2', pick: Date.now() + 45 * 60000 });
  await rc.click('[data-a="rcTab"][data-id="new"]');
  check('reception: a pickup later today says when, and how long until then', await until(() => rc.ev(id => { const t = $(`.tk[data-id="${id}"] .tk-n.pk`); return !!t && t.innerText.includes('الاستلام الساعة') && /بعد (44|45) دقيقة/.test(t.innerText); }, oP.id)));
  const oC = await place({ branch: 'b2' });
  await until(() => rc.page.locator(`.tk[data-id="${oC.id}"]`).count().then(c => c === 1));
  check('the customer cancels before the desk accepts', (await cust('/my/cancel', { id: oC.id })).ok === true);
  await rc.click('[data-a="rcTab"][data-id="done"]');
  check('reception: the cancelled order says the customer cancelled it', await until(() => rc.ev(id => { const t = $(`.tk[data-id="${id}"]`); return !!t && t.innerText.includes('ألغاه العميل') && !t.querySelector('[data-a="rcAccept"]'); }, oC.id)));
  check('the customer rates the order he got', (await cust('/my/rate', { id: o1.id, stars: 5, note: 'القهوة ممتازة' })).ok === true);
  check('reception: the finished order shows the stars and the words', await until(() => rc.ev(id => { const t = $(`.tk[data-id="${id}"] .tk-n.rt`); return !!t && t.querySelectorAll('.rstars .on').length === 5 && t.innerText.includes('القهوة ممتازة'); }, o1.id)));
  await rc.shot('9-pick-cancel-rate');

  // 0.7: a ticket prints, with the tax invoice once there is a VAT number
  await adm.call('/admin/tax', { name: 'مؤسسة واي للتحميص', vat: '310122393500003' });
  const oT = await place({ branch: 'b2', pick: Date.now() + 30 * 60000 });
  await rc.click('[data-a="rcTab"][data-id="new"]');
  await until(() => rc.page.locator(`.tk[data-id="${oT.id}"]`).count().then(c => c === 1));
  await rc.ev(() => { window.__printed = 0; window.print = () => { window.__printed++; }; });
  await rc.click(`[data-a="rcPrint"][data-id="${oT.id}"]`); await wait(300);
  check('reception: the print button prints the ticket: number, time, items, and the invoice with its QR', await rc.ev(no => { const p = document.querySelector('#print'); return window.__printed === 1 && p.innerText.includes(no) && p.innerText.includes('الاستلام الساعة') && p.innerText.includes('لاتيه') && p.innerText.includes('310122393500003') && !!p.querySelector('svg.qr'); }, oT.no));
  await adm.call('/admin/tax', { vat: '' });

  // 0.7: the desk switches a product off at its branch
  await rc.click('[data-a="rcBr"][data-id="b2"]');
  await rc.click('[data-a="rcMenu"]');
  check('reception: the products of the branch, each with its switch', await rc.has('المنتجات في') && await rc.page.locator('.sheet [data-a="rcHere"]').count() > 10);
  await rc.page.fill('.sheet .srch input', 'لاتيه'); await wait(200);
  check('reception: the list searches while typing', await rc.ev(() => [...document.querySelectorAll('#rcml .srow b')].every(b => b.textContent.includes('لاتيه'))));
  await rc.click('.sheet [data-a="rcHere"][data-id="latte"]');
  check('reception: switched off at this branch', await until(async () => ((await raw('/catalog')).products.find(p => p.id === 'latte').off || []).includes('b2')) && await rc.has('غير متوفر في هذا الفرع'));
  const offTry = await cust('/orders', { cid: 'x' + crypto.randomBytes(8).toString('hex'), mode: 'pickup', branch: 'b2', cust: { name: 'خالد', phone: '566000111' }, items: [{ pid: 'latte', sel: {}, qty: 1 }] });
  check('a customer of that branch cannot order it', offTry._status === 409 && offTry.error === 'not_here', offTry);
  await rc.shot('10-branch-products');
  await rc.click('.sheet [data-a="rcHere"][data-id="latte"]');
  check('reception: and back on', await until(async () => !(await raw('/catalog')).products.find(p => p.id === 'latte').off));
  await rc.click('.sheet .xbtn');
  await rc.click('[data-a="rcBr"][data-id="all"]');

  // 0.7: the order desk of one branch, with its own code
  check('admin makes a desk for the second branch', (await adm.call('/admin/desk', { op: 'add', branch: 'b2', pin: '556677' })).ok === true);
  const oB1 = await place({ branch: 'b1' });
  const rc2 = await open('recv2', { width: 820, height: 1000 }, '/reception/');
  check('reception: the sign-in page offers all branches or the branch desk', await until(() => rc2.page.locator('[data-a="lgBr"]').count().then(c => c === 2)) && await rc2.has('كل الفروع'));
  await rc2.click('[data-a="lgBr"][data-id="b2"]');
  await rc2.page.fill('#pin', '654321'); await rc2.click('[data-a="login"]');
  check('reception: the code of every branch does not open a branch desk', await until(() => rc2.has('الاسم أو الرمز غير صحيح')));
  await rc2.page.fill('#pin', '556677'); await rc2.click('[data-a="login"]');
  check('reception: the branch desk opens with its own code, named after its branch, without the branch chips', await until(() => rc2.ev(() => UI.mode === 'main' && SRV.me.branch === 'b2')) && await until(() => rc2.has('شاشة الفرع')) && await rc2.page.locator('[data-a="rcBr"]').count() === 0);
  check('reception: it sees its own branch only', await until(() => rc2.ev(id => SRV.orders.length > 0 && SRV.orders.every(o => o.branch === 'b2') && !SRV.orders.some(o => o.id === id), oB1.id)));
  check('reception: its pause switch is its own branch', await until(() => rc2.page.locator('.pz [data-a="rcPause"]').count().then(c => c === 1)));
  await rc2.shot('11-branch-desk');
  check('reception: the sign-in remembers the desk', await rc2.ev(() => S.desk === 'b2'));
  await rc2.ctx.close();
  await adm.call('/admin/desk', { op: 'del', branch: 'b2' });

  // reception: sign out by the button, and the page stays signed out after a reload
  await rc.click('[data-a="signOut"]');
  check('reception: sign-out asks first', await rc.has('تسجيل الخروج') && await rc.page.locator('.dlg').count() === 1);
  await rc.click('[data-a="dlgYes"]');
  check('reception: back to sign-in', await until(() => rc.ev(() => UI.mode === 'login')) && await rc.has('الرمز السري'));
  await rc.page.reload({ waitUntil: 'domcontentloaded' });
  check('reception: still signed out after reload', await until(() => rc.has('الرمز السري')) && !(await rc.has('لا توجد طلبات')));

  check('no page errors in any page', errors.length === 0, errors);
  const failed = results.filter(r => !r.ok);
  console.log(`\n${results.length - failed.length}/${results.length} passed`);
  if (failed.length) console.log('FAILED:\n' + failed.map(f => ' - ' + f.name).join('\n'));
  await browser.close();
  process.exit(failed.length ? 1 : 0);
})().catch(e => { console.error('TEST CRASH', e); process.exit(2); });
