// End-to-end test of the customer page against the real server (headless Chrome).
// Start the server first:  test/serve.sh 8790     (fresh database every time)
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const path = require('path');
const fs = require('fs');

const URL = process.env.WHY_URL || 'http://127.0.0.1:8790/';
const BASE = URL.replace(/\/$/, '');
const OUT = path.join(__dirname, 'shots');
fs.rmSync(OUT, { recursive: true, force: true });
fs.mkdirSync(OUT, { recursive: true });

const results = [];
const check = (name, ok, extra) => { results.push({ name, ok: !!ok, extra }); console.log((ok ? 'PASS ' : 'FAIL ') + name + (extra !== undefined && !ok ? '  -> ' + JSON.stringify(extra) : '')); };
const wait = ms => new Promise(r => setTimeout(r, ms));

// what the reception, the admin and a driver do from their own pages, done straight against the API
async function staff(role, creds) {
  let cookie = '';
  const call = async (p, body) => {
    const r = await fetch(BASE + '/api' + p, { method: body === undefined ? 'GET' : 'POST', headers: { 'Content-Type': 'application/json', Cookie: cookie }, body: body === undefined ? undefined : JSON.stringify(body) });
    const sc = r.headers.get('set-cookie'); if (sc) cookie = sc.split(';')[0];
    const j = await r.json().catch(() => ({})); j._status = r.status; return j;
  };
  const me = await call(`/${role}/login`, creds);
  if (!me.ok) throw new Error('staff login failed: ' + role + ' ' + JSON.stringify(me));
  return { call, order: (id, op, x) => call(`/${role}/order`, Object.assign({ id, op }, x || {})), state: () => call(`/${role}/state?rev=-1`) };
}

// another customer on her own phone, straight against the API (0.7: gifts really go from one number to another)
async function person(name, phone) {
  const dev = require('crypto').randomBytes(16).toString('hex');
  const call = async (p, body) => {
    const r = await fetch(BASE + '/api' + p, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Dev': dev }, body: JSON.stringify(body || {}) });
    const j = await r.json().catch(() => ({})); j._status = r.status; return j;
  };
  const j = await call('/my/login', { phone, code: '12345', signup: true, name });
  if (!j.ok) throw new Error('customer sign-up failed: ' + JSON.stringify(j));
  return { call, dev };
}

(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 1.5 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errors.push('console: ' + m.text()); });
  const ORIGIN = (URL.match(/^https?:\/\/[^/]+/) || [''])[0];   // when WHY_URL is http(s), allow that one address only
  // the street pictures of the map cannot be fetched here: a clear square stands in for each, so the screenshots show no broken pictures
  const CLEAR = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGNgYGBgAAAABQABpfZFQAAAAABJRU5ErkJggg==', 'base64');
  await page.route('**/*', r => { const u = r.request().url(); if (u.startsWith('https://tile.openstreetmap.org/')) return r.fulfill({ status: 200, contentType: 'image/png', body: CLEAR }); return (u.startsWith('file://') || (ORIGIN && u.startsWith(ORIGIN + '/'))) ? r.continue() : r.abort(); });

  const shot = async n => { await wait(350); await page.screenshot({ path: path.join(OUT, n + '.png') }); };
  const ev = (f, a) => page.evaluate(f, a);
  const txt = async () => (await page.locator('#view').innerText());
  const has = async s => (await txt()).includes(s);
  const said = async s => (await page.locator('#toasts').innerText()).includes(s);
  const click = async sel => { await page.locator(sel).last().click({ timeout: 8000 }); await wait(250); };
  const tab = async id => click(`[data-a="tab"][data-id="${id}"]`);
  // the sign-up form: every field the Coffematics screen has (phone only when the form does not have it already)
  const fillSignup = async (o = {}) => {
    const d = Object.assign({ name: 'أحمد', email: 'ahmad@example.com', birth: '1994-03-09', gender: 'm', terms: true, mk: false, invite: '' }, o);
    if (d.phone) await page.fill('#ph', d.phone);
    await page.fill('#nm', d.name);
    await page.fill('#em', d.email);
    if (d.invite) await page.fill('#iv', d.invite);
    await page.fill('#bd', d.birth);
    await click(`[data-a="gender"][data-v="${d.gender}"]`);
    if (d.terms) await click('[data-a="tg"][data-k="terms"]');
    if (d.mk) await click('[data-a="tg"][data-k="mk"]');
  };
  const errCount = () => page.locator('.sheet .em').count();

  await page.goto(URL, { waitUntil: 'domcontentloaded' });
  await wait(400);
  await ev(() => { try { localStorage.clear(); } catch (e) {} });
  await page.reload({ waitUntil: 'domcontentloaded' });
  await wait(400);

  // ---------- onboarding
  check('document is RTL Arabic', await ev(() => document.documentElement.dir === 'rtl' && document.documentElement.lang === 'ar'));
  check('3 onboarding slides', await page.locator('.slide').count() === 3);
  check('slide 1 wording', await has('مرحبا بك في واي!') && await has('تجربة رقمية فريدة، مكافآت مميزة و مزايا حصرية'));
  check('counter 1/3', await page.locator('#cnt').innerText() === '1/3');
  check('three buttons', await has('تسجيل الدخول') && await has('إنشاء حساب') && await has('المتابعة كضيف'));
  await shot('01-intro1');
  await ev(() => { const s = $('#slides'); s.scrollTo({ left: -s.clientWidth, behavior: 'instant' }); });
  await wait(300);
  check('counter 2/3 after swipe', await page.locator('#cnt').innerText() === '2/3');
  check('slide 2 wording', await has('اجمع النقاط مع كل عملية شراء'));
  await shot('02-intro2');
  await ev(() => { const s = $('#slides'); s.scrollTo({ left: -2 * s.clientWidth, behavior: 'instant' }); });
  await wait(300);
  check('slide 3 wording', await has('اهدي من تحب وشاركهم اللحظات الجميلة') && await has('أرسل الهدايا لأحبائك بسهولة'));
  await shot('03-intro3');

  // ---------- login sheet
  await click('[data-a="openAuth"][data-m="login"]');
  check('login sheet open', await page.locator('.sheet .sttl').innerText() === 'تسجيل الدخول');
  check('send disabled with empty phone', await ev(() => $('[data-a="sendOtp"]').disabled));
  await page.fill('input[data-bind="f.phone"]', '54404');
  check('send still disabled for short phone', await ev(() => $('[data-a="sendOtp"]').disabled));
  await page.fill('input[data-bind="f.phone"]', '544044995');
  check('send enabled for valid phone', await ev(() => !$('[data-a="sendOtp"]').disabled));
  await shot('04-login-phone');
  await click('[data-a="sendOtp"]');
  check('otp step wording', await has('قم بإدخال رمز الامان') && await has('تأكيد رمز الأمان') && await has('إعادة الإرسال بعد'));
  check('five otp boxes', await page.locator('[data-otp]').count() === 5);
  await shot('05-otp');
  await page.click('[data-otp="0"]'); await page.keyboard.type('11111'); await wait(300);
  check('wrong code shows error', await has('رمز الأمان غير صحيح'));
  await page.click('[data-otp="0"]'); await page.keyboard.type('12345'); await wait(400);
  check('unknown phone opens the sign-up form with a note', await has('لا يوجد حساب بهذا الرقم') && await has('ادخل البيانات الخاصة بك لإنشاء حساب'));
  check('verified phone is kept in the form as 05x-xxx-xxxx', await page.inputValue('#ph') === '054-404-4995' && await ev(() => UI.f.phone === '544044995'));
  check('verified form button says create account (no second code)', (await page.locator('[data-a="sendOtp"]').last().innerText()).trim() === 'إنشاء حساب');
  await shot('06-name');
  await fillSignup({ name: 'أحمد', email: 'Ahmad@Example.com', birth: '1994-03-09', gender: 'm', mk: true });
  await click('[data-a="sendOtp"]');
  check('account saved with every sign-up field', await ev(() => S.user.name === 'أحمد' && S.user.phone === '544044995' && S.user.email === 'ahmad@example.com' && S.user.birth === '1994-03-09' && S.user.gender === 'm' && S.user.mk === true && S.user.invite === ''), await ev(() => S.user));
  check('home after sign-up', await ev(() => S.session === true && UI.tab === 'home' && !UI.sheet));
  check('welcome points 100, counted by the server', await ev(() => S.pts === 100 && S.ledger[0].label.ar === 'تم التسجيل للمرة الأولى' && S.arev != null));
  check('no made-up gifts: one welcome notification', await ev(() => S.gifts.length === 0 && S.notifs.length === 1));
  check('home wording', await has('مرحبا بك!') && await has('أحمد') && await has('رصيد النقاط') && await has('عضوية أساسية') && await has('استبدل نقاطك الآن!') && await has('اطلب الآن') && await has('أرسل هدية'));
  check('home points number 100', (await page.locator('.loyal .num').innerText()) === '100');
  check('tab labels', await has('طلباتي') && await has('الهدايا') && await has('الرئيسية') && await has('الفروع') && await has('الأخبار'));
  check('no menu tab', !(await page.locator('.tabs').innerText()).includes('القائمة'));
  await shot('07-home');
  check('brand logo image in the header', await page.locator('.htop .logo-i').count() === 1);
  check('brand mark on the centre tab', await page.locator('.tab.home .mark-i').count() === 1);
  check('first banner is the real image banner', await page.locator('#bn .bn.imb').count() === 1);
  check('home header shows the new why! wordmark, the w on the card and the home tab', await page.locator('.htop .im-logo').count() === 1 && await ev(() => Math.abs(IMG.logo.r - 2.995) < .02) && await page.locator('.loyal .logo-m').count() === 1 && await page.locator('.tab.home .mark-i').count() === 1);
  check('brand yellow is the primary colour', await ev(() => getComputedStyle(document.querySelector('.tabs')).backgroundColor === 'rgb(236, 180, 68)'));
  check('the home card is the card of the tier: basic is the black card, with the why! wordmark in gold', await ev(() => { const c = document.querySelector('.loyal'), w = c.querySelector('.logo-m'); return c.classList.contains('t-basic') && getComputedStyle(c).backgroundImage.includes('radial-gradient') && getComputedStyle(w).backgroundColor === getComputedStyle(document.documentElement).getPropertyValue('--gold').trim().replace(/^#(..)(..)(..)$/, (m, r, g, b) => `rgb(${parseInt(r, 16)}, ${parseInt(g, 16)}, ${parseInt(b, 16)})`) && getComputedStyle(w).webkitMaskImage.startsWith('url('); }));
  check('a silver or gold customer sees the silver or gold card', await ev(() => { const keep = S.tier, out = {}; for (const id of ['silver', 'gold']) { S.tier = {id, pts:0}; render(); const c = document.querySelector('.loyal'); out[id] = c.classList.contains('t-' + id) && getComputedStyle(c).backgroundImage.includes('linear-gradient') && c.innerText.includes(tierName()); } S.tier = keep; render(); return out.silver && out.gold && document.querySelector('.loyal').classList.contains('t-basic'); }));

  // ---------- profile sheet
  await click('[data-a="sheet"][data-k="profile"]');
  check('profile rows', await has('ادعُ أصدقائك') && await has('شارك التجربة مع أصدقائك') && await has('ملفي') && await has('اللغة') && await has('الشروط والأحكام') && await has('سياسة الإستخدام والشروط والأحكام') && await has('تواصل معنا') && await has('الأسئلة الشائعة وطرق التواصل معنا') && await has('تسجيل الخروج'));
  check('profile shows phone', await has('544044995'));
  await shot('08-profile');
  await click('[data-a="go"][data-p="myprofile"]');
  check('my profile page shows name, phone, email, birth date and gender', await has('الاسم') && await has('ahmad@example.com') && await has('1994-03-09') && await has('ذكر') && await has('البريد الإلكتروني') && await has('تاريخ الميلاد') && await has('الجنس'));
  await shot('09-myprofile');
  await click('[data-a="back"]');
  await click('[data-a="sheet"][data-k="profile"]');
  await click('[data-a="go"][data-p="contact"]');
  check('contact page has tel + faq', await has('+966 50 816 4307') && await has('الأسئلة الشائعة'));
  await shot('10-contact');
  await click('[data-a="back"]');
  await click('[data-a="sheet"][data-k="profile"]');
  await click('[data-a="go"][data-p="terms"]');
  check('terms page', await has('الشروط والأحكام'));
  await click('[data-a="back"]');
  check('go closes the sheet and back returns home', await ev(() => !UI.sheet && UI.stack.length === 0));

  // ---------- menu and product
  await click('[data-a="toMenu"]');
  check('menu page wording', await has('القائمة') && await has('المشروبات الساخنة') && await has('المشروبات الباردة') && await has('المشروبات المقطرة'));
  check('menu has no tab bar', await page.locator('.tabs').count() === 0 || await ev(() => !$('.screen.over .tabs')));
  await shot('11-menu');
  await page.fill('.srch input', 'لاتيه'); await wait(250);
  check('search filters', await page.locator('.prod').count() >= 2);
  await shot('12-menu-search');
  await click('#clr');
  check('search cleared', await ev(() => UI.f.q === ''));
  await click('[data-a="cat"][data-id="cold"]');
  check('cold category', await has('ايسد امريكانو'));
  await click('[data-a="cat"][data-id="hot"]');
  await click('[data-a="product"][data-id="latte"]');
  check('product sheet wording', await has('الخيارات') && await has('إضافة إلى السلة') && await has('سعرة حرارية'));
  check('option delta format', await has('(+5)') || await has('(5+)'));
  await shot('13-product');
  await click('[data-a="opt"][data-g="size"][data-id="l"]');
  check('size L price 22', await ev(() => unitPrice(PROD.latte, UI.sheet.sel) === 22));
  await click('[data-a="sq"][data-d="1"]');
  await click('[data-a="sadd"]');
  check('cart has 2 lattes', await ev(() => cartCount() === 2));
  check('fab badge 2', await page.locator('.fab .badge').last().innerText() === '2');
  await shot('14-menu-fab');

  // ---------- cart and checkout
  await click('.fab');
  check('cart page', await has('السلة') && await has('إستكمال الطلب'));
  await shot('15-cart');
  await click('[data-a="toCheckout"]');
  check('checkout wording', await has('طريقة إستلام الطلب') && await has('استلام من الفرع') && await has('خيارات التقديم') && await has('داخل الفرع') && await has('تيك أواي') && await has('توصيل إلى السيارة') && await has('لوحة + لون + نوع') && await has('غير متاح مؤقتاً') && await has('يصلك طلبك إلى عنوانك') && await has('ملخص الطلب') && await has('ضريبة القيمة المضافة (%15)') && await has('الإجمالي') && await has('بطاقة الدفع'));
  const sum = await ev(() => { const q = calc(); return { total: q.total, vat: q.bd.vat, ex: q.bd.lines.map(x => x.ex), disc: q.bd.discEx }; });
  check('summary: 2 x 22 = 44, ex VAT 38.26, VAT 5.74', sum.total === 44 && Math.abs(sum.vat - 5.74) < 0.011 && Math.abs(sum.ex[0] - 38.26) < 0.011, sum);
  check('summary adds up', await ev(() => { const q = calc(); const s = q.bd.lines.reduce((a, x) => a + x.ex, 0) + q.bd.shipEx - q.bd.discEx + q.bd.vat; return Math.abs(s - q.total) < 0.005; }));
  await shot('16-checkout');
  await click('[data-a="serve"][data-id="take"]');
  check('takeaway chip active', await ev(() => UI.co.serve === 'take'));
  await page.fill('input[data-bind="co.code"]', 'wrong'); await click('[data-a="applyCode"]');
  check('bad code error', await has('كود الخصم غير صحيح'));
  await page.fill('input[data-bind="co.code"]', 'why10'); await click('[data-a="applyCode"]');
  check('WHY10 applies 10%', await ev(() => Math.abs(calc().disc - 4.4) < 0.001 && calc().total === 39.6));
  check('summary adds up with discount', await ev(() => { const q = calc(); const s = q.bd.lines.reduce((a, x) => a + x.ex, 0) + q.bd.shipEx - q.bd.discEx + q.bd.vat; return Math.abs(s - q.total) < 0.005; }));
  await shot('17-checkout-code');
  // branch sheet: pick the 24h branch so the test does not depend on the clock
  await click('[data-a="sheet"][data-k="branch"]');
  check('branch sheet lists 3', await page.locator('.sheet .opt').count() === 3);
  await shot('18-branch-sheet');
  await click('[data-a="pickBranch"][data-id="b2"]');
  check('branch b2 chosen', await ev(() => S.branch === 'b2'));
  await click('[data-a="payM"][data-id="apple"]');
  check('apple pay black button', await page.locator('.foot .btn.apple').count() === 1);
  await shot('19-checkout-apple');
  await click('[data-a="payM"][data-id="card"]');
  check('pickup: as soon as possible unless the customer picks a time', await has('متى تستلم طلبك؟') && await has('في أقرب وقت') && await has('وقت لاحق اليوم') && await ev(() => UI.co.pick === 0) && await page.locator('#pkt').count() === 0);
  await click('[data-a="pickMode"][data-id="later"]');
  const slots = await ev(() => pickSlots(BR[S.branch]));
  check('later today: times every 15 minutes, the first one chosen', slots.length > 4 && slots[1] - slots[0] === 15 * 60000 && await ev(() => UI.co.pick === pickSlots(BR[S.branch])[0]) && await page.locator('#pkt option').count() === slots.length);
  await page.selectOption('#pkt', String(slots[2])); await wait(150);
  check('choosing a time keeps it', await ev(t => UI.co.pick === t, slots[2]));
  await shot('19b-checkout-pickup-time');
  await page.route('**/api/orders', async r => { await wait(900); r.continue(); });   // slow the call down so the overlay can be seen
  await click('[data-a="placeOrder"]');
  check('processing overlay', await page.locator('.proc').count() === 1);
  await wait(1700);
  await page.unroute('**/api/orders');
  check('success page', await has('تم إستلام طلبك بنجاح') && await has('تتبع الطلب'));
  check('order recorded with 39.6 paid, 31 pts earned (basic: 8 points for every 10 SAR)', await ev(() => S.orders.length === 1 && S.orders[0].total === 39.6 && S.orders[0].earn === 31 && S.orders[0].tier === 'basic' && S.orders[0].serve === 'take'));
  check('points now 131', await ev(() => S.pts === 131));
  check('cart emptied', await ev(() => S.cart.length === 0));
  check('the pickup time is on the order and on the success page', await ev(t => S.orders[0].pick === t, slots[2]) && await has('وقت الاستلام') && await has(await ev(t => clockAt(t), slots[2])));
  await shot('20-success');
  // ---------- 0.7: notifications on the phone. The worker is real; the push service is not reachable from here, so the
  // permission and the subscription are stood in for, and the server's side is read back through its inbox.
  check('the notifications worker is running for the whole site', await ev(() => navigator.serviceWorker.ready.then(r => !!r.active && r.scope === location.origin + '/')));
  check('the success page offers notifications', await has('إشعارات على جوالك') && await has('تفعيل الإشعارات'));
  await ev(() => {
    Object.defineProperty(Notification, 'permission', { get: () => window.__perm || 'default', configurable: true });
    Notification.requestPermission = async () => (window.__perm = 'granted');
    SWREG = { pushManager: { getSubscription: async () => window.__sub || null, subscribe: async o => (window.__sub = { endpoint: 'https://fcm.googleapis.com/fcm/send/test-' + Math.random().toString(36).slice(2), key: o.applicationServerKey, unsubscribe: async () => { window.__sub = null; return true; } }) } };
  });
  await click('[data-a="pushOn"]'); await wait(500);
  const ep = await ev(() => window.__sub && window.__sub.endpoint);
  check('turned on: subscribed with the server\'s key, and the card goes', !!ep && await ev(() => S.push === true && window.__sub.key.length === 65) && !(await has('تفعيل الإشعارات')) && await said('تم تفعيل الإشعارات'));
  await click('[data-a="trackOrder"]');
  check('order page + code', await has('رمز الإستلام') && await has('تيك أواي'));
  await shot('21-order');
  // the order is on the server; only the reception moves it forward
  const recv = await staff('recv', { pin: '654321' });
  const oid = await ev(() => S.orders[0].id), ocode = await ev(() => S.orders[0].code);
  const seen = (await recv.state()).orders.find(o => o.id === oid);
  check('reception sees the order, without its pickup code, with the time it is picked up', seen && seen.st === 0 && seen.code === undefined && seen.cust.name === 'أحمد' && seen.total === 39.6 && seen.pick === slots[2], seen);
  check('the order can be cancelled until the branch accepts it', await has('إلغاء الطلب') && await has('يمكنك إلغاء الطلب قبل أن يقبله الفرع'));
  await ev(() => custSync()); await wait(500);
  check('stays at stage 0 until staff act', await ev(() => S.orders[0].st === 0));
  await recv.order(oid, 'accept'); await ev(() => custSync()); await wait(600);
  check('stage 1 = being prepared', await ev(() => S.orders[0].st === 1) && await has('قيد التحضير'));
  const inbox = await (await fetch(BASE + '/api/push/inbox', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ endpoint: ep }) })).json();
  check('the push for this phone says the order is being prepared, and opens the app', inbox.items && inbox.items[0] && /قيد التحضير/.test(inbox.items[0].t) && inbox.items[0].url === '/', inbox);
  check('once accepted it can no longer be cancelled', !(await has('إلغاء الطلب')));
  await recv.order(oid, 'ready'); await ev(() => custSync()); await wait(600);
  check('stage 2 = ready, confirm button', await ev(() => S.orders[0].st === 2) && await has('تأكيد الإستلام'));
  check('the customer got the notifications', await ev(() => S.notifs.filter(n => /قيد التحضير|جاهز للإستلام/.test(n.t.ar)).length === 2));
  await shot('22-order-ready');
  await click('[data-a="confirmPickup"]');
  await wait(600);
  check('stage 3 collected', await ev(() => S.orders[0].st === 3 && S.orders[0].fin));
  check('the server agrees: order finished', (await recv.state()).orders.find(o => o.id === oid).fin === true);
  // the customer rates it
  check('a finished order asks for a rating', await has('كيف كانت تجربتك؟') && await page.locator('[data-a="rateStar"]').count() === 5 && await page.locator('[data-a="rateSend"]').count() === 0);
  await click('[data-a="rateStar"][data-s="4"]');
  check('four stars: the word, a note box and the send button', await has('جيد جدًا') && await page.locator('textarea[data-bind="rate.c"]').count() === 1 && await page.locator('.stars .on').count() === 4);
  await page.fill('textarea[data-bind="rate.c"]', 'القهوة ممتازة'); await wait(100);
  await shot('22b-rate');
  await click('[data-a="rateSend"]'); await wait(700);
  check('the rating is kept on the order, shown read-only', await ev(() => S.orders[0].rate && S.orders[0].rate.s === 4 && S.orders[0].rate.c === 'القهوة ممتازة') && await has('تقييمك') && await page.locator('[data-a="rateStar"]').count() === 0 && await said('شكرًا لتقييمك'));
  check('the management sees it', (await (await staff('admin', { pin: '123456' })).state()).orders.find(o => o.id === oid).rate.s === 4);
  await click('[data-a="back"]');
  check('orders tab list', await has('طلباتي') && await has('الطلبات') && await has('طلبات النقاط'));
  await shot('23-orders');
  await click('[data-a="seg"][data-id="points"]');
  check('points orders empty state', await has('لا يوجد طلبات مسجلة'));
  await shot('24-orders-points-empty');

  // ---------- gifts: sara, on her own phone, sends a latte and a 50 riyal card to this number
  const sara = await person('سارة', '551112222');
  const sent1 = await sara.call('/my/gift', { op: 'send', to: '544044995', kind: 'item', pid: 'latte', msg: 'هلا! هذي هدية بسيطة' });
  const sent2 = await sara.call('/my/gift', { op: 'send', to: '544044995', kind: 'card', amt: 50, msg: 'عساك دايم بخير' });
  check('sara sends two gifts from her phone', sent1.ok && sent2.ok, [sent1, sent2]);
  await ev(() => custSync()); await wait(700);
  check('they reach this phone with a notification and a toast', await ev(() => S.gifts.length === 2 && S.notifs[0].t.ar === 'وصلتك هديتان') && await said('وصلتك هديتان'));
  await tab('gifts');
  check('gifts wording', await has('المستقبلة') && await has('المرسلة') && await has('المنتجات') && await has('البطاقات') && await has('X1 لاتيه') && await has('من سارة') && await has('هلا! هذي هدية بسيطة'));
  await shot('25-gifts');
  await click('[data-a="gUse"]');
  check('gift item added to cart as gift', await ev(() => S.cart.length === 1 && S.cart[0].gift));
  await click('[data-a="gsub"][data-id="card"]');
  check('cards sub-tab shows 50 card + wallet', await has('بطاقة هدية') && await has('رصيد المحفظة'));
  await shot('26-gifts-cards');
  await click('[data-a="gUse"]'); await wait(500);
  check('card credited to wallet by the server', await ev(() => S.bal === 50 && S.wal[0].label.ar === 'بطاقة هدية من سارة' && S.gifts.find(g => g.kind === 'card').state === 'used'));
  check('sara sees her card was used', (await sara.call('/my/sync', { arev: null })).acct.sent.find(g => g.kind === 'card').state === 'used');
  await click('[data-a="gseg"][data-id="sent"]');
  check('sent empty state', await has('لا توجد حالياً أي هدية'));
  await shot('27-gifts-empty');

  // ---------- send a gift
  await tab('home');
  await click('[data-a="push"][data-p="giftsend"]');
  check('gift step 1', await has('أرسل هدية') && await has('المنتجات'));
  await shot('28-giftsend1');
  await click('[data-a="gType"][data-id="card"]');
  await page.fill('#gamtx', '35'); await wait(120);
  check('a gift card can be any amount the sender types (35)', await ev(() => UI.g.amt === 35 && !document.querySelector('.amts .chip.on') && !$('[data-a="gNext"]').disabled));
  await page.fill('#gamtx', '5'); await wait(120);
  check('under 10 riyals it cannot go on', await ev(() => $('[data-a="gNext"]').disabled));
  await page.fill('#gamtx', ''); await click('[data-a="gAmt"][data-id="50"]');
  check('a chip again: 50, the typed amount cleared', await ev(() => UI.g.amt === 50 && UI.g.amtx === '' && !$('[data-a="gNext"]').disabled));
  await click('[data-a="gType"][data-id="item"]');
  await click('[data-a="gItem"][data-id="spanish"]');
  await click('[data-a="gNext"]');
  check('gift step 2 next disabled', await ev(() => $('[data-a="gNext"]').disabled));
  await page.fill('input[data-bind="g.phone"]', '555123456');
  await page.fill('input[data-bind="g.name"]', 'سارة');
  await page.fill('textarea[data-bind="g.msg"]', 'هلا سارة!');
  check('the sender chooses: with delivery or not (not by default)', await has('مع التوصيل؟') && await ev(() => !UI.g.del && !$('[data-a="gNext"]').disabled));
  await click('[data-a="gDel"][data-id="1"]');
  check('with delivery: the recipient\'s address, the fee, a map to place it; next waits for the address', await has('مدينة المستلم') && await has('رسوم التوصيل 12') && await page.locator('.lmap.pick').count() === 1 && await ev(() => $('[data-a="gNext"]').disabled));
  await shot('29b-giftsend-delivery');
  await click('[data-a="gDel"][data-id="0"]');
  await shot('29-giftsend2');
  await click('[data-a="gNext"]');
  check('gift step 3 summary', await has('سارة') && await has('الإجمالي'));
  await shot('30-giftsend3');
  await click('[data-a="gPay"]'); await wait(1900);
  check('gift sent, it earns by the tier too (20 SAR -> 16)', await ev(() => S.sent.length === 1 && S.sent[0].price === 20 && S.sent[0].earn === 16 && S.pts === 131 + 16));
  check('gift done page', await has('تم إرسال الهدية بنجاح'));
  await shot('31-giftdone');
  await click('[data-a="giftsBack"]');
  check('sent list shows gift with X1 + price, waiting for the recipient', await has('X1 لاتيه إسباني') && await has('20.0') && await has('بانتظار المستلم'));
  await shot('32-gifts-sent');

  // ---------- points and rewards
  await tab('home');
  // the membership page (opened from the card on the home page): the three tiers like the reference cards
  await ev(() => custSync()); await wait(600);
  check('the server sends the tier: basic, with the welcome, order and gift points of the last 30 days (100 + 31 + 16)', await ev(() => S.tier && S.tier.id === 'basic' && S.tier.pts === 147 && myTier().per10 === 8), await ev(() => S.tier));
  await click('.loyal');
  check('home card opens the membership page with three cards: basic, silver, gold', await ev(() => UI.stack.length === 1 && UI.stack[0].p === 'member') && await has('العضوية')
    && await ev(() => [...document.querySelectorAll('.mpage .mcard')].map(c => c.className.match(/t-(\w+)/)[1]).join() === 'basic,silver,gold'));
  check('basic is open and marked as mine, with the progress to silver (147/500)', await ev(() => { const c = document.querySelector('.mcard.t-basic'); return !c.classList.contains('locked') && !!c.querySelector('.mcur') && c.querySelector('.mprog').textContent.includes('147/500') && c.querySelector('.mprog').textContent.includes('للعضوية الفضية') && !!c.querySelector('.mbar i') && !!c.querySelector('.mmk .logo-m'); }));
  check('silver and gold are locked, with the lock and the points that open them', await ev(() => ['silver', 'gold'].every(id => { const c = document.querySelector('.mcard.t-' + id); return c.classList.contains('locked') && !!c.querySelector('.mlock') && /تفتح عند (500|1,000) نقطة/.test(c.innerText); })));
  check('every card has its info link', await page.locator('.mpage .mcard [data-a="tierInfo"]').count() === 3);
  check('membership boxes: current balance, 30-day total from the server, my earning rate', await ev(() => { const t = document.querySelector('.mpage').innerText; return t.includes('رصيد النقاط الحالي') && t.includes(S.pts + ' نقطة') && t.includes('إجمالي النقاط خلال 30 يوم') && t.includes('147') && t.includes('8 نقاط لكل'); }));
  check('the tiers list: 8, 9 from 500, 10 from 1,000', await has('مستويات العضوية') && await ev(() => { const t = document.querySelector('.mpage').innerText; return t.includes('9 نقاط لكل') && t.includes('من 500 نقطة') && t.includes('10 نقاط لكل') && t.includes('من 1,000 نقطة'); }));
  check('membership sections: about, benefits, how to earn, how to redeem, rewards, terms', await has('عن العضوية') && await has('مجانية لكل عملاء واي! المسجلين') && await has('مميزات العضوية') && await has('طريقة جمع النقاط') && await has('طريقة استبدال النقاط') && await has('المكافآت المتاحة') && await has('شروط الاستفادة من المكافآت') && await has('النقاط غير قابلة للتحويل إلى نقد'));
  check('membership: the rewards are the live ones, with the same redeem button', await ev(() => document.querySelectorAll('.mpage .rw [data-a="redeem"]').length === liveRewards().length && liveRewards().length > 0));
  check('membership: nothing wider than the screen', await ev(() => { const s = document.querySelector('.mpage'); return s.scrollWidth <= s.clientWidth; }));
  await shot('33a-membership');
  await click('.mcard.t-silver [data-a="tierInfo"]');
  check('silver info sheet like the reference: the card, 30-day total, 9 points per 10 SAR, opens at 500', await page.locator('.sheet .mcard.t-silver').count() === 1 && await ev(() => { const t = document.querySelector('.sheet').innerText; return t.includes('إجمالي النقاط خلال 30 يوم') && t.includes('147') && t.includes('9 نقاط لكل') && t.includes('500 نقطة خلال 30 يوم'); }));
  await shot('33b-membership-info');
  await click('.sheet .xbtn');
  check('info sheet closes and the page stays', await ev(() => !UI.sheet && UI.stack.length === 1 && UI.stack[0].p === 'member'));
  check('the home card names the tier', await ev(() => tierName() === 'عضوية أساسية'));
  await click('.mpage [data-a="push"][data-p="points"]');
  check('points page wording', await has('نقاطي') && await has('إجمالي النقاط') && await has('إستبدل') && await has('العمليات السابقة') && await has('تم التسجيل للمرة الأولى') && await has('+100') && !(await has('+100.0')));
  await shot('33-points');
  await click('[data-a="push"][data-p="hist"]');
  check('previous transactions open their own page, every movement in it', await ev(() => UI.stack[UI.stack.length - 1].p === 'hist') && await ev(() => document.querySelectorAll('.screen.over:last-of-type .lg-row').length === S.ledger.length));
  await click('[data-a="histF"][data-id="spend"]');
  check('spent ones only', await ev(() => [...document.querySelectorAll('.screen.over:last-of-type .lg-row .pv')].every(e => e.classList.contains('minusv'))));
  await click('[data-a="histF"][data-id="earn"]');
  check('earned ones only', await ev(() => document.querySelectorAll('.screen.over:last-of-type .lg-row').length === S.ledger.filter(e => e.pts > 0).length));
  await shot('33c-history');
  await click('[data-a="back"]');
  await click('[data-a="push"][data-p="rewards"]');
  check('rewards page', await has('إستبدل نقاطك'));
  await shot('34-rewards');
  await click('[data-a="redeem"][data-id="r1"]');
  check('reward coffee in cart, points reserved not deducted yet', await ev(() => S.cart.some(c => c.rw === 'r1') && S.pts === 147));
  await click('[data-a="back"]'); await click('[data-a="back"]');
  check('back from the points page returns to the membership page', await ev(() => UI.stack.length === 1 && UI.stack[0].p === 'member'));
  await click('[data-a="back"]');
  check('back from the membership page returns home', await ev(() => UI.stack.length === 0 && UI.tab === 'home'));
  // checkout with reward + gift line + wallet balance
  await click('.fab');
  check('cart shows reward + gift flags', await has('مكافأة') && await has('هدية'));
  await shot('35-cart-free');
  await click('[data-a="toCheckout"]');
  check('wallet row shown and fully covers', await has('إستخدام رصيد المحفظة') && await ev(() => calc().pay === 0));
  await shot('36-checkout-free');
  await click('[data-a="placeOrder"]'); await wait(1900);
  check('free order: points deducted 120, gift used, nothing paid so no points earned', await ev(() => S.pts === 27 && S.gifts.find(g => g.kind === 'item').state === 'used' && S.orders[0].spent === 120 && S.orders[0].earn === 0));
  await click('[data-a="home"]');
  await tab('orders'); await click('[data-a="seg"][data-id="points"]');
  check('points orders tab lists the redeemed order', await page.locator('.ord').count() === 1);
  await shot('37-orders-points');

  // ---------- shipping
  await click('[data-a="toMenu"]').catch(() => {});
  await tab('home');
  await click('[data-a="toMenu"]');
  await click('[data-a="cat"][data-id="prem"]');
  check('roastery hint + items', await has('منتجات المحمصة') && await has('يرقاتشيف شلشلي') && await has('كولومبي عنب واي'));
  await shot('38-beans');
  await click('[data-a="cat"][data-id="goods"]');
  check('real product photos in the list (matcha, cups)', await page.locator('.prod .pt .im').count() === 2);
  await click('[data-a="product"][data-id="matchapowder"]');
  check('photo hero in the product sheet', await page.locator('.phero.ph .im.fe').count() === 1);
  await ev(() => { A.close(); });
  await click('[data-a="cat"][data-id="prem"]');
  await click('[data-a="product"][data-id="pineapple"]');
  check('sold out toast', await ev(() => !!document.querySelector('.toast')));
  await click('[data-a="product"][data-id="yirg"]');
  check('product details shown (altitude, flavours)', await has('الارتفاع') && await has('النكهات') && await has('250 جرام'));
  await shot('38b-product-details');
  await click('[data-a="sadd"]');
  await click('.fab');
  await click('[data-a="toCheckout"]');
  check('retail-only defaults to shipping with carriers', await ev(() => calc().mode === 'ship') && await has('Redbox'));
  await shot('39-checkout-ship');
  await click('[data-a="placeOrder"]');
  check('address required toast', await ev(() => !!document.querySelector('.toast')) && await ev(() => S.orders.length === 2));
  await page.fill('input[data-bind="co.addr.city"]', 'المدينة المنورة');
  await page.fill('input[data-bind="co.addr.street"]', 'حي الخزامى');
  check('shipping fee 25 added', await ev(() => calc().ship === 25 && calc().total === 84));
  await ev(() => { UI.co.useBal = false; });
  await click('[data-a="placeOrder"]'); await wait(1900);
  check('shipping order placed', await ev(() => S.orders.length === 3 && S.orders[0].mode === 'ship' && /^WH/.test(S.orders[0].code)));
  await shot('40-ship-success');
  await click('[data-a="home"]');
  // mixed cart forces pickup
  await click('[data-a="toMenu"]');
  await click('[data-a="product"][data-id="espresso"]'); await click('[data-a="sadd"]');
  await click('[data-a="cat"][data-id="esp"]');
  await click('[data-a="product"][data-id="arsi"]'); await click('[data-a="sadd"]');
  await click('.fab'); await click('[data-a="toCheckout"]');
  check('mixed cart forces pickup and disables shipping', await ev(() => calc().mode === 'pickup') && await has('متاح لحبوب المحمصة والمنتجات فقط'));
  await shot('41-checkout-mixed');

  // ---------- delivery: the café's own driver brings anything, to the door
  await click('[data-a="mode"][data-id="delivery"]');
  check('delivery row selected, fee 12 added', await ev(() => calc().mode === 'delivery' && calc().ship === 12 && calc().total === calc().sub + 12) && await has('رسوم التوصيل'));
  check('delivery asks for the address, with a map to place it and "my location"', await page.locator('input[data-bind="co.addr.city"]').count() === 1 && await page.locator('.lmap.pick').count() === 1 && await has('موقعي الحالي') && await has('حرّك الخريطة'));
  {
    await ev(() => document.querySelector('.lmap.pick').scrollIntoView({ block: 'center' })); await wait(150);
    const mb = await page.locator('.lmap.pick').boundingBox(), lat0 = await ev(() => MAPS.co.lat);
    await page.mouse.move(mb.x + 160, mb.y + 120); await page.mouse.down(); await page.mouse.move(mb.x + 100, mb.y + 170, { steps: 6 }); await page.mouse.up(); await wait(200);
    check('moving the map sets the delivery spot under the pin', await ev(l => UI.co.addr.lat != null && MAPS.co.lat !== l && Math.abs(UI.co.addr.lat - MAPS.co.lat) < 1e-4, lat0) && await has('تم تحديد الموقع'));
    await ev(() => { UI.co.addr.lat = null; UI.co.addr.lng = null; });
  }
  await shot('41b-checkout-delivery');
  check('the address of the last order is prefilled', await page.inputValue('input[data-bind="co.addr.city"]') === 'المدينة المنورة');
  await page.fill('input[data-bind="co.addr.city"]', ''); await page.fill('input[data-bind="co.addr.street"]', '');
  const ordersBefore = await ev(() => S.orders.length);
  await click('[data-a="placeOrder"]');
  check('delivery needs an address first', await ev(n => !!document.querySelector('.toast') && S.orders.length === n, ordersBefore));
  await page.fill('input[data-bind="co.addr.city"]', 'المدينة المنورة');
  await page.fill('input[data-bind="co.addr.street"]', 'حي الخزامى، شارع الأمير نايف');
  await page.fill('input[data-bind="co.addr.note"]', 'البوابة الزرقاء');
  await ev(() => { UI.co.useBal = false; UI.co.addr.lat = 24.49; UI.co.addr.lng = 39.62; });   /* the door on the map */
  const dTotal = await ev(() => calc().total);
  await click('[data-a="placeOrder"]'); await wait(1200);
  check('delivery order placed with the right total', await ev(t => S.orders.length === 4 && S.orders[0].mode === 'delivery' && S.orders[0].total === t && S.orders[0].ship === 12 && S.orders[0].addr.city === 'المدينة المنورة', dTotal));
  check('delivery success wording + code for the driver', await has('سيوصله لك مندوبنا') && await has('أظهر هذا الرمز للمندوب'));
  await shot('41c-delivery-success');
  const did = await ev(() => S.orders[0].id), dcode = await ev(() => S.orders[0].code);
  check('delivery address saved for next time', await ev(() => S.addr && S.addr.street.includes('الخزامى')));
  const adm = await staff('admin', { pin: '123456' });
  check('admin adds a driver', (await adm.call('/admin/driver', { op: 'add', name: 'سالم', pin: '111222' })).ok === true);
  const drv = await staff('driver', { name: 'سالم', pin: '111222' });
  const dseen = (await recv.state()).orders.find(o => o.id === did);
  check('reception sees the delivery with the full address, no code', dseen && dseen.mode === 'delivery' && dseen.addr.street.includes('الخزامى') && dseen.code === undefined, dseen);
  await recv.order(did, 'accept');
  await recv.order(did, 'ready');
  const avail = (await drv.state()).avail.find(o => o.id === did);
  check('driver sees it only when ready, with city and street but no phone or note', avail && avail.addr.city === 'المدينة المنورة' && avail.addr.note === undefined && avail.cust.phone === undefined && avail.driver === null, avail);
  await ev(() => custSync()); await wait(600);
  await click('[data-a="trackOrder"]');
  check('customer sees "ready for delivery" while no driver took it', await has('جاهز للتوصيل') && !(await has('في الطريق إليك')));
  await shot('41d-delivery-waiting');
  const took = await drv.order(did, 'take');
  check('the driver takes it and now sees phone and note', took.ok && took.order.driver.name === 'سالم' && /^5\d{8}$/.test(took.order.cust.phone) && took.order.addr.note === 'البوابة الزرقاء', took);
  const race = await (await staff('driver', { name: 'سالم', pin: '111222' })).order(did, 'take');
  check('a second take is refused', race._status === 409);
  await ev(() => custSync()); await wait(600);
  check('customer sees the driver and "on its way"', await has('في الطريق إليك') && await has('سالم') && await ev(() => S.notifs.some(n => /في الطريق/.test(n.t.ar))));
  await shot('41e-delivery-on-the-way');
  // 0.7.1: once the driver's phone shares where he is, the map shows the way and how long (an estimate until the road key is set)
  await drv.call('/driver/loc', { lat: 24.4672, lng: 39.6024, acc: 10 });
  await ev(() => custSync()); await wait(700);
  check('the delivery map: the driver, and how long until he arrives', await ev(() => !!document.querySelector('.trk .mp.drv')) && await has('يصلك خلال') && await has('تقريبًا'));
  await shot('41e2-delivery-eta');
  // with the road key set, the server sends the road itself (the server side is tested in test_server.py): the map draws it, and the time is no longer "about"
  const ROAD = [[24.4672, 39.6024], [24.4701, 39.6031], [24.4708, 39.6079], [24.4766, 39.6083], [24.4791, 39.6131], [24.4853, 39.6139], [24.4862, 39.6188], [24.49, 39.62]];
  await page.route('**/api/my/sync', async r => { const res = await r.fetch(); const j = await res.json(); Object.values(j.track || {}).forEach(v => { v.way = { pts: ROAD, km: 3.2, min: 9 }; }); await r.fulfill({ response: res, json: j }); });
  await ev(() => custSync()); await wait(700);
  check('with the road: the map draws it and says 9 minutes, 3.2 km', await ev(() => document.querySelectorAll('.trk .road polyline').length === 2 && document.querySelector('.trk .road polyline').getAttribute('points').split(' ').length === 8) && await has('يصلك خلال 9 دقائق') && await has('3.2 كم') && !(await has('تقريبًا')));
  await shot('41e3-delivery-road');
  await page.unroute('**/api/my/sync');
  const bad =await drv.order(did, 'deliver', { code: dcode === '0000' ? '1111' : '0000' });
  check('wrong code refused', bad._status === 403 && bad.error === 'wrong_code', bad);
  const good = await drv.order(did, 'deliver', { code: dcode });
  check('right code delivers', good.ok === true && good.order.fin === true, good);
  await ev(() => custSync()); await wait(600);
  check('customer sees "delivered"', await ev(() => S.orders[0].fin && S.orders[0].st === 3) && await has('تم التوصيل'));
  await shot('41f-delivery-done');
  // the admin switches delivery off: the customer's checkout follows without a reload
  await adm.call('/admin/fees', { delivery_on: false });
  // the iPhone app's swipe from the left edge goes back like the page's back button
  check('the swipe back leaves the order page', await ev(() => { const n = UI.stack.length; return n > 0 && whyBack() === true && UI.stack.length === n - 1; }));
  await wait(250); await tab('home');
  await click('[data-a="toMenu"]'); await click('[data-a="product"][data-id="latte"]'); await click('[data-a="sadd"]');
  await ev(() => custSync()); await wait(600);
  await click('.fab'); await click('[data-a="toCheckout"]');
  check('delivery paused: row disabled, falls back to pickup', await ev(() => !deliveryOn() && calc().mode === 'pickup') && await has('التوصيل متوقف مؤقتًا'));
  await adm.call('/admin/fees', { delivery_on: true });
  await ev(() => custSync()); await wait(600);
  check('delivery back on', await ev(() => deliveryOn()));
  // 0.7: the smallest delivery order, the delivery area
  await adm.call('/admin/fees', { delivery_min: 500 });
  await ev(() => custSync()); await wait(600);
  await click('[data-a="mode"][data-id="delivery"]');
  check('the delivery row names the smallest order, and the checkout says how much is missing', await has('الحد الأدنى 500 ر.س') && await has('الحد الأدنى لطلب التوصيل 500 ر.س، أضف أصنافًا بقيمة'));
  await shot('41h-delivery-minimum');
  await click('[data-a="placeOrder"]');
  check('below it the order does not go', await said('الحد الأدنى لطلب التوصيل') && await ev(n => S.orders.length === n, await ev(() => S.orders.length)));
  await adm.call('/admin/fees', { delivery_min: 0, delivery_km: 3 });
  await adm.call('/admin/branches', { op: 'save', id: 'b2', b: { ar: 'فرع النخيل (مثال)', en: 'Al Nakheel branch (sample)', addr: { ar: 'حي النخيل، طريق الخدمة، المدينة المنورة، السعودية (عنوان تجريبي)', en: 'Al Nakheel, service road, Madinah, Saudi Arabia (sample address)' }, all_day: true, lat: 24.4672, lng: 39.6024 } });
  await ev(() => custSync()); await wait(800);
  await ev(() => { UI.co.addr.lat = 24.55; UI.co.addr.lng = 39.70; render(); });
  check('a spot farther than the delivery area says so', await has('كم عن الفرع، والتوصيل حتى 3 كم'));
  await ev(() => { UI.co.addr.lat = 24.47; UI.co.addr.lng = 39.605; render(); });
  check('a spot inside it is fine', !(await has('والتوصيل حتى 3 كم')) && await has('حتى 3 كم من الفرع'));
  await adm.call('/admin/fees', { delivery_km: 0 });
  await adm.call('/admin/branches', { op: 'save', id: 'b2', b: { ar: 'فرع النخيل (مثال)', en: 'Al Nakheel branch (sample)', addr: { ar: 'حي النخيل، طريق الخدمة، المدينة المنورة، السعودية (عنوان تجريبي)', en: 'Al Nakheel, service road, Madinah, Saudi Arabia (sample address)' }, all_day: true } });
  // 0.7: a product the branch does not make
  await adm.call('/admin/product', { op: 'here', id: 'latte', branch: await ev(() => S.branch), on: false });
  await ev(() => custSync()); await wait(800);
  check('the cart line says this branch does not make it, and the checkout too', await has('غير متوفر في') && await page.locator('.hint.warn').count() === 1);
  await click('[data-a="mode"][data-id="pickup"]');
  await click('[data-a="placeOrder"]');
  check('so the order does not go', await said('غير متوفرة في هذا الفرع'));
  await ev(() => { S.cart = []; save(); UI.stack = []; render(); });
  await click('[data-a="toMenu"]');
  check('the menu marks it "not available"', await ev(() => { const b = document.querySelector('[data-a="product"][data-id="latte"]'); return !!b && b.classList.contains('out') && b.innerText.includes('غير متوفر'); }));
  await click('[data-a="product"][data-id="latte"]');
  check('and it cannot be opened to add', await ev(() => !UI.sheet) && await said('اختر فرعًا آخر'));
  await shot('41i-not-at-this-branch');
  await adm.call('/admin/product', { op: 'here', id: 'latte', branch: await ev(() => S.branch), on: true });
  await ev(() => custSync()); await wait(800);
  await ev(() => { S.cart = []; save(); UI.stack = []; render(); });

  // ---------- the customer cancels an order the branch has not accepted yet
  {
    const p0 = await ev(() => S.pts);
    await click('[data-a="toMenu"]'); await click('[data-a="cat"][data-id="sweet"]'); await click('[data-a="product"][data-id="cookie"]'); await click('[data-a="sadd"]');
    await click('.fab'); await click('[data-a="toCheckout"]');
    await ev(() => { UI.co.useBal = false; render(); });
    await click('[data-a="placeOrder"]'); await wait(1200);
    const cid = await ev(() => S.orders[0].id);
    check('a new order earns points', await ev(p => S.pts === p + S.orders[0].earn && S.orders[0].earn > 0, p0));
    await click('[data-a="trackOrder"]');
    await click('[data-a="cancelOrder"]');
    check('cancelling asks first', await has('هل تريد إلغاء الطلب'));
    await click('[data-a="dlgYes"]'); await wait(700);
    check('cancelled: the page says so, the points it gave are gone', await has('ألغيت هذا الطلب') && await ev(p => S.orders[0].rej && S.orders[0].rej.by === 'cust' && S.pts === p, p0) && await said('تم إلغاء طلبك'));
    const cseen = (await recv.state()).orders.find(o => o.id === cid);
    check('the desk sees it cancelled by the customer', cseen.rej && cseen.rej.why.ar === 'ألغاه العميل', cseen);
    await shot('41g-cancelled');
    await click('[data-a="back"]');
    check('the order list marks it cancelled', await has('ملغي'));
    await tab('home');
  }

  // ---------- 0.7: the simplified tax invoice, once the admin entered the VAT number
  {
    await adm.call('/admin/tax', { name: 'مؤسسة واي للتحميص', vat: '310122393500003', cr: '4650012345', addr: 'المدينة المنورة' });
    await click('[data-a="toMenu"]'); await click('[data-a="cat"][data-id="sweet"]'); await click('[data-a="product"][data-id="cookie"]'); await click('[data-a="sadd"]');
    await click('.fab'); await click('[data-a="toCheckout"]');
    await ev(() => { UI.co.useBal = false; render(); });
    await click('[data-a="placeOrder"]'); await wait(1200);
    check('a new order carries its invoice', await ev(() => !!S.orders[0].inv && S.orders[0].inv.vat === '310122393500003'));
    await click('[data-a="trackOrder"]');
    check('the order page offers the tax invoice', await has('الفاتورة الضريبية'));
    await click('[data-a="push"][data-p="invoice"]');
    check('the invoice: its title, the seller, the VAT number, the number, the VAT and the QR code', await has('فاتورة ضريبية مبسطة') && await has('مؤسسة واي للتحميص') && await has('310122393500003') && await has('ضريبة القيمة المضافة (15%)') && await has('الإجمالي شامل الضريبة') && await page.locator('.paper svg.qr').count() === 1);
    check('the total on it is the order\'s', await ev(() => document.querySelector('.inv .iv-r.tot b').textContent === fmt2(S.orders[0].total)));
    await shot('41j-tax-invoice');
    await ev(() => { window.__printed = 0; window.print = () => { window.__printed++; }; });
    await click('[data-a="printInv"]'); await wait(300);
    check('print: the invoice alone goes to the printer', await ev(() => window.__printed === 1 && !!document.querySelector('#print .inv svg.qr') && getComputedStyle(document.querySelector('#print')).display === 'none'));
    await click('[data-a="back"]'); await click('[data-a="back"]');
    await adm.call('/admin/tax', { vat: '' });
    await ev(() => acctCall('/my/cancel', { id: S.orders[0].id })); await wait(400);   /* nothing left open: the page goes back to its slow sync */
    await tab('home');
  }

  // ---------- branches and news
  await tab('branches'); await wait(300);
  check('branches list with the working hours, in the admin\'s order', await has('أوقات العمل') && await has('24 ساعة') && await has('من 06:00 إلى 02:00') && await has('من 16:00 إلى 23:00'));
  const order = await ev(() => Array.from(document.querySelectorAll('.br b')).map(e => e.textContent));
  check('3 branch cards, first branch first', order.length === 3 && order[0].includes('الخزامى'));
  check('no made-up distance or directions while the sample branches have no place on the map', !(await has('يبعد عنك')) && await page.locator('.br .dir').count() === 0 && await page.locator('[data-a="nearMe"]').count() === 0);
  check('a real map (OpenStreetMap tiles), and no made-up pins while no branch has a place', await page.locator('.mapfull .lmap .mt').count() > 0 && await page.locator('.mapfull .pin').count() === 0 && await ev(() => document.querySelector('.mapfull .mt').src.startsWith('https://tile.openstreetmap.org/')));
  await ev(() => { BRANCHES.forEach((b, i) => { b.lat = 24.46 + i * .01; b.lng = 39.6 + i * .012; }); delete MAPS.br; render(); });
  check('a branch placed on the map by the admin shows where it is, all in view', await page.locator('.mapfull .pin').count() === 3 && await ev(() => [...document.querySelectorAll('.mapfull .pin')].every(p => { const r = p.getBoundingClientRect(); return r.top > 0 && r.bottom < $('#bsheet').getBoundingClientRect().top + 30; })));
  {
    const mb = await page.locator('.mapfull .lmap').boundingBox(), c0 = await ev(() => MAPS.br.lng);
    await page.mouse.move(mb.x + 200, mb.y + 150); await page.mouse.down(); await page.mouse.move(mb.x + 120, mb.y + 180, { steps: 6 }); await page.mouse.up(); await wait(200);
    check('the map moves with a finger, and + zooms in', await ev(c => MAPS.br.lng !== c, c0) && await ev(() => { const z = MAPS.br.z; document.querySelector('.mapfull [data-zm="1"]').click(); return MAPS.br.z === z + 1; }));
  }
  await shot('42b-branches-map');
  await ev(() => { BRANCHES.forEach(b => { b.lat = null; b.lng = null; }); delete MAPS.br; render(); });
  await shot('42-branches');
  const before = await ev(() => $('#bsheet').offsetHeight);
  const box = await page.locator('#bsgrab').boundingBox();
  await page.mouse.move(box.x + box.width / 2, box.y + 10); await page.mouse.down(); await page.mouse.move(box.x + box.width / 2, box.y - 150, { steps: 6 }); await page.mouse.up(); await wait(200);
  const after = await ev(() => $('#bsheet').offsetHeight);
  check('bottom sheet drags taller', after > before + 80, { before, after });
  await shot('43-branches-expanded');
  await tab('news');
  check('news wording and date format', await has('الأخبار') && /\d\d:\d\d - 20\d\d-\d\d-\d\d/.test(await txt()));
  await shot('44-news');
  await click('[data-a="news"]');
  check('article page', await ev(() => UI.stack[0].p === 'article'));
  await shot('45-article');
  await click('[data-a="back"]');

  // ---------- notifications
  await tab('home');
  await click('[data-a="push"][data-p="notifs"]');
  check('notifications list', await page.locator('.notif').count() >= 3);
  await shot('46-notifs');
  await click('[data-a="back"]');
  check('notifications marked read', await ev(() => unread() === 0));

  // ---------- the wallet: top up with a chip or a typed amount
  {
    const bal0 = await ev(() => S.bal);
    await click('[data-a="sheet"][data-k="profile"]');
    await click('.sheet [data-a="go"][data-p="topup"]');
    check('wallet top-up page from the account sheet, with the wallet movements', await has('شحن المحفظة') && await has('أو اكتب المبلغ') && await has('حركات المحفظة') && await has('بطاقة هدية من سارة'));
    await page.fill('#tpamtx', '1500'); await wait(120);
    check('more than 1,000 cannot be paid', await ev(() => $('[data-a="tpPay"]').disabled));
    await page.fill('#tpamtx', '75'); await wait(120);
    check('a typed 75 can, and the button shows it', await ev(() => !$('[data-a="tpPay"]').disabled && $('#tpsum').innerText.includes('75')));
    await shot('47b-topup');
    await click('[data-a="tpPay"]'); await wait(1900);
    check('75 riyals added to the wallet', await ev(b => Math.abs(S.bal - b - 75) < 1e-9 && UI.stack.length === 0, bal0) && await said('تمت إضافة 75'));
  }

  // ---------- language
  await click('[data-a="sheet"][data-k="profile"]');
  await click('[data-a="sheet"][data-k="lang"]');
  check('language sheet', await has('العربية') && await has('English'));
  await shot('47-language');
  await click('[data-a="setLang"][data-id="en"]');
  check('LTR English', await ev(() => document.documentElement.dir === 'ltr' && S.lang === 'en'));
  check('English home', await has('Welcome!') && await has('Points balance') && await has('Redeem your points now!'));
  await shot('48-home-en');
  await tab('orders');
  await shot('49-orders-en');
  await tab('home');
  await click('[data-a="toMenu"]'); await click('[data-a="product"][data-id="latte"]');
  await shot('50-product-en');
  await click('.xbtn'); await click('[data-a="back"]');
  await click('[data-a="sheet"][data-k="profile"]'); await click('[data-a="sheet"][data-k="lang"]'); await click('[data-a="setLang"][data-id="ar"]');
  check('back to Arabic RTL', await ev(() => document.documentElement.dir === 'rtl'));

  // ---------- persistence, logout, login again
  await page.reload({ waitUntil: 'domcontentloaded' }); await wait(400);
  check('session survives reload', await ev(() => S.session === true && S.pts >= 0) && await has('أحمد'));
  check('notifications stay on after a reload', await ev(() => S.push === true));
  await ev(e => {   /* the stand-ins again (a reload put the real, empty push manager back) */
    Object.defineProperty(Notification, 'permission', { get: () => 'granted', configurable: true });
    window.__sub = { endpoint: e, unsubscribe: async () => { window.__sub = null; return true; } };
    SWREG = { pushManager: { getSubscription: async () => window.__sub } };
  }, ep);
  const ptsBefore = await ev(() => S.pts);
  await click('[data-a="sheet"][data-k="profile"]');
  await click('[data-a="logout"]');
  check('logout confirm dialog', await has('هل أنت متأكد من تسجيل الخروج'));
  await click('[data-a="dlgYes"]');
  await wait(400);
  const offNow = await ev(() => ({ push: S.push, sub: !!window.__sub }));
  const leftInbox = (await (await fetch(BASE + '/api/push/inbox', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ endpoint: ep }) })).json()).items;
  check('signing out switches this phone\'s notifications off', !offNow.push && !offNow.sub && leftInbox.length === 0, [offNow, leftInbox]);
  check('back to onboarding after logout, nothing of the account left on the phone', await page.locator('.slide').count() === 3 && await ev(() => !S.session && !S.user && S.pts === 0 && !S.orders.length && !S.gifts.length && !S.ledger.length));
  await click('[data-a="openAuth"][data-m="login"]');
  await page.fill('input[data-bind="f.phone"]', '544044995'); await click('[data-a="sendOtp"]');
  await page.click('[data-otp="0"]'); await page.keyboard.type('12345'); await wait(700);
  check('the same number brings the account back from the server', await ev(p => S.session === true && S.user.name === 'أحمد' && S.pts === p && S.orders.length === 6 && S.gifts.length === 2 && S.sent.length === 1, ptsBefore), await ev(() => [S.pts, S.orders.length, S.gifts.length]));
  check('and its orders, with their pickup codes', await ev(() => S.orders.every(o => o.code)));

  // ---------- sign-up on a new phone resets data
  await click('[data-a="sheet"][data-k="profile"]'); await click('[data-a="logout"]'); await click('[data-a="dlgYes"]');
  await click('[data-a="openAuth"][data-m="signup"]');
  check('sign-up sheet is the Coffematics form (wording)', await has('إنشاء حساب') && await has('ادخل البيانات الخاصة بك لإنشاء حساب') && await has('الإسم') && await has('البريد الإلكتروني') && await has('رمز الدعوة (اختياري)') && await has('تاريخ الميلاد') && await has('الجنس') && await has('ذكر') && await has('أنثى') && await has('من خلال الإستمرار فأنت موافق على') && await has('الخاصة بالتطبيق') && await has('أوافق على تلقي إشعارات التسويق والعروض') && await has('إرسل رمز الأمان'));
  check('phone field has the Saudi flag and the 05x-xxx-xxxx hint', await page.getAttribute('#ph', 'placeholder') === '05x-xxx-xxxx' && await page.locator('.sheet .fl.ph .flag svg').count() === 1);
  check('sign-up is a tall bottom sheet', await ev(() => { const s = $('.sheet'); return s.classList.contains('tall') && s.getBoundingClientRect().height > innerHeight * 0.8; }));
  check('send button looks enabled even when the form is empty', await ev(() => !$('[data-a="sendOtp"]').disabled));
  check('invite code starts empty and is marked optional', await page.inputValue('#iv') === '' && await has('رمز الدعوة (اختياري)'));
  await shot('51-signup');
  // an empty form: every required field says what is missing (the invite code is optional)
  await click('[data-a="sendOtp"]');
  check('empty submit shows six errors and stays on the form', await errCount() === 6 && await ev(() => UI.auth.step === 'phone' && UI.sheet.k === 'auth'), await errCount());
  check('error wording', await has('أدخل رقم جوال سعودي صحيح') && await has('أدخل اسمك') && await has('أدخل بريدًا إلكترونيًا صحيحًا') && await has('اختر تاريخ ميلادك') && await has('اختر الجنس') && await has('يجب الموافقة على الشروط والأحكام للمتابعة') && !(await has('رمز الدعوة غير صحيح')));
  check('first missing field (phone) gets the focus', await ev(() => !!document.activeElement && document.activeElement.id === 'ph'));
  await shot('51b-signup-errors');
  // fixing a field clears its own error straight away
  await page.fill('#ph', '0566000111');
  check('phone shows as 05x-xxx-xxxx and is kept as 9 digits', await page.inputValue('#ph') === '056-600-0111' && await ev(() => UI.f.phone === '566000111'));
  check('fixing the phone clears only its own error', await errCount() === 5 && !(await has('أدخل رقم جوال سعودي صحيح')) && await has('أدخل اسمك'));
  await page.fill('#ph', '966566000111');
  check('a number typed with 966 is normalised', await page.inputValue('#ph') === '056-600-0111' && await ev(() => UI.f.phone === '566000111'));
  await page.fill('#nm', 'خالد');
  await page.fill('#em', 'khaled@');
  await page.fill('#bd', '1990-12-25');
  await click('[data-a="gender"][data-v="m"]');
  check('gender pill is selected and its error is gone', await ev(() => UI.f.gender === 'm' && !!$('.gen button.on') && $('.gen button.on').dataset.v === 'm') && !(await has('اختر الجنس')));
  check('date of birth is kept and its label floats up', await ev(() => UI.f.birth === '1990-12-25' && $('#bd').closest('.fl').classList.contains('has')));
  await click('[data-a="sendOtp"]');
  check('bad email and missing terms are the only errors left', await errCount() === 2 && await has('أدخل بريدًا إلكترونيًا صحيحًا') && await has('يجب الموافقة على الشروط والأحكام للمتابعة'), await errCount());
  // the terms link opens the terms and comes back to the same form, nothing typed is lost
  await click('[data-a="showTerms"]');
  check('terms link opens the terms sheet', await page.locator('.sheet .sttl').innerText() === 'الشروط والأحكام' && await page.locator('[data-a="termsBack"]').count() === 1);
  await shot('51c-signup-terms');
  await click('[data-a="termsBack"]');
  check('back from the terms keeps everything typed', await page.locator('.sheet .sttl').innerText() === 'إنشاء حساب' && await page.inputValue('#nm') === 'خالد' && await page.inputValue('#em') === 'khaled@' && await page.inputValue('#bd') === '1990-12-25' && await page.inputValue('#ph') === '056-600-0111' && await ev(() => UI.f.gender === 'm' && UI.f.terms === false));
  await page.fill('#em', 'khaled@example.com');
  await page.fill('#iv', 'ab');
  await click('button.cb[data-k="terms"]');
  check('terms checkbox ticks and shows a check mark', await ev(() => UI.f.terms === true) && await page.locator('button.cb.on[data-k="terms"] svg').count() === 1);
  await click('span[data-a="tg"][data-k="mk"]');
  check('tapping the marketing text ticks its box', await ev(() => UI.f.mk === true) && await page.locator('button.cb.on[data-k="mk"]').count() === 1);
  await click('button.cb[data-k="mk"]');
  check('tapping the box again clears it (marketing is optional)', await ev(() => UI.f.mk === false) && await page.locator('button.cb.on[data-k="mk"]').count() === 0);
  await click('[data-a="sendOtp"]');
  check('a bad invite code is the only error', await errCount() === 1 && await has('رمز الدعوة غير صحيح'), await errCount());
  await page.fill('#iv', 'Friend7');
  await shot('51d-signup-filled');
  await click('[data-a="sendOtp"]');
  check('valid form goes to the security-code step', await ev(() => UI.auth.step === 'otp') && await has('قم بإدخال رمز الامان'));
  await page.click('[data-otp="0"]'); await page.keyboard.type('11111'); await wait(300);
  check('wrong code is rejected on the sign-up path too', await has('رمز الأمان غير صحيح') && await ev(() => !S.session));
  await page.click('[data-otp="0"]'); await page.keyboard.type('12345'); await wait(500);
  check('sign-up creates the account with every field, 100 pts, no orders', await ev(() => S.session === true && S.user.name === 'خالد' && S.user.phone === '566000111' && S.user.email === 'khaled@example.com' && S.user.birth === '1990-12-25' && S.user.gender === 'm' && S.user.invite === 'FRIEND7' && S.user.mk === false && S.pts === 100 && S.orders.length === 0), await ev(() => S.user));
  check('the form is cleared after sign-up', await ev(() => !UI.f.name && !UI.f.email && !UI.f.birth && !UI.f.gender && !UI.f.terms && !UI.f.invite));
  // deleting the account: for good, on the server
  await click('[data-a="sheet"][data-k="profile"]'); await click('[data-a="go"][data-p="myprofile"]');
  await click('[data-a="deleteAcct"]');
  check('deleting asks first and says it is for good', await has('حذف الحساب نهائيًا') && await has('لا يمكن التراجع'));
  await shot('51g-delete');
  await click('[data-a="dlgYes"]'); await wait(700);
  check('the account is gone from the phone', await ev(() => !S.session && !S.user && S.pts === 0) && await said('تم حذف حسابك'));
  const again = await (await fetch(BASE + '/api/my/login', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Dev': 'ab'.repeat(16) }, body: JSON.stringify({ phone: '566000111', code: '12345' }) })).json();
  check('and from the server: the number is new again', again.need === 'signup', again);

  // ---------- the sign-up form in English
  await ev(() => { try { localStorage.clear(); } catch (e) {} });
  await page.reload({ waitUntil: 'domcontentloaded' }); await wait(400);
  await ev(() => { S.lang = 'en'; applyLang(); save(); render(); });
  await click('[data-a="openAuth"][data-m="signup"]');
  check('English sign-up form wording', await ev(() => document.documentElement.dir === 'ltr') && await has('Create account') && await has('Enter your details to create an account') && await has('Name') && await has('Email') && await has('Invite code (optional)') && await has('Date of birth') && await has('Gender') && await has('Male') && await has('Female') && await has('terms and conditions') && await has('I agree to receive marketing notifications and offers') && await has('Send security code'));
  await shot('51e-signup-en');
  await click('[data-a="sendOtp"]');
  check('English error wording', await has('Enter a valid Saudi mobile number') && await has('Enter your name') && await has('Enter a valid email address') && await has('Choose your date of birth') && await has('Choose your gender') && await has('You need to agree to the terms and conditions to continue') && await errCount() === 6);
  await shot('51f-signup-en-errors');
  await ev(() => { S.lang = 'ar'; applyLang(); save(); UI.sheet = null; render(); });
  check('back to Arabic after the English check', await ev(() => document.documentElement.dir === 'rtl') && await has('تسجيل الدخول'));

  // ---------- guest
  await ev(() => { try { localStorage.clear(); } catch (e) {} });
  await page.reload({ waitUntil: 'domcontentloaded' }); await wait(400);
  await click('[data-a="guest"]');
  check('guest sees home with Guest name', await has('ضيف') && await has('مرحبا بك!'));
  await tab('orders');
  check('guest orders locked', await has('سجّل دخولك لعرض طلباتك'));
  await shot('52-guest-orders');
  await tab('home');
  await click('.loyal');
  check('guest can read the membership page and is asked to log in to collect points', await ev(() => UI.stack.length === 1 && UI.stack[0].p === 'member') && await has('سجّل دخولك لتبدأ بجمع النقاط') && await has('طريقة جمع النقاط') && await page.locator('.mpage [data-a="login"]').count() === 1);
  await click('[data-a="back"]');
  await click('.rb[data-p="points"]');
  check('guest points opens login sheet', await has('تسجيل الدخول مطلوب'));
  await shot('53-login-required');
  await click('.xbtn');
  await click('[data-a="toMenu"]'); await click('[data-a="product"][data-id="latte"]'); await click('[data-a="sadd"]');
  await click('.fab'); await click('[data-a="toCheckout"]'); await click('[data-a="placeOrder"]');
  check('guest placing order asks to log in', await has('يجب تسجيل الدخول لإتمام طلبك'));
  await click('[data-a="login"]');
  await page.fill('input[data-bind="f.phone"]', '577001122'); await click('[data-a="sendOtp"]');
  await page.click('[data-otp="0"]'); await page.keyboard.type('12345'); await wait(400);
  check('guest login with an unknown phone opens the sign-up form', await has('لا يوجد حساب بهذا الرقم') && await page.inputValue('#ph') === '057-700-1122');
  await fillSignup({ name: 'منى', email: 'muna@example.com', birth: '2000-01-15', gender: 'f' });
  await click('[data-a="sendOtp"]');
  check('after login the cart page opens with the cart kept', await ev(() => S.session && UI.stack.length === 1 && UI.stack[0].p === 'cart' && S.cart.length === 1));
  await shot('54-after-login-cart');

  // ---------- small phone
  await page.setViewportSize({ width: 360, height: 640 });
  await wait(300);
  await click('[data-a="back"]').catch(() => {});
  await shot('55-small-home');
  await ev(() => { localStorage.clear(); }); await page.reload({ waitUntil: 'domcontentloaded' }); await wait(400);
  await shot('56-small-intro');
  await click('[data-a="openAuth"][data-m="signup"]');
  check('small phone: sign-up form scrolls inside the sheet and fits the width', await ev(() => { const b = $('.sheet .sbody'), s = $('.sheet').getBoundingClientRect(); return b.scrollHeight > b.clientHeight && getComputedStyle(b).overflowY === 'auto' && document.documentElement.scrollWidth <= innerWidth && s.left >= 0 && s.right <= innerWidth + 1 && s.top >= 0; }));
  await ev(() => { $('.sheet .sbody').scrollTop = 99999; }); await wait(200);
  check('small phone: the send button can be reached by scrolling', await ev(() => { const r = $('[data-a="sendOtp"]').getBoundingClientRect(); return r.bottom <= innerHeight + 1 && r.top >= 0; }));
  await shot('57-small-signup');

  // 0.6: a delivery on its way shows the driver on a small map (the position comes from the server with every sync)
  check('map: a delivery on its way shows the driver and the address on the map', await ev(() => {
    const o = {id:'trk1', no:'#9999', ts:Date.now(), mode:'delivery', branch:'b1', st:2, at:[Date.now()], items:[], sub:0, ship:0, disc:0, total:0, vat:0, earn:0, payM:'card', code:'1234',
      addr:{city:'المدينة', street:'قباء', lat:24.4672, lng:39.6111}, driver:{name:'سالم'}, fin:false, rej:null};
    UI.sheet = null; S.session = true; S.user = S.user || {name:'منى', phone:'544044995'};   /* the page above was left on the sign-up form */
    S.orders.unshift(o); TRK = {trk1:{lat:24.47, lng:39.6, ts:Date.now() + (SRV.skew || 0)}};
    setStack([{p:'order', id:'trk1'}]); render();
    const m = document.querySelector('.trk .osm'), tiles = m ? [...m.querySelectorAll('img.mt')] : [];
    return !!m && tiles.length >= 2 && tiles.every(i => /^https:\/\/tile\.openstreetmap\.org\/\d+\/\d+\/\d+\.png$/.test(i.src) && i.referrerPolicy === 'strict-origin-when-cross-origin')
      && m.querySelectorAll('.mp.drv').length === 1 && m.querySelectorAll('.mp.dst').length === 1 && m.innerText.includes('OpenStreetMap') && document.querySelector('.trk-l').innerText.includes('الآن');
  }));
  await shot('60-driver-map');
  check('map: without a position yet it says the map will show', await ev(() => { TRK = {}; render(); return !document.querySelector('.osm') && document.querySelector('.trk-w').innerText.includes('في الطريق'); }));
  check('map: none once delivered', await ev(() => { const o = S.orders.find(x => x.id === 'trk1'); o.st = 3; o.fin = true; TRK = {trk1:{lat:24.47, lng:39.6, ts:Date.now()}}; render(); const ok = !document.querySelector('.trk'); S.orders = S.orders.filter(x => x.id !== 'trk1'); TRK = {}; setStack([]); render(); return ok; }));
  // ---------- the maps with two fingers (a touch phone): pinch out zooms in, pinch in zooms out, one finger moves
  {
    const tctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true });
    const tp = await tctx.newPage();
    tp.on('pageerror', e => errors.push('touch page: ' + e.message));
    await tp.route('**/*', r => r.request().url().startsWith(BASE + '/') ? r.continue() : r.abort());
    await tp.goto(BASE + '/'); await wait(700);
    await tp.evaluate(() => { S.guest = true; UI.tab = 'branches'; render(); }); await wait(300);
    const cdp = await tctx.newCDPSession(tp), touch = (type, touchPoints) => cdp.send('Input.dispatchTouchEvent', { type, touchPoints });
    const pinch = async (d0, d1) => { await touch('touchStart', [{ x: 195 - d0, y: 220, id: 1 }, { x: 195 + d0, y: 220, id: 2 }]); for (let k = 1; k <= 8; k++) { const d = d0 + (d1 - d0) * k / 8; await touch('touchMove', [{ x: 195 - d, y: 220, id: 1 }, { x: 195 + d, y: 220, id: 2 }]); } await touch('touchEnd', []); await wait(250); };
    const z0 = await tp.evaluate(() => MAPS.br.z);
    await pinch(50, 100);
    check('two fingers apart zoom the map in', await tp.evaluate(z => MAPS.br.z === z + 1, z0));
    await pinch(100, 25);
    check('two fingers together zoom it out', await tp.evaluate(z => MAPS.br.z === z - 1, z0));
    const lng0 = await tp.evaluate(() => MAPS.br.lng);
    await touch('touchStart', [{ x: 200, y: 220, id: 1 }]); for (let k = 1; k <= 6; k++) await touch('touchMove', [{ x: 200 - 12 * k, y: 220, id: 1 }]); await touch('touchEnd', []); await wait(200);
    check('one finger still moves it', await tp.evaluate(l => MAPS.br.lng > l, lng0));
    await tctx.close();
  }

  check('no page errors', errors.length === 0, errors);
  const failed = results.filter(r => !r.ok);
  console.log(`\n${results.length - failed.length}/${results.length} passed`);
  if (failed.length) console.log('FAILED:\n' + failed.map(f => ' - ' + f.name).join('\n'));
  await browser.close();
  process.exit(failed.length ? 1 : 0);
})().catch(e => { console.error('TEST CRASH', e); process.exit(2); });
