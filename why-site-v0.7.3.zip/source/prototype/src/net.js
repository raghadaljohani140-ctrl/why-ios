/* Net: the connection to the server.
   SRV is this page's copy of what the server last said:
   the customer page gets the public part (branch pauses, banners, codes, fees),
   a staff page gets everything its role may see (orders, drivers, customers, week...).
   Every page also gets the menu (categories, products, photos) with its revision crev, and only when that changed. */

const API = '/api';
const SRV = {srev:-1, crev:-1, menu:{}, br:{}, bn:{}, codes:{}, ship:SHIP_FEE, delivery:{on:true, fee:DELIVERY_FEE}, tiers:TIERS.map(t => Object.assign({}, t)), tdays:TIER_DAYS,
  orders:[], rev:-1, today:'', now:0, skew:0, me:null, drivers:[], cust:[], week:[], avail:[], mine:[], done:[]};
const sleep = ms => new Promise(r => setTimeout(r, ms));

class ApiErr extends Error {
  constructor(status, code, body) { super(code); this.status = status; this.code = code; this.body = body || {}; }
}

/* one call to the server. GET when there is no body. Throws ApiErr: status 0 = no connection. */
async function api(path, body, opt) {
  opt = opt || {};
  const ctl = opt.ctl || new AbortController();
  const timer = setTimeout(() => ctl.abort(), opt.timeout || 15000);
  const headers = {'Content-Type':'application/json'};
  if (APP === 'cust') headers['X-Dev'] = S.dev;
  let r, j = null;
  try {
    r = await fetch(API + path, {method:body === undefined ? 'GET' : 'POST', headers, body:body === undefined ? undefined : JSON.stringify(body), credentials:'same-origin', cache:'no-store', signal:ctl.signal});
    try { j = await r.json(); } catch (e) { j = null; }
  } catch (e) {
    throw new ApiErr(0, 'net');
  } finally {
    clearTimeout(timer);
  }
  if (!r.ok) throw new ApiErr(r.status, (j && j.error) || (r.status >= 500 ? 'server' : 'bad_response'), j);
  if (!j) throw new ApiErr(r.status, 'bad_response');
  return j;
}

/* what the person reads when a call fails */
const ERR = {
  net:['تعذّر الاتصال، تأكد من الإنترنت وحاول مرة أخرى', 'No connection. Check your internet and try again'],
  server:['حدث خطأ في الخادم، حاول بعد قليل', 'Server error. Try again in a moment'],
  bad_response:['وصلت استجابة غير متوقعة، حاول مرة أخرى', 'Unexpected reply. Try again'],
  paused:['الفرع متوقف عن استقبال الطلبات حاليًا، إختر فرعًا آخر', 'This branch is not taking orders right now. Pick another one'],
  bad_reward:['تأكد من النقاط، ومن المنتج أو مبلغ الرصيد (من 1 إلى 1000)', 'Check the points, and the product or the credit (1 to 1000)'],
  bad_banner:['اختر وجهة الإعلان، ولإعلان جديد أضف صورة أو عنوانًا', 'Choose where the banner leads; a new banner needs a picture or a title'],
  bad_tiers:['كل مستوى أعلى يحتاج نقاطًا أكثر ويعطي نقاطًا مثل الذي قبله أو أكثر، والأساسية تبدأ من صفر', 'Each higher tier needs more points and gives at least as many points as the one below; basic starts at zero'],
  bad_gift:['اكتب رقم جوال المستلم الصحيح', 'Enter the recipient’s correct mobile number'],
  bad_otp:['رمز الأمان غير صحيح، حاول مرة أخرى', 'Wrong security code, try again'],
  bad_phone:['أدخل رقم جوال سعودي صحيح (05XXXXXXXX)', 'Enter a valid Saudi mobile number (05XXXXXXXX)'],
  no_points:['نقاطك لا تكفي', 'Not enough points'],
  no_balance:['رصيد محفظتك لا يكفي، تم تحديثه', 'Your wallet balance is not enough. It was refreshed'],
  gift_used:['هذه الهدية مستخدمة أو لم تعد متاحة', 'This gift was used or is no longer available'],
  bad_amount:['اكتب مبلغًا من 10 إلى 1000 ريال', 'Enter an amount from 10 to 1000 SAR'],
  open_orders:['لديك طلب قيد التنفيذ، يمكنك حذف الحساب بعد اكتماله', 'You have an order in progress. You can delete the account once it is done'],
  bad_pick:['اختر وقت استلام آخر خلال ساعات عمل الفرع', 'Pick another pickup time within the branch hours'],
  bad_rate:['اختر عدد النجوم', 'Choose the number of stars'],
  rated:['قيّمت هذا الطلب من قبل', 'You already rated this order'],
  push_denied:['الإشعارات مرفوضة لهذا الموقع، فعّلها من إعدادات المتصفح', 'Notifications are blocked for this site. Allow them in the browser settings'],
  push_later:['لم تُفعّل الإشعارات', 'Notifications were not enabled'],
  bad_push:['هذا المتصفح لا يدعم الإشعارات', 'This browser cannot get notifications'],
  not_here:['أحد الأصناف غير متوفر في هذا الفرع، غيّر الفرع أو عدّل السلة', 'An item is not available at this branch. Change the branch or the cart'],
  below_min:['قيمة الطلب أقل من الحد الأدنى للتوصيل', 'The order is below the smallest delivery order'],
  too_far:['الموقع خارج نطاق التوصيل لهذا الفرع', 'The spot is outside this branch’s delivery area'],
  need_pin:['حدّد موقع التوصيل على الخريطة', 'Set the delivery spot on the map'],
  not_yours:['هذا لفرع آخر', 'This belongs to another branch'],
  exists:['يوجد حساب لهذا الفرع، غيّر رمزه بدل إضافة حساب جديد', 'This branch has an account already; change its code instead'],
  bad_km:['اكتب مسافة من 0 إلى 100 كم (0 = بدون حد)', 'Enter a distance from 0 to 100 km (0 = no limit)'],
  bad_branch:['اختر فرعًا صحيحًا', 'Choose a valid branch'],
  bad_vat:['الرقم الضريبي 15 رقمًا يبدأ وينتهي بـ 3', 'The VAT number is 15 digits starting and ending with 3'],
  bad_cr:['رقم السجل التجاري 10 أرقام', 'The commercial registration is 10 digits'],
  bad_news:['اكتب عنوان الخبر (حرفان على الأقل)', 'Write the news title (two letters at least)'],
  bad_range:['اختر فترة صحيحة: البداية قبل النهاية، وسنة على الأكثر', 'Choose a valid period: the start first, one year at most'],
  delivery_off:['التوصيل متوقف مؤقتًا', 'Delivery is paused for now'],
  stock:['أحد الأصناف لم يعد متوفرًا، عدّل السلة', 'An item is no longer available. Update your cart'],
  price_changed:['تغيّرت الأسعار، راجع الطلب ثم أكّده مرة أخرى', 'Prices changed. Review your order and confirm again'],
  bad_code:['كود الخصم غير صالح', 'This discount code is not valid'],
  slow_down:['محاولات كثيرة، انتظر قليلًا ثم حاول مرة أخرى', 'Too many attempts. Wait a moment and try again'],
  too_many_open:['لديك طلبات كثيرة قيد التنفيذ، انتظر اكتمال بعضها', 'You have too many open orders. Wait for some to finish'],
  bad_address:['أكمل العنوان: المدينة والحي والشارع', 'Complete the address: city, district and street'],
  bad_customer:['سجّل الدخول ثم أعد المحاولة', 'Sign in and try again'],
  locked:['تم إيقاف المحاولات مؤقتًا، حاول لاحقًا', 'Too many attempts. Try again later'],
  bad_login:['الاسم أو الرمز غير صحيح', 'Wrong name or PIN'],
  auth:['انتهت الجلسة، سجّل الدخول من جديد', 'Your session ended. Sign in again'],
  bad_state:['تغيّرت حالة الطلب، تم تحديث الشاشة', 'The order changed. The screen was refreshed'],
  taken:['سبقك مندوب آخر إلى هذا الطلب', 'Another driver took this order first'],
  too_many:['لديك 5 طلبات نشطة، أنهِ واحدًا أولًا', 'You already have 5 active orders. Finish one first'],
  wrong_code:['الرمز غير صحيح', 'Wrong code'],
  bad_pin:['الرمز السري من 6 إلى 10 أرقام', 'The PIN must be 6 to 10 digits'],
  bad_pin_confirm:['الرمز السري للإدارة غير صحيح', 'The admin PIN is wrong'],
  exists:['الاسم مستخدم من قبل', 'This name is already used'],
  busy:['لا يمكن حذف المندوب: معه طلب لم يُسلَّم بعد', 'Cannot remove him: he still has an undelivered order'],
  last_banner:['يجب أن يبقى إعلان واحد على الأقل', 'At least one banner must stay on'],
  bad_price:['السعر غير صحيح', 'Invalid price'],
  bad_pct:['نسبة الخصم من 1 إلى 90', 'The discount must be between 1 and 90'],
  bad_fee:['الرسوم غير صحيحة', 'Invalid fee'],
  not_found:['العنصر غير موجود، تم تحديث الشاشة', 'Not found. The screen was refreshed'],
  duplicate:['تم إرسال هذا الطلب من قبل', 'This order was already sent'],
  bad_name:['اكتب الاسم بالعربي (حرفان على الأقل)', 'Type the Arabic name (two letters at least)'],
  bad_cat:['اختر قسمًا موجودًا', 'Pick a category that exists'],
  mixed_kinds:['لا يجتمع في منتج واحد قسم يُحضَّر في الفرع وقسم يُشحن', 'One product cannot be in a branch category and a shipped one'],
  bad_opts:['أحد الخيارات غير معروف، أعد فتح المنتج', 'An option is unknown. Open the product again'],
  bad_img:['تعذّر استخدام هذه الصورة، جرّب صورة أخرى (JPG أو PNG)', 'This photo cannot be used. Try another one (JPG or PNG)'],
  too_big:['الصورة كبيرة جدًا، جرّب صورة أصغر', 'The photo is too large. Try a smaller one'],
  bad_kind:['اختر نوع القسم', 'Choose the kind of category'],
  cat_not_empty:['في هذا القسم منتجات: انقلها إلى قسم آخر أو احذفها أولًا', 'This category has products. Move them or delete them first'],
  last_cat:['يجب أن يبقى قسم واحد على الأقل', 'At least one category must stay'],
  bad_op:['تعذّر تنفيذ العملية، حدّث الصفحة', 'Could not do that. Reload the page'],
  bad_request:['تحقق من البيانات المدخلة', 'Check what you typed'],
  bad_hours:['أوقات العمل غير صحيحة', 'The working hours are not right'],
  bad_location:['الموقع غير صحيح', 'The location is not right'],
  last_branch:['يجب أن يبقى فرع واحد على الأقل', 'At least one branch must stay'],
  branch_busy:['في هذا الفرع طلبات لم تكتمل بعد: أكملها أو ارفضها أولًا', 'This branch has unfinished orders: finish or reject them first'],
  bad_branch:['هذا الفرع لم يعد موجودًا، اختر فرعًا آخر', 'This branch no longer exists. Pick another one'],
  bad_link:['الصق رابط الموقع من خرائط جوجل، أو الإحداثيات مثل 24.4672, 39.6111', 'Paste the Google Maps link of the place, or coordinates like 24.4672, 39.6111'],
  no_location:['لم نجد الموقع في هذا الرابط. افتح المكان في خرائط جوجل وانسخ الإحداثيات', 'No location in this link. Open the place in Google Maps and copy its coordinates'],
  link_unreachable:['تعذّر فتح الرابط الآن، جرّب بعد قليل أو استخدم موقعك الحالي', 'The link could not be opened now. Try again soon or use your current location']
};
function errText(e) {
  const c = e && e.code, m = ERR[c];
  let t = m ? T(m[0], m[1]) : T('تعذّر تنفيذ العملية، حاول مرة أخرى', 'Could not complete this. Try again');
  if (c === 'wrong_code' && e.body) {
    if (e.body.left === 0) return T('الرمز غير صحيح، تم إيقاف المحاولات لمدة 3 دقائق', 'Wrong code. Tries are paused for 3 minutes');
    if (e.body.left > 0) return t + T(` (المتبقي ${e.body.left})`, ` (${e.body.left} left)`);
  }
  const w = e && e.body && e.body.retry;
  if (w && (c === 'locked' || c === 'slow_down' || c === 'wrong_code')) {
    const mn = Math.max(1, Math.ceil(w / 60));
    t += w > 60 ? T(` (بعد ${mn} دقيقة)`, ` (in ${mn} min)`) : T(` (بعد ${w} ثانية)`, ` (in ${w} s)`);
  }
  return t;
}

/* ---------- the menu: the server keeps it, the admin edits it, every page takes it from there ----------
   CATS and PRODUCTS are what the page shows (deleted ones left out). CAT and PROD know every one, deleted ones too,
   so an old order can still name what it held. The first menu in data.js is only what shows before the first answer. */
function applyCatalog(c, quiet) {
  if (!c || !Array.isArray(c.cats) || !Array.isArray(c.products) || !c.cats.some(x => !x.gone)) return false;
  CATS.length = 0; c.cats.forEach(x => { if (!x.gone) CATS.push(x); });
  Object.keys(CAT).forEach(k => delete CAT[k]); c.cats.forEach(x => { CAT[x.id] = x; });
  PRODUCTS.length = 0; c.products.forEach(p => { if (!p.gone) PRODUCTS.push(p); });
  Object.keys(PROD).forEach(k => delete PROD[k]); c.products.forEach(p => { PROD[p.id] = p; });
  if (Array.isArray(c.branches) && c.branches.some(b => !b.gone)) {   /* a copy saved by 0.4.0 has no branches: the page keeps its own */
    BRANCHES.length = 0; c.branches.forEach(b => { if (!b.gone) BRANCHES.push(b); });
    Object.keys(BR).forEach(k => delete BR[k]); c.branches.forEach(b => { BR[b.id] = b; });
  }
  SRV.crev = c.crev;
  if (typeof afterCatalog === 'function') afterCatalog(quiet);   /* each app tidies what pointed at the old menu */
  return true;
}
/* the category the menu shows: the one picked, or the first that has something in it */
const catHas = id => PRODUCTS.some(p => (p.cats || [p.cat]).includes(id));
function curCat(key, all) {
  const list = all ? CATS : CATS.filter(c => catHas(c.id));
  const ok = list.some(c => c.id === key);
  return ok ? key : ((list[0] || CATS[0] || {}).id || '');
}
/* a banner as the page shows it: one of the first set keeps the page's own picture and words unless the admin changed them */
function bnView(b) {
  const base = BANNERS.find(x => x.id === b.id) || {bg:'linear-gradient(135deg,#1A1A1A,#3A3A3A)', t:{ar:'', en:''}, s:{ar:'', en:''}, a:'menu'};
  const pick = k => b[k] && (b[k].ar || b[k].en) ? b[k] : base[k];
  return Object.assign({}, base, {id:b.id, t:pick('t'), s:pick('s'), a:b.a || base.a, img:b.img || null});
}
const bannersAll = () => SRV.banners ? SRV.banners.map(bnView) : BANNERS;
/* news: the admin's list (server). The first ones keep the app's words, colour and picture until the admin changes them;
   a text is paragraphs, one per line. A text missing in English shows the Arabic one. */
const paras = s => String(s || '').split(/\n+/).map(x => x.trim()).filter(Boolean);
function nwView(x) {
  const base = NEWS.find(n => n.id === x.id), has = o => o && (o.ar || o.en);
  const t = has(x.t) ? x.t : base ? base.t : {ar:'', en:''};
  let b = base ? base.b : {ar:[], en:[]};
  if (has(x.b)) { const ar = paras(x.b.ar), en = paras(x.b.en); b = {ar:ar.length ? ar : en, en:en.length ? en : ar}; }
  return {id:x.id, t, b, img:x.img || null, ts:x.ts || (base ? Date.parse(base.ts) : 0), bg:base ? base.bg : 'linear-gradient(135deg,#0F0F0F,#ECB444)', on:x.on !== false, builtin:!!base};
}
const newsAll = () => SRV.news ? SRV.news.map(nwView) : NEWS.map(n => nwView({id:n.id}));
const newsLive = () => newsAll().filter(n => n.on);
const bannersLive = () => { const all = bannersAll(), l = all.filter(b => SRV.bn[b.id] !== false); return l.length ? l : all; };
/* rewards: the admin's list (server); a reward that left the list leaves the cart too */
function applyRewards(list) {
  if (!Array.isArray(list)) return false;
  const ok = list.filter(r => r && r.id && Number.isInteger(r.pts) && (r.pid || r.credit));
  REWARDS.splice(0, REWARDS.length, ...ok);
  if (APP === 'cust') { const n = S.cart.length; S.cart = S.cart.filter(c => !c.rw || RW(c.rw)); if (S.cart.length < n) save(); }
  return true;
}
let TRK = {};   /* order id -> where its driver was a moment ago (only while the order is on its way) */
const bPaused = id => !!(SRV.br[id] && SRV.br[id].pause);

/* the public part: what every customer needs to know before ordering */
function applyPub(p) {
  SRV.srev = p.srev; SRV.br = p.br || {}; SRV.bn = p.bn || {}; SRV.codes = p.codes || {};
  SRV.ship = p.ship; SRV.delivery = Object.assign({on:true, fee:DELIVERY_FEE}, p.delivery || {});
  if (tiersOk(p.tiers)) SRV.tiers = p.tiers;
  applyRewards(p.rewards);
  if (Array.isArray(p.banners) && p.banners.length) SRV.banners = p.banners;
  if (Array.isArray(p.news)) SRV.news = p.news;   /* the customer gets only the news that are on */
  if (p.tdays > 0) SRV.tdays = p.tdays;
  if (UI.bn >= bannersLive().length) UI.bn = 0;
}
if (APP === 'cust' && S.pub) applyPub(S.pub);
if (APP === 'cust' && S.cat) applyCatalog(S.cat, true);   /* the menu this phone saw last: shown at once, checked with the server next */

/* ---------- the customer page: ask the server now and then ---------- */
const hasOpen = () => S.orders.some(o => !o.fin && !o.rej);
let syncBusy = false, syncAgain = false, syncTimer = 0, syncFails = 0;
function syncSoon(ms) { clearTimeout(syncTimer); syncTimer = setTimeout(custSync, ms); }
const syncDelay = () => syncFails ? Math.min(60000, 4000 * 2 ** Math.min(syncFails, 4)) : (hasOpen() ? 4000 : (S.session ? 20000 : 45000));

/* the customer's orders from the server (a phone that has just signed in): they replace what this phone had */
function mergeHistory(list) {
  if (!Array.isArray(list)) return false;
  const have = new Map(S.orders.map(o => [o.id, o]));
  list.forEach(o => { o.driver = o.driver || null; have.set(o.id, o); });
  S.orders = Array.from(have.values()).sort((a, b) => b.ts - a.ts).slice(0, 80);
  return true;
}
/* what the server says about one of my orders */
function mergeStatus(s) {
  const o = S.orders.find(x => x.id === s.id); if (!o) return false;
  let ch = false;
  if (s.rate && !o.rate) { o.rate = s.rate; ch = true; }
  if (s.rej && !o.rej) { rejectOrder(o, s.rej); ch = true; }
  if (!o.rej && s.st > o.st) { advance(o, s.st); ch = true; }
  if (s.at && s.at.length && s.at.length !== (o.at || []).length) { o.at = s.at.slice(); ch = true; }
  const dn = s.driver || null;
  if (((o.driver && o.driver.name) || null) !== dn) {
    o.driver = dn ? {name:dn} : null; ch = true;
    if (dn && o.mode === 'delivery' && !o.fin && !o.rej && s.st === 2) notifyDriver(o);
  }
  if (s.fin && !o.fin) { o.fin = true; o.done = true; ch = true; }
  return ch;
}
function takeBonus(r, sent) {
  S.ack = S.ack.filter(i => !sent.includes(i));
  let ch = false;
  (r.bonus || []).forEach(b => {
    if (!S.seen.includes(b.id)) {
      S.seen.push(b.id); if (S.seen.length > 300) S.seen.splice(0, S.seen.length - 300);
      if (legacyAcct()) addPts(b.pts, {ar:'نقاط هدية من واي', en:'Bonus points from Why'}, 'bonus');   /* otherwise already in the account */
      note({ar:'وصلتك نقاط هدية', en:'You received bonus points'}, {ar:`أضفنا ${b.pts} نقطة إلى رصيدك.`, en:`We added ${b.pts} points to your balance.`}, 'star');
      toast(T(`وصلتك ${b.pts} نقطة هدية`, `You received ${b.pts} bonus points`)); ch = true;
    }
    if (!S.ack.includes(b.id)) S.ack.push(b.id);
  });
  return ch;
}
async function custSync() {
  clearTimeout(syncTimer); syncTimer = 0;
  if (document.hidden) return;   /* the page asks again the moment it is visible */
  if (syncBusy) { syncAgain = true; return; }
  syncBusy = true;
  try {
    const body = {since:S.since, srev:SRV.srev, crev:SRV.crev, ack:S.ack.slice(0, 50)};
    if (S.user && S.session) {
      body.name = S.user.name; body.phone = S.user.phone; body.arev = S.arev;
      if (legacyAcct()) body.legacy = legacyBody();   /* once: what this phone counted becomes the account's opening balance */
      ['email', 'birth', 'gender', 'invite', 'mk'].forEach(k => { if (S.user[k] !== undefined && S.user[k] !== '') body[k] = S.user[k]; });
    }
    const r = await api('/my/sync', body, {timeout:12000});
    syncFails = 0;
    if (r.gone && S.session) { pushUnsubscribe(); signedOut(T('حُذف هذا الحساب من جهاز آخر', 'This account was deleted on another device')); return; }
    let ch = false;
    if (r.pub) { S.pub = r.pub; applyPub(r.pub); ch = true; }
    if (r.cat && applyCatalog(r.cat)) { S.cat = r.cat; ch = true; }
    if (r.acct && applyAcct(r.acct)) ch = true;   /* first: a turned-down order is then given back by the server, not twice */
    if (r.history && mergeHistory(r.history)) ch = true;
    (r.orders || []).forEach(s => { if (mergeStatus(s)) ch = true; });
    if (takeBonus(r, body.ack)) ch = true;
    if (r.now) SRV.skew = r.now - Date.now();
    const trk = r.track || {};
    if (JSON.stringify(trk) !== JSON.stringify(TRK)) { TRK = trk; ch = true; }
    if (r.tier && r.tier.id && (!S.tier || S.tier.id !== r.tier.id || S.tier.pts !== r.tier.pts)) { S.tier = {id:r.tier.id, pts:Number(r.tier.pts) || 0}; ch = true; }
    S.since = r.rev;
    save();
    if (ch) UI.dirty = true;
  } catch (e) {
    syncFails++;
  } finally {
    syncBusy = false;
    syncSoon(syncAgain ? 200 : syncDelay());
    syncAgain = false;
  }
}

/* ---------- a staff page: the server pushes changes (long poll) ---------- */
let pollCtl = null, pollGen = 0;
function stopPoll() { pollGen++; if (pollCtl) pollCtl.abort(); }
function startPoll() {
  stopPoll();
  const gen = pollGen;
  (async () => {
    let fails = 0, quick = true;   /* the first ask after a start or a failure is a quick one: it shows at once if the line works */
    while (gen === pollGen) {
      const t0 = Date.now(), wait = quick ? 0 : 25;
      quick = false;
      pollCtl = new AbortController();
      try {
        const r = await api(`/${APP}/state?rev=${SRV.rev}&crev=${SRV.crev}&wait=${wait}`, undefined, {timeout:wait ? 40000 : 15000, ctl:pollCtl});
        if (gen !== pollGen) return;
        fails = 0;
        if (UI.offline) { UI.offline = false; UI.dirty = true; }
        if (r.same) { if (wait && Date.now() - t0 < 2000) await sleep(2500); }
        else onState(r);
      } catch (e) {
        if (gen !== pollGen) return;
        if (e.status === 401) { SRV.rev = -1; onSignedOut(); return; }
        fails++; quick = true;
        if (!UI.offline) { UI.offline = true; UI.dirty = true; }
        await sleep(Math.min(15000, 1500 * 2 ** Math.min(fails, 4)));
      }
    }
  })();
}
function onState(r) {
  const first = SRV.rev < 0;
  r.skew = r.now ? r.now - Date.now() : 0;
  if (UI.mode !== 'main') { UI.mode = 'main'; keepAwake(); if (APP === 'recv' || APP === 'driver') pushRefresh(`/${APP}/push`); }
  const oldNew = new Set(SRV.orders.filter(o => o.st === 0 && !o.rej).map(o => o.id));
  const oldAvail = new Set((SRV.avail || []).map(o => o.id));
  const cat = r.cat; delete r.cat; delete r.crev;   /* the menu's revision changes only with the menu itself */
  Object.assign(SRV, r);
  if (r.rewards) applyRewards(r.rewards);
  if (cat) applyCatalog(cat, first);
  if (!first && S.sound) {
    if (APP === 'recv' && SRV.orders.some(o => o.st === 0 && !o.rej && !oldNew.has(o.id))) beep();
    if (APP === 'driver' && SRV.avail.some(o => !oldAvail.has(o.id))) beep();
  }
  UI.dirty = true;
}

/* ---------- notifications on the phone, even with the page closed (0.7, Web Push) ----------
   The push carries nothing; the service worker (/sw.js) asks the server what to say. The worker is made when the page
   opens, so a tap on "enable" can ask for the permission and subscribe at once (iPhones want both inside the tap).
   On an iPhone this works only from the app added to the Home Screen. */
let SWREG = null, PUSHKEY = '';
const pushOK = () => 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window && window.isSecureContext;
const isIOS = () => /iP(hone|ad|od)/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
const standalone = () => (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || navigator.standalone === true;
/* on: this device gets them · off: it can · denied: the browser was told no · ios: add it to the Home Screen first · no: this browser cannot */
const pushState = () => !pushOK() ? (isIOS() && !standalone() && !window.WHY_APP ? 'ios' : 'no')   /* WHY_APP: inside the iPhone app (no web push there) */ : Notification.permission === 'denied' ? 'denied' : (S.push && Notification.permission === 'granted') ? 'on' : 'off';
const b64Bytes = s => { s = s.replace(/-/g, '+').replace(/_/g, '/'); const r = atob(s + '='.repeat((4 - s.length % 4) % 4)); return Uint8Array.from(r, c => c.charCodeAt(0)); };
function pushInit(path) {
  if (!pushOK()) return;
  navigator.serviceWorker.register('/sw.js', {scope:'/'}).then(r => { SWREG = r; if (path) pushRefresh(path); }).catch(() => {});
  api('/push/key').then(r => { PUSHKEY = r.key; }).catch(() => {});
}
async function pushSubscribe(path) {
  const perm = await Notification.requestPermission();   /* first thing, inside the tap */
  if (perm !== 'granted') { UI.dirty = true; throw new ApiErr(0, perm === 'denied' ? 'push_denied' : 'push_later'); }
  const reg = SWREG || await navigator.serviceWorker.ready;
  if (!PUSHKEY) PUSHKEY = (await api('/push/key')).key;
  const sub = (await reg.pushManager.getSubscription()) || await reg.pushManager.subscribe({userVisibleOnly:true, applicationServerKey:b64Bytes(PUSHKEY)});
  await api(path, {endpoint:sub.endpoint, lang:S.lang});
  S.push = true; save();
}
async function pushUnsubscribe() {
  S.push = false; save();
  try {
    const reg = SWREG || (navigator.serviceWorker && await navigator.serviceWorker.getRegistration('/'));
    const sub = reg && await reg.pushManager.getSubscription();
    if (sub) { await api('/push/off', {endpoint:sub.endpoint}).catch(() => {}); await sub.unsubscribe(); }
  } catch (e) {}
}
/* the push service may change the address: the server hears it again each time the page opens */
async function pushRefresh(path) {
  if (!S.push || !pushOK() || Notification.permission !== 'granted') return;
  try {
    const reg = SWREG || await navigator.serviceWorker.getRegistration('/');
    const sub = reg && await reg.pushManager.getSubscription();
    if (sub) await api(path, {endpoint:sub.endpoint, lang:S.lang}); else { S.push = false; save(); UI.dirty = true; }
  } catch (e) {}
}

/* never rebuild the screen while the person is typing: wait for the next beat */
setInterval(() => {
  if (!UI.dirty || UI.mapDrag) return;   /* nor while a finger moves a map */
  const ae = document.activeElement;
  if (ae && /^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName)) return;
  UI.dirty = false; render();
}, 500);
document.addEventListener('visibilitychange', () => {
  if (document.hidden) return;
  if (APP === 'cust') custSync(); else if (UI.mode !== 'login') startPoll();
});
window.addEventListener('online', () => { if (APP === 'cust') custSync(); else if (UI.mode !== 'login') startPoll(); });
/* the phone says the line is gone: show it at once instead of waiting for a request to fail */
window.addEventListener('offline', () => { if (APP !== 'cust' && UI.mode !== 'login') { UI.offline = true; UI.dirty = true; } });
