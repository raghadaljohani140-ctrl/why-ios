/* Why! service worker: notifications only. It keeps no pages and touches no request of the pages.
   A push carries nothing: the worker asks the server what to say (/api/push/inbox, with its own subscription address),
   shows it, and a tap opens the page the message is about. */
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));

self.addEventListener('push', e => {
  e.waitUntil((async () => {
    let items = [];
    try {
      const sub = await self.registration.pushManager.getSubscription();
      if (sub) {
        const r = await fetch('/api/push/inbox', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({endpoint:sub.endpoint}), cache:'no-store', credentials:'omit'});
        if (r.ok) items = (await r.json()).items || [];
      }
    } catch (err) { /* no line: the general words below */ }
    if (!items.length) items = [{t:'Why!', b:'لديك تحديث جديد في التطبيق', url:'/', tag:'why', lang:'ar'}];   /* a push must always show something */
    const icon = new URL('/icon-192.png', self.location.origin).href;
    for (const m of items.slice(-3)) {
      await self.registration.showNotification(m.t, {body:m.b, tag:m.tag || undefined, data:{url:m.url || '/'}, icon, badge:icon, lang:m.lang || 'ar', dir:m.lang === 'en' ? 'ltr' : 'rtl'});
    }
  })());
});

self.addEventListener('notificationclick', e => {
  e.notification.close();
  const url = new URL((e.notification.data && e.notification.data.url) || '/', self.location.origin);
  e.waitUntil((async () => {
    const wins = await self.clients.matchAll({type:'window', includeUncontrolled:true});
    for (const w of wins) {
      if (new URL(w.url).pathname === url.pathname && 'focus' in w) return w.focus();
    }
    return self.clients.openWindow(url.href);
  })());
});
